import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from forward import forward

DIM = 10
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def gradient(x, h=1e-4):
    g = np.zeros(DIM)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = h
        g[i] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def find_kinks(p, d, T=8.0, n=200, tol=1e-9):
    def g(t):
        return f(p + t * d)

    h = 1e-6
    kinks = []

    def slope_at(t):
        return (g(t + h) - g(t - h)) / (2 * h)

    def recurse(a, b, sa, sb):
        if abs(sa - sb) < tol:
            return
        if b - a < 1e-5:
            fa, fb = g(a), g(b)
            t_star = (fb - fa + sa * a - sb * b) / (sa - sb)
            if a - 1e-6 <= t_star <= b + 1e-6:
                kinks.append(t_star)
            return
        m = 0.5 * (a + b)
        sm = slope_at(m)
        recurse(a, m, sa, sm)
        recurse(m, b, sm, sb)

    ts = np.linspace(-T, T, n + 1) + rng.uniform(-1e-3, 1e-3)
    ss = [slope_at(t) for t in ts]
    for i in range(n):
        recurse(ts[i], ts[i + 1], ss[i], ss[i + 1])
    out = []
    for k in sorted(kinks):
        if out and abs(k - out[-1]) < 1e-4:
            continue
        out.append(k)
    return out


def steal(num_lines=30):
    rows = []
    for _ in range(num_lines):
        p = rng.normal(size=DIM) * 0.5
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        for t in find_kinks(p, d):
            x = p + t * d
            eps = 1e-3
            g1 = gradient(x + eps * d, h=1e-5)
            g2 = gradient(x - eps * d, h=1e-5)
            diff = g1 - g2
            nrm = np.linalg.norm(diff)
            if nrm < 1e-8:
                continue
            v = diff / nrm
            v *= np.sign(v[np.argmax(np.abs(v))])
            rows.append(v)

    clusters = []
    for v in rows:
        for c in clusters:
            if np.linalg.norm(c[0] - v) < 1e-3:
                c.append(v)
                break
        else:
            clusters.append([v])

    counts = [len(c) for c in clusters]
    maxc = max(counts)
    good = [np.median(np.array(c), axis=0) for c in clusters
            if len(c) >= max(2, 0.05 * maxc)]
    good = [g / np.linalg.norm(g) for g in good]
    return np.array(good)


if __name__ == "__main__":
    A1_hat = steal()
    np.save(os.path.join(HERE, "stolen_A1.npy"), A1_hat)
    print(A1_hat.shape)
    print(A1_hat)
