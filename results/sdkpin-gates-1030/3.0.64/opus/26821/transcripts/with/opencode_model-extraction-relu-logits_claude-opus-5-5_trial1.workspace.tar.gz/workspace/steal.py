"""Recover A1 (up to row permutation and scaling) of a 1-hidden-layer ReLU net
using only black-box queries to forward(x).

Method: along random lines in input space the network is piecewise linear;
each kink is where one hidden neuron's preactivation crosses zero. At a kink,
the difference of the input-gradient on the two sides equals A2_i * A1_i, i.e.
a scaled copy of row i of A1. We collect these, normalize, and deduplicate.
"""
import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi, n=400):
    """Return t values of kinks of g(t)=f(x0+t d) on [lo, hi]."""
    g = lambda t: f(x0 + t * d)
    ts = np.linspace(lo, hi, n + 1)
    vals = np.array([g(t) for t in ts])
    kinks = []

    def rec(a, b, fa, fb, depth=0):
        # Slopes just inside each end
        h = (b - a) * 1e-3
        sa = (g(a + h) - fa) / h
        sb = (fb - g(b - h)) / h
        if abs(sa - sb) < 1e-9 * max(1.0, abs(sa), abs(sb)):
            return
        # Intersection of the two lines -> candidate single kink
        tc = a + (fb - fa - sb * (b - a)) / (sa - sb)
        if a < tc < b:
            pred = fa + sa * (tc - a)
            if abs(g(tc) - pred) < 1e-11 * max(1.0, abs(pred)):
                # verify the two pieces are each linear (single kink)
                m1, m2 = (a + tc) / 2, (tc + b) / 2
                if (abs(g(m1) - (fa + sa * (m1 - a))) < 1e-11 and
                        abs(g(m2) - (fb - sb * (b - m2))) < 1e-11):
                    kinks.append(tc)
                    return
        if depth > 60 or b - a < 1e-12:
            return
        m = (a + b) / 2
        fm = g(m)
        rec(a, m, fa, fm, depth + 1)
        rec(m, b, fm, fb, depth + 1)

    for i in range(n):
        rec(ts[i], ts[i + 1], vals[i], vals[i + 1])
    return kinks


def gradient(x, h=1e-6):
    f0 = f(x)
    gr = np.empty(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        gr[j] = (f(x + e) - f0) / h
    return gr


def row_at_kink(x, d, eps=1e-5):
    gp = gradient(x + eps * d)
    gm = gradient(x - eps * d)
    return gp - gm


def main():
    rows = []  # normalized directions (sign canonicalized)
    counts = []
    stale = 0
    line = 0
    while stale < 15 and line < 200:
        line += 1
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        new = 0
        for t in find_kinks(x0, d, -30.0, 30.0):
            x = x0 + t * d
            v = row_at_kink(x, d, 1e-5)
            v2 = row_at_kink(x, d, 1e-4)
            nv, nv2 = np.linalg.norm(v), np.linalg.norm(v2)
            if nv < 1e-8 or nv2 < 1e-8:
                continue
            v, v2 = v / nv, v2 / nv2
            # reject kinks where nearby hyperplanes contaminate the estimate
            if abs(np.dot(v, v2)) < 1 - 1e-6 or abs(nv - nv2) > 1e-3 * nv:
                continue
            v = v * np.sign(v[np.argmax(np.abs(v))])
            matched = False
            for k, r in enumerate(rows):
                if abs(np.dot(r, v)) > 1 - 1e-4:
                    # running average to reduce noise
                    rows[k] = r * counts[k] + v * np.sign(np.dot(r, v))
                    counts[k] += 1
                    rows[k] /= np.linalg.norm(rows[k])
                    matched = True
                    break
            if not matched:
                rows.append(v)
                counts.append(1)
                new += 1
        stale = 0 if new else stale + 1

    # Real neurons are hit on nearly every line; drop rare spurious clusters.
    counts = np.array(counts)
    keep = counts >= max(3, 0.2 * counts.max())
    A1 = np.array(rows)[keep]
    np.save(OUT, A1)
    print(f"Recovered {A1.shape[0]} neurons (input dim {DIM})")
    print(A1)
    return A1


if __name__ == "__main__":
    main()
