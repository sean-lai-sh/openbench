"""Extract A1 (up to row permutation and scaling) from black-box queries to forward().

Method: f is piecewise linear. Along random lines we locate "critical points"
(kinks) where exactly one hidden neuron switches on/off. The gradient of f jumps
across such a kink by a2_i * A1[i, :], which gives row i of A1 up to scale.
Directions from many kinks are clustered to obtain each unique row.
"""
import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi, flo, fhi, depth=0, out=None):
    """Recursively find t values where f(x0 + t d) is non-linear."""
    if out is None:
        out = []
    mid = 0.5 * (lo + hi)
    fmid = f(x0 + mid * d)
    lin = 0.5 * (flo + fhi)
    tol = 1e-13 * max(1.0, abs(flo), abs(fhi))
    if abs(fmid - lin) <= tol and depth > 4:
        return out  # linear on this segment (with high probability)
    if hi - lo < 1e-5:
        out.append(mid)
        return out
    find_kinks(x0, d, lo, mid, flo, fmid, depth + 1, out)
    find_kinks(x0, d, mid, hi, fmid, fhi, depth + 1, out)
    return out


def refine_kink(x0, d, t, w=2e-5):
    """Locate kink precisely by intersecting the two linear pieces."""
    a, b = t - w, t + w
    h = w * 0.1
    fa, fa2 = f(x0 + (a - h) * d), f(x0 + a * d)
    fb, fb2 = f(x0 + b * d), f(x0 + (b + h) * d)
    sa = (fa2 - fa) / h
    sb = (fb2 - fb) / h
    if abs(sa - sb) < 1e-12:
        return None
    # line A: fa2 + sa (s - a); line B: fb + sb (s - b)
    s = (fb - fa2 + sa * a - sb * b) / (sa - sb)
    if abs(s - t) > 2 * w:
        return None
    return s


def gradient(x, h=1e-7):
    f0 = f(x)
    g = np.empty(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        g[j] = (f(x + e) - f0) / h
    return g


def normalize(v):
    v = v / np.linalg.norm(v)
    k = np.argmax(np.abs(v))
    return v * np.sign(v[k])


def main():
    directions = []
    n_lines = 60
    R = 20.0
    for _ in range(n_lines):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        kinks = find_kinks(x0, d, -R, R, f(x0 - R * d), f(x0 + R * d))
        for t in kinks:
            s = refine_kink(x0, d, t)
            if s is None:
                continue
            xc = x0 + s * d
            delta = 1e-4
            g1 = gradient(xc - delta * d)
            g2 = gradient(xc + delta * d)
            diff = g2 - g1
            if np.linalg.norm(diff) < 1e-8:
                continue
            directions.append(normalize(diff))

    # Cluster directions
    clusters = []  # list of [sum_vector, count]
    for v in directions:
        for c in clusters:
            rep = c[0] / np.linalg.norm(c[0])
            if abs(np.dot(rep, v)) > 1 - 1e-5:
                c[0] += v * np.sign(np.dot(rep, v))
                c[1] += 1
                break
        else:
            clusters.append([v.copy(), 1])

    rows = [c[0] / np.linalg.norm(c[0]) for c in clusters if c[1] >= 2]
    A1_hat = np.array(rows)
    np.save(OUT, A1_hat)
    print(f"Recovered {A1_hat.shape[0]} neurons from {len(directions)} critical points")
    print(A1_hat)
    return A1_hat


if __name__ == "__main__":
    main()
