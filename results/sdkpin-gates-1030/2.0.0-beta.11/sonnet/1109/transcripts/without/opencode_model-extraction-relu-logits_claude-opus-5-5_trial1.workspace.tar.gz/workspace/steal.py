import numpy as np
from forward import forward

D = 10
rng = np.random.default_rng(1)
H = 1e-7


def grad(x):
    f0 = forward(x)
    g = np.zeros(D)
    for i in range(D):
        e = np.zeros(D)
        e[i] = H
        g[i] = (forward(x + e) - f0) / H
    return g


def find_kinks(p, d, T=8.0, N=3000):
    ts = np.linspace(-T, T, N)
    fs = np.array([forward(p + t * d) for t in ts])
    dt = ts[1] - ts[0]
    s = np.diff(fs) / dt
    ds = np.abs(np.diff(s))
    flag = ds > 1e-6
    res = []
    for k in range(1, N - 5):
        if not (flag[k] and flag[k + 1] and not flag[k - 1] and not flag[k + 2]):
            continue
        sl = s[k]
        sr = s[k + 2]
        tl, fl = ts[k], fs[k]
        tr, fr = ts[k + 3], fs[k + 3]
        if abs(sl - sr) < 1e-9:
            continue
        tk = (fr - fl - sr * tr + sl * tl) / (sl - sr)
        if not (ts[k + 1] - dt <= tk <= ts[k + 2] + dt):
            continue
        xk = p + tk * d
        gl = grad(xk - 1e-4 * d)
        gr = grad(xk + 1e-4 * d)
        diff = gr - gl
        if np.linalg.norm(diff) < 1e-4:
            continue
        res.append(diff)
    return res


found = []
for it in range(60):
    p = rng.standard_normal(D) * 0.5
    d = rng.standard_normal(D)
    d /= np.linalg.norm(d)
    for v in find_kinks(p, d):
        found.append(v / np.linalg.norm(v))

clusters = []
for v in found:
    for c in clusters:
        ref = c[0]
        if abs(ref @ v) > 0.9999:
            c[1].append(v * np.sign(ref @ v))
            break
    else:
        clusters.append([v, [v]])

rows = []
for ref, vs in clusters:
    if len(vs) >= 2:
        m = np.mean(vs, axis=0)
        rows.append(m / np.linalg.norm(m))
A1 = np.array(rows)
print(A1.shape)
np.save("/tmp/obench-cell-z4ralouf/bench_opencode_model-extraction-relu-logits_75e8z28o/stolen_A1.npy", A1)
