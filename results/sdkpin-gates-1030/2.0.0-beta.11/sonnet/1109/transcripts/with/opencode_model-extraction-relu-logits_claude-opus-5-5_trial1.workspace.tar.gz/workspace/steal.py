import os
import sys
import itertools
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from forward import forward

D = 10
rng = np.random.default_rng(12345)


def f(x):
    return forward(x)


def find_kinks(x0, d, T=6.0, n=3000):
    ts = np.linspace(-T, T, n + 1)
    fs = np.array([f(x0 + t * d) for t in ts])
    found = []

    def collinear(ta, fa, tb, fb, tol):
        for q in (0.2, 0.5, 0.8):
            t = ta + q * (tb - ta)
            if abs(f(x0 + t * d) - (fa + q * (fb - fa))) > tol:
                return False
        return True

    def rec(ta, fa, tb, fb):
        w = tb - ta
        if collinear(ta, fa, tb, fb, 1e-11):
            return
        if w < 1e-5:
            sl = (fa - f(x0 + (ta - w) * d)) / w
            sr = (f(x0 + (tb + w) * d) - fb) / w
            if abs(sr - sl) < 1e-7:
                return
            t = (fb - fa + sl * ta - sr * tb) / (sl - sr)
            if ta - w <= t <= tb + w:
                found.append(t)
            return
        tm = 0.5 * (ta + tb)
        fm = f(x0 + tm * d)
        rec(ta, fa, tm, fm)
        rec(tm, fm, tb, fb)

    for k in range(n):
        s = ts[k + 1] - ts[k]
        rec(ts[k], fs[k], ts[k + 1], fs[k + 1])
    return found


def grad(x, h=1e-6):
    f0 = f(x)
    g = np.zeros(D)
    for i in range(D):
        e = np.zeros(D)
        e[i] = h
        g[i] = (f(x + e) - f0) / h
    return g


events = []
NLINES = 40
for _ in range(NLINES):
    x0 = rng.normal(size=D) * 0.5
    d = rng.normal(size=D)
    d /= np.linalg.norm(d)
    for t in find_kinks(x0, d):
        xs = x0 + t * d
        delta = 2e-4
        gl = grad(xs - delta * d)
        gr = grad(xs + delta * d)
        J = gr - gl
        nJ = np.linalg.norm(J)
        if nJ < 1e-6:
            continue
        u = J / nJ
        events.append((u, xs, nJ))

clusters = []
for u, xs, nJ in events:
    for c in clusters:
        ref = c["u"]
        cs = float(np.dot(u, ref))
        if abs(cs) > 0.9995:
            s = 1.0 if cs > 0 else -1.0
            c["us"].append(s * u)
            c["pts"].append(xs)
            c["u"] = np.mean(c["us"], axis=0)
            c["u"] /= np.linalg.norm(c["u"])
            break
    else:
        clusters.append({"u": u.copy(), "us": [u.copy()], "pts": [xs]})

if clusters:
    med = np.median([len(c['us']) for c in clusters])
    clusters = [c for c in clusters if len(c['us']) >= max(2, 0.2 * med)]
A = []
B = []
for c in clusters:
    a = c["u"]
    bs = [-np.dot(a, p) for p in c["pts"]]
    A.append(a)
    B.append(np.median(bs))
A = np.array(A)
B = np.array(B)
n = len(A)

signs = np.ones(n)
if n > 0:
    N = 4000
    X = rng.normal(size=(N, D)) * 1.0
    y = np.array([f(x) for x in X])
    Z = X @ A.T + B
    feats = np.hstack([np.maximum(Z, 0), X, np.ones((N, 1))])
    coef, *_ = np.linalg.lstsq(feats, y, rcond=None)
    c = coef[:n]
    L = coef[n:n + D]
    V = c[:, None] * A
    if n <= 24:
        best = None
        CH = 1 << 16
        total = 1 << n
        for start in range(0, total, CH):
            idx = np.arange(start, min(total, start + CH), dtype=np.int64)
            bits = ((idx[:, None] >> np.arange(n)) & 1).astype(float)
            err = np.linalg.norm(bits @ V + L, axis=1)
            k = int(np.argmin(err))
            if best is None or err[k] < best[0]:
                best = (err[k], bits[k].copy())
        signs = np.where(best[1] > 0.5, -1.0, 1.0)

A_out = A * signs[:, None]
np.save(os.path.join(HERE, "stolen_A1.npy"), A_out)
print(A_out)
