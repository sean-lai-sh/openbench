import numpy as np
from forward import forward

D = 10
rng = np.random.default_rng(1)
F = lambda x: forward(x)


def grad(x):
    h = 1e-7
    g = np.zeros(D)
    for i in range(D):
        e = np.zeros(D)
        e[i] = h
        g[i] = (F(x + e) - F(x - e)) / (2 * h)
    return g


def find_kinks(p, d, lo, hi, depth=0, out=None):
    if out is None:
        out = []
    e = (hi - lo) * 1e-3
    f = lambda t: F(p + t * d)
    f0, f1, f2, f3 = f(lo), f(lo + e), f(hi - e), f(hi)
    sL = (f1 - f0) / e
    sR = (f3 - f2) / e
    if abs(sL - sR) < 1e-7:
        tm = (lo + hi) / 2
        lin = f0 + sL * (tm - lo)
        if abs(f(tm) - lin) < 1e-9 and abs(f(lo + (hi - lo) * 0.25) - (f0 + sL * (hi - lo) * 0.25)) < 1e-9:
            return out
        if depth > 60:
            return out
        mid = (lo + hi) / 2
        find_kinks(p, d, lo, mid, depth + 1, out)
        find_kinks(p, d, mid, hi, depth + 1, out)
        return out
    ts = (f2 - f0 + sL * lo - sR * (hi) ) / (sL - sR)
    ts = ((f2 - sR * (hi - e)) - (f0 - sL * lo)) / (sL - sR)
    if lo <= ts <= hi:
        L = f0 + sL * (ts - lo)
        if abs(f(ts) - L) < 1e-9 and (hi - lo) < 1e-1:
            out.append(ts)
            return out
    if depth > 60:
        return out
    mid = (lo + hi) / 2
    find_kinks(p, d, lo, mid, depth + 1, out)
    find_kinks(p, d, mid, hi, depth + 1, out)
    return out


rows = []


def add_row(v, xs):
    n = np.linalg.norm(v)
    if n < 1e-6:
        return
    v = v / n
    for r in rows:
        if abs(abs(np.dot(r[0], v)) - 1) < 1e-4:
            r[1].append(v if np.dot(r[0], v) > 0 else -v)
            r[2].append(xs)
            return
    rows.append((v, [v], [xs]))


R = 6.0
for it in range(60):
    p = rng.normal(size=D) * rng.uniform(0, 1.5)
    d = rng.normal(size=D)
    d /= np.linalg.norm(d)
    cells = np.linspace(-R, R, 241)
    ks = []
    for a, b in zip(cells[:-1], cells[1:]):
        ks += find_kinks(p, d, a, b)
    ks = sorted(ks)
    for t in ks:
        dl = 1e-5
        gl = grad(p + (t - dl) * d)
        gr = grad(p + (t + dl) * d)
        v = gr - gl
        if np.linalg.norm(v) > 1e-4:
            add_row(v, p + t * d)

U = np.array([np.mean(r[1], axis=0) for r in rows])
U = U / np.linalg.norm(U, axis=1, keepdims=True)
beta = np.array([-np.mean([np.dot(U[k], x) for x in rows[k][2]]) for k in range(len(U))])
n = len(U)

X = rng.normal(size=(1500, D)) * rng.uniform(0.2, 3, size=(1500, 1))
y = np.array([F(x) for x in X])
Phi = np.hstack([np.maximum(0, X @ U.T + beta), X, np.ones((len(X), 1))])
coef = np.linalg.lstsq(Phi, y, rcond=None)[0]
c = coef[:n]
w = coef[n:n + D]

signs = np.ones(n)
if n <= 24:
    target = -w
    CU = c[:, None] * U
    best = (np.inf, 0)
    chunk = 1 << 16
    idx_all = np.arange(1 << n, dtype=np.int64)
    for st in range(0, 1 << n, chunk):
        idx = idx_all[st:st + chunk]
        bits = ((idx[:, None] >> np.arange(n)) & 1).astype(float)
        err = np.linalg.norm(bits @ CU - target, axis=1)
        k = err.argmin()
        if err[k] < best[0]:
            best = (err[k], idx[k])
    flip = (best[1] >> np.arange(n)) & 1
    signs = np.where(flip == 1, -1.0, 1.0)
A = U * signs[:, None]
np.save("/tmp/obench-cell-1rtmc_so/bench_opencode_model-extraction-relu-logits_13bqxlel/stolen_A1.npy", A)
print(A.shape)
