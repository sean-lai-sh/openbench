import numpy as np
from forward import forward

D = 10
rng = np.random.default_rng(1)
H = 1e-6
EPS = 1e-3


def f(x):
    return forward(x)


def grad(x):
    f0 = f(x)
    g = np.empty(D)
    for j in range(D):
        e = np.zeros(D)
        e[j] = H
        g[j] = (f(x + e) - f0) / H
    return g


def find_kinks(p, d, R=8.0, N=1600):
    ts = np.linspace(-R, R, N + 1)
    vals = np.array([f(p + t * d) for t in ts])
    sd = vals[2:] - 2 * vals[1:-1] + vals[:-2]
    idx = np.where(np.abs(sd) > 1e-7)[0]
    out = []
    last = -10
    for i in idx:
        if i - last <= 2:
            last = i
            continue
        last = i
        a, b = i, i + 2
        if a < 3 or b > N - 3:
            continue
        s1 = (vals[a] - vals[a - 1]) / (ts[a] - ts[a - 1])
        s2 = (vals[b + 1] - vals[b]) / (ts[b + 1] - ts[b])
        if abs(s1 - s2) < 1e-9:
            continue
        l1 = lambda t: vals[a] + s1 * (t - ts[a])
        l2 = lambda t: vals[b] + s2 * (t - ts[b])
        t0 = (vals[b] - vals[a] - s2 * ts[b] + s1 * ts[a]) / (s1 - s2)
        if not (ts[a] - 1e-9 <= t0 <= ts[b] + 1e-9):
            continue
        ok = abs(f(p + (t0 - 0.5 * (ts[b] - ts[a]) / 2) * d) - l1(t0 - 0.5 * (ts[b] - ts[a]) / 2)) < 1e-8 and \
            abs(f(p + (t0 + 0.5 * (ts[b] - ts[a]) / 2) * d) - l2(t0 + 0.5 * (ts[b] - ts[a]) / 2)) < 1e-8
        if not ok:
            continue
        out.append(t0)
    return out


neurons = []
miss = 0
for it in range(400):
    p = rng.standard_normal(D) * 0.5
    d = rng.standard_normal(D)
    d /= np.linalg.norm(d)
    new = 0
    for t0 in find_kinks(p, d):
        x0 = p + t0 * d
        gm = grad(x0 - EPS * d)
        gp = grad(x0 + EPS * d)
        gm2 = grad(x0 - 2 * EPS * d)
        gp2 = grad(x0 + 2 * EPS * d)
        if np.linalg.norm(gm - gm2) > 1e-4 or np.linalg.norm(gp - gp2) > 1e-4:
            continue
        J = gp - gm
        nJ = np.linalg.norm(J)
        if nJ < 1e-6:
            continue
        n = J / nJ
        alpha = nJ * np.sign(n @ d)
        e = -n @ x0
        dup = False
        for nr in neurons:
            c = nr[0] @ n
            if abs(c) > 1 - 1e-6:
                dup = True
                break
        if dup:
            continue
        neurons.append((n, alpha, e))
        new += 1
    miss = 0 if new else miss + 1
    if miss >= 60 and it >= 100:
        break

k = len(neurons)
Ns = np.array([nr[0] for nr in neurons])
al = np.array([nr[1] for nr in neurons])
es = np.array([nr[2] for nr in neurons])
M = Ns * al[:, None]

Cs = []
for _ in range(20):
    x = rng.standard_normal(D) * 2
    pred = ((Ns @ x + es) > 0).astype(float) @ M
    Cs.append(grad(x) - pred)
C = np.median(np.array(Cs), axis=0)
target = -C

sigma = np.ones(k)
if k <= 26 and np.linalg.norm(target) > 1e-6:
    k1 = k // 2
    k2 = k - k1
    def sums(Mp):
        m = len(Mp)
        bits = ((np.arange(2 ** m)[:, None] >> np.arange(m)) & 1).astype(float)
        return bits, bits @ Mp if m else np.zeros((1, D))
    b1, s1 = sums(M[:k1])
    b2, s2 = sums(M[k1:])
    best = (np.inf, 0, 0)
    for j in range(len(s2)):
        err = np.linalg.norm(s1 + s2[j] - target, axis=1)
        i = int(np.argmin(err))
        if err[i] < best[0]:
            best = (err[i], i, j)
    _, i, j = best
    neg = np.concatenate([b1[i], b2[j]])
    sigma = np.where(neg > 0.5, -1.0, 1.0)

A1 = Ns * sigma[:, None]
np.save("/tmp/obench-cell-y9xdhyus/bench_opencode_model-extraction-relu-logits_6sp1in9n/stolen_A1.npy", A1)
print(A1)
