import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from forward import forward

DIM = 10
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi):
    g = lambda t: f(x0 + t * d)
    kinks = []

    def rec(a, ga, b, gb, depth):
        m = 0.5 * (a + b)
        gm = g(m)
        q1 = 0.5 * (a + m)
        q3 = 0.5 * (m + b)
        g1 = g(q1)
        g3 = g(q3)
        tol = 1e-12 * (1 + abs(ga) + abs(gb))
        lin = (abs(gm - 0.5 * (ga + gb)) < tol and abs(g1 - 0.5 * (ga + gm)) < tol
               and abs(g3 - 0.5 * (gm + gb)) < tol)
        if lin and depth > 3:
            return
        if b - a < 1e-6:
            kinks.append(m)
            return
        rec(a, ga, m, gm, depth + 1)
        rec(m, gm, b, gb, depth + 1)

    rec(lo, g(lo), hi, g(hi), 0)
    merged = []
    for k in sorted(kinks):
        if not merged or k - merged[-1] > 1e-5:
            merged.append(k)
    return merged


def grad(x, h=1e-5):
    gr = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        gr[j] = (f(x + e) - f(x - e)) / (2 * h)
    return gr


def canon(v):
    v = v / np.linalg.norm(v)
    i = np.argmax(np.abs(v))
    return v * np.sign(v[i])


def main():
    rows = []
    stale = 0
    lines = 0
    while stale < 30 and lines < 500:
        lines += 1
        x0 = rng.normal(size=DIM) * rng.uniform(0.5, 3)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        new = False
        for t in find_kinks(x0, d, -20.0, 20.0):
            xk = x0 + t * d
            eps = 1e-4
            gp = grad(xk + eps * d)
            gm = grad(xk - eps * d)
            gp2 = grad(xk + 2 * eps * d)
            gm2 = grad(xk - 2 * eps * d)
            if np.linalg.norm(gp - gp2) > 1e-6 * (1 + np.linalg.norm(gp)) or \
               np.linalg.norm(gm - gm2) > 1e-6 * (1 + np.linalg.norm(gm)):
                continue
            diff = gp - gm
            if np.linalg.norm(diff) < 1e-9:
                continue
            v = canon(diff)
            if not any(abs(np.dot(v, r)) > 0.9999 for r in rows):
                rows.append(v)
                new = True
        stale = 0 if new else stale + 1
    A = np.array(rows)
    np.save(os.path.join(HERE, "stolen_A1.npy"), A)
    print(A.shape)
    print(A)


if __name__ == "__main__":
    main()
