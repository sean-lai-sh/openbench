import os
import numpy as np
from forward import forward

DIM = 10
HERE = os.path.dirname(os.path.abspath(__file__))
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi, flo, fhi, out, depth=0):
    mid = 0.5 * (lo + hi)
    fmid = f(x0 + mid * d)
    lin = 0.5 * (flo + fhi)
    scale = max(1.0, abs(flo), abs(fhi))
    if abs(fmid - lin) < 1e-14 * scale and depth > 3:
        return
    if hi - lo < 1e-6:
        out.append(mid)
        return
    find_kinks(x0, d, lo, mid, flo, fmid, out, depth + 1)
    find_kinks(x0, d, mid, hi, fmid, fhi, out, depth + 1)


def gradient(x, h=1e-6):
    g = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        g[j] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def normalize(v):
    v = v / np.linalg.norm(v)
    if v[np.argmax(np.abs(v))] < 0:
        v = -v
    return v


def merge_kinks(ts, tol=1e-5):
    ts = sorted(ts)
    merged = []
    for t in ts:
        if merged and t - merged[-1][-1] < tol:
            merged[-1].append(t)
        else:
            merged.append([t])
    return [float(np.mean(m)) for m in merged]


def steal(num_lines=60, R=50.0):
    rows = []
    stable = 0
    for _ in range(num_lines):
        x0 = rng.standard_normal(DIM)
        d = rng.standard_normal(DIM)
        d /= np.linalg.norm(d)
        kinks = []
        find_kinks(x0, d, -R, R, f(x0 - R * d), f(x0 + R * d), kinks)
        kinks = merge_kinks(kinks)
        before = len(rows)
        for t in kinks:
            p = x0 + t * d
            eps = 1e-4
            g1 = gradient(p + eps * d)
            g2 = gradient(p - eps * d)
            diff = g1 - g2
            if np.linalg.norm(diff) < 1e-8:
                continue
            v = normalize(diff)
            if not any(abs(np.dot(v, r)) > 0.9999 for r in rows):
                rows.append(v)
        if len(rows) == before:
            stable += 1
            if stable >= 10:
                break
        else:
            stable = 0
    return np.array(rows)


if __name__ == "__main__":
    A1_stolen = steal()
    np.save(os.path.join(HERE, "stolen_A1.npy"), A1_stolen)
    print(A1_stolen.shape)
    print(A1_stolen)
