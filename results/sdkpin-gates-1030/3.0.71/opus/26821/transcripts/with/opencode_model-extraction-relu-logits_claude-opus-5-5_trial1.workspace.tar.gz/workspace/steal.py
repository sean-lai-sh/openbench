"""Extract A1 (up to neuron permutation and per-row scaling) from a one-hidden-layer
ReLU network using only black-box queries to forward(x).

Method (critical-point / gradient-difference attack):
  1. Along random lines x0 + t*d the network is piecewise linear in t; each kink
     is where some hidden neuron's pre-activation crosses zero.
  2. Locate kinks precisely by bisection on slope changes + intersecting the two
     adjacent linear pieces.
  3. At a kink, the gradient jump of the output between the two sides equals
     +/- A2_i * A1_i, i.e. a scaled copy of row i of A1.
  4. Normalise, fix sign, and deduplicate the recovered rows.
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from forward import forward  # noqa: E402

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi):
    """Return list of t values where f(x0 + t d) has a kink in [lo, hi]."""
    g = lambda t: f(x0 + t * d)
    h = 1e-7 * max(1.0, hi - lo)

    def slope_r(t):
        return (g(t + h) - g(t)) / h

    def slope_l(t):
        return (g(t) - g(t - h)) / h

    kinks = []

    def rec(a, b, ga, gb, sa, sb, depth):
        # sa: slope just right of a, sb: slope just left of b
        if abs(sa - sb) < 1e-9 * (1 + abs(sa) + abs(sb)):
            # check linearity at midpoint too (guards against cancelling kinks)
            m = 0.5 * (a + b)
            if abs(g(m) - 0.5 * (ga + gb)) < 1e-10 * (1 + abs(ga) + abs(gb)):
                return
        if depth > 0:
            # try: single kink -> intersection of the two lines
            if abs(sa - sb) > 1e-12:
                t = a + ((gb - ga) - sb * (b - a)) / (sa - sb)
                if a < t < b:
                    pred = ga + sa * (t - a)
                    gt = g(t)
                    m1 = 0.5 * (a + t)
                    m2 = 0.5 * (t + b)
                    ok = (abs(gt - pred) < 1e-9 * (1 + abs(gt))
                          and abs(g(m1) - (ga + sa * (m1 - a))) < 1e-9 * (1 + abs(gt))
                          and abs(g(m2) - (gb + sb * (m2 - b))) < 1e-9 * (1 + abs(gt)))
                    if ok:
                        kinks.append(t)
                        return
        if b - a < 1e-9 or depth > 60:
            return
        m = 0.5 * (a + b)
        gm = g(m)
        rec(a, m, ga, gm, sa, slope_l(m), depth + 1)
        rec(m, b, gm, gb, slope_r(m), sb, depth + 1)

    rec(lo, hi, g(lo), g(hi), slope_r(lo), slope_l(hi), 0)
    return kinks


def grad(x, h):
    gr = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        gr[j] = (f(x + e) - f(x - e)) / (2 * h)
    return gr


def row_at_kink(xc, d):
    delta = 1e-4
    g1 = grad(xc + delta * d, delta * 1e-2)
    g2 = grad(xc - delta * d, delta * 1e-2)
    v = g1 - g2
    n = np.linalg.norm(v)
    if n < 1e-10:
        return None
    v = v / n
    # canonical sign: largest-magnitude entry positive
    if v[np.argmax(np.abs(v))] < 0:
        v = -v
    return v


def main():
    rows = []      # list of [sum_vector, count]
    no_new = 0
    it = 0
    while no_new < 40 and it < 500:
        it += 1
        x0 = rng.normal(size=DIM) * 0.5
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        found_new = False
        for t in find_kinks(x0, d, -10.0, 10.0):
            v = row_at_kink(x0 + t * d, d)
            if v is None:
                continue
            for r in rows:
                c = r[0] / r[1]
                if abs(np.dot(c / np.linalg.norm(c), v)) > 0.999:
                    if np.dot(c, v) < 0:
                        v = -v
                    r[0] += v
                    r[1] += 1
                    break
            else:
                rows.append([v.copy(), 1])
                found_new = True
        no_new = 0 if found_new else no_new + 1

    # keep only rows confirmed at least twice if they are a small minority (noise guard)
    A = np.array([r[0] / np.linalg.norm(r[0]) for r in rows if r[1] >= 2 or len(rows) < 3])
    print(f"Recovered {A.shape[0]} neurons")
    np.set_printoptions(precision=6, suppress=True, linewidth=150)
    print(A)
    np.save(OUT, A)
    return A


if __name__ == "__main__":
    main()
