"""Recover A1 (up to row permutation and scaling) of f(x) = A2 relu(A1 x + b1) + b2
using only black-box queries to forward(x)."""
import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi):
    """Return t values where f(x0 + t d) is non-linear (ReLU boundaries)."""
    g = lambda t: f(x0 + t * d)
    kinks = []
    stack = [(lo, hi, g(lo), g(hi))]
    while stack:
        a, b, fa, fb = stack.pop()
        m = 0.5 * (a + b)
        fm = g(m)
        q1, q3 = a + 0.25 * (b - a), a + 0.75 * (b - a)
        f1, f3 = g(q1), g(q3)
        lin = lambda t: fa + (fb - fa) * (t - a) / (b - a)
        tol = 1e-13 * max(1.0, abs(fa), abs(fb))
        if (abs(fm - lin(m)) < tol and abs(f1 - lin(q1)) < tol
                and abs(f3 - lin(q3)) < tol):
            continue
        if b - a < 1e-9:
            kinks.append(m)
            continue
        stack.append((a, m, fa, fm))
        stack.append((m, b, fm, fb))
    # merge kinks that are essentially the same
    kinks.sort()
    merged = []
    for k in kinks:
        if not merged or k - merged[-1] > 1e-7:
            merged.append(k)
    return merged


def gradient(x, h=1e-7):
    gr = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        gr[j] = (f(x + e) - f(x - e)) / (2 * h)
    return gr


def normalize(v):
    v = v / np.linalg.norm(v)
    i = np.argmax(np.abs(v))
    return v * np.sign(v[i])


def steal(max_lines=400, patience=60):
    found = []  # list of [direction, count]
    since_new = 0
    for _ in range(max_lines):
        x0 = rng.normal(size=DIM) * 0.5
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        new_here = False
        for t in find_kinks(x0, d, -30.0, 30.0):
            delta = 1e-4
            gp = gradient(x0 + (t + delta) * d)
            gm = gradient(x0 + (t - delta) * d)
            diff = gp - gm
            if np.linalg.norm(diff) < 1e-8:
                continue
            v = normalize(diff)
            for entry in found:
                if abs(np.dot(entry[0], v)) > 1 - 1e-6:
                    # running average to refine the estimate
                    entry[0] = normalize(entry[0] * entry[1] + v)
                    entry[1] += 1
                    break
            else:
                found.append([v, 1])
                new_here = True
        since_new = 0 if new_here else since_new + 1
        if since_new >= patience:
            break
    # discard spurious directions seen only once if they're rare
    rows = [e[0] for e in found if e[1] >= 2] or [e[0] for e in found]
    return np.array(rows)


if __name__ == "__main__":
    A1_hat = steal()
    np.save(OUT, A1_hat)
    print("Recovered shape:", A1_hat.shape)
    print(A1_hat)
