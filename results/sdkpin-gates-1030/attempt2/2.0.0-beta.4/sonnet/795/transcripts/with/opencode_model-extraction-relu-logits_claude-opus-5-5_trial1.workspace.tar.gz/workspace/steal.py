import numpy as np
from forward import forward

D = 10
R = 6.0
rng = np.random.default_rng(1)
F = lambda x: forward(x)


def linear_ok(f, a, b, fa, fb, tol=1e-10):
    for q in (0.25, 0.5, 0.75):
        t = a + q * (b - a)
        if abs(f(t) - (fa + q * (fb - fa))) > tol:
            return False
    return True


def kinks_in(f, a, b, fa, fb, out):
    if linear_ok(f, a, b, fa, fb):
        return
    if b - a > 1e-3:
        m = 0.5 * (a + b)
        fm = f(m)
        kinks_in(f, a, m, fa, fm, out)
        kinks_in(f, m, b, fm, fb, out)
        return
    d = (b - a) / 10
    sl = (f(a + d) - fa) / d
    sr = (fb - f(b - d)) / d
    if abs(sl - sr) < 1e-9:
        return
    # lines: fa + sl (t-a) ; fb + sr (t-b)
    t = (fb - fa + sl * a - sr * b) / (sl - sr)
    if not (a <= t <= b):
        return
    ft = fa + sl * (t - a)
    if abs(f(t) - ft) > 1e-9:
        return
    out.append(t)


def grad(x, eps=1e-6):
    f0 = F(x)
    g = np.empty(D)
    for j in range(D):
        e = np.zeros(D)
        e[j] = eps
        g[j] = (F(x + e) - f0) / eps
    return g


def find_rows(p, d):
    f = lambda t: F(p + t * d)
    ts = np.linspace(-R, R, 121)
    fs = [f(t) for t in ts]
    out = []
    for i in range(len(ts) - 1):
        kinks_in(f, ts[i], ts[i + 1], fs[i], fs[i + 1], out)
    out = sorted(set(round(t, 7) for t in out))
    rows = []
    s = 1e-4
    for t in out:
        xl = p + (t - s) * d
        xr = p + (t + s) * d
        dg = grad(xr) - grad(xl)
        n = np.linalg.norm(dg)
        if n < 1e-6:
            continue
        rows.append(dg / n)
    return rows


def main():
    clusters = []
    counts = []
    for it in range(400):
        p = rng.normal(size=D) * 0.5
        d = rng.normal(size=D)
        d /= np.linalg.norm(d)
        for r in find_rows(p, d):
            for k, c in enumerate(clusters):
                cs = float(np.dot(c / np.linalg.norm(c), r))
                if abs(cs) > 1 - 1e-4:
                    clusters[k] = c + np.sign(cs) * r
                    counts[k] += 1
                    break
            else:
                clusters.append(r.copy())
                counts.append(1)
    A = []
    for c, n in zip(clusters, counts):
        if n >= 2:
            v = c / np.linalg.norm(c)
            A.append(v)
    A = np.array(A)
    np.save("/tmp/obench-cell-csb9wg17/bench_opencode_model-extraction-relu-logits_mmux21cc/stolen_A1.npy", A)
    print(A.shape)
    print(A)


if __name__ == "__main__":
    main()
