import numpy as np
from forward import forward

D = 10
rng = np.random.default_rng(1)


def grad(x, h=1e-6):
    g = np.zeros(D)
    f0 = forward(x)
    for i in range(D):
        e = np.zeros(D)
        e[i] = h
        fp = forward(x + e)
        fm = forward(x - e)
        gf = (fp - f0) / h
        gb = (f0 - fm) / h
        if abs(gf - gb) > 1e-5:
            return None
        g[i] = (fp - fm) / (2 * h)
    return g


dirs = []
counts = []


def add(v):
    n = np.linalg.norm(v)
    if n < 1e-6:
        return
    v = v / n
    for k, u in enumerate(dirs):
        if abs(np.dot(u, v)) > 0.9999:
            counts[k] += 1
            return
    dirs.append(v)
    counts.append(1)


N = 4000
R = 8.0
ts = np.linspace(-R, R, N)
dt = ts[1] - ts[0]
for line in range(60):
    p = rng.normal(size=D) * 0.5
    d = rng.normal(size=D)
    d /= np.linalg.norm(d)
    f = np.array([forward(p + t * d) for t in ts])
    sl = np.diff(f) / dt
    ch = np.abs(np.diff(sl)) > 1e-7
    j = 0
    while j + 3 < len(sl):
        if not (ch[j] and ch[j + 1]) or (j + 2 < len(ch) and ch[j + 2]) or (j > 0 and ch[j - 1]):
            j += 1
            continue
        sa, sb = sl[j], sl[j + 2]
        t1, t2 = ts[j + 1], ts[j + 2]
        tk = (f[j + 2] - f[j + 1] + sa * t1 - sb * ts[j + 2]) / (sa - sb)
        j += 2
        if not (t1 - 1e-9 <= tk <= t2 + 1e-9):
            continue
        s = 2e-4
        gl = grad(p + (tk - s) * d)
        gr = grad(p + (tk + s) * d)
        if gl is None or gr is None:
            continue
        add(gr - gl)

order = np.argsort(counts)[::-1]
cnt = np.array(counts)[order]
dd = np.array(dirs)[order]
print("clusters:", len(dd), "counts:", cnt.tolist())
keep = cnt >= 2
A1 = dd[keep]
np.save("/tmp/obench-cell-wzswe0yn/bench_opencode_model-extraction-relu-logits_a1hjr9bz/stolen_A1.npy", A1)
print(A1.shape)
