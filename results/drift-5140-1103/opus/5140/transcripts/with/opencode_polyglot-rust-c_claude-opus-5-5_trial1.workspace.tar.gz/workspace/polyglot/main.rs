/* /* */
#include <cstdio>
#include <cstdlib>
#include <vector>
typedef unsigned long long u64;
int main(int argc, char** argv) {
    if (argc < 2) { fprintf(stderr, "usage: %s N\n", argv[0]); return 1; }
    long n = strtol(argv[1], 0, 10);
    std::vector<u64> a(1, 1), b(1, 1);
    const u64 BASE = 1000000000ULL;
    for (long i = 1; i <= n; i++) {
        std::vector<u64> c;
        u64 carry = 0;
        for (size_t j = 0; j < b.size() || carry; j++) {
            u64 s = carry + (j < a.size() ? a[j] : 0) + (j < b.size() ? b[j] : 0);
            c.push_back(s % BASE);
            carry = s / BASE;
        }
        a = b;
        b = c;
    }
    printf("%llu", a.back());
    for (size_t j = a.size() - 1; j-- > 0;) printf("%09llu", a[j]);
    printf("\n");
    return 0;
}
#if 0
*/
fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.len() < 2 {
        eprintln!("usage: {} N", args[0]);
        std::process::exit(1);
    }
    let n: u64 = args[1].trim().parse().expect("N must be a non-negative integer");
    const BASE: u64 = 1_000_000_000;
    let mut a: Vec<u64> = vec![1];
    let mut b: Vec<u64> = vec![1];
    for _ in 0..n {
        let mut c: Vec<u64> = Vec::with_capacity(b.len() + 1);
        let mut carry = 0u64;
        let mut j = 0;
        while j < b.len() || carry > 0 {
            let s = carry + a.get(j).copied().unwrap_or(0) + b.get(j).copied().unwrap_or(0);
            c.push(s % BASE);
            carry = s / BASE;
            j += 1;
        }
        a = b;
        b = c;
    }
    let mut out = format!("{}", a[a.len() - 1]);
    for j in (0..a.len() - 1).rev() {
        out.push_str(&format!("{:09}", a[j]));
    }
    println!("{}", out);
}
/* /* */
#endif
// */
