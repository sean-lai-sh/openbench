"""Pipeline-parallel training step (AFAB schedule) for HuggingFace LlamaForCausalLM."""

import torch
import torch.distributed as dist
import torch.nn.functional as F


# ---------------------------------------------------------------------------
# Partitioning
# ---------------------------------------------------------------------------
def _partition_layers(num_layers, world_size, rank):
    """Return [start, end) of the decoder layers owned by `rank` (balanced split)."""
    base, rem = divmod(num_layers, world_size)
    start = rank * base + min(rank, rem)
    end = start + base + (1 if rank < rem else 0)
    return start, end


# ---------------------------------------------------------------------------
# Communication helpers (P2POp based)
# ---------------------------------------------------------------------------
def _send(tensor, peer):
    ops = [dist.P2POp(dist.isend, tensor.contiguous(), peer)]
    for req in dist.batch_isend_irecv(ops):
        req.wait()


def _recv(shape, peer, device, dtype):
    buf = torch.empty(shape, device=device, dtype=dtype)
    ops = [dist.P2POp(dist.irecv, buf, peer)]
    for req in dist.batch_isend_irecv(ops):
        req.wait()
    return buf


# ---------------------------------------------------------------------------
# Layer-input helpers (masks / rotary embeddings), robust across HF versions
# ---------------------------------------------------------------------------
def _build_causal_mask(llama, hidden, position_ids):
    config = llama.config
    try:
        from transformers.masking_utils import create_causal_mask
    except Exception:  # older transformers
        create_causal_mask = None

    if create_causal_mask is not None:
        cache_position = torch.arange(hidden.shape[1], device=hidden.device)
        base = dict(
            config=config,
            attention_mask=None,
            past_key_values=None,
            position_ids=position_ids,
        )
        for extra in (
            {"inputs_embeds": hidden},
            {"input_embeds": hidden, "cache_position": cache_position},
            {"input_embeds": hidden},
            {"inputs_embeds": hidden, "cache_position": cache_position},
        ):
            try:
                return create_causal_mask(**base, **extra)
            except TypeError:
                continue

    if hasattr(llama, "_update_causal_mask"):
        cache_position = torch.arange(hidden.shape[1], device=hidden.device)
        for args in (
            (None, hidden, cache_position, None, False),
            (None, hidden, cache_position, None),
            (None, hidden, cache_position),
        ):
            try:
                return llama._update_causal_mask(*args)
            except TypeError:
                continue
    return None


def _layer_kwargs(llama, hidden):
    seq_len = hidden.shape[1]
    position_ids = torch.arange(seq_len, device=hidden.device).unsqueeze(0)
    kwargs = {
        "attention_mask": _build_causal_mask(llama, hidden, position_ids),
        "position_ids": position_ids,
    }
    if hasattr(llama, "rotary_emb"):
        kwargs["position_embeddings"] = llama.rotary_emb(hidden, position_ids)
    return kwargs


def _run_layers(llama, layers, hidden):
    if len(layers) == 0:
        return hidden
    kwargs = _layer_kwargs(llama, hidden)
    for layer in layers:
        out = layer(hidden, **kwargs)
        hidden = out[0] if isinstance(out, (tuple, list)) else out
    return hidden


# ---------------------------------------------------------------------------
# Training step
# ---------------------------------------------------------------------------
def train_step_pipeline_afab(model, inputs, targets, device, dtype):
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    is_first = rank == 0
    is_last = rank == world_size - 1

    llama = model.model
    config = model.config
    hidden_size = config.hidden_size
    num_layers = len(llama.layers)
    start, end = _partition_layers(num_layers, world_size, rank)
    my_layers = [llama.layers[i] for i in range(start, end)]

    num_mb = len(inputs)
    stage_inputs = []  # received hidden states (leaf tensors) per microbatch
    stage_outputs = []  # output hidden states (or loss on last stage) per microbatch
    total_loss = torch.zeros((), device=device, dtype=torch.float32)

    # ---------------- all forward ----------------
    for mb in range(num_mb):
        input_ids = inputs[mb].to(device)
        mb_size, seq_len = input_ids.shape[0], input_ids.shape[1]
        shape = (mb_size, seq_len, hidden_size)

        if is_first:
            hidden_in = None
            hidden = llama.embed_tokens(input_ids).to(dtype)
        else:
            hidden_in = _recv(shape, rank - 1, device, dtype)
            hidden_in.requires_grad_(True)
            hidden = hidden_in

        hidden = _run_layers(llama, my_layers, hidden)

        if is_last:
            hidden = llama.norm(hidden)
            logits = model.lm_head(hidden)
            tgt = targets[mb].to(device)
            loss = (
                F.cross_entropy(logits.reshape(-1, logits.size(-1)), tgt.reshape(-1))
                / num_mb
            )
            total_loss = total_loss + loss.detach().float()
            stage_outputs.append(loss)
        else:
            hidden = hidden.to(dtype)
            _send(hidden.detach(), rank + 1)
            stage_outputs.append(hidden)
        stage_inputs.append(hidden_in)

    # ---------------- all backward ----------------
    for mb in range(num_mb):
        out = stage_outputs[mb]
        if is_last:
            out.backward()
        else:
            grad = _recv(out.shape, rank + 1, device, dtype)
            torch.autograd.backward(out, grad_tensors=grad)

        if not is_first:
            hin = stage_inputs[mb]
            g = hin.grad if hin.grad is not None else torch.zeros_like(hin)
            _send(g.to(device=device, dtype=dtype), rank - 1)

        stage_outputs[mb] = None
        stage_inputs[mb] = None

    return total_loss if is_last else None
