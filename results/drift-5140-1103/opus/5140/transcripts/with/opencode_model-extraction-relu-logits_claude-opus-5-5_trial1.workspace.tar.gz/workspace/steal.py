"""Black-box extraction of A1 from f(x) = A2 ReLU(A1 x + b1) + b2.

Only forward() is queried. Strategy:
  1. Along random lines, locate the kinks (critical points) of the piecewise
     linear function f via recursive subdivision + slope intersection.
  2. At each kink, the jump in the gradient is proportional to the row of A1
     of the neuron that switches there. Collect + deduplicate these directions.
  3. (Bonus) Recover each row's sign by fitting f with ReLU features of the
     recovered hyperplanes plus a linear term, then solving a small subset
     problem for which rows were flipped.
"""

import itertools
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from forward import forward  # noqa: E402

DIM = 10
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def grad(x, h=1e-6):
    """Central finite-difference gradient (exact on linear regions)."""
    g = np.zeros(DIM)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = h
        g[i] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def find_kinks(x0, d, lo, hi):
    """Return t-values of kinks of t -> f(x0 + t d) in [lo, hi]."""
    g = lambda t: f(x0 + t * d)
    eps = 1e-7
    slope = lambda t: (g(t + eps) - g(t - eps)) / (2 * eps)
    kinks = []

    def rec(a, b, fa, fb, sa, sb, depth):
        if b - a < 1e-9 or depth > 60:
            return
        # Linear on [a,b]?
        if abs(sa - sb) < 1e-9 * max(1.0, abs(sa)):
            m = 0.5 * (a + b)
            if abs(g(m) - 0.5 * (fa + fb)) < 1e-11:
                return
        # Try single-kink hypothesis: intersect the two end lines.
        if abs(sa - sb) > 1e-12:
            tk = (fb - fa + sa * a - sb * b) / (sa - sb)
            if a < tk < b:
                pred = fa + sa * (tk - a)
                if (
                    abs(g(tk) - pred) < 1e-10
                    and abs(slope(tk - 1e-5) - sa) < 1e-6
                    and abs(slope(tk + 1e-5) - sb) < 1e-6
                ):
                    kinks.append(tk)
                    return
        m = 0.5 * (a + b)
        fm, sm = g(m), slope(m)
        rec(a, m, fa, fm, sa, sm, depth + 1)
        rec(m, b, fm, fb, sm, sb, depth + 1)

    rec(lo, hi, g(lo), g(hi), slope(lo), slope(hi), 0)
    return kinks


def normalize(v):
    v = v / np.linalg.norm(v)
    # canonical sign: largest-magnitude entry positive
    return v * np.sign(v[np.argmax(np.abs(v))])


def main():
    rows = []  # unit directions (canonical sign)
    points = []  # a point on each neuron's hyperplane
    stale = 0
    n_lines = 0
    while stale < 8 and n_lines < 200:
        n_lines += 1
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        new = 0
        for tk in find_kinks(x0, d, -200.0, 200.0):
            xk = x0 + tk * d
            delta = 1e-4
            gl = grad(xk - delta * d)
            gr = grad(xk + delta * d)
            jump = gr - gl
            if np.linalg.norm(jump) < 1e-8:
                continue
            u = normalize(jump)
            if any(abs(abs(u @ r) - 1) < 1e-5 for r in rows):
                continue
            rows.append(u)
            points.append(xk)
            new += 1
        stale = 0 if new else stale + 1
    W = np.array(rows)
    P = np.array(points)
    b = -np.einsum("ij,ij->i", W, P)  # hyperplane offsets: W x + b = 0
    n = len(W)
    print(f"found {n} neurons using {n_lines} lines")

    # ---- Sign recovery (optional; result is valid up to scaling regardless).
    try:
        X = rng.normal(size=(max(400, 10 * n), DIM)) * 3
        y = np.array([f(x) for x in X])
        Z = X @ W.T + b
        feats = np.hstack([np.maximum(Z, 0), X, np.ones((len(X), 1))])
        coef, *_ = np.linalg.lstsq(feats, y, rcond=None)
        resid = np.abs(feats @ coef - y).max()
        alpha, L = coef[:n], coef[n : n + DIM]
        if resid < 1e-6 and n <= 22:
            V = alpha[:, None] * W  # (n, DIM)
            best, best_err = None, np.inf
            # find subset S with sum_{i in S} alpha_i w_i = -L
            half = n // 2
            A_idx, B_idx = range(half), range(half, n)
            combA = np.array(list(itertools.product([0, 1], repeat=half)))
            combB = np.array(list(itertools.product([0, 1], repeat=n - half)))
            sA = combA @ V[:half]
            sB = combB @ V[half:]
            target = -L
            for j in range(len(combB)):
                err = np.linalg.norm(sA + sB[j] - target, axis=1)
                k = np.argmin(err)
                if err[k] < best_err:
                    best_err = err[k]
                    best = np.concatenate([combA[k], combB[j]])
            if best_err < 1e-5:
                W = W * np.where(best == 1, -1, 1)[:, None]
                print("signs recovered (err %.2e)" % best_err)
            else:
                print("sign recovery inconclusive; signs canonicalized")
        else:
            print("sign recovery skipped (resid %.2e)" % resid)
    except Exception as e:  # pragma: no cover
        print("sign recovery failed:", e)

    out = os.path.join(HERE, "stolen_A1.npy")
    np.save(out, W)
    print("saved", out, W.shape)
    return W


if __name__ == "__main__":
    main()
