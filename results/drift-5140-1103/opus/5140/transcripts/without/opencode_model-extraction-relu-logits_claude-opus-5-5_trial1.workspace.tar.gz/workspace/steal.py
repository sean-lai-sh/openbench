import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from forward import forward  # noqa: E402

DIM = 10
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, a, b, fa, fb, out, depth=0):
    """Recursively locate points t in [a,b] where f(x0+t d) is non-linear."""
    m = 0.5 * (a + b)
    fm = f(x0 + m * d)
    if abs(fm - 0.5 * (fa + fb)) < 1e-11 * (1 + abs(fa) + abs(fb)):
        # check with quarter points too, to reduce chance of cancelling kinks
        q1, q3 = a + 0.25 * (b - a), a + 0.75 * (b - a)
        f1, f3 = f(x0 + q1 * d), f(x0 + q3 * d)
        if abs(f1 - 0.75 * fa - 0.25 * fb) < 1e-11 * (1 + abs(fa) + abs(fb)) and abs(
            f3 - 0.25 * fa - 0.75 * fb
        ) < 1e-11 * (1 + abs(fa) + abs(fb)):
            return
    if b - a < 1e-6:
        out.append(m)
        return
    find_kinks(x0, d, a, m, fa, fm, out, depth + 1)
    find_kinks(x0, d, m, b, fm, fb, out, depth + 1)


def grad(x, h=1e-7):
    g = np.zeros(DIM)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = h
        g[i] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def normalize(v):
    v = v / np.linalg.norm(v)
    if v[np.argmax(np.abs(v))] < 0:
        v = -v
    return v


def main():
    rows = []
    stale = 0
    lines = 0
    while stale < 40 and lines < 2000:
        lines += 1
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        a, b = -30.0, 30.0
        kinks = []
        find_kinks(x0, d, a, b, f(x0 + a * d), f(x0 + b * d), kinks)
        # merge kinks that are very close
        kinks = sorted(kinks)
        merged = []
        for t in kinks:
            if not merged or t - merged[-1] > 1e-5:
                merged.append(t)
        new = 0
        for idx, t in enumerate(merged):
            # offset must stay away from neighbouring kinks
            gap = min([abs(t - s) for s in merged if s != t] + [1.0])
            eps = min(1e-4, gap / 4)
            gl = grad(x0 + (t - eps) * d, h=eps / 100)
            gr = grad(x0 + (t + eps) * d, h=eps / 100)
            diff = gr - gl
            if np.linalg.norm(diff) < 1e-8:
                continue
            v = normalize(diff)
            if all(abs(np.dot(v, r)) < 1 - 1e-4 for r in rows):
                rows.append(v)
                new += 1
        stale = 0 if new else stale + 1

    A = np.array(rows)
    np.save(os.path.join(HERE, "stolen_A1.npy"), A)
    print(f"Recovered {A.shape[0]} neurons (rows), shape {A.shape}")
    print(A)
    return A


if __name__ == "__main__":
    main()
