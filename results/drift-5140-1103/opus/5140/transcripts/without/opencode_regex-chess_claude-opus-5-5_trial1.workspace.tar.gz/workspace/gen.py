import json
import re

# Internal line format (70 chars + '\n'):
#   pos 0      : marker '@' (original) or '#' (candidate)
#   pos 1..64  : board, a8..h8, a7..h7, ..., a1..h1 ; empty = '1'
#   pos 65..68 : castling K Q k q  (letter or 'x')
#   pos 69     : en-passant file letter or '-'
CK, CQ, Ck, Cq, EP = 65, 66, 67, 68, 69
LINE_LEN = 70

EMPTY = "1"
NOTWHITE = "[1pnbrqk]"
BLACK = "[pnbrqk]"


def sq(f, r):  # f 0..7, r 1..8 -> line pos
    return 1 + (8 - r) * 8 + f


def onb(f, r):
    return 0 <= f < 8 and 1 <= r <= 8


def render(cons, start, end):
    """Render constraints for positions start..end-1 (dict pos->class)."""
    out = []
    gap = 0
    for p in range(start, end):
        c = cons.get(p)
        if c is None:
            gap += 1
        else:
            if gap:
                out.append("." if gap == 1 else ".{%d}" % gap)
                gap = 0
            out.append(c)
    return "".join(out), gap


def render_prefix(cons):
    """Render as lookahead body starting from pos 1; trailing gap dropped."""
    s, _ = render(cons, 1, LINE_LEN)
    return s


def attack_alts(f, r):
    """List of constraint dicts meaning 'square (f,r) attacked by black'."""
    alts = []
    for df, dr in [
        (1, 2),
        (2, 1),
        (-1, 2),
        (-2, 1),
        (1, -2),
        (2, -1),
        (-1, -2),
        (-2, -1),
    ]:
        if onb(f + df, r + dr):
            alts.append({sq(f + df, r + dr): "n"})
    for df in (-1, 1):
        if onb(f + df, r + 1):
            alts.append({sq(f + df, r + 1): "p"})
    for df in (-1, 0, 1):
        for dr in (-1, 0, 1):
            if (df or dr) and onb(f + df, r + dr):
                alts.append({sq(f + df, r + dr): "k"})
    for dirs, cls in [
        ([(1, 0), (-1, 0), (0, 1), (0, -1)], "[rq]"),
        ([(1, 1), (1, -1), (-1, 1), (-1, -1)], "[bq]"),
    ]:
        for df, dr in dirs:
            path = []
            ff, rr = f + df, r + dr
            while onb(ff, rr):
                c = {p: EMPTY for p in path}
                c[sq(ff, rr)] = cls
                alts.append(c)
                path.append(sq(ff, rr))
                ff += df
                rr += dr
    return alts


def attack_lookahead_body(f, r):
    return "(?:" + "|".join(render_prefix(a) for a in attack_alts(f, r)) + ")"


rules = []

# ---------- input normalisation ----------
rules.append([r"^(\S+) w (\S+) (\S+).*$", r"\1 \2 \3"])
rules.append([r"([a-h])[36]$", r"\1"])
for mask in range(16):
    letters = "KQkq"
    field = "".join(letters[i] for i in range(4) if mask >> i & 1) or "-"
    fixed = "".join(letters[i] if mask >> i & 1 else "x" for i in range(4))
    rules.append([" " + re.escape(field) + " ", " " + fixed])
for d in range(8, 1, -1):
    rules.append([str(d), "1" * d])
rules.append(["/", ""])
rules.append([r"^(\S{64}) (\S{5})$", "@\\1\\2\n"])

# ---------- move generation ----------
gen = []


def add_move(cons, changes, extra_look=""):
    """cons: pos->class constraints on '@' line; changes: pos->new char."""
    changes = dict(changes)
    changes.setdefault(EP, "-")
    pat = [r"\A(@" + extra_look]
    rep = [r"\1#"]
    g = 1
    p = 1
    while p < LINE_LEN:
        if p in changes:
            c = cons.get(p, ".")
            pat.append(c)
            rep.append(changes[p])
            p += 1
        else:
            q = p
            while q < LINE_LEN and q not in changes:
                q += 1
            s, gap = render(cons, p, q)
            if gap:
                s += "." if gap == 1 else ".{%d}" % gap
            g += 1
            pat.append("(" + s + ")")
            rep.append(r"\g<%d>" % g)
            p = q
    pat.append(r"\n)")
    rep.append("\n")
    gen.append(["".join(pat), "".join(rep)])


for f in range(8):
    for r in range(1, 9):
        s = sq(f, r)
        # knights
        for df, dr in [
            (1, 2),
            (2, 1),
            (-1, 2),
            (-2, 1),
            (1, -2),
            (2, -1),
            (-1, -2),
            (-2, -1),
        ]:
            if onb(f + df, r + dr):
                t = sq(f + df, r + dr)
                add_move({s: "N", t: NOTWHITE}, {s: EMPTY, t: "N"})
        # king
        for df in (-1, 0, 1):
            for dr in (-1, 0, 1):
                if (df or dr) and onb(f + df, r + dr):
                    t = sq(f + df, r + dr)
                    add_move({s: "K", t: NOTWHITE}, {s: EMPTY, t: "K"})
        # sliders
        for piece, dirs in [
            ("R", [(1, 0), (-1, 0), (0, 1), (0, -1)]),
            ("B", [(1, 1), (1, -1), (-1, 1), (-1, -1)]),
            (
                "Q",
                [(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)],
            ),
        ]:
            for df, dr in dirs:
                path = []
                ff, rr = f + df, r + dr
                while onb(ff, rr):
                    t = sq(ff, rr)
                    c = {p: EMPTY for p in path}
                    c[s] = piece
                    c[t] = NOTWHITE
                    add_move(c, {s: EMPTY, t: piece})
                    path.append(t)
                    ff += df
                    rr += dr
        # pawns
        if 2 <= r <= 7:
            np = "Q" if r == 7 else "P"
            t = sq(f, r + 1)
            add_move({s: "P", t: EMPTY}, {s: EMPTY, t: np})
            if r == 2:
                t2 = sq(f, 4)
                add_move(
                    {s: "P", t: EMPTY, t2: EMPTY},
                    {s: EMPTY, t2: "P", EP: "abcdefgh"[f]},
                )
            for df in (-1, 1):
                if onb(f + df, r + 1):
                    t = sq(f + df, r + 1)
                    add_move({s: "P", t: BLACK}, {s: EMPTY, t: np})
            if r == 5:
                for df in (-1, 1):
                    if onb(f + df, 6):
                        t = sq(f + df, 6)
                        cap = sq(f + df, 5)
                        add_move(
                            {s: "P", t: EMPTY, cap: "p", EP: "abcdefgh"[f + df]},
                            {s: EMPTY, t: "P", cap: EMPTY},
                        )

# castling
e1, f1, g1, h1, d1, c1, b1, a1 = (
    sq(4, 1),
    sq(5, 1),
    sq(6, 1),
    sq(7, 1),
    sq(3, 1),
    sq(2, 1),
    sq(1, 1),
    sq(0, 1),
)
noatt = "(?!%s)(?!%s)" % (attack_lookahead_body(4, 1), attack_lookahead_body(5, 1))
add_move(
    {e1: "K", f1: EMPTY, g1: EMPTY, h1: "R", CK: "K"},
    {e1: EMPTY, f1: "R", g1: "K", h1: EMPTY},
    noatt,
)
noatt = "(?!%s)(?!%s)" % (attack_lookahead_body(4, 1), attack_lookahead_body(3, 1))
add_move(
    {e1: "K", d1: EMPTY, c1: EMPTY, b1: EMPTY, a1: "R", CQ: "Q"},
    {e1: EMPTY, d1: "R", c1: "K", a1: EMPTY},
    noatt,
)

rules.extend(gen)

# remove original line
rules.append([r"(?m)^@.*\n", ""])

# ---------- legality filter: delete lines where white king attacked ----------
for f in range(8):
    for r in range(1, 9):
        k = sq(f, r) - 1
        rules.append(
            [r"(?m)^#(?=.{%d}K)(?=%s).*\n" % (k, attack_lookahead_body(f, r)), ""]
        )


# ---------- castling rights update ----------
def rights(cond_pos, notch, right_pos):
    pat = r"(?m)^(#.{%d}[^%s].{%d})[A-Za-z]" % (
        cond_pos - 1,
        notch,
        right_pos - cond_pos - 1,
    )
    rules.append([pat, r"\1x"])


rights(sq(4, 1), "K", CK)
rights(sq(4, 1), "K", CQ)
rights(sq(7, 1), "R", CK)
rights(sq(0, 1), "R", CQ)
rights(sq(4, 8), "k", Ck)
rights(sq(4, 8), "k", Cq)
rights(sq(7, 8), "r", Ck)
rights(sq(0, 8), "r", Cq)

# ---------- output formatting ----------
rules.append(
    [
        r"(?m)^#" + "(.{8})" * 8 + "(....)(.)$",
        "/".join(r"\g<%d>" % i for i in range(1, 9)) + r" b \g<9> \g<10> 0 0",
    ]
)
rules.append([r"(?m) ([a-h]) 0 0$", r" \g<1>3 0 0"])
rules.append([r" b xxxx ", " b - "])
rules.append([r"x", ""])
for d in range(8, 1, -1):
    rules.append(["1" * d, str(d)])
rules.append([r"\n\Z", ""])

json.dump(rules, open("re.json", "w"))
print(len(rules), "rules", len(json.dumps(rules)), "bytes")
