// \
/*
#include <cstdio>
#include <cstdlib>
int main(int argc, char **argv) {
    if (argc < 2) { std::fprintf(stderr, "usage: %s N\n", argv[0]); return 1; }
    long n = std::strtol(argv[1], nullptr, 10);
    unsigned long long a = 1, b = 1;
    for (long i = 0; i < n; i++) { unsigned long long t = a + b; a = b; b = t; }
    std::printf("%llu\n", a);
    return 0;
}
#if 0
*/
fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.len() < 2 {
        eprintln!("usage: {} N", args[0]);
        std::process::exit(1);
    }
    let n: u64 = args[1].trim().parse().expect("N must be a non-negative integer");
    let (mut a, mut b): (u64, u64) = (1, 1);
    for _ in 0..n {
        let t = a.wrapping_add(b);
        a = b;
        b = t;
    }
    println!("{}", a);
}
// \
/*
#endif
// \
*/
