"""Recover A1 (up to row permutation and scaling) of f(x) = A2 ReLU(A1 x + b1) + b2
using only black-box queries to forward(x).

Idea: along a random line x0 + t*d, f is piecewise linear; each kink is where one
hidden neuron's pre-activation crosses zero. At such a point the change in the
input gradient of f is a2_i * A1[i,:], i.e. proportional to row i of A1.
"""
import os
import numpy as np
from forward import forward

DIM = 10
rng = np.random.default_rng(12345)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def line_fn(x0, d):
    return lambda t: f(x0 + t * d)


def find_kinks(g, a, b, ga, gb, out, depth=0, tol=1e-12):
    """Recursively locate kinks of 1-D piecewise-linear g on [a, b]."""
    m = 0.5 * (a + b)
    gm = g(m)
    q1, q3 = 0.5 * (a + m), 0.5 * (m + b)
    g1, g3 = g(q1), g(q3)
    scale = max(1.0, abs(ga), abs(gb))
    lin = lambda ta, va, tb, vb, t: va + (vb - va) * (t - ta) / (tb - ta)
    err = max(abs(gm - lin(a, ga, b, gb, m)),
              abs(g1 - lin(a, ga, b, gb, q1)),
              abs(g3 - lin(a, ga, b, gb, q3)))
    if err < tol * scale:
        return
    if b - a < 1e-5 or depth > 60:
        out.append(m)
        return
    find_kinks(g, a, m, ga, gm, out, depth + 1, tol)
    find_kinks(g, m, b, gm, gb, out, depth + 1, tol)


def refine_kink(g, t, w=2e-6):
    """Refine kink location by intersecting left and right linear pieces."""
    a, b = t - 10 * w, t + 10 * w
    s_l = (g(a + w) - g(a)) / w
    s_r = (g(b) - g(b - w)) / w
    if abs(s_r - s_l) < 1e-12:
        return t
    # line_l: g(a) + s_l (x-a); line_r: g(b) + s_r (x-b)
    x = (g(b) - g(a) + s_l * a - s_r * b) / (s_l - s_r)
    if a <= x <= b:
        return x
    return t


def grad(x, h=1e-7):
    g = np.zeros(DIM)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = h
        g[i] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def normalize(v):
    v = v / np.linalg.norm(v)
    k = np.argmax(np.abs(v))
    return v * np.sign(v[k])


def main():
    rows = []        # list of representative normalized directions
    counts = []
    lines_without_new = 0
    n_lines = 0
    R = 100.0
    while lines_without_new < 50 and n_lines < 1000:
        n_lines += 1
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        g = line_fn(x0, d)
        # coarse grid then recursive search per cell
        ts = np.linspace(-R, R, 401)
        vs = [g(t) for t in ts]
        kinks = []
        for i in range(len(ts) - 1):
            find_kinks(g, ts[i], ts[i + 1], vs[i], vs[i + 1], kinks)
        found_new = False
        for t in kinks:
            t = refine_kink(g, t)
            x = x0 + t * d
            delta = 1e-4
            gl = grad(x - delta * d)
            gr = grad(x + delta * d)
            diff = gr - gl
            if np.linalg.norm(diff) < 1e-8:
                continue
            v = normalize(diff)
            matched = False
            for j, r in enumerate(rows):
                if np.linalg.norm(v - r) < 1e-4:
                    counts[j] += 1
                    matched = True
                    break
            if not matched:
                rows.append(v)
                counts.append(1)
                found_new = True
        lines_without_new = 0 if found_new else lines_without_new + 1

    # Keep directions seen more than once to discard spurious detections
    # (e.g. two kinks too close together), unless only seen rarely overall.
    A = np.array([r for r, c in zip(rows, counts) if c >= 2])
    print(f"Lines used: {n_lines}; recovered {A.shape[0]} neurons")
    np.save(OUT, A)
    print(A)
    return A


if __name__ == "__main__":
    main()
