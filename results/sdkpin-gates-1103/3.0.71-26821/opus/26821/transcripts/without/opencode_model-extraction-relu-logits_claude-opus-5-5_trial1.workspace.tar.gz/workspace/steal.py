"""Extract A1 (up to neuron permutation and scaling) from a 1-hidden-layer ReLU
network using only black-box queries to forward(x).

Method (Carlini et al. style "critical point" attack):
  1. Walk along random lines x0 + t*d and locate kinks (critical points) where
     some hidden neuron's pre-activation crosses zero.
  2. At each critical point, the gradient of f jumps by a2_i * A1[i, :].
     Measuring gradients on both sides of the kink recovers row i up to scale.
  3. Normalize, deduplicate, and stack the unique rows.
"""
import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def grad(x, h=1e-6):
    g = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        g[j] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def find_kinks(x0, d, lo, hi, n_seg=100, h=1e-7, slope_tol=1e-7, val_tol=1e-11):
    """Return t-values of kinks of g(t)=f(x0+t d) in [lo, hi].

    On each interval compare the one-sided slopes at both ends. If they agree
    the interval is linear. Otherwise intersect the two end lines; if g at the
    intersection matches the prediction there is exactly one kink there,
    otherwise bisect and recurse.
    """
    g = lambda t: f(x0 + t * d)
    kinks = []

    def rec(a, b, depth=0):
        if b - a < 4 * h or depth > 60:
            return
        fa, fb = g(a), g(b)
        sa = (g(a + h) - fa) / h
        sb = (fb - g(b - h)) / h
        if abs(sa - sb) < slope_tol:
            return
        # intersection of lines fa + sa (t-a) and fb + sb (t-b)
        t = (fb - fa + sa * a - sb * b) / (sa - sb)
        if a + h < t < b - h:
            pred = fa + sa * (t - a)
            if abs(g(t) - pred) < val_tol * (1 + abs(pred)):
                kinks.append(t)
                return
        m = 0.5 * (a + b)
        rec(a, m, depth + 1)
        rec(m, b, depth + 1)

    ts = np.linspace(lo, hi, n_seg + 1)
    for i in range(n_seg):
        rec(ts[i], ts[i + 1])
    # merge near-duplicates
    kinks.sort()
    merged = []
    for k in kinks:
        if not merged or k - merged[-1] > 1e-6:
            merged.append(k)
    return merged


def canon(v):
    v = v / np.linalg.norm(v)
    i = np.argmax(np.abs(v))
    return v * np.sign(v[i])


rows = []
counts = []
no_new = 0
for it in range(200):
    x0 = rng.normal(size=DIM)
    d = rng.normal(size=DIM)
    d /= np.linalg.norm(d)
    found_new = False
    for t in find_kinks(x0, d, -15.0, 15.0):
        xc = x0 + t * d
        delta = 1e-4
        diff = grad(xc + delta * d) - grad(xc - delta * d)
        if np.linalg.norm(diff) < 1e-8:
            continue
        r = canon(diff)
        for k, existing in enumerate(rows):
            if np.linalg.norm(existing - r) < 1e-3:
                counts[k] += 1
                break
        else:
            rows.append(r)
            counts.append(1)
            found_new = True
    no_new = 0 if found_new else no_new + 1
    if it >= 10 and no_new >= 15:
        break

# keep rows seen more than once when possible (filters spurious double-kinks)
rows = np.array(rows)
counts = np.array(counts)
if (counts > 1).sum() > 0:
    rows = rows[counts > 1]

print("Recovered %d neurons" % len(rows))
np.set_printoptions(precision=5, suppress=True, linewidth=150)
print(rows)
np.save(OUT, rows)
