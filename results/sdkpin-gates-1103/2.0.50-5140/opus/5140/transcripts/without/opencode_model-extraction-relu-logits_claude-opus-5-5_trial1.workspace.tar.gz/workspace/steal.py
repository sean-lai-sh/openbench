"""
Black-box extraction of the first-layer weights A1 of a one-hidden-layer ReLU
network  f(x) = A2 relu(A1 x + b1) + b2  using only queries to forward(x).

Method:
 1. Along random lines x0 + t d, f is piecewise linear; locate the kinks
    (critical points where one hidden neuron changes state) by recursive
    bisection + line intersection.
 2. At each kink, the gradient difference across the kink is proportional to
    the corresponding row of A1. Collect, normalise, deduplicate.
 3. Resolve the sign of every row (which side of its hyperplane the neuron is
    active on) by fitting gradients at random points with a linear model.
"""

import os
import numpy as np
from forward import forward

D = 10
rng = np.random.default_rng(12345)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")

nq = 0


def f(x):
    global nq
    nq += 1
    return forward(np.asarray(x, dtype=np.float64))


def grad(x, h=1e-5):
    f0 = f(x)
    g = np.empty(D)
    for j in range(D):
        e = np.zeros(D)
        e[j] = h
        g[j] = (f(x + e) - f0) / h
    return g


def find_kinks(x0, d, lo, hi):
    """Return list of t values where f(x0 + t d) has a kink in [lo, hi]."""
    g = lambda t: f(x0 + t * d)
    kinks = []
    h = 1e-6

    def slope_at(t, side):
        if side > 0:
            return (g(t + h) - g(t)) / h
        return (g(t) - g(t - h)) / h

    def rec(a, b, fa, fb, sa, sb, depth):
        # sa: slope just right of a; sb: slope just left of b
        scale = 1e-9 * (abs(fa) + abs(fb) + 1e-3)
        if (
            abs(sa - sb) < 1e-9 * (abs(sa) + abs(sb) + 1e-6)
            and abs(fa + sa * (b - a) - fb) < scale
        ):
            return  # linear on [a, b]
        # try single-kink hypothesis: intersect the two lines
        if abs(sa - sb) > 1e-12:
            tk = (fb - fa + sa * a - sb * b) / (sa - sb)
            if a < tk < b:
                fk = g(tk)
                pred = fa + sa * (tk - a)
                if abs(fk - pred) < scale and depth > 0:
                    # verify: midpoints of both halves lie on their lines
                    m1, m2 = (a + tk) / 2, (tk + b) / 2
                    if (
                        abs(g(m1) - (fa + sa * (m1 - a))) < scale
                        and abs(g(m2) - (fb + sb * (m2 - b))) < scale
                    ):
                        kinks.append(tk)
                        return
        if b - a < 1e-7 or depth > 60:
            return
        m = (a + b) / 2
        fm = g(m)
        rec(a, m, fa, fm, sa, slope_at(m, -1), depth + 1)
        rec(m, b, fm, fb, slope_at(m, +1), sb, depth + 1)

    rec(lo, hi, g(lo), g(hi), slope_at(lo, +1), slope_at(hi, -1), 0)
    return kinks


def main():
    rows = []  # unit normals (unsigned)
    biases = []  # offsets so that n.x + beta = 0 on the hyperplane
    n_lines = 0
    stale = 0
    while stale < 15 and n_lines < 300:
        n_lines += 1
        x0 = rng.normal(size=D)
        d = rng.normal(size=D)
        d /= np.linalg.norm(d)
        new = 0
        for t in find_kinks(x0, d, -20.0, 20.0):
            xk = x0 + t * d
            # step along d away from the kink, check gradient difference
            diffs = []
            for delta in (1e-3, 3e-4):
                diffs.append(grad(xk + delta * d, 1e-8) - grad(xk - delta * d, 1e-8))
            diff = diffs[0]
            nrm = np.linalg.norm(diff)
            if nrm < 1e-6 or np.linalg.norm(diffs[0] - diffs[1]) > 1e-4 * nrm:
                continue  # inconsistent (nearby second kink / noise)
            n = diff / nrm
            # canonical orientation for dedup
            n = n * np.sign(n[np.argmax(np.abs(n))])
            beta = -n @ xk
            dup = False
            for i, r in enumerate(rows):
                if abs(abs(r @ n) - 1) < 1e-5 and abs(beta - biases[i]) < 1e-3 * (
                    1 + abs(beta)
                ):
                    dup = True
                    break
            if not dup:
                rows.append(n)
                biases.append(beta)
                new += 1
        stale = 0 if new else stale + 1

    N = np.array(rows)
    B = np.array(biases)
    k = len(N)
    print(f"found {k} neurons using {n_lines} lines, {nq} queries")

    # ---- sign recovery ----
    # gradient(x) = sum_i p_i r_i h_i(x) + c,  h_i = 1[n_i.x+beta_i>0]
    # If neuron i is active on the + side of its hyperplane it contributes
    # nothing to c; if active on the - side it contributes -p_i r_i to c.
    # So find z in {0,1}^k with sum_i z_i (-p_i r_i) = c  (z_i=1 => flip).
    rowsM, rhs = [], []
    for _ in range(max(40, 6 * k)):
        x = rng.normal(size=D) * 3
        gx = grad(x, 1e-8)
        hx = (N @ x + B > 0).astype(float)
        rowsM.append(np.concatenate([N.T * hx, np.eye(D)], axis=1))
        rhs.append(gx)
    sol, *_ = np.linalg.lstsq(np.vstack(rowsM), np.concatenate(rhs), rcond=None)
    p, c = sol[:k], sol[k:]
    V = -(p[:, None] * N)  # k x D, candidate contributions to c

    def subset_sums(idx):
        m = len(idx)
        bits = ((np.arange(2 ** m)[:, None] >> np.arange(m)) & 1).astype(float)
        return bits, bits @ V[idx]

    h1 = list(range(k // 2))
    h2 = list(range(k // 2, k))
    bits1, s1 = subset_sums(h1)
    bits2, s2 = subset_sums(h2)
    best, bi, bj = np.inf, 0, 0
    target = c - s2  # want s1 = c - s2
    for j0 in range(0, len(target), 256):
        T = target[j0:j0 + 256]
        dist = ((s1[:, None, :] - T[None, :, :]) ** 2).sum(-1)
        a, b = np.unravel_index(np.argmin(dist), dist.shape)
        if dist[a, b] < best:
            best, bi, bj = dist[a, b], a, j0 + b
    z = np.concatenate([bits1[bi], bits2[bj]])
    print("sign-fit residual:", np.sqrt(best), " |c| =", np.linalg.norm(c))
    signs = 1.0 - 2.0 * z
    A1_hat = N * signs[:, None]

    np.save(OUT, A1_hat)
    print("stolen A1 (rows unit-normalised, shape %s):" % (A1_hat.shape,))
    np.set_printoptions(precision=5, suppress=True, linewidth=150)
    print(A1_hat)
    return A1_hat


if __name__ == "__main__":
    main()
