"""
Extract the first-layer weights A1 of f(x) = A2 ReLU(A1 x + b1) + b2 using only
black-box queries to forward().

Method (critical-point / kink search):
  1. Along random lines x0 + t d, f is piecewise linear; find the kinks with
     bisection. Each kink is a point where some neuron's pre-activation is 0.
  2. At each kink, gradient(after) - gradient(before) is proportional to that
     neuron's weight row.
  3. Cluster the recovered directions (up to sign) -> one row per neuron.
  4. Recover the true sign of each row from the global gradient structure.
"""

import os
import sys
import itertools
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from forward import forward  # noqa: E402

DIM = 10
OUT = os.path.join(HERE, "stolen_A1.npy")
rng = np.random.default_rng(1234)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi, tol=1e-13, width=1e-5):
    g = lambda t: f(x0 + t * d)
    lin = lambda fa, fm, fb: abs(fm - 0.5 * (fa + fb)) <= tol * (1 + abs(fa) + abs(fb))
    kinks = []
    stack = [(lo, hi, g(lo), g(hi))]
    while stack:
        a, b, fa, fb = stack.pop()
        m = 0.5 * (a + b)
        fm = g(m)
        if lin(fa, fm, fb):
            q1, q3 = 0.5 * (a + m), 0.5 * (m + b)
            if lin(fa, g(q1), fm) and lin(fm, g(q3), fb):
                continue
        if b - a < width:
            kinks.append(m)
            continue
        stack.append((a, m, fa, fm))
        stack.append((m, b, fm, fb))
    kinks.sort()
    merged = []
    for k in kinks:
        if not merged or k - merged[-1] > 10 * width:
            merged.append(k)
    return merged


def grad(x, h=1e-6):
    """Finite-difference gradient; None if f is not linear around x."""
    gv = np.zeros(DIM)
    f0 = f(x)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = h
        fp, fm = f(x + e), f(x - e)
        if abs((fp - f0) - (f0 - fm)) > 1e-12:
            return None
        gv[i] = (fp - fm) / (2 * h)
    return gv


def collect(n_lines=40):
    """Return list of (diff, d, x_kink) for every kink found."""
    out = []
    for _ in range(n_lines):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        ks = find_kinks(x0, d, -30.0, 30.0)
        for i, t in enumerate(ks):
            gaps = [1e-2]
            if i > 0:
                gaps.append((t - ks[i - 1]) / 3)
            if i < len(ks) - 1:
                gaps.append((ks[i + 1] - t) / 3)
            delta = min(gaps)
            if delta < 1e-4:
                continue
            gp = grad(x0 + (t + delta) * d)
            gm = grad(x0 + (t - delta) * d)
            if gp is None or gm is None:
                continue
            diff = gp - gm
            if np.linalg.norm(diff) < 1e-9:
                continue
            out.append((diff, d, x0 + t * d))
    return out, n_lines


def main():
    obs, n_lines = collect()

    # --- cluster directions up to sign ---
    clusters = []
    for diff, d, x in obs:
        u = diff / np.linalg.norm(diff)
        for c in clusters:
            if abs(np.dot(c["u"], u)) > 0.9999:
                c["members"].append((diff, d, x))
                break
        else:
            clusters.append({"u": u, "members": [(diff, d, x)]})

    min_count = max(2, n_lines // 4)
    neurons = []
    for c in clusters:
        if len(c["members"]) < min_count:
            continue
        u0 = c["u"]
        dirs, ts, betas = [], [], []
        for diff, d, x in c["members"]:
            v = diff * np.sign(np.dot(diff, u0))
            dirs.append(v / np.linalg.norm(v))
        w_hat = np.median(np.array(dirs), axis=0)
        w_hat /= np.linalg.norm(w_hat)
        for diff, d, x in c["members"]:
            # gradient change when crossing into the w_hat-positive side
            ts.append(diff * np.sign(np.dot(w_hat, d)))
            betas.append(-np.dot(w_hat, x))
        neurons.append((w_hat, np.median(np.array(ts), axis=0), np.median(betas)))

    n = len(neurons)
    W = np.array([nw[0] for nw in neurons])
    T = np.array([nw[1] for nw in neurons])
    B = np.array([nw[2] for nw in neurons])
    print(f"Recovered {n} neurons")

    # --- sign recovery ---
    # grad(x) = sum_j T_j 1[W_j x + B_j > 0] - sum_{j: sign_j = -1} T_j
    targets = []
    for _ in range(10):
        x = rng.normal(size=DIM)
        g = grad(x)
        if g is None:
            continue
        act = (W @ x + B) > 0
        targets.append(T[act].sum(axis=0) - g)
    target = np.median(np.array(targets), axis=0)

    signs = np.ones(n)
    if n <= 26:
        nl = min(n, 16)
        low = np.array(list(itertools.product([0, 1], repeat=nl)), dtype=float)
        low_sums = low @ T[:nl]
        rest = n - nl
        best, best_err = None, np.inf
        for hi in itertools.product([0, 1], repeat=rest):
            hi = np.array(hi, dtype=float)
            base = hi @ T[nl:] if rest else np.zeros(DIM)
            errs = np.linalg.norm(low_sums + base - target, axis=1)
            k = int(np.argmin(errs))
            if errs[k] < best_err:
                best_err = errs[k]
                best = np.concatenate([low[k], hi])
        print(f"sign recovery residual: {best_err:.3e}")
        signs = np.where(best == 1, -1.0, 1.0)
    else:
        print("Too many neurons for exhaustive sign recovery; signs left canonical.")

    A1 = W * signs[:, None]
    np.save(OUT, A1)
    print(A1)


if __name__ == "__main__":
    main()
