import os
import numpy as np
from forward import forward

D = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(1)


def f_line(p, d, ts):
    return np.array([forward(p + t * d) for t in ts])


def grad(x, eps=1e-7):
    g = np.zeros(D)
    for i in range(D):
        e = np.zeros(D)
        e[i] = eps
        g[i] = (forward(x + e) - forward(x - e)) / (2 * eps)
    return g


def find_kinks(p, d, R=4.0, N=400):
    ts = np.linspace(-R, R, N + 1)
    ys = f_line(p, d, ts)
    h = ts[1] - ts[0]
    sl = np.diff(ys) / h
    res = []
    ch = np.abs(np.diff(sl)) > 1e-7
    M = len(ch)
    j = 0
    while j < M - 1:
        if ch[j] and ch[j + 1] and (j == 0 or not ch[j - 1]) and (j + 2 >= M or not ch[j + 2]):
            sL, sR = sl[j], sl[j + 2]
            ta, fa = ts[j], ys[j]
            tb, fb = ts[j + 3], ys[j + 3]
            tstar = (fb - fa - sR * tb + sL * ta) / (sL - sR)
            if ts[j + 1] - 1e-9 <= tstar <= ts[j + 2] + 1e-9:
                res.append(tstar)
            j += 3
        else:
            j += 1
    return res


dirs = []
for _ in range(250):
    p = rng.normal(size=D)
    d = rng.normal(size=D)
    d /= np.linalg.norm(d)
    for ts in find_kinks(p, d):
        dl = 2e-5
        xl = p + (ts - dl) * d
        xr = p + (ts + dl) * d
        gl, gr = grad(xl), grad(xr)
        v = gr - gl
        n = np.linalg.norm(v)
        if n < 1e-6:
            continue
        v /= n
        k = np.argmax(np.abs(v))
        if v[k] < 0:
            v = -v
        dirs.append(v)

dirs = np.array(dirs)
centers, counts = [], []
for v in dirs:
    for j, c in enumerate(centers):
        if np.linalg.norm(v - c / np.linalg.norm(c)) < 1e-3 or np.linalg.norm(v + c / np.linalg.norm(c)) < 1e-3:
            s = 1 if np.dot(v, c) > 0 else -1
            centers[j] = c + s * v
            counts[j] += 1
            break
    else:
        centers.append(v.copy())
        counts.append(1)

rows = [c / np.linalg.norm(c) for c, n in zip(centers, counts) if n >= 3]
A = np.array(rows)
np.save(OUT, A)
print(A.shape)
print(A)
