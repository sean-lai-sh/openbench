import os
import numpy as np
from forward import forward

D = 10
rng = np.random.default_rng(1)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")


def grad(x, h=1e-6):
    g = np.zeros(D)
    for k in range(D):
        e = np.zeros(D)
        e[k] = h
        g[k] = (forward(x + e) - forward(x - e)) / (2 * h)
    return g


def kinks_on_line(p, d, R, n):
    ts = np.linspace(-R, R, n)
    f = np.array([forward(p + t * d) for t in ts])
    s = np.diff(f) / np.diff(ts)
    scale = max(1e-12, np.abs(s).max())
    tol = 1e-8 * scale
    res = []
    for j in range(2, len(s) - 2):
        if abs(s[j - 1] - s[j - 2]) < tol and abs(s[j + 1] - s[j + 2]) < tol \
                and abs(s[j + 1] - s[j - 1]) > 1e-6 * scale:
            a0 = f[j] - s[j - 1] * ts[j]
            a1 = f[j + 1] - s[j + 1] * ts[j + 1]
            tk = (a1 - a0) / (s[j - 1] - s[j + 1])
            if ts[j] - 1e-9 <= tk <= ts[j + 1] + 1e-9:
                res.append(tk)
    return res


dirs = []
for it in range(400):
    p = rng.normal(size=D) * rng.choice([0.5, 3, 10])
    d = rng.normal(size=D)
    d /= np.linalg.norm(d)
    R = 40.0
    for tk in kinks_on_line(p, d, R, 4001):
        delta = 1e-4
        xl = p + (tk - delta) * d
        xr = p + (tk + delta) * d
        diff = grad(xr) - grad(xl)
        nrm = np.linalg.norm(diff)
        if nrm < 1e-6:
            continue
        diff /= nrm
        if abs(np.dot(grad(p + (tk - 2 * delta) * d), grad(xl))) < 0:
            continue
        dirs.append(diff)

clusters = []
for v in dirs:
    for c in clusters:
        ref = c[0]
        if abs(np.dot(ref, v)) > 0.9999:
            c.append(v if np.dot(ref, v) > 0 else -v)
            break
    else:
        clusters.append([v])

rows = []
for c in clusters:
    if len(c) >= 2:
        m = np.mean(c, axis=0)
        rows.append(m / np.linalg.norm(m))
A = np.array(rows)
print("found", len(rows), "neurons; single-hit clusters:", sum(len(c) == 1 for c in clusters))
np.save(OUT, A)
