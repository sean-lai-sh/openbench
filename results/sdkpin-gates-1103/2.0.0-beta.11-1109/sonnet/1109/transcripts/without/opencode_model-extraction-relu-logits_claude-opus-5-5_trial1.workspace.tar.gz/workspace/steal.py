import numpy as np
from forward import forward

rng = np.random.default_rng(12345)
DIM = 10
R = 6.0
N = 600
H = 1e-7
DELTA = 1e-5
EPS = 1e-8


def f(x):
    return forward(x)


def line_f(p, d, t):
    return f(p + t * d)


def slope(p, d, t, direction):
    return direction * (line_f(p, d, t + direction * H) - line_f(p, d, t)) / H


def find_kinks(p, d, a, b, fa, fb, depth=0):
    sa = slope(p, d, a, 1)
    sb = slope(p, d, b, -1)
    if abs(sa - sb) < 1e-5:
        mid = 0.5 * (a + b)
        fm = line_f(p, d, mid)
        if abs(fm - (fa + sa * (mid - a))) < 1e-9:
            return []
        if depth > 40:
            return []
    else:
        denom = sa - sb
        t = (fb - fa - sb * (b - a) + sa * 0) / 1.0
        ts = (fb - sb * b - fa + sa * a) / denom
        if a <= ts <= b:
            ft = line_f(p, d, ts)
            pred = fa + sa * (ts - a)
            if abs(ft - pred) < 1e-9 and abs(ft - (fb + sb * (ts - b))) < 1e-9:
                return [ts]
        if depth > 40 or (b - a) < 1e-9:
            return []
    mid = 0.5 * (a + b)
    fm = line_f(p, d, mid)
    return find_kinks(p, d, a, mid, fa, fm, depth + 1) + find_kinks(p, d, mid, b, fm, fb, depth + 1)


def grad(x):
    g = np.zeros(DIM)
    f0 = f(x)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = EPS
        g[i] = (f(x + e) - f0) / EPS
    return g


def kink_direction(p, d, t):
    x = p + t * d
    gl = grad(x - DELTA * d)
    gr = grad(x + DELTA * d)
    v = gr - gl
    n = np.linalg.norm(v)
    if n < 1e-4:
        return None
    v = v / n
    if abs(v @ d) < 1e-6 and False:
        return None
    return v


def collect(nlines):
    dirs = []
    for _ in range(nlines):
        p = rng.normal(size=DIM) * 0.5
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        ts = np.linspace(-R, R, N + 1)
        fs = np.array([line_f(p, d, t) for t in ts])
        for i in range(N):
            for k in find_kinks(p, d, ts[i], ts[i + 1], fs[i], fs[i + 1]):
                v = kink_direction(p, d, k)
                if v is not None:
                    dirs.append(v)
    return dirs


def cluster(dirs, tol=1e-3):
    centers = []
    members = []
    for v in dirs:
        for j, c in enumerate(centers):
            cc = c / np.linalg.norm(c)
            cs = v @ cc
            if abs(cs) > 1 - tol:
                members[j].append(v if cs > 0 else -v)
                centers[j] = np.mean(members[j], axis=0)
                break
        else:
            centers.append(v.copy())
            members.append([v])
    return centers, members


def main():
    dirs = []
    stable = 0
    last = -1
    for it in range(200):
        dirs += collect(5)
        centers, members = cluster(dirs)
        good = [c for c, m in zip(centers, members) if len(m) >= 3]
        cnt = len(good)
        if cnt == last:
            stable += 1
        else:
            stable = 0
        last = cnt
        if stable >= 15:
            break
    rows = []
    for c in good:
        c = c / np.linalg.norm(c)
        rows.append(c)
    A = np.array(rows)
    np.save("/tmp/obench-cell-56h0vct8/bench_opencode_model-extraction-relu-logits_6i0aubtg/stolen_A1.npy", A)
    print(A.shape)
    print(A)


if __name__ == "__main__":
    main()
