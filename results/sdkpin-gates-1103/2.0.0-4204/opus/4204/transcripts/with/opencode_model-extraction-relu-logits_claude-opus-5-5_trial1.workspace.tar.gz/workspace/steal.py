"""Black-box extraction of A1 (up to row permutation and scaling) for
f(x) = A2 @ ReLU(A1 @ x + b1) + b2, using only queries to forward().

Approach: along random lines through input space f is piecewise linear;
each kink is where some hidden neuron's pre-activation crosses zero.
At a kink, the gradient jump of f equals A2[i] * A1[i], i.e. the row of A1
up to scale. We collect these directions and de-duplicate them.
"""

import os
import numpy as np
from forward import forward

DIM = 10
rng = np.random.default_rng(12345)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, a, b, fa, fb, out, depth=0):
    """Recursively locate kinks of g(t)=f(x0+t d) on [a,b]."""
    m = 0.5 * (a + b)
    fm = f(x0 + m * d)
    q1, q3 = a + 0.25 * (b - a), a + 0.75 * (b - a)
    f1, f3 = f(x0 + q1 * d), f(x0 + q3 * d)
    tol = 1e-11 * (1 + abs(fa) + abs(fb))
    lin = (
        abs(fm - 0.5 * (fa + fb)) < tol
        and abs(f1 - (0.75 * fa + 0.25 * fb)) < tol
        and abs(f3 - (0.25 * fa + 0.75 * fb)) < tol
    )
    if lin:
        return
    if b - a < 1e-5 or depth > 60:
        out.append(refine(x0, d, a, b))
        return
    find_kinks(x0, d, a, m, fa, fm, out, depth + 1)
    find_kinks(x0, d, m, b, fm, fb, out, depth + 1)


def refine(x0, d, a, b):
    """Intersect the linear pieces on either side of [a,b] to locate the kink."""
    h = 1e-6
    ga, gb = f(x0 + a * d), f(x0 + b * d)
    sa = (ga - f(x0 + (a - h) * d)) / h
    sb = (f(x0 + (b + h) * d) - gb) / h
    if abs(sa - sb) < 1e-12:
        return 0.5 * (a + b)
    # ga + sa (t-a) = gb + sb (t-b)
    t = (gb - ga + sa * a - sb * b) / (sa - sb)
    return float(np.clip(t, a, b))


def grad(x, h=1e-6):
    g = np.zeros(DIM)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = h
        g[i] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def normalize(v):
    v = v / np.linalg.norm(v)
    k = np.argmax(np.abs(v))
    return v * np.sign(v[k])


def steal(max_lines=400, patience=60, T=20.0, n_init=64):
    rows = []
    since_new = 0
    for _ in range(max_lines):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        # coarse grid then recursive search on each cell
        ts = np.linspace(-T, T, n_init + 1)
        fs = [f(x0 + t * d) for t in ts]
        kinks = []
        for j in range(n_init):
            find_kinks(x0, d, ts[j], ts[j + 1], fs[j], fs[j + 1], kinks)
        found_new = False
        for t in kinks:
            xs = x0 + t * d
            delta = 1e-4
            diff = grad(xs + delta * d) - grad(xs - delta * d)
            if np.linalg.norm(diff) < 1e-8:
                continue
            v = normalize(diff)
            if all(abs(np.dot(v, r)) < 0.9999 for r in rows):
                rows.append(v)
                found_new = True
        since_new = 0 if found_new else since_new + 1
        if since_new >= patience:
            break
    return np.array(rows)


if __name__ == "__main__":
    A1_hat = steal()
    np.save(OUT, A1_hat)
    print(f"Recovered {A1_hat.shape[0]} neurons; shape {A1_hat.shape}")
    print(A1_hat)
