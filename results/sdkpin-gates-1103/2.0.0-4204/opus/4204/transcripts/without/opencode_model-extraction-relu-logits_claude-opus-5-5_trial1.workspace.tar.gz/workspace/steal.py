"""
Extract A1 (up to neuron permutation and row scaling) from a one-hidden-layer
ReLU network f(x) = A2 ReLU(A1 x + b1) + b2 using only black-box queries.

Method:
  1. Walk along random lines x(t) = x0 + t*d and locate the kinks (critical
     points) where some hidden neuron switches on/off.
  2. At each kink, compute the gradient of f on both sides. The difference
     equals +/- a2_i * A1[i, :], i.e. the row of A1 up to scale.
  3. Normalize, de-duplicate and stack the rows.
"""

import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from forward import forward  # noqa: E402

DIM = 10
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def line_fn(x0, d):
    return lambda t: f(x0 + t * d)


def find_kinks(g, a, b, ga, gb, out, depth=0, tol=1e-9):
    """Recursively find kinks of piecewise-linear 1D function g on [a, b]."""
    m = 0.5 * (a + b)
    gm = g(m)
    q1, q3 = 0.5 * (a + m), 0.5 * (m + b)
    g1, g3 = g(q1), g(q3)
    scale = max(1.0, abs(ga), abs(gb))
    lin = (
        abs(gm - 0.5 * (ga + gb)) < tol * scale
        and abs(g1 - 0.5 * (ga + gm)) < tol * scale
        and abs(g3 - 0.5 * (gm + gb)) < tol * scale
    )
    if lin:
        return
    if b - a < 1e-3 or depth > 60:
        # Try to resolve a single kink by intersecting the end slopes.
        e = (b - a) * 1e-3
        sl = (g(a + e) - ga) / e
        sr = (gb - g(b - e)) / e
        if abs(sl - sr) < 1e-12:
            return
        t = (gb - ga + sl * a - sr * b) / (sl - sr)
        if a < t < b:
            pred = ga + sl * (t - a)
            if abs(g(t) - pred) < 1e-8 * scale:
                out.append(t)
                return
        if b - a < 1e-9:
            out.append(m)
            return
    find_kinks(g, a, m, ga, gm, out, depth + 1, tol)
    find_kinks(g, m, b, gm, gb, out, depth + 1, tol)


def gradient(x, h=1e-5):
    gr = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        gr[j] = (f(x + e) - f(x - e)) / (2 * h)
    return gr


def side_gradient(xs, d, sign):
    """Gradient on one side of a kink; None if region looks inconsistent."""
    g1 = gradient(xs + sign * 1e-3 * d)
    g2 = gradient(xs + sign * 2e-3 * d)
    if np.linalg.norm(g1 - g2) > 1e-6 * max(1e-3, np.linalg.norm(g1)):
        return None
    return g1


def canon(v):
    v = v / np.linalg.norm(v)
    k = np.argmax(np.abs(v))
    return v if v[k] > 0 else -v


def steal(num_lines=60, T=50.0, stable_rounds=15):
    rows = []
    counts = []
    since_new = 0
    for it in range(num_lines * 5):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        g = line_fn(x0, d)
        # Split into chunks to make recursion robust.
        grid = np.linspace(-T, T, 41)
        vals = [g(t) for t in grid]
        kinks = []
        for i in range(len(grid) - 1):
            find_kinks(g, grid[i], grid[i + 1], vals[i], vals[i + 1], kinks)
        new = False
        for t in kinks:
            xs = x0 + t * d
            gl = side_gradient(xs, d, -1)
            gr = side_gradient(xs, d, +1)
            if gl is None or gr is None:
                continue
            diff = gr - gl
            if np.linalg.norm(diff) < 1e-8:
                continue
            v = canon(diff)
            for k, r in enumerate(rows):
                if abs(np.dot(v, r)) > 0.9999:
                    counts[k] += 1
                    break
            else:
                rows.append(v)
                counts.append(1)
                new = True
        since_new = 0 if new else since_new + 1
        if it >= num_lines and since_new >= stable_rounds:
            break
    rows = [r for r, c in zip(rows, counts) if c >= 2]
    return np.array(rows)


if __name__ == "__main__":
    A1_hat = steal()
    np.save(os.path.join(HERE, "stolen_A1.npy"), A1_hat)
    print("Recovered %d neurons" % A1_hat.shape[0])
    print(A1_hat)
