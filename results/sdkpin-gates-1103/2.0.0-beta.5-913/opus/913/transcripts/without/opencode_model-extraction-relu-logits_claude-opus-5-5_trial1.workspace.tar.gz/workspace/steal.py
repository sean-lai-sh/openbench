import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(u, d, a, b, fa, fb, out, depth=0):
    m = 0.5 * (a + b)
    fm = f(u + m * d)
    if abs(fm - 0.5 * (fa + fb)) < 1e-12 * (1 + abs(fa) + abs(fb)) and depth > 4:
        return
    if b - a < 1e-3:
        eps = (b - a) * 1e-3
        sl = (f(u + (a + eps) * d) - fa) / eps
        sr = (fb - f(u + (b - eps) * d)) / eps
        if abs(sl - sr) < 1e-9:
            return
        t = (fb - fa + sl * a - sr * b) / (sl - sr)
        if a <= t <= b:
            out.append(t)
        return
    find_kinks(u, d, a, m, fa, fm, out, depth + 1)
    find_kinks(u, d, m, b, fm, fb, out, depth + 1)


def grad(x, h=1e-6):
    g = np.zeros(DIM)
    f0 = f(x)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = h
        g[i] = (f(x + e) - f0) / h
    return g


def normalize(v):
    v = v / np.linalg.norm(v)
    if v[np.argmax(np.abs(v))] < 0:
        v = -v
    return v


rows = []
counts = []
for _ in range(60):
    u = rng.normal(size=DIM)
    d = rng.normal(size=DIM)
    d /= np.linalg.norm(d)
    R = 20.0
    kinks = []
    find_kinks(u, d, -R, R, f(u - R * d), f(u + R * d), kinks)
    for t in kinks:
        x = u + t * d
        delta = 1e-4
        gl = grad(x - delta * d)
        gr = grad(x + delta * d)
        diff = gr - gl
        if np.linalg.norm(diff) < 1e-8:
            continue
        v = normalize(diff)
        for j, r in enumerate(rows):
            if np.linalg.norm(r - v) < 1e-3:
                counts[j] += 1
                rows[j] = r + (v - r) / counts[j]
                break
        else:
            rows.append(v)
            counts.append(1)

keep = [r for r, c in zip(rows, counts) if c >= 2]
A1 = np.array([normalize(r) for r in keep])
np.save(OUT, A1)
print(A1.shape)
print(A1)
