import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from forward import forward

DIM = 10
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, a, b, fa, fb, out, depth=0):
    m = 0.5 * (a + b)
    fm = f(x0 + m * d)
    q1 = a + 0.25 * (b - a)
    q3 = a + 0.75 * (b - a)
    f1 = f(x0 + q1 * d)
    f3 = f(x0 + q3 * d)
    tol = 1e-9 * (1 + abs(fa) + abs(fb))
    lin = (abs(fm - 0.5 * (fa + fb)) < tol and
           abs(f1 - 0.5 * (fa + fm)) < tol and
           abs(f3 - 0.5 * (fm + fb)) < tol)
    if lin:
        return
    if b - a < 1e-4 or depth > 60:
        out.append(m)
        return
    find_kinks(x0, d, a, m, fa, fm, out, depth + 1)
    find_kinks(x0, d, m, b, fm, fb, out, depth + 1)


def refine_kink(x0, d, t, w):
    a, b = t - w, t + w
    h = w * 1e-2
    fa, fa2 = f(x0 + a * d), f(x0 + (a + h) * d)
    fb, fb2 = f(x0 + b * d), f(x0 + (b - h) * d)
    sa = (fa2 - fa) / h
    sb = (fb - fb2) / h
    if abs(sa - sb) < 1e-12:
        return None
    return (fb - fa + sa * a - sb * b) / (sa - sb)


def gradient(x, h=1e-6):
    g = np.zeros(DIM)
    f0 = f(x)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = h
        g[i] = (f(x + e) - f0) / h
    return g


def main():
    rows = []
    T = 30.0
    n_lines = 40
    for _ in range(n_lines):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        kinks = []
        find_kinks(x0, d, -T, T, f(x0 - T * d), f(x0 + T * d), kinks)
        for t in kinks:
            tr = refine_kink(x0, d, t, 1e-3)
            if tr is None or abs(tr - t) > 1e-3:
                tr = t
            eps = 1e-4
            g1 = gradient(x0 + (tr - eps) * d)
            g2 = gradient(x0 + (tr + eps) * d)
            dg = g2 - g1
            n = np.linalg.norm(dg)
            if n < 1e-6:
                continue
            v = dg / n
            v *= np.sign(v[np.argmax(np.abs(v))])
            rows.append(v)

    clusters = []
    for v in rows:
        for c in clusters:
            if abs(np.dot(c[0], v)) > 0.999:
                c.append(v * np.sign(np.dot(c[0], v)))
                break
        else:
            clusters.append([v])

    A = []
    for c in clusters:
        if len(c) < 2:
            continue
        m = np.median(np.array(c), axis=0)
        A.append(m / np.linalg.norm(m))
    A = np.array(A)
    np.save(os.path.join(HERE, "stolen_A1.npy"), A)
    print(A.shape)
    print(A)


if __name__ == "__main__":
    main()
