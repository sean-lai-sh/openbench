"""Extract A1 (up to neuron permutation and scaling) from a 1-hidden-layer
ReLU network using only black-box queries to forward(x).

Method:
  1. Walk along random lines x(t) = p + t*d. f(x(t)) is piecewise linear in t;
     each kink is where some hidden neuron's pre-activation crosses zero.
  2. Locate kinks precisely by intersecting linear pieces (recursive search).
  3. At each kink, take the gradient of f just on either side. The difference
     equals A2_i * A1_i for the neuron that switched, i.e. row i of A1 up to
     scale.
  4. Normalise, fix sign, deduplicate -> rows of A1.
"""

import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def line_fn(p, d):
    return lambda t: f(p + t * d)


def slope(g, t, h=1e-7):
    return (g(t + h) - g(t - h)) / (2 * h)


def find_kinks(g, a, b, ga, gb, sa, sb, out, depth=0):
    """Find kinks of piecewise-linear g on [a, b]. sa/sb = slopes at a/b."""
    if b - a < 1e-9 or depth > 60:
        return
    scale = max(1.0, abs(sa), abs(sb))
    if abs(sa - sb) < 1e-8 * scale:
        # same slope on both ends; check midpoint to rule out cancelling kinks
        m = 0.5 * (a + b)
        gm = g(m)
        if abs(gm - (ga + sa * (m - a))) < 1e-9 * max(1.0, abs(gm)):
            return
    else:
        # intersect the two lines
        tk = (gb - ga + sa * a - sb * b) / (sa - sb)
        if a < tk < b:
            gk = g(tk)
            pred = ga + sa * (tk - a)
            if abs(gk - pred) < 1e-9 * max(1.0, abs(gk)):
                # verify slopes immediately on either side match sa / sb
                eps = 1e-5 * (b - a) + 1e-9
                if (
                    tk - eps > a
                    and tk + eps < b
                    and abs(slope(g, tk - eps, h=eps / 10) - sa) < 1e-6 * scale
                    and abs(slope(g, tk + eps, h=eps / 10) - sb) < 1e-6 * scale
                ):
                    out.append(tk)
                    return
    m = 0.5 * (a + b)
    gm = g(m)
    sm = slope(g, m, h=min(1e-7, (b - a) / 100))
    find_kinks(g, a, m, ga, gm, sa, sm, out, depth + 1)
    find_kinks(g, m, b, gm, gb, sm, sb, out, depth + 1)


def grad(x, h=1e-7):
    gr = np.zeros(DIM)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = h
        gr[i] = (f(x + e) - f(x - e)) / (2 * h)
    return gr


def normalise(v):
    v = v / np.linalg.norm(v)
    k = np.argmax(np.abs(v))
    return v if v[k] > 0 else -v


def main():
    rows = []
    stale = 0
    n_lines = 0
    T = 20.0
    while stale < 40 and n_lines < 2000:
        n_lines += 1
        p = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        g = line_fn(p, d)
        kinks = []
        find_kinks(g, -T, T, g(-T), g(T), slope(g, -T), slope(g, T), kinks)
        found_new = False
        for tk in kinks:
            x = p + tk * d
            eps = 1e-4
            diff = grad(x + eps * d, h=1e-6) - grad(x - eps * d, h=1e-6)
            if np.linalg.norm(diff) < 1e-10:
                continue
            v = normalise(diff)
            if not any(np.linalg.norm(v - r) < 1e-4 for r in rows):
                rows.append(v)
                found_new = True
        stale = 0 if found_new else stale + 1

    A = np.array(rows)
    np.save(OUT, A)
    print(f"Recovered {A.shape[0]} neurons from {n_lines} lines")
    print(A)
    return A


if __name__ == "__main__":
    main()
