import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)
nq = 0


def f(x):
    global nq
    nq += 1
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi, out, depth=0):
    """Find t values where g(t)=f(x0+t d) has a slope change in [lo, hi]."""
    h = 1e-6 * max(1.0, hi - lo)
    g = lambda t: f(x0 + t * d)
    ga, gb = g(lo), g(hi)
    sa = (g(lo + h) - ga) / h
    sb = (gb - g(hi - h)) / h
    tol = 1e-9 * (1 + abs(ga) + abs(gb))
    if abs(sa - sb) < 1e-8 * (1 + abs(sa)):
        # same slope; check linearity
        if abs(ga + sa * (hi - lo) - gb) < tol:
            return
    elif depth > 2:
        # try single-kink hypothesis: intersect the two lines
        t = (gb - ga + sa * lo - sb * hi) / (sa - sb)
        if lo < t < hi:
            pred = ga + sa * (t - lo)
            if abs(g(t) - pred) < tol * 10:
                # verify both halves are linear
                m1 = 0.5 * (lo + t)
                m2 = 0.5 * (t + hi)
                if (
                    abs(g(m1) - (ga + sa * (m1 - lo))) < tol * 10
                    and abs(g(m2) - (gb - sb * (hi - m2))) < tol * 10
                ):
                    out.append(t)
                    return
    if hi - lo < 1e-7 or depth > 60:
        out.append(0.5 * (lo + hi))
        return
    mid = 0.5 * (lo + hi)
    find_kinks(x0, d, lo, mid, out, depth + 1)
    find_kinks(x0, d, mid, hi, out, depth + 1)


def grad(x, eps=1e-6):
    g = np.zeros(DIM)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = eps
        g[i] = (f(x + e) - f(x - e)) / (2 * eps)
    return g


def main():
    rows = []
    counts = []
    stable = 0
    for it in range(200):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        kinks = []
        find_kinks(x0, d, -100.0, 100.0, kinks)
        new = 0
        for t in kinks:
            delta = 1e-3
            gp = grad(x0 + (t + delta) * d)
            gm = grad(x0 + (t - delta) * d)
            diff = gp - gm
            n = np.linalg.norm(diff)
            if n < 1e-7:
                continue
            v = diff / n
            if any(abs(np.dot(v, r)) > 0.9999 for r in rows):
                continue
            rows.append(v)
            new += 1
        stable = stable + 1 if new == 0 else 0
        counts.append(len(rows))
        if stable >= 15:
            break
    A = np.array(rows)
    # canonicalize sign so the largest-magnitude entry is positive
    idx = np.argmax(np.abs(A), axis=1)
    A = A * np.sign(A[np.arange(len(A)), idx])[:, None]
    np.save(OUT, A)
    print(f"Recovered {A.shape[0]} neurons using {nq} queries")
    print(A)
    return A


if __name__ == "__main__":
    main()
