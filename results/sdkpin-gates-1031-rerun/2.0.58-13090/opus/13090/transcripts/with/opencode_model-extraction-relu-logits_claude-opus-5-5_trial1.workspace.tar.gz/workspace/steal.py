"""Extract A1 (up to neuron permutation and positive scaling) from a one-hidden-layer
ReLU network using only black-box queries to forward(x)."""

import itertools
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from forward import forward  # noqa: E402

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(1234)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi, out, depth=0):
    """Recursively find t values where f(x0 + t d) is non-linear."""
    flo, fhi = f(x0 + lo * d), f(x0 + hi * d)
    mid = 0.5 * (lo + hi)
    fmid = f(x0 + mid * d)
    q1, q3 = lo + 0.25 * (hi - lo), lo + 0.75 * (hi - lo)
    f1, f3 = f(x0 + q1 * d), f(x0 + q3 * d)
    lin = lambda t: flo + (fhi - flo) * (t - lo) / (hi - lo)
    scale = 1e-10 * (1 + abs(flo) + abs(fhi))
    if max(abs(fmid - lin(mid)), abs(f1 - lin(q1)), abs(f3 - lin(q3))) < scale:
        return  # linear on [lo, hi]
    if hi - lo < 1e-3 or depth > 40:
        # Try to resolve a single kink by intersecting the two outer linear pieces.
        e = (hi - lo) * 1e-3
        sl = (f(x0 + (lo + e) * d) - flo) / e
        sr = (fhi - f(x0 + (hi - e) * d)) / e
        if abs(sl - sr) < 1e-9:
            return
        t = (fhi - flo + sl * lo - sr * hi) / (sl - sr)
        if lo <= t <= hi:
            # verify it's a single kink: pieces must match at t
            if abs((flo + sl * (t - lo)) - f(x0 + t * d)) < 1e-7 * (1 + abs(flo)):
                out.append(t)
                return
        if hi - lo < 1e-7:
            return
    find_kinks(x0, d, lo, mid, out, depth + 1)
    find_kinks(x0, d, mid, hi, out, depth + 1)


def grad(x, h=1e-4):
    g = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        g[j] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def analyze_kink(x0, d, t):
    """Return (gradient jump along d, kink point)."""
    xs = x0 + t * d
    eps = 1e-4
    gp = grad(xs + eps * d, h=1e-6)
    gm = grad(xs - eps * d, h=1e-6)
    gp2 = grad(xs + 3 * eps * d, h=1e-6)
    gm2 = grad(xs - 3 * eps * d, h=1e-6)
    tol = 1e-6 + 1e-4 * np.linalg.norm(gp - gm)
    if np.linalg.norm(gp - gp2) > tol or np.linalg.norm(gm - gm2) > tol:
        return np.zeros(DIM), xs  # not an isolated single kink; discard
    return gp - gm, xs


# ---- 1. collect critical points along random lines ----
neurons = []  # list of dict(p=unit normal, conv=sign of a2, c=offset, mag)


def match(p):
    for n in neurons:
        if abs(abs(np.dot(n["u"], p)) - 1) < 1e-4:
            return n
    return None


for trial in range(60):
    x0 = rng.normal(size=DIM) * 0.5
    d = rng.normal(size=DIM)
    d /= np.linalg.norm(d)
    ts = []
    find_kinks(x0, d, -20.0, 20.0, ts)
    for t in ts:
        delta, xs = analyze_kink(x0, d, t)
        nrm = np.linalg.norm(delta)
        if nrm < 1e-8:
            continue
        u = delta / nrm
        if match(u) is not None:
            continue
        # Delta along d for a crossing: delta = a2*w*sign(w.d). Convexity sign:
        # moving along +u, the jump is sign(a2) * |delta| * u.
        s = 1.0 if np.dot(delta, d) * 1.0 >= 0 else -1.0
        # The second derivative along d is >0 iff a2>0; delta.d = a2 |w.d| ... sign = sign(a2)
        neurons.append(dict(u=u, p=delta * np.sign(np.dot(u, delta)), sa2=s, x=xs))

n = len(neurons)
print(f"found {n} neurons", file=sys.stderr)

# p_i = +- a2_i w_i (we use p_i = delta as measured), sa2 = sign(a2_i).
P = np.array([nn["p"] for nn in neurons])  # rows
S = np.array([nn["sa2"] for nn in neurons])
C = np.array([-np.dot(nn["p"], nn["x"]) for nn in neurons])  # h_i(x) = p.x + c

# ---- 2. resolve global sign of each row ----
# grad(x) = sum_i tau_i p_i 1[tau_i s_i h_i(x) > 0]
#        = sum_i -p_i 1[s_i h_i(x) < 0] + sum_{tau_i = +1} p_i
targets = []
while len(targets) < 5:
    x = rng.normal(size=DIM) * 0.5
    h = P @ x + C
    if np.min(np.abs(h) / np.linalg.norm(P, axis=1)) < 1e-2:
        continue
    g = grad(x)
    base = -(P * ((S * h) < 0)[:, None]).sum(0)
    targets.append(g - base)
target = np.mean(targets, axis=0)

# Brute-force subset search (meet in the middle) for sum_{tau=+1} p_i == target.
half = n // 2
A, B = P[:half], P[half:]


def all_sums(M):
    k = len(M)
    masks = np.array(list(itertools.product([0, 1], repeat=k)), dtype=np.float64)
    return masks, masks @ M if k else np.zeros((1, DIM))


mA, sA = all_sums(A)
mB, sB = all_sums(B)
best = (np.inf, None)
for i in range(0, len(sA), 512):
    blk = sA[i : i + 512]
    # distance from target - blk to every sB
    r = target[None, :] - blk
    dists = (r**2).sum(1)[:, None] - 2 * r @ sB.T + (sB**2).sum(1)[None, :]
    j = np.unravel_index(np.argmin(dists), dists.shape)
    if dists[j] < best[0]:
        best = (dists[j], np.concatenate([mA[i + j[0]], mB[j[1]]]))
tau = np.where(best[1] > 0.5, 1.0, -1.0)
print(f"sign residual {np.sqrt(max(best[0], 0)):.3e}", file=sys.stderr)

# w_i proportional (positive scale) to tau_i * s_i * p_i
W = (tau * S)[:, None] * P
W /= np.linalg.norm(W, axis=1, keepdims=True)

# ---- 3. sanity check: rebuild full network and compare ----
K = tau[:, None] * P  # = a2_i w_i
a2 = S * np.linalg.norm(K, axis=1)  # with unit-norm w
b = -np.einsum("ij,ij->i", W, np.array([nn["x"] for nn in neurons]))


def model(x):
    return a2 @ np.maximum(0, W @ x + b)


xs = rng.normal(size=(50, DIM))
b2 = np.mean([f(x) - model(x) for x in xs])
err = max(abs(f(x) - model(x) - b2) for x in rng.normal(size=(200, DIM)) * 3)
print(f"reconstruction max error: {err:.3e}", file=sys.stderr)

np.save(OUT, W)
print(W)
