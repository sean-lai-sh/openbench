"""Extract A1 (up to row permutation and scaling) from a 1-hidden-layer ReLU net
using only black-box queries to forward(x).

Method (critical-point / kink search):
  1. Along random lines x0 + t*d, f is piecewise linear in t. Kinks occur exactly
     where some hidden neuron's pre-activation a_i.x + b_i crosses zero.
  2. Locate kinks by recursive bisection + intersecting the two linear pieces.
  3. At each kink x*, the gradient of f jumps by A2_i * a_i. Measuring the
     gradient (finite differences) on both sides gives a vector proportional
     to row a_i of A1.
  4. Normalize, deduplicate (up to sign), and stack the unique rows.
"""

import os
import numpy as np
from forward import forward

DIM = 10
rng = np.random.default_rng(12345)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi, flo, fhi, depth=0, out=None):
    """Recursively find t values in [lo, hi] where f(x0 + t d) has a kink."""
    if out is None:
        out = []
    mid = 0.5 * (lo + hi)
    fmid = f(x0 + mid * d)
    if abs(fmid - 0.5 * (flo + fhi)) < 1e-12 * max(1.0, abs(flo) + abs(fhi)):
        # Check quarter points too to avoid symmetric cancellation
        q1, q3 = lo + 0.25 * (hi - lo), lo + 0.75 * (hi - lo)
        f1, f3 = f(x0 + q1 * d), f(x0 + q3 * d)
        if (
            abs(f1 - 0.75 * flo - 0.25 * fhi) < 1e-12
            and abs(f3 - 0.25 * flo - 0.75 * fhi) < 1e-12
        ):
            return out
    if hi - lo < 1e-3 or depth > 60:
        # Refine: intersect left and right linear pieces
        e = 1e-6
        sl = (f(x0 + (lo + e) * d) - flo) / e
        sr = (fhi - f(x0 + (hi - e) * d)) / e
        if abs(sl - sr) > 1e-9:
            t = lo + (fhi - flo - sr * (hi - lo)) / (sl - sr)
            if lo - 1e-6 <= t <= hi + 1e-6:
                out.append(t)
            else:
                out.append(mid)
        return out
    find_kinks(x0, d, lo, mid, flo, fmid, depth + 1, out)
    find_kinks(x0, d, mid, hi, fmid, fhi, depth + 1, out)
    return out


def gradient(x, h=1e-5):
    g = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        g[j] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def row_at_kink(x0, d, t, eps=1e-4):
    gp = gradient(x0 + (t + eps) * d)
    gm = gradient(x0 + (t - eps) * d)
    # Validate: gradient must be locally constant on each side (single kink)
    gp2 = gradient(x0 + (t + 2 * eps) * d)
    gm2 = gradient(x0 + (t - 2 * eps) * d)
    scale = max(np.linalg.norm(gp), np.linalg.norm(gm), 1e-12)
    if (np.linalg.norm(gp - gp2) > 1e-6 * scale or
            np.linalg.norm(gm - gm2) > 1e-6 * scale):
        return None
    diff = gp - gm
    n = np.linalg.norm(diff)
    if n < 1e-8:
        return None
    return diff / n


def main():
    rows = []
    counts = []
    stable = 0
    T = 50.0
    for it in range(200):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        flo, fhi = f(x0 - T * d), f(x0 + T * d)
        kinks = find_kinks(x0, d, -T, T, flo, fhi)
        new = 0
        for t in kinks:
            r = row_at_kink(x0, d, t)
            if r is None:
                continue
            # canonical sign
            r = r * np.sign(r[np.argmax(np.abs(r))])
            match = [k for k, q in enumerate(rows) if abs(np.dot(r, q)) > 0.9999]
            if match:
                counts[match[0]] += 1
                continue
            rows.append(r)
            counts.append(1)
            new += 1
        stable = stable + 1 if new == 0 else 0
        if stable >= 15 and it >= 20:
            break
    # Keep only directions observed repeatedly (true neurons recur across lines)
    A = np.array([r for r, c in zip(rows, counts) if c >= 2])
    np.save(OUT, A)
    print(f"Recovered {A.shape[0]} neurons; saved to {OUT}")
    print(A)
    return A


if __name__ == "__main__":
    main()
