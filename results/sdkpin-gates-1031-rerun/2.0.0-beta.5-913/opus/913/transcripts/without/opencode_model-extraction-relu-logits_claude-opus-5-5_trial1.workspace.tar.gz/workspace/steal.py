import os
import sys
import itertools
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from forward import forward

DIM = 10
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def grad(x, eps=1e-6):
    x = np.asarray(x, dtype=np.float64)
    g = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = eps
        g[j] = (f(x + e) - f(x - e)) / (2 * eps)
    return g


def find_kinks(p, d, a, b, out, depth=0):
    h = 1e-6
    fa, fb = f(p + a * d), f(p + b * d)
    sa = (f(p + (a + h) * d) - fa) / h
    sb = (fb - f(p + (b - h) * d)) / h
    if abs(sa - sb) < 1e-9 * max(1.0, abs(sa), abs(sb)):
        mid = 0.5 * (a + b)
        if abs(f(p + mid * d) - (fa + fb) / 2) < 1e-10:
            return
    if abs(sa - sb) > 1e-12:
        t = (fb - fa + sa * a - sb * b) / (sa - sb)
        if a < t < b:
            pred = fa + sa * (t - a)
            if abs(f(p + t * d) - pred) < 1e-10 and abs(sa - sb) > 1e-8:
                out.append(t)
                return
    if b - a < 1e-7 or depth > 60:
        return
    mid = 0.5 * (a + b)
    find_kinks(p, d, a, mid, out, depth + 1)
    find_kinks(p, d, mid, b, out, depth + 1)


def collect_neurons(n_lines=60, R=30.0):
    dirs, points = [], []
    stable = 0
    for _ in range(n_lines):
        p = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        ts = []
        find_kinks(p, d, -R, R, ts)
        before = len(dirs)
        for t in ts:
            x0 = p + t * d
            delta = 1e-4
            v = grad(x0 + delta * d) - grad(x0 - delta * d)
            nv = np.linalg.norm(v)
            if nv < 1e-8:
                continue
            u = v / nv
            if any(abs(u @ w) > 0.999 for w in dirs):
                continue
            dirs.append(u)
            points.append(x0)
        stable = stable + 1 if len(dirs) == before else 0
        if stable >= 15:
            break
    return np.array(dirs), np.array(points)


def fix_signs(U, X0, n_samples=None):
    k = len(U)
    n_samples = n_samples or max(4 * k, 60)
    rows_A, rows_y = [], []
    for _ in range(n_samples):
        x = rng.normal(size=DIM) * 3
        H = np.einsum("ij,ij->i", U, x[None, :] - X0)
        if np.min(np.abs(H)) < 1e-4:
            continue
        g = grad(x)
        ind = (H > 0).astype(float)
        M = np.zeros((DIM, DIM + k))
        M[:, :DIM] = np.eye(DIM)
        M[:, DIM:] = (U * ind[:, None]).T
        rows_A.append(M)
        rows_y.append(g)
    A = np.vstack(rows_A)
    y = np.concatenate(rows_y)
    sol, *_ = np.linalg.lstsq(A, y, rcond=None)
    C = sol[:DIM]
    dcoef = sol[DIM:]
    V = -(dcoef[:, None] * U)

    # find subset S with sum_{i in S} V_i = C (meet in the middle)
    half = k // 2
    A_idx, B_idx = list(range(half)), list(range(half, k))

    def all_sums(idx):
        n = len(idx)
        masks = np.arange(2 ** n)
        bits = ((masks[:, None] >> np.arange(n)) & 1).astype(float)
        return bits, bits @ V[idx] if n else np.zeros((1, DIM))

    bitsA, sumsA = all_sums(A_idx)
    bitsB, sumsB = all_sums(B_idx)
    best, best_err = None, np.inf
    try:
        from scipy.spatial import cKDTree
        tree = cKDTree(sumsB)
        dist, j = tree.query(C - sumsA)
        i = int(np.argmin(dist))
        best = np.concatenate([bitsA[i], bitsB[j[i]]])
    except ImportError:
        for i in range(len(sumsA)):
            err = np.linalg.norm(sumsB - (C - sumsA[i]), axis=1)
            jj = int(np.argmin(err))
            if err[jj] < best_err:
                best_err = err[jj]
                best = np.concatenate([bitsA[i], bitsB[jj]])
    signs = np.where(best > 0.5, -1.0, 1.0)
    return U * signs[:, None]


def main():
    U, X0 = collect_neurons()
    A1 = fix_signs(U, X0)
    np.save(os.path.join(HERE, "stolen_A1.npy"), A1)
    print(A1.shape)
    print(A1)


if __name__ == "__main__":
    main()
