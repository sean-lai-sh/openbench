import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from forward import forward

DIM = 10
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi):
    g = lambda t: f(x0 + t * d)
    h = 1e-6
    kinks = []

    def slope_r(t):
        return (g(t + h) - g(t)) / h

    def slope_l(t):
        return (g(t) - g(t - h)) / h

    def rec(a, fa, sa, b, fb, sb, depth):
        if b - a < 1e-9 or depth > 60:
            return
        scale = max(abs(sa), abs(sb), 1e-12)
        if abs(sa - sb) < 1e-7 * scale + 1e-12:
            return
        if abs(sa - sb) > 1e-12:
            tc = (fb - fa + sa * a - sb * b) / (sa - sb)
            if a + 2 * h < tc < b - 2 * h:
                pred = fa + sa * (tc - a)
                fc = g(tc)
                if abs(fc - pred) < 1e-9 * max(1.0, abs(fc)):
                    sl, sr = slope_l(tc - h), slope_r(tc + h)
                    if abs(sl - sa) < 1e-6 * scale + 1e-10 and abs(sr - sb) < 1e-6 * scale + 1e-10:
                        kinks.append(tc)
                        return
        m = 0.5 * (a + b)
        fm = g(m)
        rec(a, fa, sa, m, fm, slope_l(m), depth + 1)
        rec(m, fm, slope_r(m), b, fb, sb, depth + 1)

    rec(lo, g(lo), slope_r(lo), hi, g(hi), slope_l(hi), 0)
    return kinks


def gradient(x, h=1e-6):
    f0 = f(x)
    gr = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        gr[j] = (f(x + e) - f0) / h
    return gr


def jump_at_kink(x0, d, t):
    diffs = []
    for delta in (1e-3, 1e-4):
        diffs.append(gradient(x0 + (t + delta) * d) - gradient(x0 + (t - delta) * d))
    a, b = diffs
    n = np.linalg.norm(b)
    if n < 1e-9 or np.linalg.norm(a - b) > 1e-4 * n:
        return None
    return b


def solve_signs(J, P, W):
    n = len(J)
    x = rng.normal(size=DIM)
    H = np.array([W[i] @ (x - P[i]) for i in range(n)])
    G0 = gradient(x) - (J * (H > 0)[:, None]).sum(axis=0)
    target = -G0
    half = n // 2
    def sums(idx):
        k = len(idx)
        masks = ((np.arange(2 ** k)[:, None] >> np.arange(k)) & 1).astype(float)
        return masks, masks @ J[idx] if k else np.zeros((1, DIM))
    iA, iB = np.arange(half), np.arange(half, n)
    mA, sA = sums(iA)
    mB, sB = sums(iB)
    proj = rng.normal(size=DIM)
    pA, pB = sA @ proj, sB @ proj
    order = np.argsort(pB)
    pBs = pB[order]
    scale = np.abs(J).sum() + 1e-12
    tol = 1e-6 * scale
    best = None
    for a in range(len(pA)):
        need = target @ proj - pA[a]
        lo = np.searchsorted(pBs, need - tol * np.linalg.norm(proj) * 10)
        hi = np.searchsorted(pBs, need + tol * np.linalg.norm(proj) * 10)
        for k in range(lo, hi):
            b = order[k]
            err = np.linalg.norm(sA[a] + sB[b] - target)
            if best is None or err < best[0]:
                best = (err, a, b)
    if best is None or best[0] > tol:
        return None
    flipped = np.concatenate([mA[best[1]], mB[best[2]]]).astype(bool)
    return np.where(flipped, -1.0, 1.0)


def main():
    W, J, P, counts = [], [], [], []
    no_new = 0
    lines = 0
    while no_new < 50 and lines < 3000:
        lines += 1
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        found_new = False
        for t in find_kinks(x0, d, -50.0, 50.0):
            jump = jump_at_kink(x0, d, t)
            if jump is None:
                continue
            w = jump / np.linalg.norm(jump) * np.sign(jump @ d)
            for i, r in enumerate(W):
                if abs(r @ w) > 1 - 1e-6:
                    counts[i] += 1
                    if counts[i] == 2:
                        found_new = True
                    break
            else:
                W.append(w)
                J.append(jump)
                P.append(x0 + t * d)
                counts.append(1)
        no_new = 0 if found_new else no_new + 1

    keep = [i for i in range(len(W)) if counts[i] >= 2]
    W = np.array([W[i] for i in keep])
    J = np.array([J[i] for i in keep])
    P = np.array([P[i] for i in keep])

    signs = None
    for _ in range(5):
        signs = solve_signs(J, P, W)
        if signs is not None:
            break
    if signs is None:
        signs = np.ones(len(W))
    A = W * signs[:, None]
    np.save(os.path.join(HERE, "stolen_A1.npy"), A)
    print(A.shape)
    print(A)


if __name__ == "__main__":
    main()
