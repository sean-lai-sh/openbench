import os
import itertools
import numpy as np

from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks_on_line(x0, d, lo, hi, depth=0, flo=None, fhi=None):
    if flo is None:
        flo = f(x0 + lo * d)
    if fhi is None:
        fhi = f(x0 + hi * d)
    mid = 0.5 * (lo + hi)
    fmid = f(x0 + mid * d)
    lin = 0.5 * (flo + fhi)
    scale = 1e-11 * (1 + abs(flo) + abs(fhi))
    if abs(fmid - lin) < scale and depth > 4:
        return []
    if hi - lo < 1e-6:
        return [mid]
    if depth > 4 and hi - lo < 1e-2:
        q1, q3 = lo + 0.25 * (hi - lo), lo + 0.75 * (hi - lo)
        f1, f3 = f(x0 + q1 * d), f(x0 + q3 * d)
        sl = (f1 - flo) / (q1 - lo)
        sr = (fhi - f3) / (hi - q3)
        sl2 = (fmid - f1) / (mid - q1)
        sr2 = (f3 - fmid) / (q3 - mid)
        if abs(sl - sl2) < 1e-7 * (1 + abs(sl)) and abs(sr - sr2) < 1e-7 * (1 + abs(sr)) \
                and abs(sl - sr) > 1e-9:
            t = (fhi - flo + sl * lo - sr * hi) / (sl - sr)
            if lo < t < hi:
                return [t]
    return (find_kinks_on_line(x0, d, lo, mid, depth + 1, flo, fmid)
            + find_kinks_on_line(x0, d, mid, hi, depth + 1, fmid, fhi))


def grad(x, h=1e-5):
    g = np.zeros(DIM)
    f0 = f(x)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = h
        g[i] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def main():
    rows = []
    points = []
    n_lines = 60
    for _ in range(n_lines):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        ts = sorted(find_kinks_on_line(x0, d, -20.0, 20.0))
        for j, t in enumerate(ts):
            gaps = []
            if j > 0:
                gaps.append(t - ts[j - 1])
            if j < len(ts) - 1:
                gaps.append(ts[j + 1] - t)
            gap = min(gaps) if gaps else 1.0
            eps = min(1e-3, gap / 4)
            h = min(1e-5, eps / 10)
            xs = x0 + t * d
            g_after = grad(xs + eps * d, h)
            g_before = grad(xs - eps * d, h)
            dg = g_after - g_before
            nrm = np.linalg.norm(dg)
            if nrm < 1e-8:
                continue
            u = dg / nrm
            u = u * np.sign(u[np.argmax(np.abs(u))])
            rows.append((u, nrm, dg))
            points.append(xs)

    clusters = []
    for (u, nrm, dg), xs in zip(rows, points):
        for c in clusters:
            if abs(np.dot(c["u"][0], u)) > 0.9999:
                c["u"].append(u)
                c["x"].append(xs)
                break
        else:
            clusters.append({"u": [u], "x": [xs]})
    clusters = [c for c in clusters if len(c["u"]) >= 2] or clusters

    W = []
    B = []
    for c in clusters:
        U = np.array(c["u"])
        u = np.median(U, axis=0)
        u /= np.linalg.norm(u)
        W.append(u)
        B.append(np.median([-u @ x for x in c["x"]]))
    W = np.array(W)
    B = np.array(B)
    k = len(W)

    # Resolve signs: with all rows in a canonical orientation, the true model is
    # sum a_i relu(W_i x + B_i) + v.x + c, where v = -sum_{flipped} a_i W_i.
    X = rng.normal(size=(max(400, 10 * k), DIM)) * 3
    y = np.array([f(x) for x in X])
    Phi = np.hstack([np.maximum(0, X @ W.T + B), X, np.ones((len(X), 1))])
    coef, *_ = np.linalg.lstsq(Phi, y, rcond=None)
    a = coef[:k]
    v = coef[k:k + DIM]
    M = -(a[:, None] * W)  # contributions if flipped
    best, best_err = None, np.inf
    if k <= 22:
        chunk = 1 << min(k, 16)
        total = 1 << k
        idx = np.arange(k)
        for start in range(0, total, chunk):
            ids = np.arange(start, min(start + chunk, total))
            S = ((ids[:, None] >> idx) & 1).astype(np.float64)
            err = np.linalg.norm(S @ M - v, axis=1)
            j = np.argmin(err)
            if err[j] < best_err:
                best_err, best = err[j], S[j]
    else:
        S = np.zeros(k)
        resid = v.copy()
        improved = True
        while improved:
            improved = False
            for i in range(k):
                S2 = S.copy()
                S2[i] = 1 - S2[i]
                if np.linalg.norm(S2 @ M - v) < np.linalg.norm(S @ M - v):
                    S = S2
                    improved = True
        best = S
    signs = np.where(best > 0.5, -1.0, 1.0)
    W = W * signs[:, None]

    np.save(OUT, W)
    print("Recovered", k, "neurons")
    print(W)


if __name__ == "__main__":
    main()
