import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from forward import forward  # noqa: E402

DIM = 10
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def line_fn(x0, d):
    return lambda t: f(x0 + t * d)


def slope(g, t, side, h=1e-7):
    if side > 0:
        return (g(t + h) - g(t)) / h
    return (g(t) - g(t - h)) / h


def find_kinks(g, a, b, depth=0, out=None):
    if out is None:
        out = []
    if depth > 60 or b - a < 1e-9:
        return out
    fa, fb = g(a), g(b)
    sa, sb = slope(g, a, +1), slope(g, b, -1)
    scale = max(1.0, abs(sa), abs(sb))
    if abs(sa - sb) < 1e-8 * scale:
        mid = 0.5 * (a + b)
        if abs(g(mid) - (fa + fb) / 2) < 1e-10 * max(1.0, abs(fa), abs(fb)):
            return out
    else:
        tstar = (fb - fa + sa * a - sb * b) / (sa - sb)
        if a < tstar < b:
            pred = fa + sa * (tstar - a)
            if abs(g(tstar) - pred) < 1e-9 * max(1.0, abs(pred)):
                left_ok = abs(g(0.5 * (a + tstar)) - (fa + sa * (0.5 * (tstar - a)))) < 1e-9 * max(1.0, abs(fa))
                right_ok = abs(g(0.5 * (tstar + b)) - (fb - sb * (0.5 * (b - tstar)))) < 1e-9 * max(1.0, abs(fb))
                if left_ok and right_ok:
                    out.append(tstar)
                    return out
    mid = 0.5 * (a + b)
    find_kinks(g, a, mid, depth + 1, out)
    find_kinks(g, mid, b, depth + 1, out)
    return out


def gradient(x, h=1e-6):
    g = np.zeros(DIM)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = h
        g[i] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def row_at_kink(x0, d, t, delta=1e-3):
    g1 = gradient(x0 + (t + delta) * d)
    g2 = gradient(x0 + (t - delta) * d)
    r = g1 - g2
    n = np.linalg.norm(r)
    if n < 1e-9:
        return None
    return r / n


def canonical(r):
    i = np.argmax(np.abs(r))
    return r * np.sign(r[i])


def steal(num_lines=60, T=50.0, patience=15):
    rows = []
    since_new = 0
    for _ in range(num_lines * 10):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        g = line_fn(x0, d)
        kinks = sorted(find_kinks(g, -T, T))
        found_new = False
        for t in kinks:
            r = row_at_kink(x0, d, t)
            if r is None:
                continue
            r = canonical(r)
            matched = False
            for k, (s, cnt) in enumerate(rows):
                if np.abs(s / cnt - r).max() < 1e-3:
                    rows[k] = (s + r, cnt + 1)
                    matched = True
                    break
            if not matched:
                rows.append((r, 1))
                found_new = True
        since_new = 0 if found_new else since_new + 1
        if since_new >= patience:
            break
    A = np.array([s / c for s, c in rows if c >= 2] or [s / c for s, c in rows])
    A /= np.linalg.norm(A, axis=1, keepdims=True)
    return A


if __name__ == "__main__":
    A1 = steal()
    print(A1.shape)
    print(A1)
    np.save(os.path.join(HERE, "stolen_A1.npy"), A1)
