"""
Black-box extraction of A1 (up to row permutation and scaling) from a
one-hidden-layer ReLU network f(x) = A2 relu(A1 x + b1) + b2, using only
queries to forward().

Method:
  1. Along random lines x(t) = x0 + t*d, f is piecewise linear in t. Each kink
     corresponds to a hidden neuron i crossing zero (A1_i . x + b1_i = 0).
     Kinks are located by recursive bisection using slope comparisons.
  2. At each kink, the gradient of f jumps by A2_i * A1_i. Computing the
     gradient (finite differences) on either side and differencing gives a
     vector proportional to row A1_i.
  3. Normalize the vectors, fix sign, and deduplicate across many lines.
"""

import numpy as np
from forward import forward

DIM = 10
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi, eps=1e-6, tol=1e-9, depth=0):
    """Return list of t-values in [lo, hi] where f(x0 + t d) has a kink."""
    g = lambda t: f(x0 + t * d)

    def slope(t, s):
        return (g(t + s) - g(t)) / s

    kinks = []

    def rec(a, b, fa, fb, sa, sb, depth):
        if b - a < 1e-7 or depth > 60:
            return
        if abs(sa - sb) < tol * max(1.0, abs(sa), abs(sb)):
            # check linearity at midpoint (guards against cancelling kinks)
            m = 0.5 * (a + b)
            if abs(g(m) - (fa + sa * (m - a))) < 1e-10:
                return
        # Intersection of the two end lines
        if abs(sa - sb) > 1e-14:
            tc = (fb - fa + sa * a - sb * b) / (sa - sb)
            if a < tc < b:
                pred = fa + sa * (tc - a)
                if abs(g(tc) - pred) < 1e-10:
                    # verify single kink: slopes just left/right match ends
                    left = (g(tc) - g(tc - eps * 10)) / (eps * 10)
                    right = (g(tc + eps * 10) - g(tc)) / (eps * 10)
                    if abs(left - sa) < 1e-6 and abs(right - sb) < 1e-6:
                        kinks.append(tc)
                        return
        m = 0.5 * (a + b)
        fm = g(m)
        sml = (fm - g(m - eps)) / eps
        smr = (g(m + eps) - fm) / eps
        rec(a, m, fa, fm, sa, sml, depth + 1)
        rec(m, b, fm, fb, smr, sb, depth + 1)

    fa, fb = g(lo), g(hi)
    sa = slope(lo, eps)
    sb = (fb - g(hi - eps)) / eps
    rec(lo, hi, fa, fb, sa, sb, 0)
    return kinks


def gradient(x, h=1e-7):
    x = np.asarray(x, dtype=np.float64)
    f0 = f(x)
    gr = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        gr[j] = (f(x + e) - f0) / h
    return gr


def normalize(v):
    v = v / np.linalg.norm(v)
    k = np.argmax(np.abs(v))
    return v * np.sign(v[k])


def steal(n_lines=60, span=30.0, offset=1e-4):
    rows = []
    counts = []
    for _ in range(n_lines):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        for t in find_kinks(x0, d, -span, span):
            gl = gradient(x0 + (t - offset) * d)
            gr = gradient(x0 + (t + offset) * d)
            diff = gr - gl
            if np.linalg.norm(diff) < 1e-8:
                continue
            v = normalize(diff)
            for i, r in enumerate(rows):
                if np.linalg.norm(r - v) < 1e-3:
                    counts[i] += 1
                    # running average for accuracy
                    rows[i] = normalize(r * (counts[i] - 1) + v)
                    break
            else:
                rows.append(v)
                counts.append(1)
    # discard spurious rows seen only once if they are rare outliers
    rows = [r for r, c in zip(rows, counts) if c >= 2] or rows
    return np.array(rows)


if __name__ == "__main__":
    A1_hat = steal()
    print("Recovered", A1_hat.shape[0], "neurons")
    print(A1_hat)
    np.save(
        "/tmp/obench-cell-r0o7mznx/bench_opencode_model-extraction-relu-logits_ti96co6i/stolen_A1.npy",
        A1_hat,
    )
