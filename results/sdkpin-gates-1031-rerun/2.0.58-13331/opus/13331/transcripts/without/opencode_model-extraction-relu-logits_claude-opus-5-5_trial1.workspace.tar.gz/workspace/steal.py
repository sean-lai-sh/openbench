"""Black-box extraction of A1 from f(x) = A2 ReLU(A1 x + b1) + b2 using only forward()."""

import os
import itertools
import numpy as np
from forward import forward

HERE = os.path.dirname(os.path.abspath(__file__))
DIM = 10
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo=-20.0, hi=20.0):
    """Return t values where f(x0 + t d) has a kink (piecewise-linear search)."""
    g = lambda t: f(x0 + t * d)
    h = 1e-7

    def slope(t, side):
        return (g(t + h) - g(t)) / h if side > 0 else (g(t) - g(t - h)) / h

    kinks = []

    def rec(a, b, fa, fb, sa, sb, depth):
        if b - a < 1e-9 or depth > 60:
            return
        tol = 1e-9 * (1 + abs(fa) + abs(fb))
        if abs(sa - sb) < 1e-7:
            m = 0.5 * (a + b)
            if abs(g(m) - (fa + sa * (m - a))) < tol:
                return  # linear on [a, b]
        else:
            # Hypothesize a single kink at intersection of the two lines
            ts = (fb - fa + sa * a - sb * b) / (sa - sb)
            if a < ts < b:
                fts = g(ts)
                if (
                    abs(fts - (fa + sa * (ts - a))) < tol
                    and abs(fts - (fb + sb * (ts - b))) < tol
                ):
                    # check it is the only kink: midpoints of both halves linear
                    m1, m2 = 0.5 * (a + ts), 0.5 * (ts + b)
                    if (
                        abs(g(m1) - (fa + sa * (m1 - a))) < tol
                        and abs(g(m2) - (fb + sb * (m2 - b))) < tol
                    ):
                        kinks.append(ts)
                        return
        m = 0.5 * (a + b)
        fm = g(m)
        sml, smr = slope(m, -1), slope(m, +1)
        rec(a, m, fa, fm, sa, sml, depth + 1)
        rec(m, b, fm, fb, smr, sb, depth + 1)

    rec(lo, hi, g(lo), g(hi), slope(lo, +1), slope(hi, -1), 0)
    return sorted(kinks)


def grad(x, h=1e-6):
    out = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        out[j] = (f(x + e) - f(x - e)) / (2 * h)
    return out


def neuron_at_kink(x0, d, t):
    """Return (unit normal u, offset c) of the hyperplane u.x + c = 0 through the kink."""
    xs = x0 + t * d
    eps = 1e-3
    v = grad(xs + eps * d) - grad(xs - eps * d)  # proportional to a_i * w_i
    n = np.linalg.norm(v)
    if n < 1e-8:
        return None
    u = v / n
    # canonical sign: largest-magnitude component positive
    u = u * np.sign(u[np.argmax(np.abs(u))])
    return u, -u @ xs


def collect_neurons(max_lines=60, patience=15):
    neurons = []  # list of (u, c)
    since_new = 0
    for _ in range(max_lines):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        found_new = False
        for t in find_kinks(x0, d):
            r = neuron_at_kink(x0, d, t)
            if r is None:
                continue
            u, c = r
            if any(
                np.linalg.norm(u - u2) < 1e-4 and abs(c - c2) < 1e-4 * (1 + abs(c))
                for u2, c2 in neurons
            ):
                continue
            neurons.append((u, c))
            found_new = True
        since_new = 0 if found_new else since_new + 1
        if since_new >= patience:
            break
    return neurons


def resolve_signs(U, C):
    """Each hyperplane is known up to sign. True model has no free linear term:
    f = sum b_i relu(u_i x + c_i) + L.x + b0 with L = -sum_{i in S} b_i u_i where S is
    the set of neurons whose true orientation is flipped. Fit and find S."""
    k = len(U)
    X = rng.normal(size=(40 * k + 200, DIM)) * 3
    y = np.array([f(x) for x in X])
    feats = np.maximum(0, X @ U.T + C)
    M = np.hstack([feats, X, np.ones((len(X), 1))])
    coef, *_ = np.linalg.lstsq(M, y, rcond=None)
    beta, L = coef[:k], coef[k : k + DIM]
    cols = -(beta[:, None] * U)  # contribution if flipped, shape (k, DIM)
    best, best_err = None, np.inf
    # brute force over subsets (in chunks)
    if k <= 22:
        chunk = 1 << 16
        total = 1 << k
        bits = np.arange(k)
        for start in range(0, total, chunk):
            idx = np.arange(start, min(total, start + chunk))
            mask = ((idx[:, None] >> bits) & 1).astype(np.float64)
            err = np.linalg.norm(mask @ cols - L, axis=1)
            j = np.argmin(err)
            if err[j] < best_err:
                best_err, best = err[j], mask[j].astype(bool)
    else:  # fallback: greedy/rounded least squares
        g, *_ = np.linalg.lstsq(cols.T, L, rcond=None)
        best = g > 0.5
    signs = np.where(best, -1.0, 1.0)
    return signs


def main():
    neurons = collect_neurons()
    U = np.array([u for u, _ in neurons])
    C = np.array([c for _, c in neurons])
    signs = resolve_signs(U, C)
    A1_stolen = U * signs[:, None]
    np.save(os.path.join(HERE, "stolen_A1.npy"), A1_stolen)
    print(f"Recovered {len(A1_stolen)} neurons")
    print(A1_stolen)
    return A1_stolen


if __name__ == "__main__":
    main()
