"""Extract A1 (up to neuron permutation and row scaling) from a one-hidden-layer
ReLU network using only black-box queries to forward(x).

Method (critical-point / gradient-difference attack):
  1. Walk along random lines x(t) = x0 + t*d and locate the points where the
     piecewise-linear function f(x(t)) changes slope. Each such point lies on
     a hyperplane A1[i] . x + b1[i] = 0 for some hidden neuron i.
  2. At each critical point, estimate the gradient of f just before and just
     after the kink. The difference is A2[i] * A1[i], i.e. a scaled row of A1.
  3. Normalise the rows and de-duplicate them to get one row per neuron.
"""
import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi, depth=0, out=None, fcache=None):
    """Recursively find t values in [lo, hi] where g(t) = f(x0 + t d) kinks."""
    if out is None:
        out = []
    g = lambda t: f(x0 + t * d)
    delta = 1e-7 * max(1.0, hi - lo)
    glo, ghi = g(lo), g(hi)
    sL = (g(lo + delta) - glo) / delta
    sR = (ghi - g(hi - delta)) / delta
    mid = 0.5 * (lo + hi)
    gm = g(mid)
    scale = 1e-9 + 1e-7 * (abs(glo) + abs(ghi))

    # No kink: slopes agree and midpoint lies on the line.
    if abs(sL - sR) < 1e-7 * (1 + abs(sL)) and abs(gm - (glo + sL * (mid - lo))) < scale:
        return out
    if hi - lo < 1e-9 or depth > 60:
        return out
    # Try single-kink hypothesis: intersect the two linear pieces.
    if abs(sL - sR) > 1e-12:
        tstar = (ghi - sR * hi - glo + sL * lo) / (sL - sR)
        if lo + 2 * delta < tstar < hi - 2 * delta:
            pred = glo + sL * (tstar - lo)
            if abs(g(tstar) - pred) < scale:
                # verify at quarter points of each side
                q1 = 0.5 * (lo + tstar)
                q2 = 0.5 * (tstar + hi)
                if (abs(g(q1) - (glo + sL * (q1 - lo))) < scale
                        and abs(g(q2) - (ghi + sR * (q2 - hi))) < scale):
                    out.append(tstar)
                    return out
    find_kinks(x0, d, lo, mid, depth + 1, out)
    find_kinks(x0, d, mid, hi, depth + 1, out)
    return out


def grad(x, h=1e-6):
    g = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        g[j] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def normalise(v):
    v = v / np.linalg.norm(v)
    # fix sign convention: largest-magnitude entry positive
    return v * np.sign(v[np.argmax(np.abs(v))])


def main():
    rows = []
    counts = []
    stale = 0
    for it in range(200):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        kinks = sorted(find_kinks(x0, d, -30.0, 30.0))
        new = 0
        for k, t in enumerate(kinks):
            # stay well clear of neighbouring kinks
            gap = min([abs(t - s) for s in kinks if s != t] + [1.0])
            eps = min(1e-3, gap / 4)
            xa = x0 + (t - eps) * d
            xb = x0 + (t + eps) * d
            diff = grad(xb, h=min(1e-6, eps / 100)) - grad(xa, h=min(1e-6, eps / 100))
            if np.linalg.norm(diff) < 1e-8:
                continue
            v = normalise(diff)
            for i, r in enumerate(rows):
                if abs(np.dot(r, v)) > 0.999:
                    # running average to refine the estimate
                    rows[i] = normalise(r * counts[i] + v)
                    counts[i] += 1
                    break
            else:
                rows.append(v)
                counts.append(1)
                new += 1
        stale = 0 if new else stale + 1
        if stale >= 15 and it >= 20:
            break

    A = np.array(rows)
    np.save(OUT, A)
    print(f"Recovered {A.shape[0]} neurons (rows normalised to unit norm):")
    np.set_printoptions(precision=5, suppress=True, linewidth=150)
    print(A)


if __name__ == "__main__":
    main()
