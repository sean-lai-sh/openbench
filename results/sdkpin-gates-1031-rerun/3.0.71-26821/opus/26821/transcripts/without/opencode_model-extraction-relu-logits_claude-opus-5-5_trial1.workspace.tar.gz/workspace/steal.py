"""Extract A1 (up to neuron permutation and scaling) from a 1-hidden-layer ReLU net
using only black-box queries to forward(x)."""
import os
import itertools
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(1234)
nq = 0


def f(x):
    global nq
    nq += 1
    return forward(np.asarray(x, dtype=np.float64))


def grad(x, h=1e-6):
    """Gradient of the locally-linear function at x (central differences)."""
    g = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        g[j] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def find_kinks(x0, d, lo, hi):
    """Return t-values of kinks of t -> f(x0 + t d) in [lo, hi]."""
    F = lambda t: f(x0 + t * d)
    h = 1e-7
    kinks = []

    def slope_r(t):
        return (F(t + h) - F(t)) / h

    def slope_l(t):
        return (F(t) - F(t - h)) / h

    def rec(a, b, fa, fb, sa, sb, depth):
        if b - a < 1e-9 or depth > 60:
            return
        scale = 1e-7 * (1 + abs(fa) + abs(fb))
        if abs(sa - sb) < 1e-6 and abs((fb - fa) - sa * (b - a)) < scale:
            return  # linear on [a, b]
        # if exactly one kink, it's at the intersection of the two lines
        if abs(sa - sb) > 1e-9:
            tk = (fb - fa + sa * a - sb * b) / (sa - sb)
            if a + 1e-6 < tk < b - 1e-6:
                ftk = F(tk)
                pred = fa + sa * (tk - a)
                if abs(ftk - pred) < scale:
                    # verify: slopes left/right of tk match sa / sb
                    if abs(slope_l(tk - 1e-5) - sa) < 1e-5 and abs(slope_r(tk + 1e-5) - sb) < 1e-5:
                        kinks.append(tk)
                        return
        m = 0.5 * (a + b)
        fm = F(m)
        sml, smr = slope_l(m), slope_r(m)
        rec(a, m, fa, fm, sa, sml, depth + 1)
        rec(m, b, fm, fb, smr, sb, depth + 1)

    rec(lo, hi, F(lo), F(hi), slope_r(lo), slope_l(hi), 0)
    return kinks


# ---- 1. collect critical points and gradient jumps --------------------------
cands = []  # (unit normal, point on hyperplane, jump magnitude)
for line in range(30):
    x0 = rng.normal(size=DIM)
    d = rng.normal(size=DIM)
    d /= np.linalg.norm(d)
    for t in find_kinks(x0, d, -100.0, 100.0):
        xs = x0 + t * d
        eps = 1e-4
        J = grad(xs + eps * d) - grad(xs - eps * d)
        nJ = np.linalg.norm(J)
        if nJ < 1e-8:
            continue
        u = J / nJ
        cands.append((u, xs, nJ))

# ---- 2. cluster by direction (sign-insensitive) -----------------------------
clusters = []
for u, xs, nJ in cands:
    for c in clusters:
        if abs(np.dot(c["u"], u)) > 0.9999:
            c["members"].append((u * np.sign(np.dot(c["u"], u)), xs))
            break
    else:
        clusters.append({"u": u, "members": [(u, xs)]})

neurons = []
for c in clusters:
    us = np.array([m[0] for m in c["members"]])
    u = us.mean(0)
    u /= np.linalg.norm(u)
    cs = np.array([-np.dot(u, m[1]) for m in c["members"]])
    neurons.append((u, np.median(cs), len(c["members"])))

# Every true hyperplane crosses (almost) every random line; spurious directions
# (from two nearby kinks being merged) appear only rarely -> drop them.
maxcnt = max(n[2] for n in neurons)
neurons = [n for n in neurons if n[2] >= max(3, 0.3 * maxcnt)]

U = np.array([n[0] for n in neurons])  # (k, DIM) unit row directions
C = np.array([n[1] for n in neurons])  # offsets: hyperplane u.x + c = 0
k = len(neurons)
print(f"Found {k} hidden neurons using {nq} queries")

# ---- 3. recover sign of each row (global identifiability) -------------------
# f(x) = sum_i alpha_i ReLU(u_i.x + c_i) + g.x + g0 ; a neuron whose true
# orientation is -u_i contributes -alpha_i u_i to g.
N = 2000
X = rng.normal(size=(N, DIM)) * 3
y = np.array([f(x) for x in X])
Z = X @ U.T + C
Phi = np.hstack([np.maximum(Z, 0), X, np.ones((N, 1))])
coef, *_ = np.linalg.lstsq(Phi, y, rcond=None)
alpha = coef[:k]
g = coef[k:k + DIM]
print("fit residual:", np.abs(Phi @ coef - y).max())

V = -(alpha[:, None] * U)  # contribution of flipping neuron i to g
sigma = np.ones(k)
if k <= 24:
    best, best_err = None, np.inf
    chunk = 1 << min(k, 16)
    hi_bits = k - min(k, 16)
    low = np.array(list(itertools.product([0, 1], repeat=min(k, 16))), dtype=float)
    Vlow, Vhigh = V[:min(k, 16)], V[min(k, 16):]
    for hb in itertools.product([0, 1], repeat=hi_bits):
        base = np.array(hb, dtype=float) @ Vhigh if hi_bits else np.zeros(DIM)
        err = np.linalg.norm(low @ Vlow + base - g, axis=1)
        i = np.argmin(err)
        if err[i] < best_err:
            best_err = err[i]
            best = np.concatenate([low[i], np.array(hb, dtype=float)])
    sigma = 1 - 2 * best
    print("sign-recovery residual:", best_err)
else:
    print("too many neurons for exact sign recovery; signs left arbitrary")

A1_stolen = sigma[:, None] * U
np.save(OUT, A1_stolen)
print("Saved", OUT, "shape", A1_stolen.shape)
print(A1_stolen)
