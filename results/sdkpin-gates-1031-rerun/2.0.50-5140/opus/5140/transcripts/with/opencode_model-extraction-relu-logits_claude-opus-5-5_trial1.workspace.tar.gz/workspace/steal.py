"""Extract A1 (up to neuron permutation and scaling) from a 1-hidden-layer ReLU
network using only black-box queries to forward(x).

Method:
  1. Walk along random lines x0 + t*d and locate the "critical points" where the
     piecewise-linear output has a kink (a hidden neuron crosses zero).
  2. At each kink, estimate the input gradient just before and just after it.
     The difference equals a2_i * A1_i (up to sign) for the neuron that flipped,
     which gives row i of A1 up to scale.
  3. Deduplicate the recovered directions across many lines.
  4. Resolve the sign of each row (ReLU(z) != ReLU(-z)) by requiring that the
     gradient at arbitrary points is explained exactly by the recovered neurons.
"""

import os
import itertools
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)

f = lambda x: forward(np.asarray(x, dtype=np.float64))


def gradient(x, h=1e-7):
    g = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        g[j] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def find_kinks(x0, d, T=30.0, n_grid=60):
    """Return t-values of kinks of g(t)=f(x0+t d) in [-T, T]."""
    g = lambda t: f(x0 + t * d)
    ts = np.linspace(-T, T, n_grid + 1)
    kinks = []
    VTOL, STOL, MINW = 1e-10, 1e-6, 1e-8

    def slopes_at(t, ft, dl):
        return (ft - g(t - dl)) / dl, (g(t + dl) - ft) / dl

    def search(a, b, fa, fb, sa, sb, depth=0):
        # sa: slope just right of a, sb: slope just left of b
        if abs(sa - sb) < STOL:
            m = 0.5 * (a + b)
            if (
                abs(g(m) - 0.5 * (fa + fb)) < VTOL
                and abs(fb - fa - sa * (b - a)) < VTOL * 10
            ):
                return  # linear on [a, b]
        else:
            t = (fb - fa + sa * a - sb * b) / (sa - sb)
            if a < t < b:
                ft = g(t)
                if (
                    abs(ft - (fa + sa * (t - a))) < VTOL
                    and abs(ft - (fb - sb * (b - t))) < VTOL
                ):
                    # both sides must be linear: verify at the midpoints of
                    # [a, t] and [t, b] as well
                    m1, m2 = 0.5 * (a + t), 0.5 * (t + b)
                    dl = min(1e-7, (t - a) / 10, (b - t) / 10)
                    stl, str_ = slopes_at(t, ft, dl)
                    if (
                        abs(g(m1) - (fa + sa * (m1 - a))) < VTOL
                        and abs(g(m2) - (fb - sb * (b - m2))) < VTOL
                        and abs(stl - sa) < STOL
                        and abs(str_ - sb) < STOL
                    ):
                        kinks.append(t)
                        return
        if b - a < MINW or depth > 80:
            kinks.append(0.5 * (a + b))
            return
        m = 0.5 * (a + b)
        fm = g(m)
        dl = min(1e-7, (b - a) / 10)
        sml, smr = slopes_at(m, fm, dl)
        search(a, m, fa, fm, sa, sml, depth + 1)
        search(m, b, fm, fb, smr, sb, depth + 1)

    vals = [g(t) for t in ts]
    sl = [slopes_at(t, v, 1e-7) for t, v in zip(ts, vals)]
    for k in range(n_grid):
        search(ts[k], ts[k + 1], vals[k], vals[k + 1], sl[k][1], sl[k + 1][0])
    kinks = sorted(kinks)
    out = []
    for t in kinks:
        if not out or t - out[-1] > 1e-7:
            out.append(t)
    return out


def extract_rows(n_lines=30):
    rows = []  # unit vectors (sign arbitrary)
    jumps = []  # gradient jump vectors (pos side of row minus neg side)
    for _ in range(n_lines):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        ks = find_kinks(x0, d)
        for i, t in enumerate(ks):
            gaps = []
            if i > 0:
                gaps.append(t - ks[i - 1])
            if i < len(ks) - 1:
                gaps.append(ks[i + 1] - t)
            eps = min([1e-3] + [0.3 * gp for gp in gaps])
            h = eps * 1e-3
            gl = gradient(x0 + (t - eps) * d, h)
            gr = gradient(x0 + (t + eps) * d, h)
            delta = gr - gl
            nrm = np.linalg.norm(delta)
            if nrm < 1e-8:
                continue
            u = delta / nrm
            # orient u so that the right side of the kink is u's positive side
            # (sign of a2 absorbed into jump); fix canonical direction later
            if u @ d < 0:
                u_dir = -u
            else:
                u_dir = u
            # jump from negative side of u_dir to positive side of u_dir
            jump = delta if u_dir @ d > 0 else -delta
            # Note: jump = a2_i * A1_i if u_dir is parallel to A1_i (sign +)
            dup = False
            for r in rows:
                if abs(abs(r @ u_dir) - 1) < 1e-4:
                    dup = True
                    break
            if not dup:
                rows.append(u_dir)
                jumps.append(jump)
    return np.array(rows), np.array(jumps)


def kink_offsets(rows):
    """Estimate bias beta_i so that the hyperplane is rows_i . x + beta_i = 0."""
    betas = []
    for u in rows:
        # walk along u from origin and find the kink belonging to this neuron
        best = None
        x0 = np.zeros(DIM)
        for t in find_kinks(x0, u, T=60.0, n_grid=120):
            x = t * u
            eps = 1e-4
            delta = gradient(x + eps * u, 1e-8) - gradient(x - eps * u, 1e-8)
            if (
                np.linalg.norm(delta) > 1e-8
                and abs(abs(delta @ u) / np.linalg.norm(delta) - 1) < 1e-3
            ):
                best = -t
                break
        betas.append(best if best is not None else 0.0)
    return np.array(betas)


def resolve_signs(rows, jumps, betas):
    """Choose orientation of each row so the network's gradient is explained."""
    n = len(rows)
    resid = []
    for _ in range(5):
        x = rng.normal(size=DIM) * 2
        g = gradient(x, 1e-7)
        active = rows @ x + betas > 0
        resid.append(g - jumps[active].sum(axis=0))
    r = np.mean(resid, axis=0)
    # With row i flipped, the true contribution differs by -jump_i on every
    # point, so r = -sum_{i flipped} jumps_i. Search subset (meet in middle).
    target = -r
    if n > 26:
        return rows  # too many neurons for exhaustive search; leave as is
    h1 = n // 2
    A, B = jumps[:h1], jumps[h1:]

    def all_sums(M):
        k = len(M)
        masks = (
            np.array(list(itertools.product([0, 1], repeat=k)), dtype=float)
            if k
            else np.zeros((1, 0))
        )
        return masks, masks @ M if k else np.zeros((1, DIM))

    ma, sa = all_sums(A)
    mb, sb = all_sums(B)
    best_d = np.inf
    best_mask = np.zeros(n)
    # for each half-B sum, find nearest half-A sum to target - sB
    from numpy.linalg import norm

    for j in range(len(sb)):
        need = target - sb[j]
        dists = norm(sa - need, axis=1)
        k = np.argmin(dists)
        if dists[k] < best_d:
            best_d = dists[k]
            best_mask = np.concatenate([ma[k], mb[j]])
    flips = best_mask.astype(bool)
    signs = np.where(flips, -1.0, 1.0)
    return rows * signs[:, None]


def main():
    rows, jumps = extract_rows()
    betas = kink_offsets(rows)
    rows = resolve_signs(rows, jumps, betas)
    print("Recovered %d hidden neurons" % len(rows))
    np.save(OUT, rows)
    print(rows)


if __name__ == "__main__":
    main()
