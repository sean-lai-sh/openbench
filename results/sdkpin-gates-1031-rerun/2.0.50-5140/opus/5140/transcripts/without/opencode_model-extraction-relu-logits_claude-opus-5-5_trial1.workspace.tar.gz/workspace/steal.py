"""Extract A1 (up to neuron permutation and scaling) from a 1-hidden-layer ReLU net
using only black-box queries to forward(x).

Method: along random lines, f is piecewise linear; each kink is where some hidden
neuron's pre-activation crosses zero. The jump in the full gradient across a kink
is proportional to that neuron's weight row. Collect and de-duplicate these.
"""

import os
import itertools
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def grad(x, h=1e-6):
    g = np.zeros(DIM)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = h
        g[i] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def find_kinks(x0, d, lo, hi):
    """Return sorted list of t where f(x0 + t d) has a kink in [lo, hi]."""
    g = lambda t: f(x0 + t * d)
    kinks = []

    def slope_at(t, s):
        delta = 1e-6
        return (g(t + s * delta) - g(t)) / (s * delta)

    def rec(a, b, fa, fb, sa, sb, depth):
        # sa: slope just right of a, sb: slope just left of b
        if b - a < 1e-9 or depth > 60:
            kinks.append(0.5 * (a + b))
            return
        tol = 1e-6 * (1 + abs(sa) + abs(sb))
        if abs(sa - sb) < tol:
            # also verify linearity at midpoint to catch cancelling kinks
            m = 0.5 * (a + b)
            if abs(g(m) - 0.5 * (fa + fb)) < 1e-9 * (1 + abs(fa)):
                return
        else:
            # candidate single kink at intersection of the two lines
            t = (fb - fa + sa * a - sb * b) / (sa - sb)
            if a < t < b:
                pred = fa + sa * (t - a)
                ft = g(t)
                if abs(ft - pred) < 1e-9 * (1 + abs(ft)):
                    # check the region on each side is truly linear
                    m1, m2 = 0.5 * (a + t), 0.5 * (t + b)
                    if abs(g(m1) - (fa + sa * (m1 - a))) < 1e-9 * (1 + abs(fa)) and abs(
                        g(m2) - (fb + sb * (m2 - b))
                    ) < 1e-9 * (1 + abs(fb)):
                        kinks.append(t)
                        return
        m = 0.5 * (a + b)
        fm = g(m)
        rec(a, m, fa, fm, sa, slope_at(m, -1), depth + 1)
        rec(m, b, fm, fb, slope_at(m, +1), sb, depth + 1)

    rec(lo, hi, g(lo), g(hi), slope_at(lo, +1), slope_at(hi, -1), 0)
    return sorted(kinks)


def main():
    hyperplanes = []  # each: (u unit vector, beta, w) with neuron z = u.x + beta, jump w*u
    n_lines = 60
    R = 20.0
    for _ in range(n_lines):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        ts = find_kinks(x0, d, -R, R)
        if not ts:
            continue
        bounds = [-R] + ts + [R]
        for k, t in enumerate(ts):
            # step just past the kink, staying well inside the neighbouring pieces
            eps = min(1e-4, 0.25 * (t - bounds[k]), 0.25 * (bounds[k + 2] - t))
            jump = grad(x0 + (t + eps) * d, h=eps * 1e-2) - grad(x0 + (t - eps) * d, h=eps * 1e-2)
            nrm = np.linalg.norm(jump)
            if nrm < 1e-8:
                continue
            u = jump / nrm
            # orient so that z increases along d
            if u @ d < 0:
                u = -u
            xs = x0 + t * d
            beta = -u @ xs
            w = jump @ u  # jump (in direction of increasing z) = w * u
            # dedupe
            key = np.append(u, beta)
            key /= np.linalg.norm(key)
            dup = False
            for u2, b2, w2, cnt in hyperplanes:
                k2 = np.append(u2, b2)
                k2 /= np.linalg.norm(k2)
                if abs(key @ k2) > 1 - 1e-6:
                    dup = True
                    break
            if not dup:
                hyperplanes.append((u, beta, w, 1))

    n = len(hyperplanes)
    U = np.array([h[0] for h in hyperplanes])
    B = np.array([h[1] for h in hyperplanes])
    W = np.array([h[2] for h in hyperplanes])
    print(f"Found {n} hidden neurons")

    # Resolve sign ambiguity of each row: gradient at x equals
    # sum_i W_i U_i [z_i(x)>0] - sum_{flipped i} W_i U_i.
    if n <= 22:
        residuals = []
        for _ in range(5):
            x = rng.normal(size=DIM)
            z = U @ x + B
            residuals.append(grad(x) - (W * (z > 0)) @ U)
        r = np.mean(residuals, axis=0)
        V = -(W[:, None] * U)  # contribution if flipped
        best, best_err = None, np.inf
        chunk = 16
        lo_n = min(n, chunk)
        lo_masks = np.array(list(itertools.product([0, 1], repeat=lo_n)), dtype=float)
        lo_sums = lo_masks @ V[:lo_n]
        hi_n = n - lo_n
        for hi_bits in itertools.product([0, 1], repeat=hi_n):
            hb = np.array(hi_bits, dtype=float)
            hs = hb @ V[lo_n:] if hi_n else np.zeros(DIM)
            errs = np.linalg.norm(lo_sums + hs - r, axis=1)
            j = np.argmin(errs)
            if errs[j] < best_err:
                best_err = errs[j]
                best = np.concatenate([lo_masks[j], hb])
        if best is not None and best_err < 1e-4 * (1 + np.linalg.norm(r)):
            flip = best.astype(bool)
            U[flip] = -U[flip]
            B[flip] = -B[flip]
            print(f"Sign resolution residual {best_err:.2e}, flipped {flip.sum()} rows")
        else:
            print("Could not resolve signs reliably; rows are correct up to sign")

    A1_stolen = U  # rows: hidden neurons, unit-normalized
    np.save(OUT, A1_stolen)
    print("Stolen A1 shape:", A1_stolen.shape)
    print(A1_stolen)
    return A1_stolen


if __name__ == "__main__":
    main()
