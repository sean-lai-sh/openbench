"""Extract A1 (up to neuron permutation and scaling) from a 1-hidden-layer ReLU
network using only black-box queries to forward(x).

Method:
  1. Along random lines, f is piecewise linear; locate kinks (critical points)
     by recursive bisection.
  2. At each kink, the gradient jump across it equals (+/-) A2_i * A1_i, giving
     the direction of row i of A1 and a point on its hyperplane.
  3. Cluster the directions across many lines to get the distinct neurons.
  4. Resolve the sign of each row (which side of the hyperplane is active) by
     solving a small subset-sum on the gradient at a reference point.
"""

import os
import itertools
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def grad(x, eps=1e-7):
    g = np.zeros(DIM)
    for k in range(DIM):
        e = np.zeros(DIM)
        e[k] = eps
        g[k] = (f(x + e) - f(x - e)) / (2 * eps)
    return g


def find_kinks_on_line(x0, d, T=30.0, n_grid=600, tol=1e-7):
    ts = np.linspace(-T, T, n_grid)
    fs = np.array([f(x0 + t * d) for t in ts])
    kinks = []

    def rec(a, b, fa, fb, depth=0):
        m = 0.5 * (a + b)
        fm = f(x0 + m * d)
        dev = abs(fm - 0.5 * (fa + fb))
        if dev < 1e-12 * max(1.0, abs(fa), abs(fb)) + 1e-14:
            return
        if b - a < tol or depth > 60:
            kinks.append(m)
            return
        rec(a, m, fa, fm, depth + 1)
        rec(m, b, fm, fb, depth + 1)

    for i in range(n_grid - 1):
        rec(ts[i], ts[i + 1], fs[i], fs[i + 1])
    return kinks


def canon(v):
    u = v / np.linalg.norm(v)
    k = np.argmax(np.abs(u))
    return u if u[k] > 0 else -u


def collect(n_lines=40):
    recs = []  # (unit direction a_hat, p, offset c)
    for _ in range(n_lines):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        for t in find_kinks_on_line(x0, d):
            delta = 1e-4
            gl = grad(x0 + (t - delta) * d)
            gr = grad(x0 + (t + delta) * d)
            v = gr - gl
            if np.linalg.norm(v) < 1e-9:
                continue
            a = canon(v)
            p = float(v @ a) * np.sign(a @ d)
            c = float(a @ (x0 + t * d))
            recs.append((a, p, c))
    return recs


def cluster(recs, cos_tol=1e-4, off_tol=1e-3):
    clusters = []  # lists of records
    for r in recs:
        for cl in clusters:
            a0 = cl[0][0]
            if 1 - abs(a0 @ r[0]) < cos_tol and abs(cl[0][2] - r[2]) < off_tol:
                cl.append(r)
                break
        else:
            clusters.append([r])
    return clusters


def main():
    recs = collect()
    clusters = cluster(recs)
    # Keep neurons seen on at least two lines (filters merged/spurious kinks)
    good = [cl for cl in clusters if len(cl) >= 2]
    A = np.array([np.mean([r[0] for r in cl], axis=0) for cl in good])
    A /= np.linalg.norm(A, axis=1, keepdims=True)
    P = np.array([np.median([r[1] for r in cl]) for cl in good])
    C = np.array([np.median([r[2] for r in cl]) for cl in good])
    n = len(A)
    print(f"Found {n} neurons")

    # Sign resolution: g(x) = sum_i P_i A_i [A_i.x > C_i] - sum_{i in S} P_i A_i
    # where S = neurons whose active side is A_i.x < C_i.
    signs = np.ones(n)
    if n <= 24:
        x = rng.normal(size=DIM)
        g = grad(x)
        h = (A @ x - C > 0).astype(float)
        beta = g - (P * h) @ A
        V = -(P[:, None] * A)  # contributions of each neuron to beta
        best, best_err = None, np.inf
        half = n // 2
        # brute force over all subsets (chunked by first half)
        lo = np.array(list(itertools.product([0, 1], repeat=n - half)), dtype=float)
        lo_sum = lo @ V[half:]
        for bits in itertools.product([0, 1], repeat=half):
            s = np.array(bits, dtype=float) @ V[:half]
            err = np.linalg.norm(lo_sum + s - beta, axis=1)
            j = int(np.argmin(err))
            if err[j] < best_err:
                best_err = err[j]
                best = np.concatenate([np.array(bits, dtype=float), lo[j]])
        print(f"sign resolution residual: {best_err:.3e}")
        signs = np.where(best > 0.5, -1.0, 1.0)

    stolen = A * signs[:, None]
    np.save(OUT, stolen)
    print(stolen)
    return stolen


if __name__ == "__main__":
    main()
