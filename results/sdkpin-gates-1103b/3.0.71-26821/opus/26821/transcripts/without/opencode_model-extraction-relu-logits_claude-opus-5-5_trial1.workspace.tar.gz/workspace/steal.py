"""Extract A1 (up to neuron permutation and row scaling) from a 1-hidden-layer
ReLU network using only black-box queries to forward(x)."""
import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(p, d, lo, hi, flo, fhi, depth=0, out=None):
    """Recursively locate breakpoints of t -> f(p + t d) on [lo, hi]."""
    if out is None:
        out = []
    mid = 0.5 * (lo + hi)
    fmid = f(p + mid * d)
    # Linear on this interval? (check two interior points for robustness)
    q1, q3 = lo + 0.25 * (hi - lo), lo + 0.75 * (hi - lo)
    f1, f3 = f(p + q1 * d), f(p + q3 * d)
    tol = 1e-12 * (1 + abs(flo) + abs(fhi))
    lin = (abs(fmid - 0.5 * (flo + fhi)) < tol and
           abs(f1 - (0.75 * flo + 0.25 * fhi)) < tol and
           abs(f3 - (0.25 * flo + 0.75 * fhi)) < tol)
    if lin:
        return out
    if hi - lo < 1e-5 or depth > 60:
        out.append(mid)
        return out
    find_kinks(p, d, lo, mid, flo, fmid, depth + 1, out)
    find_kinks(p, d, mid, hi, fmid, fhi, depth + 1, out)
    return out


def refine_kink(p, d, t, w=1e-6):
    """Refine kink location using intersection of the two linear pieces."""
    a, b = t - 50 * w, t + 50 * w
    fa, fa2 = f(p + a * d), f(p + (a - w) * d)
    fb, fb2 = f(p + b * d), f(p + (b + w) * d)
    sa = (fa - fa2) / w
    sb = (fb2 - fb) / w
    if abs(sa - sb) < 1e-14:
        return t
    tk = (fb - fa + sa * a - sb * b) / (sa - sb)
    return tk if a <= tk <= b else t


def gradient(x, h=1e-7):
    g = np.zeros(DIM)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = h
        g[i] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def steal(n_lines=60, T=30.0):
    rows = []
    for _ in range(n_lines):
        p = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        # split into sub-intervals to avoid missing kinks that cancel
        grid = np.linspace(-T, T, 61)
        fv = [f(p + t * d) for t in grid]
        kinks = []
        for j in range(len(grid) - 1):
            find_kinks(p, d, grid[j], grid[j + 1], fv[j], fv[j + 1], out=kinks)
        kinks = sorted(kinks)
        merged = []
        for t in kinks:
            if not merged or t - merged[-1] > 3e-5:
                merged.append(t)
        for t in merged:
            t = refine_kink(p, d, t)
            eps = 1e-5
            gp = gradient(p + (t + eps) * d)
            gm = gradient(p + (t - eps) * d)
            diff = gp - gm
            n = np.linalg.norm(diff)
            if n < 1e-8:
                continue
            rows.append(diff / n)

    # Cluster rows by |cosine similarity| (sign is ambiguous)
    clusters = []
    for r in rows:
        for c in clusters:
            ref = c[0]
            cs = float(np.dot(ref, r))
            if abs(cs) > 0.999:
                c.append(r if cs > 0 else -r)
                break
        else:
            clusters.append([r])
    # Keep clusters seen at least twice (filters spurious detections)
    good = [c for c in clusters if len(c) >= 2] or clusters
    A = np.array([np.mean(c, axis=0) for c in good])
    A /= np.linalg.norm(A, axis=1, keepdims=True)
    return A


if __name__ == "__main__":
    A1_hat = steal()
    np.save(OUT, A1_hat)
    print("Recovered", A1_hat.shape[0], "neurons")
    print(A1_hat)
