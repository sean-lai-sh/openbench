"""Black-box extraction of A1 (up to row permutation and scaling) from a
one-hidden-layer ReLU network f(x) = A2 relu(A1 x + b1) + b2, using only
queries to forward(x).

Method (critical-point attack):
  1. Along random lines x0 + t*d, f is piecewise linear in t. Kinks occur
     exactly where some hidden neuron's pre-activation crosses zero.
  2. Locate kinks by recursive bisection, refined by intersecting the two
     adjacent linear pieces.
  3. At each kink, estimate the full input gradient just before and just
     after it. The difference equals +/- a2_i * A1[i, :], i.e. a scaled copy
     of the row of A1 for the neuron that switched.
  4. Normalize, deduplicate (up to sign) and stack the rows.
"""
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from forward import forward  # noqa: E402

DIM = 10
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi):
    g = lambda t: f(x0 + t * d)
    kinks = []

    def slope(t, h=1e-7):
        return (g(t + h) - g(t - h)) / (2 * h)

    def rec(a, b, fa, fb, depth):
        m = 0.5 * (a + b)
        fm = g(m)
        lin = 0.5 * (fa + fb)
        scale = max(1.0, abs(fa), abs(fb))
        if abs(fm - lin) < 1e-11 * scale and depth > 6:
            return  # looks linear on [a, b]
        if b - a < 1e-3:
            # Try to locate a single kink by intersecting the two pieces.
            sa, sb = slope(a + 1e-6), slope(b - 1e-6)
            if abs(sa - sb) < 1e-9:
                return
            t = (fb - fa + sa * a - sb * b) / (sa - sb)
            if a <= t <= b:
                kinks.append(t)
            return
        rec(a, m, fa, fm, depth + 1)
        rec(m, b, fm, fb, depth + 1)

    rec(lo, hi, g(lo), g(hi), 0)
    return sorted(kinks)


def grad(x, h=1e-6):
    gr = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        gr[j] = (f(x + e) - f(x - e)) / (2 * h)
    return gr


def canon(v):
    v = v / np.linalg.norm(v)
    j = np.argmax(np.abs(v))
    return v * np.sign(v[j])


def steal(n_lines=30, R=50.0, stable_after=8):
    rows = []
    unchanged = 0
    for _ in range(n_lines):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        ks = find_kinks(x0, d, -R, R)
        before = len(rows)
        for idx, t in enumerate(ks):
            gap = np.inf
            if idx > 0:
                gap = min(gap, t - ks[idx - 1])
            if idx + 1 < len(ks):
                gap = min(gap, ks[idx + 1] - t)
            eps = min(1e-3, gap / 4)
            if eps < 1e-5:
                continue
            diff = grad(x0 + (t + eps) * d) - grad(x0 + (t - eps) * d)
            if np.linalg.norm(diff) < 1e-8:
                continue
            v = canon(diff)
            if not any(abs(np.dot(v, r)) > 1 - 1e-4 for r in rows):
                rows.append(v)
        unchanged = unchanged + 1 if len(rows) == before else 0
        if unchanged >= stable_after:
            break
    return np.array(rows)


if __name__ == "__main__":
    A1_hat = steal()
    out = os.path.join(HERE, "stolen_A1.npy")
    np.save(out, A1_hat)
    print("Recovered matrix shape:", A1_hat.shape)
    print(A1_hat)
