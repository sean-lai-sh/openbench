"""Extract A1 (up to neuron permutation and row scaling) from a 1-hidden-layer
ReLU network using only black-box queries to forward(x).

Method: along random lines the function is piecewise linear; each kink is where
one hidden neuron's pre-activation crosses zero. At a kink, the jump in the
input-gradient equals A2[i] * A1[i, :], i.e. a scaled copy of row i of A1.
"""

import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from forward import forward  # noqa: E402

DIM = 10
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, a, b, fa, fb, sa, sb, out, depth=0, h=1e-6):
    """Find kink locations of g(t)=f(x0+t d) in [a,b].
    sa/sb are slopes just inside a and b."""
    if depth > 60 or b - a < 1e-9:
        return
    if abs(sa - sb) <= 1e-9 * (1 + abs(sa) + abs(sb)):
        return  # linear on [a,b] (assumed; possible cancelled pairs handled by many lines)
    # Intersection of the two end lines -> candidate single kink
    tc = (fb - fa + sa * a - sb * b) / (sa - sb)
    if a < tc < b:
        fc = f(x0 + tc * d)
        pred = fa + sa * (tc - a)
        if abs(fc - pred) <= 1e-9 * (1 + abs(fc)):
            # verify single kink: slopes just left/right of tc match ends
            sl = (fc - f(x0 + (tc - h) * d)) / h
            sr = (f(x0 + (tc + h) * d) - fc) / h
            if abs(sl - sa) < 1e-6 * (1 + abs(sa)) and abs(sr - sb) < 1e-6 * (
                1 + abs(sb)
            ):
                out.append(tc)
                return
    m = 0.5 * (a + b)
    fm = f(x0 + m * d)
    sml = (fm - f(x0 + (m - h) * d)) / h
    smr = (f(x0 + (m + h) * d) - fm) / h
    find_kinks(x0, d, a, m, fa, fm, sa, sml, out, depth + 1, h)
    find_kinks(x0, d, m, b, fm, fb, smr, sb, out, depth + 1, h)


def grad(x, h=1e-5):
    f0 = f(x)
    g = np.empty(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        g[j] = (f(x + e) - f0) / h
    return g


def row_at_kink(x0, d, t, kinks):
    # choose offset smaller than distance to neighbouring kinks
    others = [abs(k - t) for k in kinks if k != t]
    gap = min(others) if others else 1.0
    eps = min(1e-3, gap / 4)
    gl = grad(x0 + (t - eps) * d, h=eps / 100)
    gr = grad(x0 + (t + eps) * d, h=eps / 100)
    return gr - gl


def main():
    rows = []  # normalized unique rows

    def add(v):
        n = np.linalg.norm(v)
        if n < 1e-8:
            return False
        u = v / n
        if u[np.argmax(np.abs(u))] < 0:
            u = -u
        for r in rows:
            if abs(np.dot(r, u)) > 1 - 1e-4:
                return False
        rows.append(u)
        return True

    no_new = 0
    T = 20.0
    h = 1e-6
    while no_new < 30:
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        a, b = -T, T
        fa, fb = f(x0 + a * d), f(x0 + b * d)
        sa = (f(x0 + (a + h) * d) - fa) / h
        sb = (fb - f(x0 + (b - h) * d)) / h
        kinks = []
        find_kinks(x0, d, a, b, fa, fb, sa, sb, kinks)
        kinks.sort()
        new = False
        for t in kinks:
            v = row_at_kink(x0, d, t, kinks)
            if add(v):
                new = True
        no_new = 0 if new else no_new + 1

    A = np.array(rows)
    np.save(os.path.join(HERE, "stolen_A1.npy"), A)
    print(A.shape)
    print(A)
    return A


if __name__ == "__main__":
    main()
