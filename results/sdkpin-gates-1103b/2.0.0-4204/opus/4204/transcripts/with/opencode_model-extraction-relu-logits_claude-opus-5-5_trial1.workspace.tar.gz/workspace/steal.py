import os
import numpy as np
from forward import forward

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
DIM = 10
rng = np.random.default_rng(12345)
NQ = [0]


def f(x):
    NQ[0] += 1
    return forward(x)


def find_kinks(x0, d, lo, hi, n_init=200, tol=1e-11):
    """Return t values of kinks of g(t)=f(x0+t d) in [lo, hi]."""
    g = lambda t: f(x0 + t * d)
    kinks = []

    def rec(a, fa, b, fb, depth):
        m = 0.5 * (a + b)
        fm = g(m)
        if abs(fm - 0.5 * (fa + fb)) < tol * max(1.0, abs(fa) + abs(fb)):
            # check also quarter points to reduce false "linear"
            q = a + 0.25 * (b - a)
            fq = g(q)
            if abs(fq - (0.75 * fa + 0.25 * fb)) < tol * max(1.0, abs(fa) + abs(fb)):
                return
        if b - a < 1e-3:
            # try to locate single kink via two-line intersection
            h = (b - a) * 1e-3
            sa = (g(a + h) - fa) / h
            sb = (fb - g(b - h)) / h
            if abs(sa - sb) < 1e-12:
                return
            t = (fb - fa + sa * a - sb * b) / (sa - sb)
            if a < t < b:
                # verify: predicted value matches
                ft = g(t)
                pred = fa + sa * (t - a)
                if abs(ft - pred) < 1e-9:
                    kinks.append(t)
                    return
            if b - a < 1e-9:
                return
        rec(a, fa, m, fm, depth + 1)
        rec(m, fm, b, fb, depth + 1)

    ts = np.linspace(lo, hi, n_init + 1)
    fs = [g(t) for t in ts]
    for i in range(n_init):
        rec(ts[i], fs[i], ts[i + 1], fs[i + 1], 0)
    return kinks


def grad(x, h=1e-6):
    f0 = f(x)
    gr = np.zeros(DIM)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = h
        gr[i] = (f(x + e) - f0) / h
    return gr


def normalize(v):
    v = v / np.linalg.norm(v)
    i = np.argmax(np.abs(v))
    return v * np.sign(v[i])


rows = []
for line in range(30):
    x0 = rng.normal(size=DIM)
    d = rng.normal(size=DIM)
    d /= np.linalg.norm(d)
    for t in find_kinks(x0, d, -20.0, 20.0):
        xs = x0 + t * d
        eps = 1e-4
        # gradients on each side (forward differences stepping away from kink)
        gp = grad(xs + eps * d, h=1e-7)
        gm = grad(xs - eps * d, h=1e-7)
        diff = gp - gm
        if np.linalg.norm(diff) < 1e-8:
            continue
        rows.append(normalize(diff))

# cluster directions
clusters = []
for r in rows:
    for c in clusters:
        if np.linalg.norm(c[0] - r) < 1e-3:
            c.append(r)
            break
    else:
        clusters.append([r])

# keep clusters observed multiple times (robust to spurious detections)
clusters = [c for c in clusters if len(c) >= 2]
A1 = np.array([np.median(np.array(c), axis=0) for c in clusters])
A1 = np.array([normalize(r) for r in A1])
print("queries:", NQ[0], "neurons found:", A1.shape[0])
print(A1)
np.save(OUT, A1)
