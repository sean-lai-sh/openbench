import json, re, sys

R = []
def add(p, r): R.append([p, r])

FILES = "abcdefgh"
def sqname(i): return FILES[i % 8] + str(8 - i // 8)
def rc(i): return divmod(i, 8)
def idx(r, c): return 8 * r + c
def ok(r, c): return 0 <= r < 8 and 0 <= c < 8

# ---------------- Stage 0: normalise ----------------
# -> "BOARD64 CASTLE EP" ; side dropped (always white)
add(r" \d+ \d+$", "")
for n in range(8, 1, -1):
    add(str(n) + r"(?=[^ ]* )", "." * n)
add(r"1(?=[^ ]* )", ".")
add(r"/", "")
add(r" w ", " ")

NOTWHITE = "[^PNBRQK]"
BLACKSET = "[pnbrqk]"

def rule(cons, new, ep=None, castle=None):
    """Emit original line + finished line '~BOARD CASTLE EP'.
    cons: {sq: regex} ; new: {sq: replacement char}.
    Rule anchored to an UNFINISHED line (first char not '~')."""
    pat = "(?m)^"
    out = ""
    pos = 0
    g = 0
    for k in sorted(cons):
        if k > pos:
            g += 1
            pat += "([^~ \\n]{%d})" % (k - pos)
            out += "\\%d" % g
        g += 1
        pat += "(" + cons[k] + ")"
        out += new[k] if k in new else "\\%d" % g
        pos = k + 1
    if pos < 64:
        g += 1
        pat += "([^~ \\n]{%d})" % (64 - pos)
        out += "\\%d" % g
    pat += r" (\S+) (\S+)$"
    whole = "\\g<0>\n~" + out + " \\%d %s" % (g + 1, ep or "-")
    return pat, whole

def add_move(i, j, piece, between=(), newpiece=None, cap=NOTWHITE, extra_cons=None, extra_new=None, ep=None):
    cons = {i: re.escape(piece), j: cap}
    for b in between:
        cons[b] = r"\."
    if extra_cons:
        cons.update(extra_cons)
    new = {i: ".", j: newpiece or piece}
    if extra_new:
        new.update(extra_new)
    add(*rule(cons, new, ep=ep))

def ray(i, dr, dc):
    r, c = rc(i)
    out = []
    path = []
    r += dr; c += dc
    while ok(r, c):
        out.append((idx(r, c), tuple(path)))
        path.append(idx(r, c))
        r += dr; c += dc
    return out

ROOK = [(1,0),(-1,0),(0,1),(0,-1)]
BISH = [(1,1),(1,-1),(-1,1),(-1,-1)]
KN = [(1,2),(2,1),(-1,2),(-2,1),(1,-2),(2,-1),(-1,-2),(-2,-1)]

# ---------------- Stage 1: pseudo-legal moves ----------------
for i in range(64):
    r, c = rc(i)
    for piece, dirs in (("R", ROOK), ("B", BISH), ("Q", ROOK + BISH)):
        for dr, dc in dirs:
            for j, btw in ray(i, dr, dc):
                add_move(i, j, piece, btw)
    for dr, dc in KN:
        if ok(r + dr, c + dc):
            add_move(i, idx(r + dr, c + dc), "N")
    for dr in (-1, 0, 1):
        for dc in (-1, 0, 1):
            if (dr or dc) and ok(r + dr, c + dc):
                add_move(i, idx(r + dr, c + dc), "K")
    # pawns (white moves up: row decreases)
    if r >= 1:
        promo = (r == 1)
        np_ = "Q" if promo else "P"
        if r != 0:
            add_move(i, idx(r - 1, c), "P", cap=r"\.", newpiece=np_)
        for dc in (-1, 1):
            if ok(r - 1, c + dc):
                add_move(i, idx(r - 1, c + dc), "P", cap=BLACKSET, newpiece=np_)
        if r == 6:
            adj = [idx(4, c + d) for d in (-1, 1) if ok(4, c + d)]
            # two rules: with adjacent black pawn -> tentative ep ; otherwise "-"
            lk = "|".join("[^ ]{%d}p" % a for a in adj)
            base_cons = {i: "P", idx(4, c): r"\.", idx(5, c): r"\."}
            base_new = {i: ".", idx(4, c): "P"}
            p1, w1 = rule(base_cons, base_new, ep=FILES[c] + "3")
            p2, w2 = rule(base_cons, base_new, ep=None)
            p1 = p1.replace("(?m)^", "(?m)^(?=(?:" + lk + "))", 1)
            p2 = p2.replace("(?m)^", "(?m)^(?!(?:" + lk + "))", 1)
            add(p1, w1); add(p2, w2)

# en passant: ep square on rank 6 (row 2); white pawn on row 3 adjacent
for c in range(8):
    epsq = idx(2, c)
    for dc in (-1, 1):
        if ok(3, c + dc):
            i = idx(3, c + dc)
            pat, whole = rule({i: "P", epsq: r"\.", idx(3, c): "p"},
                              {i: ".", epsq: "P", idx(3, c): "."})
            pat = pat[:-len(r" (\S+) (\S+)$")] + " (\\S+) " + FILES[c] + "6$"
            # whole references group numbers; ep group is last-1 -> fine (castle group)
            add(pat, whole)

# ---------------- attack detection ----------------
def attacked_regex(k):
    """Regex (applied at the start of the 64-char board, no anchors beyond ^) matching
    if a BLACK piece attacks square k (white king/piece assumed there)."""
    alts = []
    r, c = rc(k)
    def before(j):  # skip to square j
        return "[^ ]{%d}" % j
    # sliders
    for dirs, sl in ((ROOK, "[rq]"), (BISH, "[bq]")):
        for dr, dc in dirs:
            path = []
            rr, cc = r + dr, c + dc
            while ok(rr, cc):
                j = idx(rr, cc)
                # attacker at j with empty path
                cons = {j: sl}
                for p in path:
                    cons[p] = r"\."
                alts.append(cons)
                path.append(j)
                rr += dr; cc += dc
    for dr, dc in KN:
        if ok(r + dr, c + dc):
            alts.append({idx(r + dr, c + dc): "n"})
    for dr in (-1, 0, 1):
        for dc in (-1, 0, 1):
            if (dr or dc) and ok(r + dr, c + dc):
                alts.append({idx(r + dr, c + dc): "k"})
    for dc in (-1, 1):                      # black pawns attack downward (row+1)
        if ok(r - 1, c + dc):
            alts.append({idx(r - 1, c + dc): "p"})
    return alts

def cons_to_regex(cons):
    pat = ""
    pos = 0
    for kk in sorted(cons):
        if kk > pos:
            pat += "[^ ]{%d}" % (kk - pos)
        pat += cons[kk]
        pos = kk + 1
    return pat

ATT = {}
def att_alt(k):
    if k not in ATT:
        ATT[k] = "|".join(cons_to_regex(c) for c in attacked_regex(k))
    return ATT[k]


def castle_rule(cons, new, flag, safe):
    pat = "(?m)^"
    out = ""
    pos = 0
    g = 0
    # lookaheads: none of the 'safe' squares attacked (board assumed with white king on e1: use
    # attack alternation at that square; the king is physically on e1 and transit squares are empty,
    # so slider rays through them behave correctly because the king itself never blocks a ray
    # towards the transit squares from the far side)
    look = ""
    for sqr in safe:
        look += "(?!" + att_alt(sqr) + ")"
    pat += look
    for k in sorted(cons):
        if k > pos:
            g += 1; pat += "([^~ \\n]{%d})" % (k - pos); out += "\\%d" % g
        g += 1; pat += "(" + cons[k] + ")"
        out += new[k] if k in new else "\\%d" % g
        pos = k + 1
    if pos < 64:
        g += 1; pat += "([^~ \\n]{%d})" % (64 - pos); out += "\\%d" % g
    pat += r" (\S*" + flag + r"\S*) (\S+)$"
    add(pat, "\\g<0>\n~" + out + " \\%d -" % (g + 1))

# e1=60 f1=61 g1=62 h1=63 d1=59 c1=58 b1=57 a1=56
castle_rule({60: "K", 61: r"\.", 62: r"\.", 63: "R"}, {60: ".", 61: "R", 62: "K", 63: "."}, "K", (60, 61))
castle_rule({56: "R", 57: r"\.", 58: r"\.", 59: r"\.", 60: "K"}, {56: ".", 57: ".", 58: "K", 59: "R", 60: "."}, "Q", (60, 59))

# ---------------- Stage 2: drop originals ----------------
add(r"(?m)^[^~\n][^\n]*\n?", "")

# ---------------- Stage 3: legality filter ----------------
for k in range(64):
    # king at k, and attacked by black
    pre = "[^ ]{%d}K" % k if k else "K"
    add("(?m)^~(?=" + pre + ")(?=" + att_alt(k) + ")[^\\n]*\\n?", "")

# ---------------- Stage 4: castling legality helper is built into generation?


# ---------------- Stage 4b: validate tentative en-passant ----------------
# finished line: ~BOARD CASTLE EP, EP is "-" or "<file>3".
# Pass A: append 'y' to EP if some capturer's capture leaves the black king safe.
# Pass B: EP without 'y' -> '-'; strip 'y'.
def white_attackers(k, virt):
    alts = []
    r, c = rc(k)
    for dirs, sl in ((ROOK, "[RQ]"), (BISH, "[BQ]")):
        for dr, dc in dirs:
            path = []
            rr, cc = r + dr, c + dc
            while ok(rr, cc):
                j = idx(rr, cc)
                v = virt.get(j)
                if v is None:
                    cons = {j: sl}
                    for p in path:
                        cons[p] = r"\."
                    alts.append(cons)
                    path.append(j)
                elif v == ".":
                    pass                      # transparent virtual-empty square
                else:
                    break                     # virtual blocker (the capturing pawn)
                rr += dr; cc += dc
    for dr, dc in KN:
        if ok(r + dr, c + dc) and idx(r + dr, c + dc) not in virt:
            alts.append({idx(r + dr, c + dc): "N"})
    for dr in (-1, 0, 1):
        for dc in (-1, 0, 1):
            if (dr or dc) and ok(r + dr, c + dc) and idx(r + dr, c + dc) not in virt:
                alts.append({idx(r + dr, c + dc): "K"})
    for dc in (-1, 1):
        if ok(r + 1, c + dc) and idx(r + 1, c + dc) not in virt:
            alts.append({idx(r + 1, c + dc): "P"})
    return alts

for c in range(8):
    for d in (-1, 1):
        if not ok(4, c + d):
            continue
        cap = idx(4, c + d)
        for k in range(64):
            virt = {cap: ".", idx(4, c): ".", idx(5, c): "p"}
            if k in virt:
                continue
            alts = white_attackers(k, virt)
            kk = ("[^ ]{%d}" % k if k else "") + "k"
            cp = ("[^ ]{%d}" % cap if cap else "") + "p"
            lookatt = "(?!" + "|".join(cons_to_regex(a) for a in alts) + ")" if alts else ""
            add("(?m)^(~(?=" + cp + ")(?=" + kk + ")" + lookatt + "[^ \\n]* [^ \\n]* " + FILES[c] + "3)$",
                "\\1y")
add(r"(?m)^(~[^ \n]* [^ \n]* )[a-h]3$", r"\1-")
add(r"(?m)^(~[^ \n]* [^ \n]* [a-h]3)y$", r"\1")

# ---------------- Stage 5: castling rights from board ----------------
# finished line: ~BOARD CASTLE -
def fix(flag, conds):
    # remove flag from castle field if NOT (all conds hold)
    # conds: {sq: char}; we do: if line fails a cond, strip flag.
    for sqr, ch in conds.items():
        pre = "[^ ]{%d}" % sqr if sqr else ""
        # (?m) line starting ~ ; board lookahead for violation; flag removal in castle field
        add("(?m)^(~(?=" + pre + "[^" + ch + "])[^ ]* [^ \\n]*?)" + flag, "\\1")
# White: K needs e1=K(60), h1=R(63); Q needs e1=K, a1=R(56)
# Black: k needs e8=k(4), h8=r(7);   q needs e8=k, a8=r(0)
for flag, conds in (("K", {60: "K", 63: "R"}), ("Q", {60: "K", 56: "R"}),
                    ("k", {4: "k", 7: "r"}), ("q", {4: "k", 0: "r"})):
    fix(flag, conds)

# ---------------- Stage 6: output formatting ----------------
# line: ~BOARD CASTLE EP ; CASTLE may be empty (double space) if all rights gone.
add(r"(?m)^~([^ ]{64})  ", r"~\1 - ")
add(r"\n+$", "")
add(r"(?m)^~([^ ]{8})([^ ]{8})([^ ]{8})([^ ]{8})([^ ]{8})([^ ]{8})([^ ]{8})([^ ]{8}) ", r"\1/\2/\3/\4/\5/\6/\7/\8 ")
for n in range(8, 0, -1):
    add(r"\." * n, str(n))
add(r"(?m) ([^ ]+) ([^ ]+)$", r" b \1 \2 0 0")

if __name__ == "__main__":
    json.dump(R, open("/app/re.json", "w"))
    print(len(R), "rules")
