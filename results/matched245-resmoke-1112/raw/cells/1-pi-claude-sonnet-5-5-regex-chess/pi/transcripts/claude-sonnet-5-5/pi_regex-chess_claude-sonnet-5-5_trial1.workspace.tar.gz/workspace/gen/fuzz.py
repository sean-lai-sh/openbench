import random, chess, json, re, sys, time
RES = json.load(open("/app/re.json"))
COMP = [(re.compile(p), r) for p, r in RES]
def run(fen):
    for p, r in COMP: fen = p.sub(r, fen)
    return [" ".join(x.split(" ")[:-2]) for x in fen.split("\n")]
def expected(board):
    out=set()
    for m in board.legal_moves:
        if m.promotion and m.promotion!=chess.QUEEN: continue
        c=board.copy(); c.push(m); out.add(" ".join(c.fen().split(" ")[:-2]))
    return out
def check(fen):
    b=chess.Board(fen)
    ours=run(fen); exp=expected(b)
    bad=[x for x in ours if not (x in exp or x.rpartition(" ")[0]+" -" in exp)]
    if bad or len(ours)!=len(exp) or len(set(ours))!=len(ours):
        return (fen, sorted(set(ours)-exp)[:3], sorted(exp-set(ours))[:3], len(ours), len(exp))
seed=int(sys.argv[1]) if len(sys.argv)>1 else 0
random.seed(seed)
N=int(sys.argv[2]) if len(sys.argv)>2 else 30
n=0; fails=0; t=time.time()
for g in range(N):
    b=chess.Board()
    for ply in range(random.randint(1,200)):
        if b.is_game_over(): break
        if b.turn==chess.WHITE:
            f=b.fen(); n+=1
            r=check(f)
            if r:
                fails+=1; print("FAIL",r)
                if fails>5: sys.exit(1)
        b.push(random.choice(list(b.legal_moves)))
print("positions",n,"fails",fails,time.time()-t)
