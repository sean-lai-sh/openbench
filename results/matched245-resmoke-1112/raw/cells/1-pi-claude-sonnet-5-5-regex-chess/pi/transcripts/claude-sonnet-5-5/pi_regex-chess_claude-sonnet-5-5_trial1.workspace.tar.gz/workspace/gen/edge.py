from fuzz_lib import check
cases = [
 # ep discovered rank check (illegal ep) -> ep field must be '-'
 "8/8/8/K2pP2r/8/8/8/7k w - d6 0 1",
 # legal ep
 "4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 1",
 # castle through attacked square f1
 "4k3/8/8/8/8/8/5r2/R3K2R w KQ - 0 1",
 # castle out of check
 "4k3/8/8/8/8/8/4r3/R3K2R w KQ - 0 1",
 # queenside: b1 attacked is fine
 "4k3/8/8/8/8/8/1r6/R3K2R w KQ - 0 1",
 # capture black rook on h8 removes black K right
 "4k2r/6B1/8/8/8/8/8/4K3 w k - 0 1",
 "r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1",
 # capture rook on a8 by promotion
 "r3k3/1P6/8/8/8/8/8/4K3 w q - 0 1",
 # promotion with capture
 "1n2k3/P7/8/8/8/8/8/4K3 w - - 0 1",
 "1nr1k3/P1P5/8/8/8/8/8/4K3 w - - 0 1",
 # white rook moves lose rights
 "r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1",
 # pinned ep pawn diagonal
 "4k3/8/8/2pP4/8/8/8/K3r3 w - c6 0 1",
 "7k/8/8/1b1pP3/8/8/8/4K3 w - d6 0 1",
 "8/8/3k4/3pP3/8/8/8/K2R4 w - d6 0 1",
 # white double push creating ep for black w/ pin
 "4k3/8/8/8/1p6/8/P7/4K3 w - - 0 1",
 "8/8/8/8/k2p4/8/4P3/4K2R w - - 0 1",
 "8/8/8/8/1k1p3R/8/4P3/4K3 w - - 0 1",
 "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
 "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1",
 "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1",
 "r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1",
 "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8",
 "r4rk1/1pp1qppp/p1np1n2/2b1p1B1/2B1P1b1/P1NP1N2/1PP1QPPP/R4RK1 w - - 0 10",
]
bad=0
for c in cases:
    r=check(c)
    print("OK " if not r else "BAD", c)
    if r: print(r); bad+=1
print("bad",bad)
