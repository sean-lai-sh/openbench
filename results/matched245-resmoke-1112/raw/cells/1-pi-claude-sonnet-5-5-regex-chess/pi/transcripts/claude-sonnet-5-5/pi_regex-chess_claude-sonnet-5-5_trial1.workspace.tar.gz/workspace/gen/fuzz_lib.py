import random, chess, json, re, sys, time
RES = json.load(open("/app/re.json"))
COMP = [(re.compile(p), r) for p, r in RES]
def run(fen):
    for p, r in COMP: fen = p.sub(r, fen)
    return [" ".join(x.split(" ")[:-2]) for x in fen.split("\n")]
def expected(board):
    out=set()
    for m in board.legal_moves:
        if m.promotion and m.promotion!=chess.QUEEN: continue
        c=board.copy(); c.push(m); out.add(" ".join(c.fen().split(" ")[:-2]))
    return out
def check(fen):
    b=chess.Board(fen)
    ours=run(fen); exp=expected(b)
    bad=[x for x in ours if not (x in exp or x.rpartition(" ")[0]+" -" in exp)]
    if bad or len(ours)!=len(exp) or len(set(ours))!=len(ours):
        return (fen, sorted(set(ours)-exp)[:3], sorted(exp-set(ours))[:3], len(ours), len(exp))
