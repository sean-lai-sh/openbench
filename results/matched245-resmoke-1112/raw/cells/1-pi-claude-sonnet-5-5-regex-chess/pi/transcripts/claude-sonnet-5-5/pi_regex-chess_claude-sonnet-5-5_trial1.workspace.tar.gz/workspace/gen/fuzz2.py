import random, chess, sys, time
from fuzz_lib import check
seed=int(sys.argv[1]); N=int(sys.argv[2])
random.seed(seed)
fails=0; n=0; t=time.time()
def rand_pos():
    b=chess.Board(None)
    # kings
    sqs=random.sample(range(64), 2+random.randint(0,14))
    b.set_piece_at(sqs[0], chess.Piece(chess.KING, chess.WHITE))
    b.set_piece_at(sqs[1], chess.Piece(chess.KING, chess.BLACK))
    for s in sqs[2:]:
        pt=random.choice([chess.PAWN]*3+[chess.KNIGHT,chess.BISHOP,chess.ROOK,chess.QUEEN])
        col=random.random()<0.5
        if pt==chess.PAWN and chess.square_rank(s) in (0,7): continue
        b.set_piece_at(s, chess.Piece(pt, col))
    b.turn=chess.WHITE
    return b
def castle_pos():
    b=chess.Board(None)
    b.set_piece_at(chess.E1, chess.Piece(chess.KING, True)); b.set_piece_at(chess.E8, chess.Piece(chess.KING, False))
    for sq,col in ((chess.A1,1),(chess.H1,1),(chess.A8,0),(chess.H8,0)):
        if random.random()<0.9: b.set_piece_at(sq, chess.Piece(chess.ROOK, bool(col)))
    for _ in range(random.randint(0,8)):
        s=random.randrange(64)
        if b.piece_at(s): continue
        pt=random.choice([chess.PAWN,chess.KNIGHT,chess.BISHOP,chess.ROOK,chess.QUEEN])
        if pt==chess.PAWN and chess.square_rank(s) in (0,7): continue
        b.set_piece_at(s, chess.Piece(pt, random.random()<0.5))
    b.turn=chess.WHITE
    b.castling_rights=0
    for sq in (chess.A1,chess.H1,chess.A8,chess.H8):
        if b.piece_at(sq) and b.piece_at(sq).piece_type==chess.ROOK and random.random()<0.8: b.castling_rights|=chess.BB_SQUARES[sq]
    return b
def ep_pos():
    b=rand_pos()
    # place black pawn double-pushed + white pawn adjacent
    f=random.randrange(8)
    for s in (chess.square(f,4),chess.square(f,5),chess.square(f,6)):
        if b.piece_at(s) and b.piece_at(s).piece_type==chess.KING: return None
        b.remove_piece_at(s)
    b.set_piece_at(chess.square(f,4), chess.Piece(chess.PAWN, False))
    d=random.choice([-1,1])
    if 0<=f+d<8:
        s=chess.square(f+d,4)
        if b.piece_at(s) and b.piece_at(s).piece_type==chess.KING: return None
        b.set_piece_at(s, chess.Piece(chess.PAWN, True))
    b.ep_square=chess.square(f,5)
    return b
def promo_pos():
    b=rand_pos()
    for _ in range(3):
        f=random.randrange(8); s=chess.square(f,6)
        if b.piece_at(s) and b.piece_at(s).piece_type==chess.KING: continue
        b.set_piece_at(s, chess.Piece(chess.PAWN, True))
    return b
gens=[rand_pos,castle_pos,ep_pos,promo_pos]
for i in range(N):
    b=gens[i%4]()
    if b is None: continue
    if not b.is_valid():
        continue
    if b.was_into_check() if hasattr(b,'was_into_check') else False: continue
    if not any(True for _ in b.legal_moves): continue
    f=b.fen()
    n+=1
    r=check(f)
    if r:
        fails+=1; print("FAIL",r)
        if fails>5: sys.exit(1)
print("positions",n,"fails",fails,time.time()-t)
