import json, re
R=[]
def add(p,r): R.append([p,r])
# --- parse
add(r'^(\S+) w (\S+) (\S+).*$', r'\1 \2 \3')
for d in range(8,0,-1):
    add(str(d)+r'(?=\S* \S+ \S+$)', '.'*d)
add(r'/', '//')
add(r'^(\S+) (\S+) (\S+)$', r'O\2#\3|\1//')
import itertools
L='KQkq'
for m in range(16):
    s=''.join(L[i] for i in range(4) if m>>i&1)
    code=''.join(str(i+1) if m>>i&1 else '-' for i in range(4))
    add('^O'+(s if s else '-')+'#', 'O'+code)
add(r'^(O.{4})-\|', r'\1-|')
for c in range(8):
    add('^(O.{4})'+'abcdefgh'[c]+r'6\|', r'\g<1>'+str(c)+'|')
# --- generation
def sq(r,c): return 7+r*10+c
def move(cond, chg):
    cond=dict(cond); chg=dict(chg)
    cond[0]='O'; chg[0]='N'
    idx=sorted(set(cond)|set(chg))
    pat='(?m)^'; rep=r'\g<0>'+'\n'; pos=0; g=0
    for i in idx:
        if i>pos:
            g+=1; pat+='(.{%d})'%(i-pos); rep+=r'\g<%d>'%g
        c=cond.get(i,'.')
        if i in chg:
            pat+='(?:%s)'%c; rep+=chg[i]
        else:
            g+=1; pat+='(%s)'%c; rep+=r'\g<%d>'%g
        pos=i+1
    g+=1; pat+='(.*)$'; rep+=r'\g<%d>'%g
    add(pat,rep)
def castle_clear(fr,to,chg):
    for s,f in ((sq(7,7),1),(sq(7,0),2),(sq(0,7),3),(sq(0,0),4)):
        if fr==s or to==s: chg[f]='-'
    if fr==sq(7,4): chg[1]='-'; chg[2]='-'
def std(piece,fr,to,path,dest='[.pnbrq]',newp=None,ep='-',extra=None):
    cond={fr:piece,to:dest}
    for p in path: cond[p]=r'\.'
    chg={fr:'.',to:newp or piece,5:ep}
    if extra: chg.update(extra)
    castle_clear(fr,to,chg)
    move(cond,chg)
ok=lambda r,c:0<=r<8 and 0<=c<8
for r in range(8):
  for c in range(8):
    fr=sq(r,c)
    for dr,dc in [(1,2),(2,1),(-1,2),(-2,1),(1,-2),(2,-1),(-1,-2),(-2,-1)]:
        if ok(r+dr,c+dc): std('N',fr,sq(r+dr,c+dc),[])
    for dr in (-1,0,1):
      for dc in (-1,0,1):
        if (dr or dc) and ok(r+dr,c+dc): std('K',fr,sq(r+dr,c+dc),[])
    for dr in (-1,0,1):
      for dc in (-1,0,1):
        if not(dr or dc): continue
        pcs=['Q']+(['B'] if dr and dc else ['R'])
        path=[]; k=1
        while ok(r+k*dr,c+k*dc):
            to=sq(r+k*dr,c+k*dc)
            for p in pcs: std(p,fr,to,path)
            path=path+[to]; k+=1
    # pawns
    if 1<=r<=6:
        np='Q' if r==1 else 'P'
        std('P',fr,sq(r-1,c),[],dest=r'\.',newp=np)
        if r==6: std('P',fr,sq(4,c),[sq(5,c)],dest=r'\.',ep=str(c))
        for dc in (-1,1):
            if ok(r-1,c+dc): std('P',fr,sq(r-1,c+dc),[],dest='[pnbrq]',newp=np)
        if r==3:
            for dc in (-1,1):
                if ok(r,c+dc):
                    move({fr:'P',sq(2,c+dc):r'\.',sq(3,c+dc):'p',5:str(c+dc)},
                         {fr:'.',sq(2,c+dc):'P',sq(3,c+dc):'.',5:'-'})
# castling with markers
e1=sq(7,4)
move({1:'1',e1:'K',e1+1:r'\.',e1+2:r'\.',e1+3:'R'},{1:'-',2:'-',5:'-',e1+1:'K',e1+2:'K',e1+3:'.'})
move({2:'2',e1:'K',e1-1:r'\.',e1-2:r'\.',e1-3:r'\.',e1-4:'R'},{1:'-',2:'-',5:'-',e1-1:'K',e1-2:'K',e1-4:'.'})
# --- legality filter
A=[r'p.{8}K',r'p.{10}K']
for o in (8,12,19,21): A+=['n.{%d}K'%(o-1),'K.{%d}n'%(o-1)]
for o in (1,9,10,11): A+=['k.{%d}K'%(o-1),'K.{%d}k'%(o-1)]
A+=[r'K\.*[qr]',r'[qr]\.*K']
for o,cl in ((10,'[qr]'),(9,'[qb]'),(11,'[qb]')):
    A+=[r'K(?:.{%d}\.)*.{%d}%s'%(o-1,o-1,cl), r'%s(?:.{%d}\.)*.{%d}K'%(cl,o-1,o-1)]
add(r'(?m)^N(?=.*(?:'+'|'.join(A)+r')).*\n?','')
add(r'(?m)^O.*\n?','')
add(r'KKK\.//$'.replace('$','(?=\n|$)'),'.RK.//')
add(r'(?m)\.\.KKK(...//)$',r'..KR.\1')
# --- output
for c in range(8):
    add(r'(?m)^(N.{4})%d\|'%c, r'\g<1>'+'abcdefgh'[c]+'3|')
add(r'(?m)^N(.{4})(-|..)\|(\S+)//$', r'\3 b \1 \2 0 0')
for i,ch in enumerate('KQkq'):
    add(r'(?m)(?<= b %s)%d'%('.'*i,i+1), ch)
for _ in range(4): add(r'(?m)(?<= b )([KQkq]*)-([KQkq-]*) ', r'\1\2 ')
add(r' b  ',' b - ')
add('//','/')
for d in range(8,0,-1): add(r'\.{%d}'%d,str(d))
add(r'\n+\Z','')
json.dump(R,open('re.json','w'))
print(len(R))
