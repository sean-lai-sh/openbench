"""Tensor-parallel linear layers (Megatron-style).

Weight layout follows torch.nn.Linear: weight has shape (out_features, in_features)
and y = x @ W^T + b.

ColumnParallelLinear: the output dimension is partitioned across ranks. Each rank
computes a slice of the output, and the slices are all-gathered along the last dim.

RowParallelLinear: the input dimension is partitioned across ranks. Each rank
computes a partial result on its slice of the input, and the partials are
all-reduced (summed). The bias is kept full on every rank and added after the
reduction.
"""

import torch
import torch.distributed as dist
import torch.nn.functional as F


def _world_size():
    if dist.is_available() and dist.is_initialized():
        return dist.get_world_size()
    return 1


def _rank():
    if dist.is_available() and dist.is_initialized():
        return dist.get_rank()
    return 0


def _divide(numerator, denominator):
    assert numerator % denominator == 0, (
        f"{numerator} is not divisible by {denominator}"
    )
    return numerator // denominator


# ---------------------------------------------------------------------------
# Communication primitives with correct autograd behaviour
# ---------------------------------------------------------------------------


def _all_reduce(x):
    if _world_size() == 1:
        return x
    x = x.contiguous()
    dist.all_reduce(x, op=dist.ReduceOp.SUM)
    return x


def _split_last_dim(x):
    world_size = _world_size()
    if world_size == 1:
        return x
    chunk = _divide(x.size(-1), world_size)
    return x.narrow(-1, _rank() * chunk, chunk).contiguous()


def _gather_last_dim(x):
    world_size = _world_size()
    if world_size == 1:
        return x
    x = x.contiguous()
    tensors = [torch.empty_like(x) for _ in range(world_size)]
    dist.all_gather(tensors, x)
    return torch.cat(tensors, dim=-1).contiguous()


class _CopyToParallelRegion(torch.autograd.Function):
    """Forward: identity. Backward: all-reduce gradient."""

    @staticmethod
    def forward(ctx, x):
        return x

    @staticmethod
    def backward(ctx, grad_output):
        return _all_reduce(grad_output.clone())


class _ReduceFromParallelRegion(torch.autograd.Function):
    """Forward: all-reduce. Backward: identity."""

    @staticmethod
    def forward(ctx, x):
        return _all_reduce(x.clone())

    @staticmethod
    def backward(ctx, grad_output):
        return grad_output


class _ScatterToParallelRegion(torch.autograd.Function):
    """Forward: take this rank's slice of the last dim. Backward: all-gather."""

    @staticmethod
    def forward(ctx, x):
        return _split_last_dim(x)

    @staticmethod
    def backward(ctx, grad_output):
        return _gather_last_dim(grad_output)


class _GatherFromParallelRegion(torch.autograd.Function):
    """Forward: all-gather along last dim. Backward: take this rank's slice."""

    @staticmethod
    def forward(ctx, x):
        return _gather_last_dim(x)

    @staticmethod
    def backward(ctx, grad_output):
        return _split_last_dim(grad_output)


def copy_to_parallel_region(x):
    return _CopyToParallelRegion.apply(x)


def reduce_from_parallel_region(x):
    return _ReduceFromParallelRegion.apply(x)


def scatter_to_parallel_region(x):
    return _ScatterToParallelRegion.apply(x)


def gather_from_parallel_region(x):
    return _GatherFromParallelRegion.apply(x)


# ---------------------------------------------------------------------------
# Layers
# ---------------------------------------------------------------------------


class ColumnParallelLinear(torch.nn.Module):
    """Linear layer with the output dimension (weight columns of W^T) sharded.

    master_weight: full weight of shape (out_features, in_features).
    Each rank holds weight of shape (out_features // world_size, in_features)
    and bias of shape (out_features // world_size,).
    """

    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.world_size = _world_size()
        self.rank = _rank()
        self.output_size_per_partition = _divide(out_features, self.world_size)

        assert tuple(master_weight.shape) == (out_features, in_features), (
            f"master_weight must have shape ({out_features}, {in_features}), "
            f"got {tuple(master_weight.shape)}"
        )

        start = self.rank * self.output_size_per_partition
        end = start + self.output_size_per_partition
        with torch.no_grad():
            shard = master_weight.detach()[start:end, :].clone().contiguous()
        self.weight = torch.nn.Parameter(shard)

        if bias:
            self.bias = torch.nn.Parameter(
                torch.zeros(
                    self.output_size_per_partition,
                    dtype=master_weight.dtype,
                    device=master_weight.device,
                )
            )
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        x = copy_to_parallel_region(x)
        local_out = F.linear(x, self.weight, self.bias)
        return gather_from_parallel_region(local_out)


class RowParallelLinear(torch.nn.Module):
    """Linear layer with the input dimension (weight rows of W^T) sharded.

    master_weight: full weight of shape (out_features, in_features).
    Each rank holds weight of shape (out_features, in_features // world_size).
    The bias (out_features,) is kept full on every rank.
    The input is expected to be the full (unsharded) tensor; each rank uses its
    slice of the last dimension.
    """

    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.world_size = _world_size()
        self.rank = _rank()
        self.input_size_per_partition = _divide(in_features, self.world_size)

        assert tuple(master_weight.shape) == (out_features, in_features), (
            f"master_weight must have shape ({out_features}, {in_features}), "
            f"got {tuple(master_weight.shape)}"
        )

        start = self.rank * self.input_size_per_partition
        end = start + self.input_size_per_partition
        with torch.no_grad():
            shard = master_weight.detach()[:, start:end].clone().contiguous()
        self.weight = torch.nn.Parameter(shard)

        if bias:
            self.bias = torch.nn.Parameter(
                torch.zeros(
                    out_features,
                    dtype=master_weight.dtype,
                    device=master_weight.device,
                )
            )
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        if (
            x.size(-1) == self.input_size_per_partition
            and self.world_size > 1
            and self.in_features != self.input_size_per_partition
        ):
            # Input already partitioned.
            x_parallel = x
        else:
            x_parallel = scatter_to_parallel_region(x)
        partial = F.linear(x_parallel, self.weight)
        out = reduce_from_parallel_region(partial)
        if self.bias is not None:
            out = out + self.bias
        return out
