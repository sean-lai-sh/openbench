#!/usr/bin/env python
"""Refine cell annotations (rectangles + polylines) into polyline masks with MobileSAM.

For every annotation in the metadata csv, MobileSAM is prompted with the
annotation bounding box (plus the polygon centroid for polyline annotations).
The predicted masks are then post-processed so that

  * every cell gets exactly one, contiguous (single connected component) mask,
  * no two masks overlap (a 1 pixel gap is kept between neighbouring masks),
  * every mask is stored as a closed polyline (never as a plain rectangle).

The output csv has exactly the same rows/columns as the input csv; only the
``xmin, xmax, ymin, ymax, coords_x, coords_y`` columns are updated.

Usage:
    python convert_masks.py --weights_path mobile_sam.pt --output_path out/ \
        --rgb_path image.png --csv_path metadata.csv
"""

import argparse
import os
import warnings

import cv2
import numpy as np
import pandas as pd
import torch
from tqdm import tqdm

warnings.filterwarnings("ignore")

from mobile_sam import SamPredictor, sam_model_registry  # noqa: E402

# --------------------------------------------------------------------------- #
# Parameters
# --------------------------------------------------------------------------- #
MAX_FULL_IMAGE_SIDE = 1024  # images up to this size are embedded in one pass
TILE_SIZE = 768  # tile size for larger images
BATCH_SIZE = 32  # number of prompts decoded at once
MIN_AREA_FRAC = 0.12  # SAM mask must cover >= this fraction of the box
MAX_AREA_FRAC = 1.6  # ... and at most this (relative to the box area)
MIN_PIXELS = 9  # minimal number of pixels of a final mask


# --------------------------------------------------------------------------- #
# Argument parsing / IO helpers
# --------------------------------------------------------------------------- #
def parse_args():
    """Arguments may be given as flags (--weights_path ...) or positionally
    in the order: weights_path output_path rgb_path csv_path."""
    names = ["weights_path", "output_path", "rgb_path", "csv_path"]
    helps = ["Path to MobileSAM weights (mobile_sam.pt)", "Output folder (or .csv file path)",
             "Path to the RGB image", "Path to the metadata csv"]
    p = argparse.ArgumentParser(description="Convert cell masks to polylines with MobileSAM.")
    for name, hlp in zip(names, helps):
        p.add_argument("pos_" + name, nargs="?", default=None, metavar=name, help=hlp)
    for name, hlp in zip(names, helps):
        p.add_argument("--" + name, "-" + name[0], type=str, default=None, help=hlp)
    args = p.parse_args()
    for name in names:
        if getattr(args, name) is None:
            setattr(args, name, getattr(args, "pos_" + name))
        if getattr(args, name) is None:
            p.error(f"missing required argument: {name}")
    return args


def load_rgb(path):
    img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    if img is None:
        from PIL import Image

        img = np.array(Image.open(path).convert("RGB"))
        return np.ascontiguousarray(img)
    if img.dtype != np.uint8:
        img = cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    if img.ndim == 2:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
    elif img.shape[2] == 4:
        img = cv2.cvtColor(img, cv2.COLOR_BGRA2RGB)
    else:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return np.ascontiguousarray(img)


def parse_coords(value):
    if isinstance(value, (list, tuple, np.ndarray)):
        return [float(v) for v in value]
    s = str(value).strip().strip("[]()")
    if not s or s.lower() == "nan":
        return []
    return [float(v) for v in s.replace(";", ",").replace(" ", ",").split(",") if v.strip() != ""]


def resolve_output_file(output_path, csv_path):
    if output_path.lower().endswith(".csv"):
        parent = os.path.dirname(os.path.abspath(output_path))
        os.makedirs(parent, exist_ok=True)
        return output_path
    os.makedirs(output_path, exist_ok=True)
    return os.path.join(output_path, os.path.basename(csv_path))


# --------------------------------------------------------------------------- #
# Mask helpers
# --------------------------------------------------------------------------- #
def largest_component(mask, connectivity=4):
    mask = mask.astype(np.uint8)
    if mask.sum() == 0:
        return mask.astype(bool)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=connectivity)
    if n <= 2:
        return mask.astype(bool)
    idx = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return lab == idx


def fill_holes(mask):
    mask = mask.astype(np.uint8)
    if mask.sum() == 0:
        return mask.astype(bool)
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    out = np.zeros_like(mask)
    cv2.drawContours(out, contours, -1, 1, thickness=cv2.FILLED)
    return out.astype(bool)


def clean_mask(mask):
    """Largest 4-connected component, holes filled, thin spurs removed."""
    m = largest_component(mask)
    m = fill_holes(m)
    if m.sum() > 4 * MIN_PIXELS:
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        opened = cv2.morphologyEx(m.astype(np.uint8), cv2.MORPH_OPEN, k).astype(bool)
        opened = largest_component(opened)
        if opened.sum() >= 0.5 * m.sum():
            m = fill_holes(opened)
    return m


def make_simple(mask, max_iter=50):
    """Remove 1-pixel necks so that the outer boundary is a simple polygon.

    A boundary trace that visits the same pixel twice means the polygon would
    touch itself (invalid geometry). Such pixels are removed and the largest
    remaining component kept, until the trace is simple.
    """
    m = largest_component(mask)
    for _ in range(max_iter):
        if m.sum() == 0:
            return m
        contours, _ = cv2.findContours(m.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        cnt = max(contours, key=len).reshape(-1, 2)
        uniq, counts = np.unique(cnt, axis=0, return_counts=True)
        if len(uniq) < 4:  # too small to form a proper polygon
            return np.zeros_like(m)
        dup = uniq[counts > 1]
        if len(dup) == 0:
            return m
        m = m.copy()
        m[dup[:, 1], dup[:, 0]] = False
        m = fill_holes(largest_component(m))
    return np.zeros_like(m)


def free_diamond(center, free, shape):
    """Small diamond (5 px) at the free location closest to ``center``."""
    k = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
    ok = cv2.erode(free.astype(np.uint8), k, borderValue=0).astype(bool)
    ys, xs = np.nonzero(ok)
    if len(xs) == 0:
        cx, cy = int(np.clip(center[0], 1, shape[1] - 2)), int(np.clip(center[1], 1, shape[0] - 2))
    else:
        j = int(np.argmin((xs - center[0]) ** 2 + (ys - center[1]) ** 2))
        cx, cy = int(xs[j]), int(ys[j])
    return np.array([[cx, cy - 1], [cx + 1, cy], [cx, cy + 1], [cx - 1, cy]])


def mask_to_polygon(mask):
    """Return an (N, 2) int array tracing the outer boundary of the mask."""
    contours, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    cnt = max(contours, key=cv2.contourArea).reshape(-1, 2)
    return cnt


def polygon_to_mask(poly, shape):
    m = np.zeros(shape, dtype=np.uint8)
    cv2.fillPoly(m, [np.round(np.asarray(poly)).astype(np.int32).reshape(-1, 1, 2)], 1)
    return m.astype(bool)


def is_axis_aligned_rectangle(poly):
    pts = np.unique(np.asarray(poly).reshape(-1, 2), axis=0)
    if len(pts) > 4:
        return False
    xs, ys = np.unique(pts[:, 0]), np.unique(pts[:, 1])
    return len(xs) <= 2 and len(ys) <= 2


def ellipse_mask(box, shape, shrink=0.9):
    x0, y0, x1, y1 = box
    m = np.zeros(shape, dtype=np.uint8)
    cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    ax = max(1, int(round((x1 - x0) / 2.0 * shrink)))
    ay = max(1, int(round((y1 - y0) / 2.0 * shrink)))
    cv2.ellipse(m, (int(round(cx)), int(round(cy))), (ax, ay), 0, 0, 360, 1, -1)
    return m.astype(bool)


# --------------------------------------------------------------------------- #
# MobileSAM
# --------------------------------------------------------------------------- #
def build_predictor(weights_path, device):
    model = sam_model_registry["vit_t"](checkpoint=None)
    state = torch.load(weights_path, map_location="cpu")
    if isinstance(state, dict) and "model" in state and isinstance(state["model"], dict):
        state = state["model"]
    model.load_state_dict(state)
    model.to(device)
    model.eval()
    return SamPredictor(model)


def make_windows(h, w, boxes):
    """Assign each box to an image window that is embedded once by SAM."""
    if max(h, w) <= MAX_FULL_IMAGE_SIDE:
        return [((0, 0, w, h), list(range(len(boxes))))]
    margin = 32  # context required around a box inside its window
    windows = []
    unassigned = sorted(range(len(boxes)), key=lambda i: (boxes[i][1], boxes[i][0]))
    while unassigned:
        i = unassigned[0]
        bx0, by0, bx1, by1 = boxes[i]
        size = max(TILE_SIZE, int(max(bx1 - bx0, by1 - by0)) + 2 * margin)
        # window anchored at the top-left of the first unassigned box
        x0 = int(max(0, min(bx0 - margin, w - size)))
        y0 = int(max(0, min(by0 - margin, h - size)))
        x1, y1 = min(w, x0 + size), min(h, y0 + size)

        def inside(j):
            a0, b0, a1, b1 = boxes[j]
            return (a0 - x0 >= min(margin, a0) and b0 - y0 >= min(margin, b0)
                    and x1 - a1 >= min(margin, w - 1 - a1) and y1 - b1 >= min(margin, h - 1 - b1))

        members = [j for j in unassigned if inside(j)]
        if i not in members:
            members.append(i)
        windows.append(((x0, y0, x1, y1), members))
        ms = set(members)
        unassigned = [j for j in unassigned if j not in ms]
    return windows


@torch.no_grad()
def run_sam(predictor, image, boxes, on_result, device):
    """Run MobileSAM with box prompts; ``on_result(i, logits, scores, window)`` is
    called for every box with the multimask logits of its window."""
    h, w = image.shape[:2]
    windows = make_windows(h, w, boxes)
    for (wx0, wy0, wx1, wy1), idxs in tqdm(windows, desc="MobileSAM", disable=len(windows) < 2):
        crop = np.ascontiguousarray(image[wy0:wy1, wx0:wx1])
        predictor.set_image(crop)
        for s in range(0, len(idxs), BATCH_SIZE):
            chunk = idxs[s:s + BATCH_SIZE]
            b = np.array([boxes[i] for i in chunk], dtype=np.float32)
            b[:, [0, 2]] -= wx0
            b[:, [1, 3]] -= wy0
            tb = torch.as_tensor(predictor.transform.apply_boxes(b, crop.shape[:2]), device=device)
            logits, scores, _ = predictor.predict_torch(
                point_coords=None, point_labels=None, boxes=tb, multimask_output=True, return_logits=True)
            logits_np = logits.cpu().numpy()
            scores_np = scores.cpu().numpy()
            for j, i in enumerate(chunk):
                on_result(i, logits_np[j], scores_np[j], (wx0, wy0, wx1, wy1))


def cell_roi(box, shape, extra=0):
    """Box + margin, clipped to the image: (x0, y0, x1, y1) with exclusive end."""
    h, w = shape
    x0, y0, x1, y1 = box
    pad = int(round(max(3, 0.15 * max(x1 - x0, y1 - y0)))) + extra
    return (max(0, int(np.floor(x0)) - pad), max(0, int(np.floor(y0)) - pad),
            min(w, int(np.ceil(x1)) + pad + 1), min(h, int(np.ceil(y1)) + pad + 1))


def select_mask(logits, scores, window, roi, box, ref_poly):
    """Pick the best multimask output inside ``roi``.

    Returns (mask, logits) arrays of the roi shape, or None if no plausible mask.
    """
    wx0, wy0, wx1, wy1 = window
    rx0, ry0, rx1, ry1 = roi
    ix0, iy0, ix1, iy1 = max(rx0, wx0), max(ry0, wy0), min(rx1, wx1), min(ry1, wy1)
    shape = (ry1 - ry0, rx1 - rx0)
    x0, y0, x1, y1 = box
    box_area = max(1.0, x1 - x0) * max(1.0, y1 - y0)
    ref = None
    if ref_poly is not None:
        ref = polygon_to_mask(ref_poly - np.array([rx0, ry0]), shape)

    best, best_val = None, -np.inf
    for k in range(logits.shape[0]):
        lg = np.full(shape, -20.0, dtype=np.float32)
        lg[iy0 - ry0:iy1 - ry0, ix0 - rx0:ix1 - rx0] = logits[k, iy0 - wy0:iy1 - wy0, ix0 - wx0:ix1 - wx0]
        m = clean_mask(lg > 0.0)
        area = m.sum()
        if area < max(MIN_PIXELS, MIN_AREA_FRAC * box_area) or area > MAX_AREA_FRAC * box_area:
            continue
        val = float(scores[k])
        if ref is not None and ref.any():
            # polyline annotations: prefer the SAM mask agreeing with the annotation
            val += np.logical_and(m, ref).sum() / max(1, np.logical_or(m, ref).sum())
        if val > best_val:
            best_val, best = val, (m, lg)
    return best


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main():
    args = parse_args()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    torch.set_grad_enabled(False)

    image = load_rgb(args.rgb_path)
    h, w = image.shape[:2]
    df = pd.read_csv(args.csv_path, index_col=0)
    n = len(df)
    out_file = resolve_output_file(args.output_path, args.csv_path)

    # ---------------- parse annotations ----------------
    boxes, ref_polys = [], []
    for _, row in df.iterrows():
        xs, ys = parse_coords(row.get("coords_x", "")), parse_coords(row.get("coords_y", ""))
        k = min(len(xs), len(ys))
        xs, ys = np.array(xs[:k]), np.array(ys[:k])
        if k >= 2:
            x0, x1, y0, y1 = xs.min(), xs.max(), ys.min(), ys.max()
        else:
            x0, x1, y0, y1 = float(row["xmin"]), float(row["xmax"]), float(row["ymin"]), float(row["ymax"])
        x0, x1 = float(np.clip(x0, 0, w - 1)), float(np.clip(x1, 0, w - 1))
        y0, y1 = float(np.clip(y0, 0, h - 1)), float(np.clip(y1, 0, h - 1))
        if x1 - x0 < 2:
            x0, x1 = max(0.0, x0 - 2), min(w - 1.0, x1 + 2)
        if y1 - y0 < 2:
            y0, y1 = max(0.0, y0 - 2), min(h - 1.0, y1 + 2)
        boxes.append((x0, y0, x1, y1))
        poly = np.stack([xs, ys], 1) if k >= 3 else None
        typ = str(row.get("type", "")).lower()
        polyline = poly is not None and "rect" not in typ and not is_axis_aligned_rectangle(poly)
        ref_polys.append(poly if polyline else None)

    rois = [cell_roi(b, (h, w)) for b in boxes]
    cands = [None] * n  # per cell: (mask, logits) in roi coordinates

    def on_result(i, logits, scores, window):
        cands[i] = select_mask(logits, scores, window, rois[i], boxes[i], ref_polys[i])

    # ---------------- MobileSAM inference ----------------
    predictor = build_predictor(args.weights_path, device)
    if n:
        run_sam(predictor, image, boxes, on_result, device)

    # ---------------- fallbacks for implausible SAM outputs ----------------
    for i in range(n):
        if cands[i] is not None:
            continue
        rx0, ry0, rx1, ry1 = rois[i]
        shape = (ry1 - ry0, rx1 - rx0)
        off = np.array([rx0, ry0])
        lbox = (boxes[i][0] - rx0, boxes[i][1] - ry0, boxes[i][2] - rx0, boxes[i][3] - ry0)
        m = None
        if ref_polys[i] is not None:  # original polyline annotation
            m = clean_mask(polygon_to_mask(ref_polys[i] - off, shape))
        if m is None or m.sum() < MIN_PIXELS:  # ellipse inscribed in the box
            m = clean_mask(ellipse_mask(lbox, shape, 0.9))
        if m.sum() < MIN_PIXELS:
            m = clean_mask(ellipse_mask(lbox, shape, 1.0))
        cands[i] = (m, np.where(m, 1.0, -1.0).astype(np.float32))

    # ---------------- resolve overlaps: pixel goes to the highest logit ----------------
    best_logit = np.full((h, w), -np.inf, dtype=np.float32)
    label = np.full((h, w), -1, dtype=np.int32)
    for i in range(n):
        rx0, ry0, rx1, ry1 = rois[i]
        m, lg = cands[i]
        sc = np.clip(lg, -20, 20)
        sub_best = best_logit[ry0:ry1, rx0:rx1]
        sub_lab = label[ry0:ry1, rx0:rx1]
        upd = m & (sc > sub_best)
        sub_best[upd] = sc[upd]
        sub_lab[upd] = i

    # ---------------- final masks: contiguous, non-overlapping polylines ----------------
    areas = np.array([cands[i][0].sum() for i in range(n)])
    order = np.argsort(areas, kind="stable")  # small cells first -> keep them intact
    occupied = np.zeros((h, w), dtype=bool)
    k3 = np.ones((3, 3), np.uint8)
    polys = [None] * n
    for i in order:
        # local working window (roi + 2 px so that dilation of neighbours is exact)
        ex0, ey0, ex1, ey1 = cell_roi(boxes[i], (h, w), extra=2)
        rx0, ry0, rx1, ry1 = rois[i]
        shape = (ey1 - ey0, ex1 - ex0)
        off = np.array([ex0, ey0])
        lbox = (boxes[i][0] - ex0, boxes[i][1] - ey0, boxes[i][2] - ex0, boxes[i][3] - ey0)
        center = ((lbox[0] + lbox[2]) / 2.0, (lbox[1] + lbox[3]) / 2.0)

        forbidden = cv2.dilate(occupied[ey0:ey1, ex0:ex1].astype(np.uint8), k3).astype(bool)
        free = ~forbidden
        own = np.zeros(shape, dtype=bool)
        own[ry0 - ey0:ry1 - ey0, rx0 - ex0:rx1 - ex0] = cands[i][0]
        candidates = [
            (label[ey0:ey1, ex0:ex1] == i) & free,  # SAM mask after overlap resolution
            own & free,  # lost to neighbours -> own SAM mask in the free space
            ellipse_mask(lbox, shape, 1.0) & free,  # box-inscribed ellipse in free space
        ]
        poly = None
        for c in candidates:
            m = make_simple(clean_mask(c) & free)
            if m.sum() < MIN_PIXELS:
                continue
            p_ = mask_to_polygon(m)
            if p_ is None or len(p_) < 3:
                continue
            if (polygon_to_mask(p_, shape) & forbidden).any():
                continue
            poly = p_
            break
        if poly is None:  # last resort: tiny diamond in the nearest free spot
            gfree = ~cv2.dilate(occupied.astype(np.uint8), k3).astype(bool)
            poly = free_diamond((center[0] + ex0, center[1] + ey0), gfree, (h, w)) - off
        if is_axis_aligned_rectangle(poly):  # make sure it is never a rectangle
            cx, cy = poly[:, 0].mean(), poly[:, 1].mean()
            xa, xb, ya, yb = poly[:, 0].min(), poly[:, 0].max(), poly[:, 1].min(), poly[:, 1].max()
            poly = np.array([[cx, ya], [xb, cy], [cx, yb], [xa, cy]]).round().astype(int)
        poly = np.asarray(poly).astype(int) + off  # back to image coordinates
        px0, py0 = max(0, poly[:, 0].min()), max(0, poly[:, 1].min())
        px1, py1 = min(w, poly[:, 0].max() + 1), min(h, poly[:, 1].max() + 1)
        occupied[py0:py1, px0:px1] |= polygon_to_mask(poly - np.array([px0, py0]), (py1 - py0, px1 - px0))
        polys[i] = poly

    # ---------------- write output ----------------
    out = df.copy()
    for col in ("xmin", "xmax", "ymin", "ymax"):
        if col not in out.columns:
            out[col] = 0
    cx_list, cy_list = [], []
    for i in range(n):
        p = polys[i]
        p = np.vstack([p, p[:1]])  # close the polyline
        cx_list.append(",".join(str(int(v)) for v in p[:, 0]))
        cy_list.append(",".join(str(int(v)) for v in p[:, 1]))
        out.at[out.index[i], "xmin"] = int(p[:, 0].min())
        out.at[out.index[i], "xmax"] = int(p[:, 0].max())
        out.at[out.index[i], "ymin"] = int(p[:, 1].min())
        out.at[out.index[i], "ymax"] = int(p[:, 1].max())
    out["coords_x"] = cx_list
    out["coords_y"] = cy_list
    for col in ("xmin", "xmax", "ymin", "ymax"):
        out[col] = out[col].astype(int)
    out.to_csv(out_file, index=True)
    print(f"Saved {n} refined polyline masks to {out_file}")


if __name__ == "__main__":
    main()
