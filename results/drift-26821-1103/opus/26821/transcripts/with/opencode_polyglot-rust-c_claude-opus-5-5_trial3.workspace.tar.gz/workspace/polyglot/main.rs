/* /* */
#include <cstdio>
#include <cstdlib>
#include <vector>
int main(int argc, char** argv) {
    long n = argc > 1 ? atol(argv[1]) : 0;
    std::vector<int> a(1, 1), b(1, 1);
    for (long i = 0; i < n; i++) {
        std::vector<int> c;
        int carry = 0;
        for (size_t j = 0; j < b.size() || carry; j++) {
            int s = carry + (j < a.size() ? a[j] : 0) + (j < b.size() ? b[j] : 0);
            c.push_back(s % 10);
            carry = s / 10;
        }
        a = b;
        b = c;
    }
    for (size_t j = a.size(); j-- > 0;) putchar('0' + a[j]);
    putchar('\n');
    return 0;
}
#if 0
// */
fn main() {
    let n: u64 = std::env::args().nth(1).map(|s| s.trim().parse().unwrap()).unwrap_or(0);
    let mut a: Vec<u8> = vec![1];
    let mut b: Vec<u8> = vec![1];
    for _ in 0..n {
        let mut c: Vec<u8> = Vec::new();
        let mut carry = 0u8;
        let mut j = 0;
        while j < b.len() || carry > 0 {
            let s = carry + a.get(j).copied().unwrap_or(0) + b.get(j).copied().unwrap_or(0);
            c.push(s % 10);
            carry = s / 10;
            j += 1;
        }
        a = b;
        b = c;
    }
    let out: String = a.iter().rev().map(|d| (b"0"[0] + d) as char).collect();
    println!("{}", out);
}
/* /* */
#endif
// */
