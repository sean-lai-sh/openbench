#!/usr/bin/env python3
"""Detect hurdle jump takeoff and landing frames in an MP4 video.

Approach:
  * The first frame (no runner) is used as a static background.
  * For each frame, foreground is obtained by background differencing.
  * In the track region (below the fence) the lowest foreground pixel gives
    the position of the athlete's lowest foot.
  * A frame is a "ground contact" frame when that lowest point is close to
    the ground level (estimated from the data itself).
  * The jump is the run of non-contact frames during which the athlete
    crosses the hurdle. Takeoff = last contact frame before it,
    landing = first contact frame after it.

Usage: python3 jump_analyzer.py [video.mp4] [output.toml]
"""
import os
import sys

import cv2
import numpy as np
import toml

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_VIDEO = os.path.join(HERE, "example_video.mp4")
DEFAULT_OUTPUT = os.path.join(HERE, "output.toml")

TRACK_TOP = 245          # rows above this are fence / background scenery
HURDLE_X = 555           # approximate x-centre of the hurdle (fixed camera)
DIFF_THRESH = 35
MIN_BLOB = 80
CONTACT_TOL = 14         # px above ground level still counted as contact


def read_frames(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise RuntimeError("Cannot open video: %s" % path)
    frames = []
    while True:
        ok, f = cap.read()
        if not ok:
            break
        frames.append(f)
    cap.release()
    if not frames:
        raise RuntimeError("Video has no frames: %s" % path)
    return frames


def analyze_frames(frames):
    h, w = frames[0].shape[:2]
    scale_x = w / 960.0
    scale_y = h / 540.0
    track_top = int(TRACK_TOP * scale_y)
    hurdle_x = HURDLE_X * scale_x
    k3 = np.ones((3, 3), np.uint8)
    k5 = np.ones((5, 5), np.uint8)

    bg = cv2.GaussianBlur(frames[0], (5, 5), 0).astype(np.int16)
    n = len(frames)
    bottoms = [None] * n      # lowest foreground y in track region
    centers = [None] * n      # foreground centroid x (whole frame)
    areas = np.zeros(n)

    for i, f in enumerate(frames):
        fb = cv2.GaussianBlur(f, (5, 5), 0).astype(np.int16)
        d = np.abs(fb - bg).max(axis=2)
        m = (d > DIFF_THRESH).astype(np.uint8)

        # whole-frame mask for the athlete's horizontal position
        mw = cv2.morphologyEx(m, cv2.MORPH_OPEN, k5)
        cnt, lab, st, cen = cv2.connectedComponentsWithStats(mw)
        keep = [j for j in range(1, cnt) if st[j, 4] >= MIN_BLOB * 3]
        if keep:
            a = st[keep, 4].astype(float)
            centers[i] = float(np.sum(cen[keep, 0] * a) / a.sum())
            areas[i] = a.sum()

        # track-region mask for feet
        mt = m.copy()
        mt[:track_top] = 0
        mt = cv2.morphologyEx(mt, cv2.MORPH_OPEN, k3)
        cnt, lab, st, cen = cv2.connectedComponentsWithStats(mt)
        keep = [j for j in range(1, cnt) if st[j, 4] >= MIN_BLOB]
        if keep:
            bottoms[i] = int(max(st[j, 1] + st[j, 3] - 1 for j in keep))

    return bottoms, centers, areas, hurdle_x


def find_jump(bottoms, centers, areas, hurdle_x):
    n = len(bottoms)
    present = [c is not None for c in centers]
    vals = [b for b in bottoms if b is not None]
    if not vals:
        return 0, n - 1
    ground = float(np.percentile(vals, 80))
    contact = [b is not None and b >= ground - CONTACT_TOL for b in bottoms]

    # frame where the athlete crosses the hurdle x position
    pres_idx = [i for i in range(n) if present[i]]
    cross = None
    for a, b in zip(pres_idx, pres_idx[1:]):
        if b - a > 3:
            continue
        if (centers[a] - hurdle_x) * (centers[b] - hurdle_x) <= 0:
            cross = a if abs(centers[a] - hurdle_x) <= abs(centers[b] - hurdle_x) else b
            break
    if cross is None and pres_idx:
        cross = min(pres_idx, key=lambda i: abs(centers[i] - hurdle_x))

    # runs of non-contact frames bounded by contact frames
    runs = []
    contact_idx = [i for i in range(n) if contact[i]]
    for a, b in zip(contact_idx, contact_idx[1:]):
        if b - a > 1:
            runs.append((a, b))
    if not runs:
        return (cross or 0), (cross or 0)

    containing = [r for r in runs if r[0] <= cross <= r[1]] if cross is not None else []
    if containing:
        take, land = max(containing, key=lambda r: r[1] - r[0])
    else:
        def score(r):
            mid = 0.5 * (r[0] + r[1])
            return (r[1] - r[0]) - 0.2 * (abs(mid - cross) if cross is not None else 0)
        take, land = max(runs, key=score)
    return int(take), int(land)


def main():
    video = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_VIDEO
    out = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_OUTPUT
    frames = read_frames(video)
    bottoms, centers, areas, hurdle_x = analyze_frames(frames)
    take, land = find_jump(bottoms, centers, areas, hurdle_x)
    result = {
        "jump_takeoff_frame_number": int(take),
        "jump_land_frame_number": int(land),
    }
    with open(out, "w") as fh:
        toml.dump(result, fh)
    print(toml.dumps(result), end="")


if __name__ == "__main__":
    main()
