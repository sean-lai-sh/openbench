"""Pipeline parallel training (AFAB schedule) for LlamaForCausalLM."""

import torch
import torch.distributed as dist
import torch.nn.functional as F


def _partition_layers(num_layers, world_size, rank):
    """Return [start, end) layer indices for this rank, balanced as evenly as possible."""
    base, rem = divmod(num_layers, world_size)
    start = rank * base + min(rank, rem)
    end = start + base + (1 if rank < rem else 0)
    return start, end


def _build_causal_mask(model, hidden_states, position_ids):
    """Build the attention mask the same way LlamaModel does (no padding mask)."""
    config = model.config
    try:
        from transformers.masking_utils import create_causal_mask

        try:
            return create_causal_mask(
                config=config,
                inputs_embeds=hidden_states,
                attention_mask=None,
                past_key_values=None,
                position_ids=position_ids,
            )
        except TypeError:
            cache_position = torch.arange(hidden_states.shape[1], device=hidden_states.device)
            return create_causal_mask(
                config=config,
                input_embeds=hidden_states,
                attention_mask=None,
                cache_position=cache_position,
                past_key_values=None,
                position_ids=position_ids,
            )
    except ImportError:
        pass
    # Fallback: explicit 4D additive causal mask.
    bsz, seq_len = hidden_states.shape[:2]
    min_val = torch.finfo(hidden_states.dtype).min
    mask = torch.full((seq_len, seq_len), min_val, device=hidden_states.device,
                      dtype=hidden_states.dtype)
    mask = torch.triu(mask, diagonal=1)
    return mask[None, None, :, :].expand(bsz, 1, seq_len, seq_len)


def _run_layers(model, layers, hidden_states):
    llama = model.model
    seq_len = hidden_states.shape[1]
    position_ids = torch.arange(seq_len, device=hidden_states.device).unsqueeze(0)
    causal_mask = _build_causal_mask(model, hidden_states, position_ids)
    position_embeddings = llama.rotary_emb(hidden_states, position_ids)
    cache_position = torch.arange(seq_len, device=hidden_states.device)
    for layer in layers:
        out = layer(
            hidden_states,
            attention_mask=causal_mask,
            position_ids=position_ids,
            position_embeddings=position_embeddings,
            cache_position=cache_position,
        )
        hidden_states = out[0] if isinstance(out, (tuple, list)) else out
    return hidden_states


def _p2p(ops):
    if not ops:
        return
    reqs = dist.batch_isend_irecv(ops)
    for r in reqs:
        r.wait()


def train_step_pipeline_afab(model, inputs, targets, device, dtype):
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    is_first = rank == 0
    is_last = rank == world_size - 1
    prev_rank = rank - 1
    next_rank = rank + 1

    num_microbatches = len(inputs)
    hidden_size = model.config.hidden_size
    num_layers = model.config.num_hidden_layers
    start, end = _partition_layers(num_layers, world_size, rank)
    my_layers = list(model.model.layers)[start:end]

    input_tensors = []   # stage inputs (received hidden states), for backward
    output_tensors = []  # stage outputs (hidden states or loss), for backward
    total_loss = torch.zeros((), device=device, dtype=torch.float32)

    # ---------------- All forward ----------------
    for i in range(num_microbatches):
        mb_ids = inputs[i]
        mb_size, seq_len = mb_ids.shape[0], mb_ids.shape[1]
        hshape = (mb_size, seq_len, hidden_size)

        if is_first:
            input_ids = mb_ids.to(device)
            hidden = model.model.embed_tokens(input_ids).to(dtype)
            stage_input = None
        else:
            recv_buf = torch.empty(hshape, device=device, dtype=dtype)
            _p2p([dist.P2POp(dist.irecv, recv_buf, prev_rank)])
            stage_input = recv_buf.requires_grad_(True)
            hidden = stage_input

        hidden = _run_layers(model, my_layers, hidden)

        if is_last:
            hidden = model.model.norm(hidden)
            logits = model.lm_head(hidden)
            tgt = targets[i].to(device)
            loss = F.cross_entropy(
                logits.reshape(-1, logits.size(-1)).float(), tgt.reshape(-1)
            ) / num_microbatches
            total_loss = total_loss + loss.detach()
            output = loss
        else:
            output = hidden.to(dtype)
            _p2p([dist.P2POp(dist.isend, output.detach().contiguous(), next_rank)])

        input_tensors.append(stage_input)
        output_tensors.append(output)

    # ---------------- All backward ----------------
    for i in range(num_microbatches):
        stage_input = input_tensors[i]
        output = output_tensors[i]

        if is_last:
            torch.autograd.backward(output)
        else:
            grad_buf = torch.empty(output.shape, device=device, dtype=dtype)
            _p2p([dist.P2POp(dist.irecv, grad_buf, next_rank)])
            torch.autograd.backward(output, grad_tensors=grad_buf)

        if not is_first:
            grad = stage_input.grad
            if grad is None:
                grad = torch.zeros_like(stage_input)
            grad = grad.to(device=device, dtype=dtype).contiguous()
            _p2p([dist.P2POp(dist.isend, grad, prev_rank)])

        # free memory
        input_tensors[i] = None
        output_tensors[i] = None

    return total_loss if is_last else None
