/* /* */
#include <cstdio>
#include <cstdlib>
#include <vector>
typedef std::vector<unsigned int> Big;
static Big add(const Big& x, const Big& y) {
    Big r;
    unsigned long long carry = 0;
    for (size_t i = 0; i < x.size() || i < y.size() || carry; i++) {
        unsigned long long s = carry;
        if (i < x.size()) s += x[i];
        if (i < y.size()) s += y[i];
        r.push_back((unsigned int)(s % 1000000000ULL));
        carry = s / 1000000000ULL;
    }
    return r;
}
int main(int argc, char** argv) {
    long n = argc > 1 ? atol(argv[1]) : 0;
    Big a(1, 1), b(1, 1);
    for (long i = 0; i < n; i++) { Big c = add(a, b); a = b; b = c; }
    printf("%u", a.back());
    for (size_t i = a.size() - 1; i-- > 0;) printf("%09u", a[i]);
    printf("\n");
    return 0;
}
#if 0
// */
fn add(x: &Vec<u32>, y: &Vec<u32>) -> Vec<u32> {
    let mut r = Vec::new();
    let mut carry: u64 = 0;
    let mut i = 0;
    while i < x.len() || i < y.len() || carry > 0 {
        let mut s = carry;
        if i < x.len() { s += x[i] as u64; }
        if i < y.len() { s += y[i] as u64; }
        r.push((s % 1000000000) as u32);
        carry = s / 1000000000;
        i += 1;
    }
    r
}
fn main() {
    let n: u64 = std::env::args().nth(1).map(|s| s.trim().parse().unwrap()).unwrap_or(0);
    let mut a: Vec<u32> = vec![1];
    let mut b: Vec<u32> = vec![1];
    for _ in 0..n { let c = add(&a, &b); a = b; b = c; }
    let mut out = format!("{}", a[a.len() - 1]);
    for i in (0..a.len() - 1).rev() { out.push_str(&format!("{:09}", a[i])); }
    println!("{}", out);
}
/* /* */
#endif
// */
