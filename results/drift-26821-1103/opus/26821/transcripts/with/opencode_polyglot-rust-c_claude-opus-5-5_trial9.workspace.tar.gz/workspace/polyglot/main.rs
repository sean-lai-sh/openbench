/* /* */
#if 0
// */
use std::env;

fn main() {
    let args: Vec<String> = env::args().collect();
    let n: u64 = if args.len() > 1 { args[1].trim().parse().unwrap_or(0) } else { 0 };
    let mut a: u128 = 1;
    let mut b: u128 = 1;
    for _ in 0..n {
        let c = a.wrapping_add(b);
        a = b;
        b = c;
    }
    println!("{}", a);
}
/* /* */
#endif
#include <cstdio>
#include <cstdlib>
#include <string>

int main(int argc, char **argv) {
    unsigned long long n = argc > 1 ? strtoull(argv[1], nullptr, 10) : 0;
    unsigned __int128 a = 1, b = 1;
    for (unsigned long long i = 0; i < n; ++i) {
        unsigned __int128 c = a + b;
        a = b;
        b = c;
    }
    std::string s;
    if (a == 0) s = "0";
    while (a > 0) { s.insert(s.begin(), (char)(48 + (int)(a % 10))); a /= 10; }
    printf("%s\n", s.c_str());
    return 0;
}
// */
