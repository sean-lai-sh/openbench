import json

W = 10          # row width (8 squares + 2 sentinels)
BLEN = 78       # board length


def idx(f, rank):
    return W * (8 - rank) + f


def onb(f, rank):
    return 0 <= f < 8 and 1 <= rank <= 8


rules = []


def R(p, r):
    rules.append([p, r])


# ---------------- 1. parse input ----------------
R(r'^(\S+) w (\S+) (\S+).*$', r'\1 \2 \3')
for n in range(8, 0, -1):
    R(str(n) + r'(?=\S* \S+ \S+$)', '.' * n)
R('/', '//')
for a, b in zip('KQkq', 'WXYZ'):
    R(a + r'(?=\S* \S+$)', b)
for i, f in enumerate('abcdefgh'):
    R(' ' + f + '6$', ' ' + str(i + 1))

# ---------------- 2. candidate generation ----------------
BLACK_OR_EMPTY = r'[.pnbrq]'
BLACK = r'[pnbrq]'


def move(conds, changes, castle=r'\S+', ep=r'\S+', new_ep='-'):
    """conds: idx->regex class; changes: idx->replacement ('SRC:<i>' copies cond i)."""
    pat = '^'
    groups = []  # (kind, idx)
    i = 0
    gi = 0
    gnum = {}
    while i < BLEN:
        if i in conds:
            pat += '(' + conds[i] + ')'
            gi += 1
            gnum[i] = gi
            groups.append(('c', i, gi))
            i += 1
        else:
            j = i
            while j < BLEN and j not in conds:
                j += 1
            pat += '(.{%d})' % (j - i)
            gi += 1
            groups.append(('r', i, gi))
            i = j
    pat += ' (' + castle + ') ' + ep
    gi += 1
    cg = gi
    repl = r'\g<0>' + '\n'
    for kind, i, g in groups:
        if kind == 'c' and i in changes:
            ch = changes[i]
            if ch.startswith('SRC:'):
                repl += r'\g<%d>' % gnum[int(ch[4:])]
            else:
                repl += ch
        else:
            repl += r'\g<%d>' % g
    repl += r' \g<%d> ' % cg + new_ep
    R(pat, repl)


ORTH = [(1, 0), (-1, 0), (0, 1), (0, -1)]
DIAG = [(1, 1), (1, -1), (-1, 1), (-1, -1)]
KNIGHT = [(1, 2), (2, 1), (-1, 2), (-2, 1), (1, -2), (2, -1), (-1, -2), (-2, -1)]

for f in range(8):
    for rk in range(1, 9):
        s = idx(f, rk)
        # sliders + king
        for dirs, pcs in ((ORTH, 'QR'), (DIAG, 'QB')):
            for df, dr in dirs:
                path = []
                d = 1
                while onb(f + df * d, rk + dr * d):
                    t = idx(f + df * d, rk + dr * d)
                    cls = '[' + pcs + ('K' if d == 1 else '') + ']'
                    conds = {s: cls, t: BLACK_OR_EMPTY}
                    for p in path:
                        conds[p] = r'\.'
                    move(conds, {s: '.', t: 'SRC:%d' % s})
                    path.append(t)
                    d += 1
        # knight
        for df, dr in KNIGHT:
            if onb(f + df, rk + dr):
                t = idx(f + df, rk + dr)
                move({s: 'N', t: BLACK_OR_EMPTY}, {s: '.', t: 'N'})
        # pawns
        if 2 <= rk <= 7:
            t = idx(f, rk + 1)
            np = 'Q' if rk == 7 else 'P'
            move({s: 'P', t: r'\.'}, {s: '.', t: np})
            if rk == 2:
                t2 = idx(f, 4)
                move({s: 'P', t: r'\.', t2: r'\.'}, {s: '.', t2: 'P'}, new_ep=str(f + 1))
            for df in (-1, 1):
                if onb(f + df, rk + 1):
                    t = idx(f + df, rk + 1)
                    move({s: 'P', t: BLACK}, {s: '.', t: np})
            if rk == 5:
                for df in (-1, 1):
                    if onb(f + df, 6):
                        t = idx(f + df, 6)
                        c = idx(f + df, 5)
                        move({s: 'P', t: r'\.', c: 'p'}, {s: '.', t: 'P', c: '.'},
                             ep=str(f + df + 1))

# castling (ghost kings on transit squares; resolved after check filter)
e1, f1, g1, h1 = idx(4, 1), idx(5, 1), idx(6, 1), idx(7, 1)
d1, c1, b1, a1 = idx(3, 1), idx(2, 1), idx(1, 1), idx(0, 1)
move({e1: 'K', f1: r'\.', g1: r'\.', h1: 'R'}, {f1: 'K', g1: 'K'},
     castle=r'\S*W\S*', new_ep='!')
move({e1: 'K', d1: r'\.', c1: r'\.', b1: r'\.', a1: 'R'}, {d1: 'K', c1: 'K'},
     castle=r'\S*X\S*', new_ep='?')

# ---------------- 3. drop root ----------------
R(r'^[^\n]*\n?', '')

# ---------------- 4. remove positions where a white king is attacked -------------
att = []
for k in (8, 12, 19, 21):
    att += ['n.{%d}K' % (k - 1), 'K.{%d}n' % (k - 1)]
att += ['p.{8}K', 'p.{10}K']
for k in (1, 9, 10, 11):
    att += ['k.{%d}K' % (k - 1), 'K.{%d}k' % (k - 1)]
att += [r'[rq]\.*K', r'K\.*[rq]']
for k, c in ((10, 'rq'), (9, 'bq'), (11, 'bq')):
    g = '.{%d}' % (k - 1)
    att += ['[%s](?:%s\\.)*%sK' % (c, g, g), 'K(?:%s\\.)*%s[%s]' % (g, g, c)]
R(r'(?m)^(?=.*(?:' + '|'.join(att) + r')).*\n?', '')

# ---------------- 5. resolve castling ----------------
R(r'(?m)^(.{%d})KKKR( \S+) !$' % e1, r'\1.RK.\2 -')
R(r'(?m)^(.{%d})R\.KKK(.{3} \S+) \?$' % a1, r'\1..KR.\2 -')

# ---------------- 6. castling rights ----------------
R(r'(?m)^(?!.{%d}K..R)(.{%d} [^ W\n]*)W' % (e1, BLEN), r'\1')
R(r'(?m)^(?!.{%d}R...K)(.{%d} [^ X\n]*)X' % (a1, BLEN), r'\1')
R(r'(?m)^(?!.{4}k..r)(.{%d} [^ Y\n]*)Y' % BLEN, r'\1')
R(r'(?m)^(?!r...k)(.{%d} [^ Z\n]*)Z' % BLEN, r'\1')
R(r'(?m)^(.{%d})  ' % BLEN, r'\1 - ')

# ---------------- 7. format ----------------
for i, f in enumerate('abcdefgh'):
    R(r'(?m) %d$' % (i + 1), ' ' + f + '3')
for a, b in zip('KQkq', 'WXYZ'):
    R(b, a)
for n in range(8, 0, -1):
    R(r'\.{%d}' % n, str(n))
R('//', '/')
R(r'(?m)^(\S+) (\S+) (\S+)$', r'\1 b \2 \3 0 0')
R(r'\n+\Z', '')

json.dump(rules, open('/tmp/obench-cell-_rulf3c6/bench_opencode_regex-chess_blw7a4h2/re.json', 'w'))
print(len(rules))
