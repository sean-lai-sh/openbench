"""Black-box extraction of A1 (up to row permutation and scaling) from a
one-hidden-layer ReLU network f(x) = A2 relu(A1 x + b1) + b2, using only
queries to forward(x).

Method:
  1. Along random lines x0 + t*d, f is piecewise linear in t. Locate the
     kinks (critical points where one hidden neuron switches on/off) by
     recursively intersecting the linear pieces at the interval ends.
  2. At each kink, the gradient of f jumps by A2[i] * A1[i, :] for the neuron
     i that switches. Estimate the gradients on both sides by finite
     differences; their difference is a scaled copy of row i of A1.
  3. Normalise, deduplicate, and stop once no new rows appear.
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from forward import forward  # noqa: E402

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, a, b, fa, fb, out, depth=0):
    """Find kink locations t in [a, b] of g(t) = f(x0 + t d)."""
    if b - a < 1e-9 or depth > 60:
        return
    m = 0.5 * (a + b)
    fm = f(x0 + m * d)
    # Linear on the whole interval?
    if abs(fm - 0.5 * (fa + fb)) < 1e-12 * (1 + abs(fa) + abs(fb)):
        # check another point to reduce false "linear" verdicts
        q = a + 0.3 * (b - a)
        if abs(f(x0 + q * d) - (fa + 0.3 * (fb - fa))) < 1e-12 * (1 + abs(fa) + abs(fb)):
            return
    # Try single-kink hypothesis: intersect the end lines.
    h = 1e-7 * (b - a)
    sl = (f(x0 + (a + h) * d) - fa) / h
    sr = (fb - f(x0 + (b - h) * d)) / h
    if abs(sl - sr) > 1e-10:
        t = (fb - fa + sl * a - sr * b) / (sl - sr)
        if a + 2 * h < t < b - 2 * h:
            pred = fa + sl * (t - a)
            if abs(f(x0 + t * d) - pred) < 1e-10 * (1 + abs(pred)):
                # also verify midpoints of the two pieces
                t1, t2 = 0.5 * (a + t), 0.5 * (t + b)
                ok1 = abs(f(x0 + t1 * d) - (fa + sl * (t1 - a))) < 1e-10 * (1 + abs(fa))
                ok2 = abs(f(x0 + t2 * d) - (fb - sr * (b - t2))) < 1e-10 * (1 + abs(fb))
                if ok1 and ok2:
                    out.append(t)
                    return
    find_kinks(x0, d, a, m, fa, fm, out, depth + 1)
    find_kinks(x0, d, m, b, fm, fb, out, depth + 1)


def gradient(x, h=1e-6):
    g = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        g[j] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def normalise(v):
    v = v / np.linalg.norm(v)
    j = np.argmax(np.abs(v))
    return v * np.sign(v[j])


def main():
    rows = []      # normalised unit rows
    counts = []
    stale = 0
    for it in range(2000):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        T = 20.0
        kinks = []
        find_kinks(x0, d, -T, T, f(x0 - T * d), f(x0 + T * d), kinks)
        kinks.sort()
        new = False
        for k, t in enumerate(kinks):
            # stay well inside neighbouring linear pieces
            gapl = t - kinks[k - 1] if k > 0 else 1.0
            gapr = kinks[k + 1] - t if k + 1 < len(kinks) else 1.0
            eps = min(1e-3, 0.25 * gapl, 0.25 * gapr)
            if eps < 1e-6:
                continue
            gl = gradient(x0 + (t - eps) * d, h=min(1e-6, eps / 10))
            gr = gradient(x0 + (t + eps) * d, h=min(1e-6, eps / 10))
            diff = gr - gl
            if np.linalg.norm(diff) < 1e-9:
                continue
            v = normalise(diff)
            match = None
            for i, r in enumerate(rows):
                if abs(np.dot(r, v)) > 0.9999:
                    match = i
                    break
            if match is None:
                rows.append(v)
                counts.append(1)
                new = True
            else:
                # running average to refine
                n = counts[match]
                rows[match] = normalise(rows[match] * n + v * np.sign(np.dot(rows[match], v)))
                counts[match] += 1
        stale = 0 if new else stale + 1
        if stale >= 30 and it >= 50:
            break

    # Drop spurious rows seen only once if there are well-supported ones
    rows = np.array([r for r, c in zip(rows, counts) if c >= 2 or max(counts) < 3])
    print(f"Recovered {rows.shape[0]} hidden neurons")
    np.save(OUT, rows)
    print(rows)
    return rows


if __name__ == "__main__":
    main()
