#!/usr/bin/env python3
"""Hurdle jump analyzer.

Detects the takeoff and landing frames of a single hurdle jump in a video
recorded from a static camera.

Method:
  1. Build a background model (median of sampled frames; first frame has no runner).
  2. Segment the runner by background subtraction and take the main blob
     (plus nearby fragments).
  3. Track the lowest foreground pixel (the feet) in every frame.
  4. A frame is "airborne" when the feet are clearly above the local ground
     level (rolling max of foot height over neighbouring frames).
  5. The airborne segment that crosses the hurdle (or, failing that, the
     longest one) is the jump. Takeoff = last ground frame before it,
     landing = first ground frame after it.

Usage: python3 jump_analyzer.py [input.mp4] [output.toml]
"""
import os
import sys

import cv2
import numpy as np
import toml

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_INPUT = os.path.join(HERE, "example_video.mp4")
DEFAULT_OUTPUT = os.path.join(HERE, "output.toml")

HURDLE_X_FRAC = 490.0 / 960.0   # hurdle horizontal position (same in all videos)
DIFF_THRESH = 60                # sum of abs BGR differences
MIN_BLOB_AREA = 2500
MIN_BLOB_HEIGHT = 80
AIR_MARGIN_FRAC = 12.0 / 540.0  # feet this far above ground => airborne
GROUND_WINDOW = 7               # +- frames for local ground estimate


def read_frames(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise RuntimeError("Cannot open video: %s" % path)
    frames = []
    while True:
        ok, f = cap.read()
        if not ok:
            break
        frames.append(cv2.GaussianBlur(f, (5, 5), 0))
    cap.release()
    if not frames:
        raise RuntimeError("No frames in video: %s" % path)
    return frames


def build_background(frames):
    step = max(1, len(frames) // 40)
    sample = np.stack(frames[::step]).astype(np.int16)
    bg = np.median(sample, axis=0).astype(np.int16)
    return bg


def runner_observation(frame, bg):
    """Return (bottom_y, center_x, left, right, area) for the runner, or None."""
    h, w = frame.shape[:2]
    diff = np.abs(frame.astype(np.int16) - bg).sum(axis=2)
    mask = (diff > DIFF_THRESH).astype(np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask)
    if n <= 1:
        return None
    # main blob: largest blob that is tall enough
    best = None
    for k in range(1, n):
        x, y, bw, bh, a = stats[k]
        if a >= MIN_BLOB_AREA and bh >= MIN_BLOB_HEIGHT:
            if best is None or a > stats[best][4]:
                best = k
    if best is None:
        return None
    x, y, bw, bh, a = stats[best]
    # merge nearby fragments (e.g. a detached foot) that lie below/around the body
    pad = int(0.05 * w)
    x0, x1 = max(0, x - pad), min(w, x + bw + pad)
    keep = [best]
    for k in range(1, n):
        if k == best:
            continue
        kx, ky, kw, kh, ka = stats[k]
        if ka < 30:
            continue
        if kx + kw >= x0 and kx <= x1 and ky >= y and ky <= y + bh + int(0.08 * h):
            keep.append(k)
    sel = np.isin(labels, keep)
    ys, xs = np.nonzero(sel)
    bottom = float(np.percentile(ys, 99.9))
    return bottom, float(xs.mean()), int(xs.min()), int(xs.max()), int(len(xs))


def segments(flags):
    segs, start = [], None
    for i, f in enumerate(flags):
        if f and start is None:
            start = i
        elif not f and start is not None:
            segs.append((start, i - 1))
            start = None
    if start is not None:
        segs.append((start, len(flags) - 1))
    return segs


def analyze(path):
    frames = read_frames(path)
    h, w = frames[0].shape[:2]
    bg = build_background(frames)
    n = len(frames)
    obs = [runner_observation(f, bg) for f in frames]

    # only trust frames where the runner is fully inside the image horizontally
    edge = 3
    valid = [o is not None and o[2] > edge and o[3] < w - 1 - edge for o in obs]
    bottom = np.array([o[0] if o is not None else np.nan for o in obs])
    vb = np.where(valid, bottom, np.nan)

    margin = AIR_MARGIN_FRAC * h
    airborne = [False] * n
    for i in range(n):
        if not valid[i]:
            continue
        lo, hi = max(0, i - GROUND_WINDOW), min(n, i + GROUND_WINDOW + 1)
        win = vb[lo:hi]
        win = win[~np.isnan(win)]
        if len(win) == 0:
            continue
        ground = win.max()
        airborne[i] = bottom[i] < ground - margin

    segs = segments(airborne)
    hurdle_x = HURDLE_X_FRAC * w

    def crosses(seg):
        s, e = seg
        lo, hi = max(0, s - 1), min(n - 1, e + 1)
        xs = [obs[i][1] for i in range(lo, hi + 1) if obs[i] is not None]
        if len(xs) < 2:
            return False
        return min(xs) <= hurdle_x <= max(xs)

    def height(seg):
        s, e = seg
        lo, hi = max(0, s - GROUND_WINDOW), min(n, e + GROUND_WINDOW + 1)
        win = vb[lo:hi]
        g = np.nanmax(win)
        return g - np.nanmin(vb[s:e + 1])

    jump = None
    if segs:
        cand = [s for s in segs if crosses(s)] or segs
        jump = max(cand, key=lambda s: (s[1] - s[0] + 1, height(s)))

    if jump is None:
        # fallback: frames around the hurdle crossing
        xs = [(i, o[1]) for i, o in enumerate(obs) if o is not None]
        if xs:
            i_c = min(xs, key=lambda t: abs(t[1] - hurdle_x))[0]
        else:
            i_c = n // 2
        return max(0, i_c - 4), min(n - 1, i_c + 4)

    takeoff = max(0, jump[0] - 1)
    land = min(n - 1, jump[1] + 1)
    return int(takeoff), int(land)


def main():
    inp = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_INPUT
    out = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_OUTPUT
    takeoff, land = analyze(inp)
    result = {
        "jump_takeoff_frame_number": takeoff,
        "jump_land_frame_number": land,
    }
    with open(out, "w") as f:
        toml.dump(result, f)
    print(toml.dumps(result), end="")


if __name__ == "__main__":
    main()
