#!/usr/bin/env python3
"""
jump_analyzer.py - detect hurdle jump takeoff / landing frames in an MP4 video.

Usage:
    python jump_analyzer.py <video.mp4> [output.toml]

Approach
--------
1. Build a clean background plate as the per-pixel median of frames sampled
   across the whole video (the runner is only present briefly, so the median
   removes them).
2. For every frame compute a jitter-robust foreground mask: the difference to
   the background is taken as the minimum over small (+-2 px) shifts of the
   background, which suppresses the edge noise caused by slight camera shake
   and compression.
3. Keep significant connected components, isolate the runner around the median
   foreground x position and measure the lowest foreground point (the feet).
4. Estimate the ground level from the feet positions of the fully visible
   runner. Frames where the feet are clearly above the ground are "airborne".
5. The hurdle clearance is the airborne run in which the feet rise highest.
   Takeoff = last ground-contact frame before that run,
   Landing = first ground-contact frame after it.
Frame numbers are 0-based (the first frame of the video is frame 0).
"""

import os
import sys

import cv2
import numpy as np
import toml

DEFAULT_OUTPUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output.toml")

SHIFT = 2              # px of camera jitter tolerated
DIFF_THRESH = 35       # colour difference threshold for foreground
MIN_COMPONENT = 300    # min area of a component (dilated) to be kept
MIN_RUNNER_PIXELS = 300
RUNNER_HALF_WIDTH = 150
EDGE_MARGIN = 3        # runner touching the frame border => partially visible


def preprocess(frame):
    return cv2.GaussianBlur(frame, (3, 3), 0).astype(np.int16)


def read_background(path, max_samples=60):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise IOError("Cannot open video: %s" % path)
    n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    frames = []
    if n > 0:
        step = max(1, n // max_samples)
        idx = 0
        while True:
            ok, f = cap.read()
            if not ok:
                break
            if idx % step == 0:
                frames.append(preprocess(f))
            idx += 1
    cap.release()
    if not frames:
        raise IOError("Video contains no frames: %s" % path)
    return np.median(np.stack(frames), axis=0).astype(np.int16)


def shifted_backgrounds(bg, s):
    """Per-pixel min / max of the background over a (2s+1)^2 neighbourhood.
    A pixel only counts as changed if it lies outside this range, which makes
    the comparison tolerant to small camera shifts."""
    k = np.ones((2 * s + 1, 2 * s + 1), np.uint8)
    b = bg.astype(np.uint8)
    lo = cv2.erode(b, k, borderType=cv2.BORDER_REPLICATE).astype(np.int16)
    hi = cv2.dilate(b, k, borderType=cv2.BORDER_REPLICATE).astype(np.int16)
    return lo, hi


def runner_measure(frame, shifts):
    """Return (bottom_y, foot_x, touches_edge, height) or None."""
    f = preprocess(frame)
    lo, hi = shifts
    d = np.maximum(np.maximum(lo - f, f - hi), 0).max(axis=2)
    m = (d > DIFF_THRESH).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))
    md = cv2.dilate(m, np.ones((7, 7), np.uint8))
    n, labels, stats, _ = cv2.connectedComponentsWithStats(md)
    if n <= 1:
        return None
    keep = np.zeros(n, bool)
    keep[1:] = stats[1:, cv2.CC_STAT_AREA] > MIN_COMPONENT
    mask = keep[labels] & (m > 0)
    ys, xs = np.nonzero(mask)
    if len(xs) < MIN_RUNNER_PIXELS:
        return None
    mx = np.median(xs)
    sel = np.abs(xs - mx) < RUNNER_HALF_WIDTH
    ys, xs = ys[sel], xs[sel]
    if len(xs) < MIN_RUNNER_PIXELS:
        return None
    k = min(15, len(ys))
    bottom = float(np.partition(ys, len(ys) - k)[len(ys) - k])  # robust max
    h, w = frame.shape[:2]
    touches = xs.min() <= EDGE_MARGIN or xs.max() >= w - 1 - EDGE_MARGIN
    height = float(bottom - ys.min())
    foot_x = float(np.mean(xs[ys >= bottom - 5]))
    return bottom, foot_x, touches, height


def analyze(path):
    bg = read_background(path)
    shifts = shifted_backgrounds(bg, SHIFT)

    cap = cv2.VideoCapture(path)
    meas = []
    while True:
        ok, f = cap.read()
        if not ok:
            break
        meas.append(runner_measure(f, shifts))
    cap.release()
    n = len(meas)

    present = [i for i, r in enumerate(meas) if r is not None]
    if not present:
        raise RuntimeError("No runner detected in the video")
    inner = [i for i in present if not meas[i][2]] or present
    runner_h = float(np.median([meas[i][3] for i in inner]))
    # frames where the whole body (incl. feet) is visible
    full = [i for i in present if meas[i][3] >= 0.6 * runner_h]
    if not full:
        full = present

    # ground line y = a*x + b fitted on the lowest foot positions
    bx = np.array([meas[i][1] for i in full])
    by = np.array([meas[i][0] for i in full])
    top = np.percentile(by, 90)
    sel = by >= top - 15
    if sel.sum() >= 3 and np.ptp(bx[sel]) > 100:
        a_, b_ = np.polyfit(bx[sel], by[sel], 1)
        if abs(a_) > 0.1:  # implausible tilt -> fall back to flat ground
            a_, b_ = 0.0, float(np.median(by[sel]))
    else:
        a_, b_ = 0.0, float(np.median(by[sel])) if sel.any() else float(top)
    tol = max(5.0, 0.03 * runner_h)

    def clearance(i):
        return (a_ * meas[i][1] + b_) - meas[i][0]

    # status per frame: 1 = on ground, 0 = airborne, None = unknown
    status = [None] * n
    for i in full:
        status[i] = 1 if clearance(i) <= tol else 0

    # airborne runs (between contact frames)
    runs = []
    i = 0
    while i < n:
        if status[i] == 0:
            j = i
            while j + 1 < n and status[j + 1] == 0:
                j += 1
            runs.append((i, j))
            i = j + 1
        else:
            i += 1

    if not runs:
        # fallback: frame where feet are highest
        k = max(full, key=clearance)
        return max(0, k - 1), min(n - 1, k + 1)

    def peak(run):
        a, b = run
        return max(clearance(k) for k in range(a, b + 1))

    best = max(runs, key=lambda r: (peak(r), r[1] - r[0]))
    a, b = best

    takeoff = a - 1
    while takeoff >= 0 and status[takeoff] is None:
        takeoff -= 1
    if takeoff < 0:
        takeoff = max(0, a - 1)
    land = b + 1
    while land < n and status[land] is None:
        land += 1
    if land >= n:
        land = min(n - 1, b + 1)
    return int(takeoff), int(land)


def main():
    if len(sys.argv) < 2:
        print("Usage: python jump_analyzer.py <video.mp4> [output.toml]")
        sys.exit(1)
    video = sys.argv[1]
    out = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_OUTPUT
    takeoff, land = analyze(video)
    result = {
        "jump_takeoff_frame_number": takeoff,
        "jump_land_frame_number": land,
    }
    with open(out, "w") as fh:
        toml.dump(result, fh)
    print(toml.dumps(result), end="")


if __name__ == "__main__":
    main()
