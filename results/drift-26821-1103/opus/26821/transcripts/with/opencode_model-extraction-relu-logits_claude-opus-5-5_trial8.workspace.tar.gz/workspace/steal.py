import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(1234)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo=-30.0, hi=30.0, n=400, tol=1e-11):
    """Find t values where f(x0 + t d) has a slope change."""
    g = lambda t: f(x0 + t * d)
    ts = np.linspace(lo, hi, n + 1)
    vals = [g(t) for t in ts]
    kinks = []

    def rec(a, fa, b, fb, depth):
        m = 0.5 * (a + b)
        fm = g(m)
        if abs(fm - 0.5 * (fa + fb)) < tol * (1 + abs(fm)):
            # check quarter points too, to reduce chance of cancelling kinks
            q = 0.25 * a + 0.75 * b
            fq = g(q)
            if abs(fq - (0.25 * fa + 0.75 * fb)) < tol * (1 + abs(fq)):
                return
        if b - a < 1e-3 or depth > 60:
            # locate kink by intersecting lines from both sides
            h = (b - a) * 1e-3
            sl = (g(a + h) - fa) / h
            sr = (fb - g(b - h)) / h
            if abs(sl - sr) > 1e-8:
                t = (fb - fa + sl * a - sr * b) / (sl - sr)
                kinks.append(t)
            return
        rec(a, fa, m, fm, depth + 1)
        rec(m, fm, b, fb, depth + 1)

    for i in range(n):
        rec(ts[i], vals[i], ts[i + 1], vals[i + 1], 0)
    return kinks


def grad(x, h=1e-6):
    f0 = f(x)
    gr = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        gr[j] = (f(x + e) - f0) / h
    return gr


def normalize(v):
    v = v / np.linalg.norm(v)
    i = np.argmax(np.abs(v))
    return v * np.sign(v[i])


def main():
    rows = []  # list of (direction, count)
    for _ in range(40):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        for t in find_kinks(x0, d):
            xs = x0 + t * d
            delta = 1e-4
            diff = grad(xs + delta * d) - grad(xs - delta * d)
            if np.linalg.norm(diff) < 1e-6:
                continue
            v = normalize(diff)
            for r in rows:
                if np.linalg.norm(r[0] - v) < 1e-3:
                    r[1].append(v)
                    break
            else:
                rows.append([v, [v]])
    # keep directions that were seen repeatedly (robust to spurious hits)
    A = np.array([normalize(np.mean(r[1], axis=0)) for r in rows if len(r[1]) >= 2])
    print(f"Recovered {A.shape[0]} neurons")
    print(A)
    np.save(OUT, A)


if __name__ == "__main__":
    main()
