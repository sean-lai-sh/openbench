/* /* */
#if 0
// */
fn add(a: &Vec<u64>, b: &Vec<u64>) -> Vec<u64> {
    let mut r = Vec::with_capacity(b.len() + 1);
    let mut carry = 0u64;
    for i in 0..std::cmp::max(a.len(), b.len()) {
        let s = carry + if i < a.len() { a[i] } else { 0 } + if i < b.len() { b[i] } else { 0 };
        r.push(s % 1000000000);
        carry = s / 1000000000;
    }
    if carry > 0 { r.push(carry); }
    r
}

fn main() {
    let n: usize = std::env::args().nth(1).expect("usage: main N").trim().parse().expect("N must be a non-negative integer");
    let mut a: Vec<u64> = vec![1];
    let mut b: Vec<u64> = vec![1];
    for _ in 0..n {
        let c = add(&a, &b);
        a = b;
        b = c;
    }
    let mut s = format!("{}", a[a.len() - 1]);
    for i in (0..a.len() - 1).rev() {
        s.push_str(&format!("{:09}", a[i]));
    }
    println!("{}", s);
}
/* /* */
#endif
// */

/* /* */
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <algorithm>

typedef unsigned long long u64;

static std::vector<u64> add(const std::vector<u64>& a, const std::vector<u64>& b) {
    std::vector<u64> r;
    u64 carry = 0;
    size_t m = std::max(a.size(), b.size());
    for (size_t i = 0; i < m; i++) {
        u64 s = carry + (i < a.size() ? a[i] : 0) + (i < b.size() ? b[i] : 0);
        r.push_back(s % 1000000000ULL);
        carry = s / 1000000000ULL;
    }
    if (carry) r.push_back(carry);
    return r;
}

int main(int argc, char** argv) {
    if (argc < 2) { fprintf(stderr, "usage: main N\n"); return 1; }
    long n = strtol(argv[1], 0, 10);
    std::vector<u64> a(1, 1), b(1, 1);
    for (long i = 0; i < n; i++) {
        std::vector<u64> c = add(a, b);
        a.swap(b);
        b.swap(c);
    }
    printf("%llu", a.back());
    for (size_t i = a.size() - 1; i-- > 0;) printf("%09llu", a[i]);
    printf("\n");
    return 0;
}
// */
