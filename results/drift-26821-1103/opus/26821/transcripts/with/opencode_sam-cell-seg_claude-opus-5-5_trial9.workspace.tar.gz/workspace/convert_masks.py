#!/usr/bin/env python
"""Refine cell annotations (rectangles + polylines) into polyline masks using MobileSAM.

For every row of the metadata csv, the annotation's bounding box is used as a
box prompt for MobileSAM (vit_t).  The returned masks are then post-processed so
that:
  * every cell gets exactly one contiguous (single connected component) mask,
  * no two masks overlap (a 1-pixel gap is enforced between neighbours),
  * every mask is written out as a closed polyline (not a rectangle).

The output csv is identical to the input csv except for the updated
xmin, ymin, xmax, ymax, coords_x and coords_y columns.

Usage:
    python convert_masks.py --weights_path mobile_sam.pt --output_path out_dir \
        --rgb_path image.png --csv_path metadata.csv
"""

import argparse
import os

import cv2
import numpy as np
import pandas as pd
import torch
from tqdm import tqdm

from mobile_sam import SamPredictor, sam_model_registry

# Max side of an image region fed to the SAM encoder in a single pass. Larger
# images are processed in overlapping tiles so small cells keep their resolution.
TILE_SIZE = 1024
TILE_OVERLAP = 256
# How far (in pixels, and as a fraction of box size) a SAM mask may extend
# beyond the annotated bounding box.
BOX_MARGIN_PX = 4
BOX_MARGIN_FRAC = 0.15
CONNECTIVITY_KERNEL = np.ones((3, 3), np.uint8)


# --------------------------------------------------------------------------- #
# Argument parsing / IO helpers
# --------------------------------------------------------------------------- #
def parse_args():
    parser = argparse.ArgumentParser(
        description="Convert rectangle/polyline cell masks into refined polylines using MobileSAM."
    )
    names = [
        ("weights_path", "Path to the MobileSAM weights (mobile_sam.pt)."),
        ("output_path", "Output folder where the new csv will be saved."),
        ("rgb_path", "Path to the RGB image."),
        ("csv_path", "Path to the metadata csv."),
    ]
    # Accept both positional (in the order above) and --flag style arguments.
    for name, help_ in names:
        parser.add_argument(f"pos_{name}", nargs="?", default=None, metavar=name, help=help_)
    for name, help_ in names:
        parser.add_argument(f"--{name}", f"--{name.replace('_', '-')}", dest=name, type=str,
                            default=None, help=help_)
    args = parser.parse_args()
    for name, _ in names:
        if getattr(args, name) is None:
            setattr(args, name, getattr(args, f"pos_{name}"))
        if getattr(args, name) is None:
            parser.error(f"missing required argument: {name}")
    return args


def parse_coords(value):
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return np.zeros(0, dtype=np.float64)
    if isinstance(value, (list, tuple, np.ndarray)):
        return np.asarray(value, dtype=np.float64)
    s = str(value).strip().strip("[]()")
    parts = [p for p in s.replace(";", ",").replace(" ", ",").split(",") if p.strip() != ""]
    return np.asarray([float(p) for p in parts], dtype=np.float64)


def load_rgb(path):
    img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    if img is None:
        raise FileNotFoundError(f"Could not read image: {path}")
    if img.dtype != np.uint8:
        img = cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    if img.ndim == 2:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
    elif img.shape[2] == 4:
        img = cv2.cvtColor(img, cv2.COLOR_BGRA2RGB)
    else:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return np.ascontiguousarray(img)


# --------------------------------------------------------------------------- #
# Geometry helpers
# --------------------------------------------------------------------------- #
def get_box(row, xs, ys, H, W):
    """Return the (clipped) bounding box [x0, y0, x1, y1] of an annotation."""
    vals = []
    for c in ("xmin", "ymin", "xmax", "ymax"):
        v = row.get(c, np.nan)
        try:
            v = float(v)
        except (TypeError, ValueError):
            v = np.nan
        vals.append(v)
    x0, y0, x1, y1 = vals
    if len(xs) and len(ys):
        x0 = np.nanmin(xs) if np.isnan(x0) else x0
        x1 = np.nanmax(xs) if np.isnan(x1) else x1
        y0 = np.nanmin(ys) if np.isnan(y0) else y0
        y1 = np.nanmax(ys) if np.isnan(y1) else y1
    if any(np.isnan(v) for v in (x0, y0, x1, y1)):
        return None
    x0, x1 = sorted((x0, x1))
    y0, y1 = sorted((y0, y1))
    x0 = int(np.clip(np.floor(x0), 0, W - 1))
    x1 = int(np.clip(np.ceil(x1), 0, W - 1))
    y0 = int(np.clip(np.floor(y0), 0, H - 1))
    y1 = int(np.clip(np.ceil(y1), 0, H - 1))
    if x1 <= x0:
        x1 = min(W - 1, x0 + 1)
        x0 = max(0, x1 - 1)
    if y1 <= y0:
        y1 = min(H - 1, y0 + 1)
        y0 = max(0, y1 - 1)
    return np.array([x0, y0, x1, y1], dtype=np.int64)


def is_rectangle(row, xs, ys):
    t = str(row.get("type", "")).strip().lower()
    if t.startswith("rect"):
        return True
    if t.startswith("poly"):
        return False
    pts = set(zip(np.round(xs).astype(int).tolist(), np.round(ys).astype(int).tolist()))
    return len(pts) <= 4 and len(set(p[0] for p in pts)) <= 2 and len(set(p[1] for p in pts)) <= 2


def cell_window(box, H, W):
    """Local window (x0, y0, x1, y1; exclusive end) = box expanded by a margin.
    SAM masks for this cell are restricted to this window."""
    x0, y0, x1, y1 = box
    mx = BOX_MARGIN_PX + int(round(BOX_MARGIN_FRAC * (x1 - x0)))
    my = BOX_MARGIN_PX + int(round(BOX_MARGIN_FRAC * (y1 - y0)))
    return (max(0, x0 - mx), max(0, y0 - my), min(W, x1 + mx + 1), min(H, y1 + my + 1))


def ellipse_mask(box, win):
    wx0, wy0, wx1, wy1 = win
    m = np.zeros((wy1 - wy0, wx1 - wx0), np.uint8)
    x0, y0, x1, y1 = box
    c = (int(round((x0 + x1) / 2)) - wx0, int(round((y0 + y1) / 2)) - wy0)
    ax = (max(1, int(round((x1 - x0) / 2))), max(1, int(round((y1 - y0) / 2))))
    cv2.ellipse(m, c, ax, 0, 0, 360, 1, -1)
    return m.astype(bool)


def polygon_mask(xs, ys, win):
    wx0, wy0, wx1, wy1 = win
    m = np.zeros((wy1 - wy0, wx1 - wx0), np.uint8)
    if len(xs) >= 3:
        pts = np.stack([xs - wx0, ys - wy0], axis=1).round().astype(np.int32)
        cv2.fillPoly(m, [pts], 1)
    return m.astype(bool)


def box_mask_local(box, win):
    wx0, wy0, wx1, wy1 = win
    m = np.zeros((wy1 - wy0, wx1 - wx0), bool)
    x0, y0, x1, y1 = box
    m[y0 - wy0:y1 - wy0 + 1, x0 - wx0:x1 - wx0 + 1] = True
    return m


def iou(a, b):
    inter = np.logical_and(a, b).sum()
    union = np.logical_or(a, b).sum()
    return float(inter) / float(union) if union else 0.0


def largest_component(mask):
    mask = mask.astype(np.uint8)
    if mask.sum() == 0:
        return mask.astype(bool)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    if n <= 2:
        return mask.astype(bool)
    k = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return lab == k


def fill_holes(mask):
    m = mask.astype(np.uint8)
    contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    out = np.zeros_like(m)
    cv2.drawContours(out, contours, -1, 1, thickness=-1)
    return out.astype(bool)


def smooth(mask):
    """Light morphological smoothing that keeps the mask non-empty."""
    if mask.sum() < 30:
        return mask
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    m = cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_OPEN, k)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, k)
    m = m.astype(bool)
    return m if m.sum() > 0.5 * mask.sum() else mask


def mask_to_polygon(mask):
    """Return the outer contour (Nx2 int array) of a single-component mask."""
    m = mask.astype(np.uint8)
    contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    c = max(contours, key=cv2.contourArea).reshape(-1, 2)
    return c


def polygon_is_valid(poly):
    if poly is None:
        return False
    uniq = np.unique(poly, axis=0)
    if len(uniq) < 3:
        return False
    return cv2.contourArea(poly.astype(np.int32).reshape(-1, 1, 2)) > 0


def looks_rectangular(mask):
    ys, xs = np.nonzero(mask)
    if len(xs) == 0:
        return False
    area_bbox = (xs.max() - xs.min() + 1) * (ys.max() - ys.min() + 1)
    return mask.sum() >= 0.97 * area_bbox


# --------------------------------------------------------------------------- #
# SAM inference
# --------------------------------------------------------------------------- #
def make_tiles(H, W):
    def starts(n):
        if n <= TILE_SIZE:
            return [0]
        step = TILE_SIZE - TILE_OVERLAP
        s = list(range(0, n - TILE_SIZE + 1, step))
        if s[-1] != n - TILE_SIZE:
            s.append(n - TILE_SIZE)
        return s
    return [(x, y, min(W, x + TILE_SIZE), min(H, y + TILE_SIZE)) for y in starts(H) for x in starts(W)]


def assign_tile(box, tiles):
    x0, y0, x1, y1 = box
    cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    best, best_key = 0, None
    for i, (tx0, ty0, tx1, ty1) in enumerate(tiles):
        contains = x0 >= tx0 and y0 >= ty0 and x1 < tx1 and y1 < ty1
        # distance of the box centre from the tile centre (prefer containing tiles)
        d = abs(cx - (tx0 + tx1) / 2.0) + abs(cy - (ty0 + ty1) / 2.0)
        key = (0 if contains else 1, d)
        if best_key is None or key < best_key:
            best, best_key = i, key
    return best


def run_sam(predictor, image, cells, H, W):
    """Set cell['logits'] (float32 logits over the cell's local window) for every cell."""
    tiles = make_tiles(H, W)
    by_tile = {}
    for idx, cell in enumerate(cells):
        if cell["box"] is None:
            continue
        by_tile.setdefault(assign_tile(cell["box"], tiles), []).append(idx)

    thr = predictor.model.mask_threshold
    pbar = tqdm(total=sum(len(v) for v in by_tile.values()), desc="MobileSAM", unit="cell")
    for t, idxs in by_tile.items():
        tx0, ty0, tx1, ty1 = tiles[t]
        crop = np.ascontiguousarray(image[ty0:ty1, tx0:tx1])
        with torch.no_grad():
            predictor.set_image(crop, image_format="RGB")
        ch, cw = crop.shape[:2]
        for idx in idxs:
            cell = cells[idx]
            x0, y0, x1, y1 = cell["box"]
            box = np.array([x0 - tx0, y0 - ty0, x1 - tx0, y1 - ty0], dtype=np.float32)
            box[[0, 2]] = np.clip(box[[0, 2]], 0, cw - 1)
            box[[1, 3]] = np.clip(box[[1, 3]], 0, ch - 1)
            with torch.no_grad():
                logits, scores, _ = predictor.predict(
                    box=box[None, :], multimask_output=True, return_logits=True
                )
            # cut the cell's window out of the tile logits (pad with -inf if the
            # window sticks out of the tile)
            wx0, wy0, wx1, wy1 = cell["win"]
            local = np.full((logits.shape[0], wy1 - wy0, wx1 - wx0), -np.inf, np.float32)
            sx0, sy0 = max(wx0, tx0), max(wy0, ty0)
            sx1, sy1 = min(wx1, tx1), min(wy1, ty1)
            if sx1 > sx0 and sy1 > sy0:
                local[:, sy0 - wy0:sy1 - wy0, sx0 - wx0:sx1 - wx0] = \
                    logits[:, sy0 - ty0:sy1 - ty0, sx0 - tx0:sx1 - tx0]
            prior, box_m = cell["prior"], cell["box_mask"]
            best_k, best_score = None, -np.inf
            for k in range(local.shape[0]):
                m = local[k] > thr
                m_cc = largest_component(m)
                if m_cc.sum() == 0:
                    continue
                # SAM confidence + agreement with the original annotation +
                # fraction of the mask lying inside the annotated box
                inside = np.logical_and(m, box_m).sum() / max(1, m.sum())
                s = float(scores[k]) + iou(m_cc, prior) + 0.5 * inside
                if s > best_score:
                    best_k, best_score = k, s
            cell["logits"] = local[best_k] if best_k is not None else None
            pbar.update(1)
    pbar.close()


# --------------------------------------------------------------------------- #
# Post-processing (contiguity + no overlap)
# --------------------------------------------------------------------------- #
def resolve_masks(cells, H, W, thr):
    """Returns a list of (local_mask, window) with contiguous, non-overlapping masks."""
    n = len(cells)
    # 1) Initial per-cell mask: SAM foreground, largest component, holes filled.
    #    Fall back to the annotation prior if SAM failed / disagrees strongly.
    for cell in cells:
        if cell["box"] is None:
            cell["mask"] = None
            continue
        lg = cell.get("logits")
        m = (lg > thr) if lg is not None else np.zeros(cell["prior"].shape, bool)
        m = fill_holes(largest_component(m))
        prior = cell["prior"]
        if prior.sum() > 0:
            too_small = m.sum() < 0.1 * prior.sum()
            disagree = (not cell["is_rect"]) and iou(m, prior) < 0.2
            if too_small or disagree:
                m = prior.copy()
                # give the prior positive logits so it competes in the overlap stage
                cell["logits"] = np.where(prior, 1.0, -np.inf).astype(np.float32)
        if looks_rectangular(m):
            m = m & ellipse_mask(cell["box"], cell["win"])
        cell["mask"] = smooth(m)

    # 2) Overlap resolution: contested pixels go to the cell with the highest logit.
    score = np.full((H, W), -np.inf, dtype=np.float32)
    owner = np.full((H, W), -1, dtype=np.int32)
    for i, cell in enumerate(cells):
        m = cell["mask"]
        if m is None or m.sum() == 0:
            continue
        wx0, wy0, wx1, wy1 = cell["win"]
        lg = cell.get("logits")
        val = np.where(m, lg if lg is not None else 0.0, -np.inf).astype(np.float32)
        val[m & ~np.isfinite(val)] = 0.0
        sc = score[wy0:wy1, wx0:wx1]
        ow = owner[wy0:wy1, wx0:wx1]
        upd = m & (val > sc)
        sc[upd] = val[upd]
        ow[upd] = i

    # 3) Per cell: keep largest component of owned pixels; enforce a 1-px gap
    #    to masks that were already finalised (so polygons can't touch/overlap).
    def area(i):
        m = cells[i]["mask"]
        return 0 if m is None else int(m.sum())
    order = sorted(range(n), key=area)  # small cells first
    taken = np.zeros((H, W), bool)
    final = [None] * n
    for i in order:
        cell = cells[i]
        if cell["box"] is None:
            continue
        wx0, wy0, wx1, wy1 = win = cell["win"]
        # blocked = finalised pixels dilated by 1 (computed on a 1-px padded window)
        px0, py0, px1, py1 = max(0, wx0 - 1), max(0, wy0 - 1), min(W, wx1 + 1), min(H, wy1 + 1)
        blk = cv2.dilate(taken[py0:py1, px0:px1].astype(np.uint8), CONNECTIVITY_KERNEL).astype(bool)
        blocked = blk[wy0 - py0:wy0 - py0 + (wy1 - wy0), wx0 - px0:wx0 - px0 + (wx1 - wx0)]
        m = owner[wy0:wy1, wx0:wx1] == i
        m = fill_holes(largest_component(m))
        m = largest_component(m & ~blocked)
        if m.sum() < 3:
            m, win = fallback_mask(cell, taken, H, W)
        m = remove_thin_parts(m)
        final[i] = (m, win)
        wx0, wy0, wx1, wy1 = win
        taken[wy0:wy1, wx0:wx1] |= m
    return final


def contour_self_touches(mask):
    """True if the outer contour visits a pixel twice (1-px necks/spurs)."""
    m = mask.astype(np.uint8)
    contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if not contours:
        return False
    c = max(contours, key=cv2.contourArea).reshape(-1, 2)
    return len(np.unique(c, axis=0)) < len(c)


def remove_thin_parts(mask):
    """Remove 1-px wide necks/spurs so the polygon is simple (non self-intersecting).
    Only ever shrinks the mask, so it cannot introduce overlaps."""
    if mask.sum() == 0 or not contour_self_touches(mask):
        return mask
    for ksize in (3, 5):
        k = cv2.getStructuringElement(cv2.MORPH_RECT, (ksize, ksize))
        m = cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_OPEN, k).astype(bool)
        m = largest_component(m)
        if m.sum() >= max(3, 0.3 * mask.sum()) and not contour_self_touches(m):
            return m
    return mask


def fallback_mask(cell, taken, H, W):
    """Guarantee a non-empty mask for a cell that was squeezed out by neighbours.
    Returns (local_mask, window)."""
    box = cell["box"]
    cx, cy = (box[0] + box[2]) // 2, (box[1] + box[3]) // 2
    r = 2
    while True:
        # growing square window around the box centre
        half = max(box[2] - box[0], box[3] - box[1]) // 2 + r
        win = (max(0, cx - half), max(0, cy - half), min(W, cx + half + 1), min(H, cy + half + 1))
        wx0, wy0, wx1, wy1 = win
        px0, py0, px1, py1 = max(0, wx0 - 1), max(0, wy0 - 1), min(W, wx1 + 1), min(H, wy1 + 1)
        blk = cv2.dilate(taken[py0:py1, px0:px1].astype(np.uint8), CONNECTIVITY_KERNEL).astype(bool)
        blocked = blk[wy0 - py0:wy0 - py0 + (wy1 - wy0), wx0 - px0:wx0 - px0 + (wx1 - wx0)]
        cands = [ellipse_mask(box, win), box_mask_local(box, win), np.ones_like(blocked)]
        for c in cands:
            m = largest_component(c & ~blocked)
            if m.sum() >= 3:
                return m, win
        if wx0 == 0 and wy0 == 0 and wx1 == W and wy1 == H:
            return np.zeros_like(blocked), win
        r *= 2


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main():
    args = parse_args()
    torch.set_grad_enabled(False)
    device = "cpu"

    image = load_rgb(args.rgb_path)
    H, W = image.shape[:2]
    df = pd.read_csv(args.csv_path)
    # Preserve an unnamed index column (if any) exactly as in the input.
    first_col = df.columns[0] if len(df.columns) else None
    keep_index_col = first_col is not None and str(first_col).startswith("Unnamed")

    print(f"Loading MobileSAM from {args.weights_path} ...")
    sam = sam_model_registry["vit_t"](checkpoint=args.weights_path)
    sam.to(device=device)
    sam.eval()
    predictor = SamPredictor(sam)

    cells = []
    for _, row in df.iterrows():
        xs = parse_coords(row.get("coords_x"))
        ys = parse_coords(row.get("coords_y"))
        n = min(len(xs), len(ys))
        xs, ys = xs[:n], ys[:n]
        box = get_box(row, xs, ys, H, W)
        rect = is_rectangle(row, xs, ys)
        if box is None:
            # no usable geometry: give it a tiny box at the image origin
            box = np.array([0, 0, min(1, W - 1), min(1, H - 1)], dtype=np.int64)
        win = cell_window(box, H, W)
        if rect or n < 3:
            prior = ellipse_mask(box, win)
        else:
            prior = polygon_mask(xs, ys, win)
            if prior.sum() == 0:
                prior = ellipse_mask(box, win)
        cells.append(dict(box=box, win=win, is_rect=rect, prior=prior,
                          box_mask=box_mask_local(box, win)))

    run_sam(predictor, image, cells, H, W)
    masks = resolve_masks(cells, H, W, predictor.model.mask_threshold)

    out = df.copy()
    for c in ("xmin", "ymin", "xmax", "ymax", "coords_x", "coords_y"):
        if c not in out.columns:
            out[c] = None
    out["coords_x"] = out["coords_x"].astype(object)
    out["coords_y"] = out["coords_y"].astype(object)
    for c in ("xmin", "ymin", "xmax", "ymax"):
        out[c] = out[c].astype(object)

    for i, (m, win) in enumerate(masks):
        wx0, wy0 = win[0], win[1]
        poly = mask_to_polygon(m) if m.sum() else None
        if poly is not None:
            poly = poly + np.array([wx0, wy0])
        if not polygon_is_valid(poly):
            # Degenerate (very thin) mask: use a tiny triangle inside the mask region.
            ys_, xs_ = np.nonzero(m)
            if len(xs_):
                x, y = int(xs_[0]) + wx0, int(ys_[0]) + wy0
            else:
                b = cells[i]["box"]
                x, y = int(b[0]), int(b[1])
            poly = np.array([[x, y], [min(W - 1, x + 1), y], [x, min(H - 1, y + 1)]])
        poly = np.vstack([poly, poly[:1]])  # close polyline like the input format
        px = poly[:, 0].astype(int)
        py = poly[:, 1].astype(int)
        idx = out.index[i]
        out.at[idx, "xmin"] = int(px.min())
        out.at[idx, "xmax"] = int(px.max())
        out.at[idx, "ymin"] = int(py.min())
        out.at[idx, "ymax"] = int(py.max())
        out.at[idx, "coords_x"] = ",".join(map(str, px.tolist()))
        out.at[idx, "coords_y"] = ",".join(map(str, py.tolist()))

    for c in ("xmin", "ymin", "xmax", "ymax"):
        out[c] = out[c].astype(int)

    out_path = args.output_path
    if out_path.lower().endswith(".csv"):
        out_dir = os.path.dirname(out_path)
        out_file = out_path
    else:
        out_dir = out_path
        out_file = os.path.join(out_path, os.path.basename(args.csv_path))
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    if keep_index_col:
        out = out.rename(columns={first_col: ""})
    out.to_csv(out_file, index=False)
    print(f"Saved {len(out)} refined polyline masks to {out_file}")


if __name__ == "__main__":
    main()
