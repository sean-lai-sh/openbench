#!/usr/bin/env python
"""Refine cell annotations (rectangles and polylines) into polylines with MobileSAM.

Every row in the metadata csv is used as a box prompt for MobileSAM.  The
predicted masks are then made mutually exclusive (no overlap, with a one pixel
gap so that the resulting polygons cannot touch), reduced to a single
contiguous component per cell and converted to closed polylines.  The output
csv is identical to the input csv except for the xmin, xmax, ymin, ymax,
coords_x and coords_y columns.

Usage:
    python convert_masks.py --weights_path mobile_sam.pt --output_path out.csv \
        --rgb_path image.png --csv_path metadata.csv
"""

import argparse
import os
import warnings

import cv2
import numpy as np
import pandas as pd
import torch

warnings.filterwarnings("ignore")

from mobile_sam import SamPredictor, sam_model_registry  # noqa: E402

KERNEL3 = np.ones((3, 3), np.uint8)
MIN_AREA = 9  # minimum number of pixels for a valid cell mask


# --------------------------------------------------------------------------- #
# Argument parsing
# --------------------------------------------------------------------------- #
ARG_NAMES = ["weights_path", "output_path", "rgb_path", "csv_path"]


def parse_args():
    parser = argparse.ArgumentParser(
        description="Convert rectangle / polyline cell masks to MobileSAM refined polylines."
    )
    for name in ARG_NAMES:
        parser.add_argument(f"--{name}", type=str, default=None)
    parser.add_argument("positional", nargs="*", help=argparse.SUPPRESS)
    parser.add_argument("--batch_size", type=int, default=32)
    args = parser.parse_args()

    # Allow the four arguments to be given positionally as well (in order).
    pos = list(args.positional)
    for name in ARG_NAMES:
        if getattr(args, name) is None and pos:
            setattr(args, name, pos.pop(0))
    missing = [n for n in ARG_NAMES if getattr(args, n) is None]
    if missing:
        parser.error("missing required arguments: " + ", ".join(missing))
    return args


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def parse_coords(value):
    if isinstance(value, (list, tuple, np.ndarray)):
        return [float(v) for v in value]
    s = str(value).strip().strip("[]()")
    return [float(v) for v in s.replace(";", ",").replace(" ", ",").split(",") if v.strip() != ""]


def load_rgb(path):
    img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    if img is None:
        from PIL import Image

        return np.array(Image.open(path).convert("RGB"))
    if img.dtype != np.uint8:
        img = cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    if img.ndim == 2:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
    elif img.shape[2] == 4:
        img = cv2.cvtColor(img, cv2.COLOR_BGRA2RGB)
    else:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return np.ascontiguousarray(img)


def largest_component(mask):
    mask = mask.astype(np.uint8)
    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    if n <= 1:
        return np.zeros(mask.shape, bool)
    idx = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return labels == idx


def fill_holes(mask):
    mask = mask.astype(np.uint8)
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    filled = np.zeros_like(mask)
    if contours:
        cv2.drawContours(filled, contours, -1, 1, thickness=cv2.FILLED)
    return filled.astype(bool) | mask.astype(bool)


def mask_to_polygon(mask):
    """Return the outer contour of a (single component) mask as a closed polyline."""
    m = mask.astype(np.uint8)
    contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    cnt = max(contours, key=cv2.contourArea)
    pts = cnt.reshape(-1, 2)
    if len(np.unique(pts, axis=0)) <= 4:
        # Too few vertices (would look like a rectangle) -> use every boundary pixel.
        contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        cnt = max(contours, key=cv2.contourArea)
        pts = cnt.reshape(-1, 2)
    if len(np.unique(pts, axis=0)) < 3:
        return None
    pts = np.vstack([pts, pts[:1]])  # close the polyline like the input data
    return pts


def polygon_mask(xs, ys, shape):
    m = np.zeros(shape, np.uint8)
    pts = np.round(np.stack([xs, ys], 1)).astype(np.int32)
    if len(pts) >= 3:
        cv2.fillPoly(m, [pts], 1)
    return m.astype(bool)


def ellipse_mask(box, shape):
    x0, y0, x1, y1 = box
    m = np.zeros(shape, np.uint8)
    c = (int(round((x0 + x1) / 2)), int(round((y0 + y1) / 2)))
    ax = (max(1, int(round((x1 - x0) / 2))), max(1, int(round((y1 - y0) / 2))))
    cv2.ellipse(m, c, ax, 0, 0, 360, 1, -1)
    return m.astype(bool)


def break_enclosures(cand, occupied, box):
    """If the hole-filled candidate would enclose already placed cells, cut a
    channel from each enclosed hole to the outside so the outer contour does
    not contain other cells."""
    for _ in range(5):
        filled = fill_holes(cand)
        holes = filled & ~cand
        if not (holes & occupied).any():
            return cand
        n, labels = cv2.connectedComponents(holes.astype(np.uint8), connectivity=4)
        for k in range(1, n):
            comp = labels == k
            if not (comp & occupied).any():
                continue
            ys, xs = np.nonzero(comp)
            cx = int(np.round(xs.mean()))
            cy = int(ys.min())
            # cut a 3 px wide vertical channel from the hole up to the image edge
            x_lo, x_hi = max(0, cx - 1), min(cand.shape[1], cx + 2)
            cand[: cy + 1, x_lo:x_hi] = False
        cand = largest_component(cand)
    return cand


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main():
    args = parse_args()
    torch.set_grad_enabled(False)
    device = "cpu"

    # ---------------- data ----------------
    with open(args.csv_path, "r") as f:
        header = f.readline()
    first_col = header.split(",")[0].strip().strip('"')
    if first_col == "" or first_col.startswith("Unnamed"):
        df = pd.read_csv(args.csv_path, index_col=0)
        write_index = True
    else:
        df = pd.read_csv(args.csv_path)
        write_index = False

    image = load_rgb(args.rgb_path)
    H, W = image.shape[:2]
    n_cells = len(df)

    boxes = np.zeros((n_cells, 4), np.float32)
    prior_masks = []
    for i, (_, row) in enumerate(df.iterrows()):
        xs = np.array(parse_coords(row["coords_x"]), float)
        ys = np.array(parse_coords(row["coords_y"]), float)
        if len(xs) and len(ys) and len(xs) == len(ys):
            x0, x1, y0, y1 = xs.min(), xs.max(), ys.min(), ys.max()
        else:
            x0, x1, y0, y1 = row["xmin"], row["xmax"], row["ymin"], row["ymax"]
        x0, x1 = np.clip([x0, x1], 0, W - 1)
        y0, y1 = np.clip([y0, y1], 0, H - 1)
        if x1 - x0 < 2:
            x0, x1 = max(0, x0 - 1), min(W - 1, x1 + 1)
        if y1 - y0 < 2:
            y0, y1 = max(0, y0 - 1), min(H - 1, y1 + 1)
        boxes[i] = [x0, y0, x1, y1]

        # prior mask used only as fallback if SAM fails for this cell
        valid = len(xs) >= 3 and len(xs) == len(ys)
        is_rect = (not valid) or str(row.get("type", "")).lower().startswith("rect")
        if valid and len(np.unique(np.stack([xs, ys], 1), axis=0)) <= 4:
            is_rect = True
        if is_rect:
            prior_masks.append(ellipse_mask(boxes[i], (H, W)))
        else:
            prior_masks.append(polygon_mask(xs, ys, (H, W)))

    # ---------------- MobileSAM ----------------
    sam = sam_model_registry["vit_t"](checkpoint=args.weights_path)
    sam.to(device=device)
    sam.eval()
    predictor = SamPredictor(sam)
    predictor.set_image(image)

    logits = np.full((n_cells, H, W), -np.inf, np.float32)
    scores = np.zeros(n_cells, np.float32)
    for s in range(0, n_cells, args.batch_size):
        b = torch.as_tensor(boxes[s : s + args.batch_size], device=device)
        tb = predictor.transform.apply_boxes_torch(b, (H, W))
        lg, iou, _ = predictor.predict_torch(
            point_coords=None,
            point_labels=None,
            boxes=tb,
            multimask_output=False,
            return_logits=True,
        )
        logits[s : s + len(b)] = lg[:, 0].cpu().numpy()
        scores[s : s + len(b)] = iou[:, 0].cpu().numpy()

    # restrict every cell to (a slightly enlarged version of) its box
    margin = 3
    for i in range(n_cells):
        x0, y0, x1, y1 = boxes[i]
        keep = np.zeros((H, W), bool)
        keep[
            max(0, int(np.floor(y0)) - margin) : min(H, int(np.ceil(y1)) + margin + 1),
            max(0, int(np.floor(x0)) - margin) : min(W, int(np.ceil(x1)) + margin + 1),
        ] = True
        logits[i][~keep] = -np.inf
        # fallback when SAM gives (almost) nothing for this box
        if (logits[i] > 0).sum() < MIN_AREA:
            prior = prior_masks[i] & keep
            if prior.sum() < MIN_AREA:
                prior = ellipse_mask(boxes[i], (H, W))
            logits[i] = np.where(prior, 1.0, -np.inf).astype(np.float32)

    # ---------------- resolve overlaps (pixel-wise argmax) ----------------
    best = np.argmax(logits, axis=0)
    best_val = np.take_along_axis(logits, best[None], 0)[0]
    label = np.where(best_val > 0, best + 1, 0).astype(np.int32)

    # sequential placement, smallest first, with a 1 px gap between cells
    areas = np.array([(label == i + 1).sum() for i in range(n_cells)])
    order = np.argsort(areas, kind="stable")
    occupied = np.zeros((H, W), bool)
    final_masks = [None] * n_cells
    for i in order:
        own = label == i + 1
        blocked = cv2.dilate(occupied.astype(np.uint8), KERNEL3).astype(bool)
        cand = largest_component(own & ~blocked)
        if cand.sum() < MIN_AREA:
            # fall back to the raw SAM mask / prior inside free space
            alt = (logits[i] > 0) & ~blocked
            if alt.sum() < MIN_AREA:
                alt = prior_masks[i] & ~blocked
            if alt.sum() < MIN_AREA:
                alt = ellipse_mask(boxes[i], (H, W)) & ~blocked
            cand = largest_component(alt)
        if cand.sum() == 0:
            # Box completely covered: carve a small disc at the box centre
            x0, y0, x1, y1 = boxes[i]
            disc = np.zeros((H, W), np.uint8)
            r = max(2, int(min(x1 - x0, y1 - y0) / 4))
            cv2.circle(disc, (int((x0 + x1) / 2), int((y0 + y1) / 2)), r, 1, -1)
            disc = disc.astype(bool)
            halo = cv2.dilate(disc.astype(np.uint8), KERNEL3).astype(bool)
            for j in range(n_cells):
                if final_masks[j] is not None and (final_masks[j] & halo).any():
                    m = largest_component(final_masks[j] & ~halo)
                    final_masks[j] = m
            occupied = np.zeros((H, W), bool)
            for j in range(n_cells):
                if final_masks[j] is not None:
                    occupied |= final_masks[j]
            cand = disc
        cand = break_enclosures(cand, occupied, boxes[i])
        cand = fill_holes(cand) & ~blocked if cand.any() else cand
        cand = largest_component(cand)
        cand = fill_holes(cand)
        final_masks[i] = cand
        occupied |= cand

    # ---------------- masks -> polylines ----------------
    out = df.copy()
    coords_x, coords_y = [], []
    xmin, xmax, ymin, ymax = [], [], [], []
    for i in range(n_cells):
        pts = mask_to_polygon(final_masks[i])
        if pts is None:
            # last resort: small triangle-free polygon around the box centre
            x0, y0, x1, y1 = boxes[i]
            cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
            ang = np.linspace(0, 2 * np.pi, 9)[:-1]
            pts = np.stack([cx + 2 * np.cos(ang), cy + 2 * np.sin(ang)], 1).round().astype(int)
            pts = np.vstack([pts, pts[:1]])
        xs, ys = pts[:, 0].astype(int), pts[:, 1].astype(int)
        coords_x.append(",".join(map(str, xs)))
        coords_y.append(",".join(map(str, ys)))
        xmin.append(int(xs.min()))
        xmax.append(int(xs.max()))
        ymin.append(int(ys.min()))
        ymax.append(int(ys.max()))

    out["xmin"] = xmin
    out["xmax"] = xmax
    out["ymin"] = ymin
    out["ymax"] = ymax
    out["coords_x"] = coords_x
    out["coords_y"] = coords_y

    # ---------------- save ----------------
    out_path = args.output_path
    if out_path.lower().endswith(".csv"):
        parent = os.path.dirname(os.path.abspath(out_path))
        os.makedirs(parent, exist_ok=True)
    else:
        os.makedirs(out_path, exist_ok=True)
        out_path = os.path.join(out_path, os.path.basename(args.csv_path))
    out.to_csv(out_path, index=write_index)
    print(f"Saved {n_cells} refined masks to {out_path}")


if __name__ == "__main__":
    main()
