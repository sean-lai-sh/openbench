#!/usr/bin/env python
"""Refine cell annotations (rectangles + polylines) into polyline masks with MobileSAM.

For every row of the metadata csv a MobileSAM prediction is made using the
annotation's bounding box (plus an interior point) as prompt. The predicted
masks are then cleaned up so that

  * every cell has exactly one contiguous (hole-free) mask,
  * masks do not overlap each other,
  * every mask is exported as a closed polyline (never a plain rectangle).

The output csv is identical to the input csv except for the
xmin, ymin, xmax, ymax, coords_x and coords_y columns.

Example:
    python convert_masks.py \
        --weights_path weights/mobile_sam.pt \
        --output_path out/ \
        --rgb_path demo_rgb.png \
        --csv_path demo_metadata.csv
"""

import argparse
import os

import cv2
import numpy as np
import pandas as pd
import torch
from tqdm import tqdm

from mobile_sam import SamPredictor, sam_model_registry

# --------------------------------------------------------------------------- #
# Parameters
# --------------------------------------------------------------------------- #
TILE_SIZE = 512        # images larger than this are processed in tiles (zoom for small cells)
TILE_OVERLAP = 192     # overlap between neighbouring tiles
CONTEXT_PAD = 32       # minimal context (px) kept around a box inside its tile
BOX_MARGIN_FRAC = 0.15  # SAM masks are restricted to the box grown by this fraction ...
BOX_MARGIN_MIN = 4      # ... but at least this many pixels
MIN_AREA = 9           # minimal number of pixels of a final mask


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def parse_coords(value):
    if isinstance(value, (list, tuple, np.ndarray)):
        return [float(v) for v in value]
    s = str(value).strip().strip("[]()")
    if not s:
        return []
    return [float(v) for v in s.replace(";", ",").split(",") if v.strip() != ""]


def polygon_to_mask(xs, ys, shape):
    mask = np.zeros(shape, np.uint8)
    if len(xs) >= 3:
        pts = np.round(np.stack([xs, ys], 1)).astype(np.int32)
        cv2.fillPoly(mask, [pts], 1)
    return mask.astype(bool)


def largest_component(mask):
    mask = mask.astype(np.uint8)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=4)
    if n <= 1:
        return np.zeros(mask.shape, bool)
    idx = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return lab == idx


def fill_holes(mask):
    m = mask.astype(np.uint8)
    contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    out = np.zeros_like(m)
    cv2.drawContours(out, contours, -1, 1, thickness=cv2.FILLED)
    return out.astype(bool)


def clean_mask(mask, open_kernel=True):
    """Smooth, keep the largest 4-connected component, and fill holes."""
    mask = mask.astype(np.uint8)
    area = int(mask.sum())
    if open_kernel and area > 4 * MIN_AREA:
        # kernel grows with object size to remove thin spurs / bridges
        ks = int(np.clip(round(0.12 * np.sqrt(area)), 1, 4)) * 2 + 1
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (ks, ks))
        opened = cv2.morphologyEx(mask, cv2.MORPH_OPEN, k)
        if opened.sum() >= MIN_AREA:
            mask = opened
    mask = largest_component(mask)
    if mask.any():
        mask = fill_holes(mask)
    return mask


def ellipse_mask(box, shape):
    x0, y0, x1, y1 = box
    m = np.zeros(shape, np.uint8)
    cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    ax, ay = max(1, int(round((x1 - x0) / 2.0))), max(1, int(round((y1 - y0) / 2.0)))
    cv2.ellipse(m, (int(round(cx)), int(round(cy))), (ax, ay), 0, 0, 360, 1, -1)
    return m.astype(bool)


def interior_point(mask, box):
    """Point deepest inside the mask (fallback: box centre)."""
    if mask is not None and mask.sum() > 0:
        dt = cv2.distanceTransform(np.pad(mask.astype(np.uint8), 1), cv2.DIST_L2, 3)[1:-1, 1:-1]
        y, x = np.unravel_index(int(np.argmax(dt)), dt.shape)
        return float(x), float(y)
    x0, y0, x1, y1 = box
    return (x0 + x1) / 2.0, (y0 + y1) / 2.0


def iou(a, b):
    inter = np.logical_and(a, b).sum()
    union = np.logical_or(a, b).sum()
    return inter / union if union else 0.0


def mask_to_polygon(mask):
    """Exterior contour of a single-component mask as closed integer polyline."""
    contours, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL,
                                   cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    c = max(contours, key=cv2.contourArea)[:, 0, :]
    if len(c) < 3:
        return None
    xs = c[:, 0].astype(int).tolist()
    ys = c[:, 1].astype(int).tolist()
    xs.append(xs[0])
    ys.append(ys[0])
    return xs, ys


def is_axis_aligned_rectangle(mask):
    ys, xs = np.nonzero(mask)
    if len(xs) == 0:
        return False
    bbox_area = (xs.max() - xs.min() + 1) * (ys.max() - ys.min() + 1)
    return bbox_area == len(xs)


def chamfer_corners(mask):
    """Remove corner pixels so the outline is no longer a plain rectangle."""
    mask = mask.copy()
    ys, xs = np.nonzero(mask)
    x0, x1, y0, y1 = xs.min(), xs.max(), ys.min(), ys.max()
    if x1 - x0 >= 2 and y1 - y0 >= 2:
        for y, x in ((y0, x0), (y0, x1), (y1, x0), (y1, x1)):
            mask[y, x] = False
    return mask


# --------------------------------------------------------------------------- #
# Tiling
# --------------------------------------------------------------------------- #
def tile_starts(length, tile, overlap):
    if length <= tile:
        return [0]
    step = max(1, tile - overlap)
    starts = list(range(0, length - tile + 1, step))
    if starts[-1] != length - tile:
        starts.append(length - tile)
    return starts


def assign_crops(boxes, img_h, img_w):
    """Group boxes by image crop (x0, y0, x1, y1) used for one SAM embedding."""
    tiles = [(x, y, min(img_w, x + TILE_SIZE), min(img_h, y + TILE_SIZE))
             for y in tile_starts(img_h, TILE_SIZE, TILE_OVERLAP)
             for x in tile_starts(img_w, TILE_SIZE, TILE_OVERLAP)]
    groups = {}
    for i, (bx0, by0, bx1, by1) in enumerate(boxes):
        best, best_score = None, -np.inf
        for t in tiles:
            tx0, ty0, tx1, ty1 = t
            pad_l = bx0 - tx0 if tx0 > 0 else np.inf
            pad_t = by0 - ty0 if ty0 > 0 else np.inf
            pad_r = tx1 - bx1 if tx1 < img_w else np.inf
            pad_b = ty1 - by1 if ty1 < img_h else np.inf
            inside = bx0 >= tx0 and by0 >= ty0 and bx1 <= tx1 and by1 <= ty1
            score = min(pad_l, pad_t, pad_r, pad_b) if inside else -np.inf
            if score > best_score:
                best, best_score = t, score
        if best is None or best_score < min(CONTEXT_PAD, 0.5 * max(bx1 - bx0, by1 - by0)):
            # dedicated crop centred on the box with generous context
            size = int(max(TILE_SIZE, 2 * max(bx1 - bx0, by1 - by0) + 2 * CONTEXT_PAD))
            cx, cy = (bx0 + bx1) / 2.0, (by0 + by1) / 2.0
            x0 = int(np.clip(round(cx - size / 2), 0, max(0, img_w - size)))
            y0 = int(np.clip(round(cy - size / 2), 0, max(0, img_h - size)))
            best = (x0, y0, min(img_w, x0 + size), min(img_h, y0 + size))
        groups.setdefault(best, []).append(i)
    return groups


# --------------------------------------------------------------------------- #
# SAM inference
# --------------------------------------------------------------------------- #
def run_sam(predictor, image, boxes, prior_masks, device, batch_size=32):
    """Return, for every cell, (best logit map clipped to its region, region slice)."""
    img_h, img_w = image.shape[:2]
    results = [None] * len(boxes)
    groups = assign_crops(boxes, img_h, img_w)

    for (cx0, cy0, cx1, cy1), idxs in tqdm(groups.items(), desc="SAM tiles"):
        crop = np.ascontiguousarray(image[cy0:cy1, cx0:cx1])
        predictor.set_image(crop)
        ch, cw = crop.shape[:2]

        for s in range(0, len(idxs), batch_size):
            batch = idxs[s:s + batch_size]
            b_boxes, b_pts = [], []
            for i in batch:
                x0, y0, x1, y1 = boxes[i]
                b_boxes.append([x0 - cx0, y0 - cy0, x1 - cx0, y1 - cy0])
                px, py = interior_point(prior_masks[i], boxes[i])
                b_pts.append([[px - cx0, py - cy0]])
            t_boxes = predictor.transform.apply_boxes_torch(
                torch.as_tensor(b_boxes, dtype=torch.float32, device=device), (ch, cw))
            t_pts = predictor.transform.apply_coords_torch(
                torch.as_tensor(b_pts, dtype=torch.float32, device=device), (ch, cw))
            t_lbl = torch.ones(t_pts.shape[:2], dtype=torch.int64, device=device)

            with torch.no_grad():
                logits, scores, _ = predictor.predict_torch(
                    point_coords=t_pts, point_labels=t_lbl, boxes=t_boxes,
                    multimask_output=True, return_logits=True)
            logits = logits.cpu().numpy()
            scores = scores.cpu().numpy()

            for j, i in enumerate(batch):
                x0, y0, x1, y1 = boxes[i]
                bw, bh = x1 - x0, y1 - y0
                m = max(BOX_MARGIN_MIN, int(round(BOX_MARGIN_FRAC * max(bw, bh))))
                rx0, ry0 = max(0, int(np.floor(x0)) - m), max(0, int(np.floor(y0)) - m)
                rx1, ry1 = min(img_w, int(np.ceil(x1)) + m + 1), min(img_h, int(np.ceil(y1)) + m + 1)
                region = (slice(ry0, ry1), slice(rx0, rx1))
                local = logits[j][:, ry0 - cy0:ry1 - cy0, rx0 - cx0:rx1 - cx0]

                prior = prior_masks[i][region] if prior_masks[i] is not None else None
                box_local = np.zeros(local.shape[1:], bool)
                box_local[int(y0) - ry0:int(np.ceil(y1)) - ry0 + 1,
                          int(x0) - rx0:int(np.ceil(x1)) - rx0 + 1] = True

                best_k, best_val = 0, -np.inf
                for k in range(local.shape[0]):
                    mk = local[k] > predictor.model.mask_threshold
                    if mk.sum() < MIN_AREA:
                        continue
                    if prior is not None and prior.any():
                        # polyline annotation: agree with the annotated outline
                        val = 0.6 * iou(mk, prior) + 0.4 * float(scores[j, k])
                    else:
                        # rectangle annotation: mask should fill the box & stay inside it
                        ys, xs = np.nonzero(mk)
                        mbox = np.zeros_like(mk)
                        mbox[ys.min():ys.max() + 1, xs.min():xs.max() + 1] = True
                        val = 0.5 * iou(mbox, box_local) + 0.5 * float(scores[j, k])
                    if val > best_val:
                        best_k, best_val = k, val
                results[i] = (local[best_k].astype(np.float32), region)
    return results


# --------------------------------------------------------------------------- #
# Post-processing: one contiguous, non-overlapping mask per cell
# --------------------------------------------------------------------------- #
def resolve_masks(sam_results, boxes, prior_masks, shape, threshold):
    n = len(boxes)
    h, w = shape
    # 1) per-cell cleaned candidate masks
    cand = []
    for i in range(n):
        logit, region = sam_results[i]
        full = np.zeros(shape, bool)
        full[region] = logit > threshold
        full = clean_mask(full)
        if full.sum() < MIN_AREA:
            # SAM failed -> fall back to annotation (polyline) or ellipse inside the box
            fb = prior_masks[i] if prior_masks[i] is not None and prior_masks[i].sum() >= MIN_AREA \
                else ellipse_mask(boxes[i], shape)
            full = clean_mask(fb, open_kernel=False)
        cand.append(full)

    # 2) contested pixels go to the cell with the highest SAM logit
    best_logit = np.full(shape, -np.inf, np.float32)
    owner = np.full(shape, -1, np.int32)
    for i in range(n):
        logit, region = sam_results[i]
        lg = np.full(shape, -np.inf, np.float32)
        lg[region] = logit
        lg[~cand[i]] = -np.inf
        # guarantee fallback masks still participate
        lg[cand[i] & ~np.isfinite(lg)] = 0.0
        lg[cand[i]] = np.maximum(lg[cand[i]], -50.0)
        upd = cand[i] & (lg > best_logit)
        best_logit[upd] = lg[upd]
        owner[upd] = i

    # 3) sequential pass (small cells first): keep a 1px gap between cells,
    #    keep one contiguous hole-free component
    areas = np.array([(owner == i).sum() for i in range(n)])
    order = np.argsort(areas, kind="stable")
    occupied = np.zeros(shape, bool)
    kernel = np.ones((3, 3), np.uint8)
    final = [None] * n
    for i in order:
        blocked = cv2.dilate(occupied.astype(np.uint8), kernel).astype(bool)
        m = (owner == i) & ~blocked
        m = clean_mask(m)
        # filling holes might cover other cells -> cut them out again (iterate)
        for _ in range(5):
            if not (m & blocked).any():
                break
            m = cv2.erode((m & ~blocked).astype(np.uint8), kernel).astype(bool)
            m = clean_mask(m, open_kernel=False)
        if (m & blocked).any() or m.sum() < MIN_AREA:
            m = fallback_free_region(boxes[i], blocked, cand[i], shape)
        if m.any() and is_axis_aligned_rectangle(m):
            m = chamfer_corners(m)
            m = largest_component(m)
        final[i] = m
        occupied |= m
    return final


def fallback_free_region(box, blocked, cand, shape):
    """Small blob in the free space closest to the cell centre."""
    h, w = shape
    free = (~blocked).astype(np.uint8)
    # restrict to the annotation box first, then the whole image
    x0, y0, x1, y1 = [int(round(v)) for v in box]
    for restrict in (True, False):
        f = free.copy()
        if restrict:
            r = np.zeros_like(f)
            r[max(0, y0):min(h, y1 + 1), max(0, x0):min(w, x1 + 1)] = 1
            f &= r
        if f.sum() == 0:
            continue
        dt = cv2.distanceTransform(np.pad(f, 1), cv2.DIST_L2, 3)[1:-1, 1:-1]
        cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
        yy, xx = np.mgrid[0:h, 0:w]
        score = np.minimum(dt, 4.0) - 1e-3 * np.hypot(xx - cx, yy - cy)
        score[f == 0] = -np.inf
        py, px = np.unravel_index(int(np.argmax(score)), score.shape)
        rad = max(1, int(min(dt[py, px] - 1, 0.5 * min(x1 - x0, y1 - y0), 6)))
        blob = np.zeros(shape, np.uint8)
        cv2.circle(blob, (int(px), int(py)), rad, 1, -1)
        blob = blob.astype(bool) & (f > 0)
        # grow inside the SAM candidate / free space if possible
        grown = largest_component(blob | (cand & (f > 0)))
        m = fill_holes(grown)
        if not (m & blocked).any() and m.sum() >= 3:
            return m
        m = largest_component(blob)
        if m.sum() >= 3:
            return m
    return np.zeros(shape, bool)


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main():
    parser = argparse.ArgumentParser(description="Refine cell masks into polylines with MobileSAM.")
    names = [("weights_path", "MobileSAM weights (mobile_sam.pt)"),
             ("output_path", "Output folder (or .csv file path) for the refined masks"),
             ("rgb_path", "RGB image"),
             ("csv_path", "Metadata csv")]
    # accept both positional (weights output rgb csv) and --flag style arguments
    for name, hlp in names:
        parser.add_argument(f"pos_{name}", nargs="?", default=None, metavar=name, help=hlp)
    for name, hlp in names:
        parser.add_argument(f"--{name}", f"--{name.replace('_', '-')}", dest=name, type=str,
                            default=None, help=hlp)
    args = parser.parse_args()
    for name, _ in names:
        if getattr(args, name) is None:
            setattr(args, name, getattr(args, f"pos_{name}"))
        if getattr(args, name) is None:
            parser.error(f"missing required argument: {name}")

    device = "cuda" if torch.cuda.is_available() else "cpu"

    image = cv2.imread(args.rgb_path, cv2.IMREAD_UNCHANGED)
    if image is None:
        raise FileNotFoundError(args.rgb_path)
    if image.dtype != np.uint8:
        image = cv2.normalize(image, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    if image.ndim == 2:
        image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
    elif image.shape[2] == 4:
        image = cv2.cvtColor(image, cv2.COLOR_BGRA2RGB)
    else:
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    h, w = image.shape[:2]

    df = pd.read_csv(args.csv_path)
    out = df.copy()

    # boxes & prior masks
    boxes, priors = [], []
    for _, row in df.iterrows():
        xs, ys = parse_coords(row["coords_x"]), parse_coords(row["coords_y"])
        n_pts = min(len(xs), len(ys))
        xs, ys = np.array(xs[:n_pts]), np.array(ys[:n_pts])
        try:
            x0, y0, x1, y1 = float(row["xmin"]), float(row["ymin"]), float(row["xmax"]), float(row["ymax"])
            if not np.all(np.isfinite([x0, y0, x1, y1])):
                raise ValueError
        except (ValueError, TypeError, KeyError):
            x0, y0, x1, y1 = xs.min(), ys.min(), xs.max(), ys.max()
        x0, x1 = sorted((float(np.clip(x0, 0, w - 1)), float(np.clip(x1, 0, w - 1))))
        y0, y1 = sorted((float(np.clip(y0, 0, h - 1)), float(np.clip(y1, 0, h - 1))))
        if x1 - x0 < 2:
            x0, x1 = max(0.0, x0 - 1), min(w - 1.0, x1 + 1)
        if y1 - y0 < 2:
            y0, y1 = max(0.0, y0 - 1), min(h - 1.0, y1 + 1)
        boxes.append((x0, y0, x1, y1))

        rtype = str(row.get("type", "")).lower()
        is_rect = "rect" in rtype
        if not is_rect and n_pts >= 3:
            # geometry check in case the type column is missing/wrong
            uniq = {(int(round(a)), int(round(b))) for a, b in zip(xs, ys)}
            is_rect = len(uniq) <= 4 and len(set(np.round(xs))) <= 2 and len(set(np.round(ys))) <= 2
        priors.append(None if is_rect or n_pts < 3 else polygon_to_mask(xs, ys, (h, w)))

    if len(df) == 0:
        save(out, args)
        return

    sam = sam_model_registry["vit_t"](checkpoint=args.weights_path)
    sam.to(device=device)
    sam.eval()
    predictor = SamPredictor(sam)

    sam_results = run_sam(predictor, image, boxes, priors, device)
    masks = resolve_masks(sam_results, boxes, priors, (h, w), sam.mask_threshold)

    for k, (idx, m) in enumerate(zip(df.index, masks)):
        poly = mask_to_polygon(m) if m.any() else None
        if poly is None:
            # last resort: small diamond at box centre (never rectangular)
            x0, y0, x1, y1 = boxes[k]
            cx, cy = int(round((x0 + x1) / 2)), int(round((y0 + y1) / 2))
            poly = ([cx, cx + 1, cx, cx - 1, cx], [cy - 1, cy, cy + 1, cy, cy - 1])
        xs, ys = poly
        out.at[idx, "xmin"] = int(min(xs))
        out.at[idx, "xmax"] = int(max(xs))
        out.at[idx, "ymin"] = int(min(ys))
        out.at[idx, "ymax"] = int(max(ys))
        out.at[idx, "coords_x"] = ",".join(str(int(v)) for v in xs)
        out.at[idx, "coords_y"] = ",".join(str(int(v)) for v in ys)

    save(out, args)


def save(out, args):
    if args.output_path.lower().endswith(".csv"):
        out_file = args.output_path
        parent = os.path.dirname(out_file)
        if parent:
            os.makedirs(parent, exist_ok=True)
    else:
        os.makedirs(args.output_path, exist_ok=True)
        out_file = os.path.join(args.output_path, os.path.basename(args.csv_path))
    # keep an unnamed index column unnamed, exactly as in the input
    out = out.rename(columns={c: "" for c in out.columns if str(c).startswith("Unnamed: ")})
    out.to_csv(out_file, index=False)
    print(f"Saved {len(out)} refined masks to {out_file}")


if __name__ == "__main__":
    main()
