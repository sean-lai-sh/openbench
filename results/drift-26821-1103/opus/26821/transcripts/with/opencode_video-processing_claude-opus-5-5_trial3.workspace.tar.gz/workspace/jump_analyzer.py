#!/usr/bin/env python3
"""Hurdle jump analyzer.

Detects the takeoff and landing frames of a single hurdle jump in an MP4
video recorded from a (nearly) stationary camera.

Approach
--------
1. The first frame (no runner) is used as the background model.
2. Every frame is registered to the background with ECC (affine) to remove
   small camera shake, then differenced against the background to obtain a
   foreground (athlete) mask.
3. For every frame the lowest foreground point (the feet) is located.
4. A local "ground level" is estimated as the lowest foot position within a
   temporal window. Frames where the feet are clearly above that level are
   flagged as airborne.
5. The airborne segment that is longest / passes over the hurdle is the jump.
   takeoff = last ground-contact frame before it, landing = first
   ground-contact frame after it.

Usage: python jump_analyzer.py <video.mp4> [output.toml]
"""
import os
import sys

import cv2
import numpy as np
import toml

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_VIDEO = os.path.join(SCRIPT_DIR, "example_video.mp4")
DEFAULT_OUTPUT = os.path.join(SCRIPT_DIR, "output.toml")

# Hurdle horizontal extent in the reference (960x540) camera setup.
HURDLE_X_RANGE = (480.0, 630.0)
REF_WIDTH = 960.0

DIFF_THRESH = 40
MIN_BLOB_AREA = 60
MIN_PERSON_AREA = 1500
BORDER = 4


def read_frames(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise IOError("Cannot open video: %s" % path)
    frames = []
    while True:
        ok, f = cap.read()
        if not ok:
            break
        frames.append(f)
    cap.release()
    if not frames:
        raise IOError("No frames read from: %s" % path)
    return frames


def foreground_masks(frames):
    """Yield (index, mask) after aligning each frame to the first frame."""
    bg = frames[0]
    h, w = bg.shape[:2]
    bg_blur = cv2.GaussianBlur(bg, (5, 5), 0)
    bg_gray = cv2.cvtColor(bg_blur, cv2.COLOR_BGR2GRAY).astype(np.float32)
    criteria = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 60, 1e-5)
    warp = np.eye(2, 3, dtype=np.float32)
    k_open = np.ones((3, 3), np.uint8)
    k_close = np.ones((9, 9), np.uint8)

    for i, f in enumerate(frames):
        fb = cv2.GaussianBlur(f, (5, 5), 0)
        g = cv2.cvtColor(fb, cv2.COLOR_BGR2GRAY).astype(np.float32)
        try:
            _, new_warp = cv2.findTransformECC(bg_gray, g, warp.copy(),
                                               cv2.MOTION_AFFINE, criteria,
                                               None, 5)
            # Reject wild estimates (should be tiny camera shake only).
            if (abs(new_warp[0, 2]) < 40 and abs(new_warp[1, 2]) < 40 and
                    np.all(np.abs(new_warp[:, :2] - np.eye(2)) < 0.05)):
                warp = new_warp
        except cv2.error:
            pass
        aligned = cv2.warpAffine(fb, warp, (w, h),
                                 flags=cv2.INTER_LINEAR + cv2.WARP_INVERSE_MAP,
                                 borderMode=cv2.BORDER_REPLICATE)
        diff = cv2.absdiff(aligned, bg_blur).max(axis=2)
        m = (diff > DIFF_THRESH).astype(np.uint8)
        m[:BORDER, :] = 0
        m[-BORDER:, :] = 0
        m[:, :BORDER] = 0
        m[:, -BORDER:] = 0
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, k_open)
        m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, k_close)
        yield i, m


def measure(frames):
    """Return per-frame arrays: foot y (bottom), foot x, area, center x."""
    n = len(frames)
    foot_y = np.full(n, np.nan)
    foot_x = np.full(n, np.nan)
    cx = np.full(n, np.nan)
    area = np.zeros(n)
    for i, m in foreground_masks(frames):
        num, lab, st, _ = cv2.connectedComponentsWithStats(m)
        if num < 2:
            continue
        keep = [k for k in range(1, num) if st[k, cv2.CC_STAT_AREA] >= MIN_BLOB_AREA]
        if not keep:
            continue
        # Restrict to blobs near the largest one (the athlete).
        big = max(keep, key=lambda k: st[k, cv2.CC_STAT_AREA])
        bx, by, bw, bh = st[big, :4]
        margin = max(bw, bh)
        sel = []
        for k in keep:
            x, y, ww, hh = st[k, :4]
            if (x + ww >= bx - margin * 0.5 and x <= bx + bw + margin * 0.5 and
                    y + hh >= by - margin * 0.5 and y <= by + bh + margin * 0.5):
                sel.append(k)
        tot = sum(st[k, cv2.CC_STAT_AREA] for k in sel)
        area[i] = tot
        if tot < MIN_PERSON_AREA:
            continue
        mask = np.isin(lab, sel)
        ys, xs = np.nonzero(mask)
        bottom = ys.max()
        foot_y[i] = bottom
        foot_x[i] = xs[ys >= bottom - 3].mean()
        cx[i] = xs.mean()
    return foot_y, foot_x, area, cx


def find_jump(foot_y, foot_x, cx, width):
    n = len(foot_y)
    valid = ~np.isnan(foot_y)
    if valid.sum() < 3:
        raise RuntimeError("Athlete not detected in video")

    # Local ground level: lowest foot position (max y) in a temporal window.
    win = 7
    ground = np.full(n, np.nan)
    for i in range(n):
        if not valid[i]:
            continue
        lo, hi = max(0, i - win), min(n, i + win + 1)
        seg = foot_y[lo:hi][valid[lo:hi]]
        ground[i] = seg.max()

    vy = foot_y[valid]
    span = np.nanmax(vy) - np.nanmin(vy) if len(vy) else 0
    thresh = max(10.0, 0.03 * span)
    air = valid & ((ground - foot_y) > thresh)

    # Contiguous airborne segments.
    segs = []
    i = 0
    while i < n:
        if air[i]:
            j = i
            while j + 1 < n and air[j + 1]:
                j += 1
            segs.append((i, j))
            i = j + 1
        else:
            i += 1

    scale = width / REF_WIDTH
    hx0, hx1 = HURDLE_X_RANGE[0] * scale, HURDLE_X_RANGE[1] * scale
    hc = 0.5 * (hx0 + hx1)

    def score(seg):
        a, b = seg
        length = b - a + 1
        # Does the athlete's horizontal position over the segment cover the hurdle?
        xs = np.concatenate([cx[a:b + 1], foot_x[a:b + 1]])
        xs = xs[~np.isnan(xs)]
        if len(xs):
            crosses = xs.min() <= hx1 and xs.max() >= hx0
            dist = np.min(np.abs(cx[a:b + 1][~np.isnan(cx[a:b + 1])] - hc)) \
                if np.any(~np.isnan(cx[a:b + 1])) else 1e9
        else:
            crosses, dist = False, 1e9
        # Ignore segments touching the frame border of visibility.
        edge = (a == 0 or not valid[a - 1]) or (b == n - 1 or not valid[b + 1])
        return (crosses and not edge, length, -dist)

    if segs:
        best = max(segs, key=score)
        takeoff = best[0] - 1
        land = best[1] + 1
    else:
        # Fallback: highest foot near the hurdle.
        idx = np.where(valid)[0]
        k = idx[np.argmin(np.abs(cx[idx] - hc))]
        takeoff, land = k - 3, k + 3

    takeoff = int(max(0, takeoff))
    land = int(min(n - 1, land))
    return takeoff, land


def analyze(video_path):
    frames = read_frames(video_path)
    width = frames[0].shape[1]
    foot_y, foot_x, _, cx = measure(frames)
    return find_jump(foot_y, foot_x, cx, width)


def main():
    video = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_VIDEO
    out = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_OUTPUT
    takeoff, land = analyze(video)
    data = {
        "jump_takeoff_frame_number": int(takeoff),
        "jump_land_frame_number": int(land),
    }
    with open(out, "w") as fh:
        toml.dump(data, fh)
    print(toml.dumps(data), end="")


if __name__ == "__main__":
    main()
