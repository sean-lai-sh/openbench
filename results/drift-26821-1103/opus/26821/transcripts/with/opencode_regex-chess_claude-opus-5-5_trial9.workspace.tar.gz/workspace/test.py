import json, re, random, sys, time
import chess

RULES = json.load(open("/tmp/obench-cell-c87bfqq0/bench_opencode_regex-chess_mo4eylgo/re.json"))


def run(fen):
    for p, r in RULES:
        fen = re.sub(p, r, fen)
    return [" ".join(x.split(" ")[:-2]) for x in fen.split("\n")]


def expected(fen):
    b = chess.Board(fen)
    s = set()
    for m in b.legal_moves:
        if m.promotion and m.promotion != chess.QUEEN:
            continue
        c = b.copy(); c.push(m)
        s.add(" ".join(c.fen().split(" ")[:-2]))
    return s


def check(fen):
    ours = run(fen)
    exp = expected(fen)
    ok = len(ours) == len(exp) and all(x in exp or x.rpartition(" ")[0] + " -" in exp for x in ours)
    if not ok:
        print("FAIL", fen)
        print(" extra:", [x for x in ours if not (x in exp or x.rpartition(" ")[0] + " -" in exp)])
        print(" counts", len(ours), len(exp))
        oset = set(ours) | {x.rpartition(" ")[0] + " -" for x in ours}
        print(" missing:", [x for x in exp if x not in oset])
    return ok


t = "rnb1k1nr/p2p1ppp/3B4/1p1NPN1P/6P1/3P1Q2/P1P5/q4Kb1 w kq - 0 1"
print(run(t))
random.seed(int(sys.argv[1]) if len(sys.argv) > 1 else 0)
n = fails = 0
t0 = time.time()
for g in range(int(sys.argv[2]) if len(sys.argv) > 2 else 300):
    b = chess.Board()
    while not b.is_game_over():
        if b.turn == chess.WHITE:
            n += 1
            if not check(b.fen()):
                fails += 1
                if fails > 5: sys.exit(1)
        moves = list(b.legal_moves)
        # bias towards captures/pawn moves/castling to hit edge cases
        b.push(random.choice(moves))
print(n, "positions", fails, "fails", time.time() - t0, "s")
