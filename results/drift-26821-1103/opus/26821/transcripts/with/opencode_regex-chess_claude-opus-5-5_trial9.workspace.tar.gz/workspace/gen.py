import json

OUT = "/tmp/obench-cell-c87bfqq0/bench_opencode_regex-chess_mo4eylgo/re.json"
rules = []


def sq(r, f):  # r: 0 = rank 8 ... 7 = rank 1 ; f: 0 = a
    return r * 8 + f


def name(s):
    return "abcdefgh"[s % 8] + str(8 - s // 8)


def on(r, f):
    return 0 <= r < 8 and 0 <= f < 8


def move_rule(conds, changes, castle=r"\S+", ep=r"\S+", new_ep="-", prefix="M"):
    """conds: {square: regex class}; changes: {square: char or ('copy', square)}"""
    squares = sorted(set(conds) | set(changes))
    pat = "(?m)^O"
    rep = [r"\g<0>" + "\n" + prefix]
    g = 0
    cur = ""
    pos = 0
    grp_of = {}

    def flush():
        nonlocal cur, pat, g
        if cur:
            g += 1
            pat += "(" + cur + ")"
            rep.append(r"\g<%d>" % g)
            cur = ""

    for s in squares:
        gap = s - pos
        if gap:
            cur += ".{%d}" % gap
        c = conds.get(s, ".")
        if s in changes:
            flush()
            g += 1
            pat += "(" + c + ")"
            grp_of[s] = g
            rep.append(("CHG", s))
        else:
            cur += c
        pos = s + 1
    if pos < 64:
        cur += ".{%d}" % (64 - pos)
    flush()
    g += 1
    pat += " (" + castle + ") " + ep + "$"
    rep.append(r" \g<%d> " % g + new_ep)
    out = ""
    for x in rep:
        if isinstance(x, tuple):
            v = changes[x[1]]
            if isinstance(v, tuple):
                out += r"\g<%d>" % grp_of[v[1]]
            else:
                out += v
        else:
            out += x
    rules.append([pat, out])


# ---------- 1. parse FEN ----------
rules.append([r"^(\S+ \S+ \S+ \S+) \S+ \S+\s*$", r"\1"])
for d in range(8, 0, -1):
    rules.append([str(d) + r"(?=\S* w )", "." * d])
rules.append([r"/", ""])
rules.append([r"^(\S+) w (\S+) (\S+)$", r"O\1 \2 \3"])

EMPTY = r"\."
TARGET = r"[.a-z]"
BLACK = r"[a-z]"

# ---------- 2. move generation ----------
ORTH = [(-1, 0), (1, 0), (0, -1), (0, 1)]
DIAG = [(-1, -1), (-1, 1), (1, -1), (1, 1)]
for r in range(8):
    for f in range(8):
        s = sq(r, f)
        # sliders
        for dirs, cls in ((ORTH, "[RQ]"), (DIAG, "[BQ]")):
            for dr, df in dirs:
                path = []
                rr, ff = r + dr, f + df
                while on(rr, ff):
                    t = sq(rr, ff)
                    conds = {p: EMPTY for p in path}
                    conds[s] = cls
                    conds[t] = TARGET
                    move_rule(conds, {s: ".", t: ("copy", s)})
                    path.append(t)
                    rr += dr
                    ff += df
        # knight
        for dr, df in [(1, 2), (2, 1), (-1, 2), (-2, 1), (1, -2), (2, -1), (-1, -2), (-2, -1)]:
            if on(r + dr, f + df):
                t = sq(r + dr, f + df)
                move_rule({s: "N", t: TARGET}, {s: ".", t: "N"})
        # king
        for dr in (-1, 0, 1):
            for df in (-1, 0, 1):
                if (dr or df) and on(r + dr, f + df):
                    t = sq(r + dr, f + df)
                    move_rule({s: "K", t: TARGET}, {s: ".", t: "K"})
        # pawns
        if 1 <= r <= 6:
            promo = "Q" if r == 1 else "P"
            t = sq(r - 1, f)
            move_rule({s: "P", t: EMPTY}, {s: ".", t: promo})
            if r == 6:
                t2 = sq(r - 2, f)
                move_rule({s: "P", t: EMPTY, t2: EMPTY}, {s: ".", t2: "P"}, new_ep=name(t))
            for df in (-1, 1):
                if on(r - 1, f + df):
                    t = sq(r - 1, f + df)
                    move_rule({s: "P", t: BLACK}, {s: ".", t: promo})
                    if r == 3:  # en passant (white pawn on rank 5)
                        cap = sq(r, f + df)
                        move_rule({s: "P", t: EMPTY, cap: "p"}, {s: ".", t: "P", cap: "."}, ep=name(t))

# castling (king squares marked, checked later)
E1, F1, G1, H1, D1, C1, B1, A1 = 60, 61, 62, 63, 59, 58, 57, 56
move_rule({E1: "K", F1: EMPTY, G1: EMPTY, H1: "R"}, {F1: "K", G1: "K", H1: "."},
          castle=r"\S*K\S*", prefix="C")
move_rule({E1: "K", D1: EMPTY, C1: EMPTY, B1: EMPTY, A1: "R"}, {D1: "K", C1: "K", A1: "."},
          castle=r"\S*Q\S*", prefix="D")

# ---------- 3. drop original ----------
rules.append([r"(?m)^O.*\n?", ""])

# ---------- 4. legality: remove lines where a white king is attacked ----------
for r in range(8):
    for f in range(8):
        k = sq(r, f)
        alts = []
        for dr, df in [(1, 2), (2, 1), (-1, 2), (-2, 1), (1, -2), (2, -1), (-1, -2), (-2, -1)]:
            if on(r + dr, f + df):
                alts.append(".{%d}n" % sq(r + dr, f + df))
        for df in (-1, 1):
            if on(r - 1, f + df):
                alts.append(".{%d}p" % sq(r - 1, f + df))
        for dr in (-1, 0, 1):
            for df in (-1, 0, 1):
                if (dr or df) and on(r + dr, f + df):
                    alts.append(".{%d}k" % sq(r + dr, f + df))
        for dirs, cls in ((ORTH, "[qr]"), (DIAG, "[qb]")):
            for dr, df in dirs:
                path = []
                rr, ff = r + dr, f + df
                while on(rr, ff):
                    t = sq(rr, ff)
                    a = "".join("(?=.{%d}\\.)" % p for p in path) + ".{%d}%s" % (t, cls)
                    alts.append(a)
                    path.append(t)
                    rr += dr
                    ff += df
        rules.append([r"(?m)^[MCD](?=.{%d}K)(?=%s).*\n?" % (k, "|".join(alts)), ""])
rules.append([r"\n+\Z", ""])

# ---------- 5. castling fixups ----------
rules.append([r"(?m)^C(.{60})KK", r"M\1.R"])
rules.append([r"(?m)^D(.{58})KKK", r"M\1KR."])

# ---------- 6. castling rights ----------
def drop(cond_sq, piece, letters):
    for L in letters:
        rules.append([r"(?m)^(M(?!.{%d}%s).{64} \S*)%s" % (cond_sq, piece, L), r"\1"])

drop(60, "K", "KQ")
drop(63, "R", "K")
drop(56, "R", "Q")
drop(4, "k", "kq")
drop(7, "r", "k")
drop(0, "r", "q")
rules.append([r"(?m)^(M.{64})  ", r"\1 - "])

# ---------- 7. back to FEN ----------
rules.append([r"(?m)^M" + "(.{8})" * 8 + r" (.*)$",
              "/".join(r"\g<%d>" % i for i in range(1, 9)) + r" b \g<9> 0 0"])
for d in range(8, 0, -1):
    rules.append([r"\." * d, str(d)])

json.dump(rules, open(OUT, "w"))
print(len(rules), "rules")
