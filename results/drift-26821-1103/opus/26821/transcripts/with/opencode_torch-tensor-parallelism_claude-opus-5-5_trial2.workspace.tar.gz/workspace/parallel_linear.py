import torch
import torch.distributed as dist
import torch.nn.functional as F


def _world_size():
    if dist.is_available() and dist.is_initialized():
        return dist.get_world_size()
    return 1


def _rank():
    if dist.is_available() and dist.is_initialized():
        return dist.get_rank()
    return 0


def _all_reduce(x):
    if _world_size() == 1:
        return x
    x = x.contiguous().clone()
    dist.all_reduce(x, op=dist.ReduceOp.SUM)
    return x


def _all_gather_last_dim(x):
    ws = _world_size()
    if ws == 1:
        return x
    x = x.contiguous()
    parts = [torch.empty_like(x) for _ in range(ws)]
    dist.all_gather(parts, x)
    return torch.cat(parts, dim=-1).contiguous()


def _split_last_dim(x):
    ws = _world_size()
    if ws == 1:
        return x
    return torch.chunk(x, ws, dim=-1)[_rank()].contiguous()


class _CopyToParallelRegion(torch.autograd.Function):
    """Identity in forward, all-reduce of gradient in backward."""

    @staticmethod
    def forward(ctx, x):
        return x

    @staticmethod
    def backward(ctx, grad):
        return _all_reduce(grad)


class _ReduceFromParallelRegion(torch.autograd.Function):
    """All-reduce in forward, identity in backward."""

    @staticmethod
    def forward(ctx, x):
        return _all_reduce(x)

    @staticmethod
    def backward(ctx, grad):
        return grad


class _GatherFromParallelRegion(torch.autograd.Function):
    """All-gather along last dim in forward, split in backward."""

    @staticmethod
    def forward(ctx, x):
        return _all_gather_last_dim(x)

    @staticmethod
    def backward(ctx, grad):
        return _split_last_dim(grad)


class _ScatterToParallelRegion(torch.autograd.Function):
    """Split along last dim in forward, all-gather in backward."""

    @staticmethod
    def forward(ctx, x):
        return _split_last_dim(x)

    @staticmethod
    def backward(ctx, grad):
        return _all_gather_last_dim(grad)


def _divide(n, ws, name):
    if n % ws != 0:
        raise ValueError(f"{name}={n} is not divisible by world_size={ws}")
    return n // ws


class ColumnParallelLinear(torch.nn.Module):
    """Y = X W^T + b with W (out_features, in_features) split along the output
    dimension. Each rank computes a slice of the output; slices are gathered
    along the last dimension."""

    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.world_size = _world_size()
        self.rank = _rank()
        self.out_features_per_partition = _divide(
            out_features, self.world_size, "out_features"
        )

        master_weight = torch.as_tensor(master_weight).detach()
        assert tuple(master_weight.shape) == (out_features, in_features), (
            f"master_weight shape {tuple(master_weight.shape)} != "
            f"{(out_features, in_features)}"
        )
        start = self.rank * self.out_features_per_partition
        end = start + self.out_features_per_partition
        self.weight = torch.nn.Parameter(master_weight[start:end, :].clone().contiguous())

        if bias:
            self.bias = torch.nn.Parameter(
                torch.zeros(
                    self.out_features_per_partition,
                    dtype=master_weight.dtype,
                    device=master_weight.device,
                )
            )
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        x = _CopyToParallelRegion.apply(x)
        local_out = F.linear(x, self.weight, self.bias)
        return _GatherFromParallelRegion.apply(local_out)


class RowParallelLinear(torch.nn.Module):
    """Y = X W^T + b with W (out_features, in_features) split along the input
    dimension. Each rank computes a partial sum which is all-reduced; the bias
    is kept full on every rank and added after the reduction."""

    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.world_size = _world_size()
        self.rank = _rank()
        self.in_features_per_partition = _divide(
            in_features, self.world_size, "in_features"
        )

        master_weight = torch.as_tensor(master_weight).detach()
        assert tuple(master_weight.shape) == (out_features, in_features), (
            f"master_weight shape {tuple(master_weight.shape)} != "
            f"{(out_features, in_features)}"
        )
        start = self.rank * self.in_features_per_partition
        end = start + self.in_features_per_partition
        self.weight = torch.nn.Parameter(master_weight[:, start:end].clone().contiguous())

        if bias:
            self.bias = torch.nn.Parameter(
                torch.zeros(
                    out_features,
                    dtype=master_weight.dtype,
                    device=master_weight.device,
                )
            )
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        # Accept either the full input (split here) or an already-partitioned input.
        if x.shape[-1] == self.in_features and self.world_size > 1:
            x = _ScatterToParallelRegion.apply(x)
        elif x.shape[-1] != self.in_features_per_partition:
            raise ValueError(
                f"Input last dim {x.shape[-1]} matches neither in_features="
                f"{self.in_features} nor partition size {self.in_features_per_partition}"
            )
        partial = F.linear(x, self.weight)
        out = _ReduceFromParallelRegion.apply(partial)
        if self.bias is not None:
            out = out + self.bias
        return out
