"""Pipeline parallel training (AFAB schedule) for LlamaForCausalLM."""

import torch
import torch.distributed as dist
import torch.nn.functional as F


# --------------------------------------------------------------------------- #
# Partitioning
# --------------------------------------------------------------------------- #
def _partition_layers(num_layers, world_size, rank):
    """Return [start, end) indices of decoder layers owned by `rank`.

    Layers are split as evenly as possible; leftover layers go to the
    earliest ranks.
    """
    base, rem = divmod(num_layers, world_size)
    start = rank * base + min(rank, rem)
    end = start + base + (1 if rank < rem else 0)
    return start, end


# --------------------------------------------------------------------------- #
# Communication helpers
# --------------------------------------------------------------------------- #
def _send(tensor, dst):
    ops = [dist.P2POp(dist.isend, tensor.contiguous(), dst)]
    for req in dist.batch_isend_irecv(ops):
        req.wait()


def _recv(shape, src, device, dtype):
    buf = torch.empty(shape, device=device, dtype=dtype)
    ops = [dist.P2POp(dist.irecv, buf, src)]
    for req in dist.batch_isend_irecv(ops):
        req.wait()
    return buf


# --------------------------------------------------------------------------- #
# Attention mask / rotary helpers
# --------------------------------------------------------------------------- #
def _manual_causal_mask(seq_len, device, dtype):
    mask = torch.full((seq_len, seq_len), torch.finfo(dtype).min, device=device, dtype=dtype)
    mask = torch.triu(mask, diagonal=1)
    return mask[None, None, :, :]


def _build_causal_mask(config, hidden, position_ids):
    """Build the causal mask the same way LlamaModel does, across HF versions."""
    seq_len = hidden.shape[1]
    try:
        from transformers.masking_utils import create_causal_mask
    except Exception:  # pragma: no cover - very old transformers
        return _manual_causal_mask(seq_len, hidden.device, hidden.dtype)

    cache_position = torch.arange(seq_len, device=hidden.device)
    attempts = (
        dict(config=config, inputs_embeds=hidden, attention_mask=None,
             past_key_values=None, position_ids=position_ids),
        dict(config=config, input_embeds=hidden, attention_mask=None,
             cache_position=cache_position, past_key_values=None,
             position_ids=position_ids),
        dict(config=config, inputs_embeds=hidden, attention_mask=None,
             cache_position=cache_position, past_key_values=None,
             position_ids=position_ids),
    )
    for kwargs in attempts:
        try:
            return create_causal_mask(**kwargs)
        except TypeError:
            continue
    return _manual_causal_mask(seq_len, hidden.device, hidden.dtype)


def _run_layer(layer, hidden, mask, position_ids, position_embeddings):
    out = layer(
        hidden,
        attention_mask=mask,
        position_ids=position_ids,
        position_embeddings=position_embeddings,
    )
    if isinstance(out, (tuple, list)):
        out = out[0]
    return out


# --------------------------------------------------------------------------- #
# Main entry point
# --------------------------------------------------------------------------- #
def train_step_pipeline_afab(model, inputs, targets, device, dtype):
    """One training step with all-forward-all-backward pipeline scheduling.

    Returns the (microbatch-scaled, summed) loss on the last rank, None elsewhere.
    Gradients are accumulated into the parameters of the layers owned by this rank.
    """
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    is_first = rank == 0
    is_last = rank == world_size - 1
    prev_rank = rank - 1
    next_rank = rank + 1

    base = model.model
    config = model.config
    hidden_size = config.hidden_size
    num_layers = len(base.layers)
    start, end = _partition_layers(num_layers, world_size, rank)
    my_layers = [base.layers[i] for i in range(start, end)]

    num_mb = len(inputs)

    input_tensors = []   # stage inputs (hidden states received), per microbatch
    output_tensors = []  # stage outputs (hidden states or loss), per microbatch
    total_loss = None

    # ------------------------------ forward ------------------------------ #
    for mb in range(num_mb):
        ids = inputs[mb].to(device)
        mb_size, seq_len = ids.shape[0], ids.shape[1]
        hidden_shape = (mb_size, seq_len, hidden_size)

        if is_first:
            hidden = base.embed_tokens(ids).to(dtype)
            stage_input = None
        else:
            hidden = _recv(hidden_shape, prev_rank, device, dtype)
            hidden.requires_grad_(True)
            stage_input = hidden

        position_ids = torch.arange(seq_len, device=device).unsqueeze(0)
        mask = _build_causal_mask(config, hidden, position_ids)
        position_embeddings = base.rotary_emb(hidden, position_ids)

        for layer in my_layers:
            hidden = _run_layer(layer, hidden, mask, position_ids, position_embeddings)

        if is_last:
            hidden = base.norm(hidden)
            logits = model.lm_head(hidden)
            tgt = targets[mb].to(device)
            loss = F.cross_entropy(
                logits.reshape(-1, logits.size(-1)).float(),
                tgt.reshape(-1).long(),
            ) / num_mb
            output = loss
            total_loss = loss.detach() if total_loss is None else total_loss + loss.detach()
        else:
            output = hidden.to(device=device, dtype=dtype)
            _send(output.detach(), next_rank)

        input_tensors.append(stage_input)
        output_tensors.append(output)

    # ------------------------------ backward ----------------------------- #
    for mb in range(num_mb):
        stage_input = input_tensors[mb]
        output = output_tensors[mb]

        if is_last:
            torch.autograd.backward(output)
        else:
            grad = _recv(tuple(output.shape), next_rank, device, dtype)
            torch.autograd.backward(output, grad_tensors=grad)

        if not is_first:
            g = stage_input.grad
            if g is None:
                g = torch.zeros_like(stage_input)
            _send(g.to(device=device, dtype=dtype), prev_rank)

        # free memory
        input_tensors[mb] = None
        output_tensors[mb] = None

    return total_loss
