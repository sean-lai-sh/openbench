"""Pipeline-parallel training step (AFAB schedule) for LlamaForCausalLM."""

import torch
import torch.distributed as dist
import torch.nn.functional as F

try:
    from transformers.masking_utils import create_causal_mask
except ImportError:  # pragma: no cover
    create_causal_mask = None


def _partition_layers(num_layers, world_size, rank):
    """Return [start, end) layer indices for this rank, balanced (diff <= 1)."""
    base, rem = divmod(num_layers, world_size)
    start = rank * base + min(rank, rem)
    end = start + base + (1 if rank < rem else 0)
    return start, end


def _send_recv(send_tensor=None, send_peer=None, recv_shape=None, recv_peer=None,
               device=None, dtype=None):
    ops = []
    recv_tensor = None
    if send_tensor is not None:
        ops.append(dist.P2POp(dist.isend, send_tensor.contiguous(), send_peer))
    if recv_shape is not None:
        recv_tensor = torch.empty(recv_shape, device=device, dtype=dtype)
        ops.append(dist.P2POp(dist.irecv, recv_tensor, recv_peer))
    if ops:
        for req in dist.batch_isend_irecv(ops):
            req.wait()
    return recv_tensor


def _run_stage(model, hidden_states, start, end):
    base = model.model
    seq_len = hidden_states.shape[1]
    position_ids = torch.arange(seq_len, device=hidden_states.device).unsqueeze(0)

    causal_mask = None
    if create_causal_mask is not None:
        causal_mask = create_causal_mask(
            config=base.config,
            inputs_embeds=hidden_states,
            attention_mask=None,
            past_key_values=None,
            position_ids=position_ids,
        )
    position_embeddings = base.rotary_emb(hidden_states, position_ids=position_ids)

    for layer in base.layers[start:end]:
        out = layer(
            hidden_states,
            attention_mask=causal_mask,
            position_embeddings=position_embeddings,
            position_ids=position_ids,
            past_key_values=None,
            use_cache=False,
        )
        hidden_states = out[0] if isinstance(out, (tuple, list)) else out
    return hidden_states


def train_step_pipeline_afab(model, inputs, targets, device, dtype):
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    is_first = rank == 0
    is_last = rank == world_size - 1
    prev_rank = rank - 1
    next_rank = rank + 1

    model.train()
    config = model.config
    hidden_size = config.hidden_size
    num_layers = config.num_hidden_layers
    start, end = _partition_layers(num_layers, world_size, rank)
    num_mb = len(inputs)

    stage_inputs = []   # received hidden states (requires grad) per microbatch
    stage_outputs = []  # stage outputs (hidden states or loss) per microbatch
    total_loss = None

    # ---------------- All forward ----------------
    for i in range(num_mb):
        mb_input = inputs[i]
        bsz, seq_len = mb_input.shape[0], mb_input.shape[1]
        hidden_shape = (bsz, seq_len, hidden_size)

        if is_first:
            input_ids = mb_input.to(device)
            hidden = model.model.embed_tokens(input_ids).to(dtype)
            stage_inputs.append(None)
        else:
            hidden = _send_recv(recv_shape=hidden_shape, recv_peer=prev_rank,
                                device=device, dtype=dtype)
            hidden.requires_grad_(True)
            stage_inputs.append(hidden)

        hidden = _run_stage(model, hidden, start, end)

        if is_last:
            hidden = model.model.norm(hidden)
            logits = model.lm_head(hidden)
            tgt = targets[i].to(device)
            loss = F.cross_entropy(
                logits.reshape(-1, logits.shape[-1]).float(), tgt.reshape(-1)
            ) / num_mb
            stage_outputs.append(loss)
            total_loss = loss.detach() if total_loss is None else total_loss + loss.detach()
        else:
            hidden = hidden.to(device=device, dtype=dtype)
            stage_outputs.append(hidden)
            _send_recv(send_tensor=hidden.detach(), send_peer=next_rank)

    # ---------------- All backward ----------------
    for i in range(num_mb):
        output = stage_outputs[i]
        if is_last:
            output.backward()
        else:
            grad = _send_recv(recv_shape=output.shape, recv_peer=next_rank,
                              device=device, dtype=dtype)
            torch.autograd.backward(output, grad_tensors=grad)

        if not is_first:
            inp = stage_inputs[i]
            grad_in = inp.grad
            if grad_in is None:
                grad_in = torch.zeros_like(inp)
            grad_in = grad_in.to(device=device, dtype=dtype)
            _send_recv(send_tensor=grad_in, send_peer=prev_rank)
        stage_inputs[i] = None
        stage_outputs[i] = None

    return total_loss
