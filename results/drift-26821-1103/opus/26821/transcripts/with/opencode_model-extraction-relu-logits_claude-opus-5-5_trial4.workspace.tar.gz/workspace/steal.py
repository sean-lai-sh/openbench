import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from forward import forward

DIM = 10
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi, flo, fhi, out, depth=0):
    """Recursively locate points where f(x0 + t d) is non-linear in t."""
    mid = 0.5 * (lo + hi)
    fmid = f(x0 + mid * d)
    lin = 0.5 * (flo + fhi)
    scale = max(1.0, abs(flo), abs(fhi))
    if abs(fmid - lin) < 1e-12 * scale and depth > 3:
        return  # linear on [lo, hi] (assume)
    if hi - lo < 1e-5:
        out.append(mid)
        return
    find_kinks(x0, d, lo, mid, flo, fmid, out, depth + 1)
    find_kinks(x0, d, mid, hi, fmid, fhi, out, depth + 1)


def refine_kink(x0, d, t, w=2e-5):
    """Refine kink location by intersecting the two linear pieces."""
    h = 1e-4
    a, b = t - w, t + w
    sl = (f(x0 + a * d) - f(x0 + (a - h) * d)) / h
    sr = (f(x0 + (b + h) * d) - f(x0 + b * d)) / h
    fa, fb = f(x0 + a * d), f(x0 + b * d)
    if abs(sr - sl) < 1e-12:
        return t
    # fa + sl (t-a) = fb + sr (t-b)
    return (fb - fa + sl * a - sr * b) / (sl - sr)


def gradient(x, h=1e-5):
    g = np.zeros(DIM)
    f0 = f(x)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = h
        g[i] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def steal(n_lines=150, T=20.0):
    rows = []
    for _ in range(n_lines):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        kinks = []
        find_kinks(x0, d, -T, T, f(x0 - T * d), f(x0 + T * d), kinks)
        # merge near-duplicates
        kinks = sorted(kinks)
        merged = []
        for k in kinks:
            if not merged or k - merged[-1] > 1e-4:
                merged.append(k)
        for j, t in enumerate(merged):
            # skip kinks that are too close to a neighbouring kink: the
            # gradient difference would then mix two neurons
            gap = min(
                [abs(t - merged[j - 1])] if j > 0 else [np.inf]
            )
            if j + 1 < len(merged):
                gap = min(gap, abs(merged[j + 1] - t))
            if gap < 1e-2:
                continue
            t2 = refine_kink(x0, d, t)
            if abs(t2 - t) > 1e-4:
                continue
            xk = x0 + t2 * d
            eps = 2e-3
            gp = gradient(xk + eps * d, h=1e-7)
            gm = gradient(xk - eps * d, h=1e-7)
            diff = gp - gm  # = +/- a2_i * A1_i
            n = np.linalg.norm(diff)
            if n < 1e-8:
                continue
            # canonical (arbitrary) orientation; true sign fixed later
            row = diff / n
            row = row * np.sign(row[np.argmax(np.abs(row))])
            beta = -row @ xk  # hyperplane: row.x + beta = 0
            rows.append(np.append(row, beta))

    # cluster (row, bias) by direction
    clusters = []
    for r in rows:
        for c in clusters:
            if np.dot(c[0][:DIM], r[:DIM]) > 0.999 and abs(c[0][DIM] - r[DIM]) < 1e-2 * (1 + abs(r[DIM])):
                c.append(r)
                break
        else:
            clusters.append([r])
    # keep clusters seen several times (robust to noise / mixed kinks)
    good = [c for c in clusters if len(c) >= 3] or clusters
    W = []
    for c in good:
        m = np.median(np.array(c), axis=0)
        W.append(m / np.linalg.norm(m[:DIM]))
    W = np.array(W)
    signs = resolve_signs(W[:, :DIM], W[:, DIM])
    return W[:, :DIM] * signs[:, None]


def resolve_signs(W, beta, n_samples=4000, scale=5.0):
    """Fit f(x) = sum_i c_i ReLU(w_i x + beta_i) + v.x + b.  Flipping the
    orientation of neuron i (ReLU(z) = ReLU(-z) + z) changes v by c_i w_i.
    The true network has no linear term, so find the subset S of neurons
    with sum_{i in S} c_i w_i = -v; those neurons must be flipped."""
    k = W.shape[0]
    X = rng.normal(size=(n_samples, DIM)) * scale
    y = np.array([f(x) for x in X])
    H = np.maximum(0, X @ W.T + beta)
    M = np.hstack([H, X, np.ones((n_samples, 1))])
    sol, *_ = np.linalg.lstsq(M, y, rcond=None)
    c, v = sol[:k], -sol[k:k + DIM]  # ReLU(-u) = ReLU(u) - u
    V = c[:, None] * W  # contribution of each flip to the linear term

    # meet-in-the-middle subset sum: find S with sum V[S] == v
    h1 = k // 2
    def enum(idx):
        m = len(idx)
        masks = np.arange(2 ** m)
        bits = ((masks[:, None] >> np.arange(m)) & 1).astype(np.float64)
        return bits, bits @ V[idx]
    idx1, idx2 = np.arange(h1), np.arange(h1, k)
    b1, s1 = enum(idx1)
    b2, s2 = enum(idx2)
    proj = rng.normal(size=DIM)
    p1 = s1 @ proj
    target = (v - s2) @ proj
    order = np.argsort(p1)
    p1s = p1[order]
    best, best_err = None, np.inf
    tol = 1e-6 * (1 + np.abs(V).sum())
    pos = np.searchsorted(p1s, target)
    for j in range(len(target)):
        for q in (pos[j] - 1, pos[j]):
            if 0 <= q < len(p1s) and abs(p1s[q] - target[j]) < 1e3 * tol:
                i1 = order[q]
                err = np.linalg.norm(s1[i1] + s2[j] - v)
                if err < best_err:
                    best_err, best = err, (i1, j)
    if best is None:
        # fallback: full scan for closest match (should not normally happen)
        for j in range(len(s2)):
            errs = np.linalg.norm(s1 + s2[j] - v, axis=1)
            i1 = np.argmin(errs)
            if errs[i1] < best_err:
                best_err, best = errs[i1], (i1, j)
    flip = np.concatenate([b1[best[0]], b2[best[1]]])
    return np.where(flip > 0, -1.0, 1.0)


if __name__ == "__main__":
    A1_hat = steal()
    print("Recovered", A1_hat.shape[0], "neurons")
    print(A1_hat)
    np.save(os.path.join(HERE, "stolen_A1.npy"), A1_hat)
