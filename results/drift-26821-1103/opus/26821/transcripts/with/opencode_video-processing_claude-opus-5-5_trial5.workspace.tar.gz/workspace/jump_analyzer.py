#!/usr/bin/env python3
"""Hurdle jump analyzer.

Detects the takeoff and landing frames of a single hurdle jump in an MP4
video recorded from a static camera.

Method:
  * The first frame (no runner) is used as background.
  * Each frame is brightness-compensated against the background and
    differenced to obtain a foreground (athlete) mask.
  * For every frame the lowest foreground pixel (the athlete's feet) is
    tracked. While running, the feet repeatedly touch the ground line; during
    the hurdle clearance the lowest point rises far above it.
  * The frame where the feet are highest marks the clearance. The takeoff is
    the last frame before it with the feet on the ground, the landing is the
    first frame after it with the feet back on the ground.

Usage:
    python jump_analyzer.py [video.mp4] [output.toml]
"""
import os
import sys

import cv2
import numpy as np
import toml

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_VIDEO = os.path.join(HERE, "example_video.mp4")
DEFAULT_OUTPUT = os.path.join(HERE, "output.toml")

DIFF_THRESHOLD = 40        # per-channel abs difference to count as foreground
MIN_BLOB_AREA = 150        # ignore small noisy components
MIN_FG_PIXELS = 1500       # frames with less foreground are "no athlete"
GROUND_TOLERANCE = 10      # px above ground line still considered "on ground"


def read_frames(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise IOError("Cannot open video: %s" % path)
    frames = []
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frames.append(frame)
    cap.release()
    if not frames:
        raise IOError("No frames read from video: %s" % path)
    return frames


def preprocess(frame):
    return cv2.GaussianBlur(frame, (5, 5), 0).astype(np.float32)


def foreground_mask(frame, bg, bg_median):
    med = np.median(frame, axis=(0, 1))
    gain = bg_median / np.maximum(med, 1.0)
    diff = np.abs(frame * gain - bg).max(axis=2)
    mask = (diff > DIFF_THRESHOLD).astype(np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    keep = np.zeros(n, dtype=bool)
    keep[1:] = stats[1:, cv2.CC_STAT_AREA] >= MIN_BLOB_AREA
    return keep[labels]


def foot_trajectory(frames):
    """Return arrays of (lowest foreground y, foreground pixel count, centroid x)."""
    bg = preprocess(frames[0])
    bg_median = np.median(bg, axis=(0, 1))
    n = len(frames)
    bottom = np.full(n, np.nan)
    count = np.zeros(n, dtype=int)
    cx = np.full(n, np.nan)
    for i in range(1, n):
        mask = foreground_mask(preprocess(frames[i]), bg, bg_median)
        ys, xs = np.nonzero(mask)
        count[i] = len(ys)
        if len(ys) >= MIN_FG_PIXELS:
            # robust "lowest point": ignore a handful of stray pixels
            bottom[i] = np.sort(ys)[-min(5, len(ys))]
            cx[i] = xs.mean()
    return bottom, count, cx


def detect_jump(bottom):
    valid = np.where(~np.isnan(bottom))[0]
    if len(valid) == 0:
        return 0, 0

    # Ground line: where the feet are most of the time when the athlete is visible.
    ground = np.percentile(bottom[valid], 80)
    on_ground_thr = ground - GROUND_TOLERANCE

    # Hurdle clearance = longest/highest airborne segment. Score each contiguous
    # airborne run (feet above ground threshold) by its peak height * length.
    airborne = (~np.isnan(bottom)) & (bottom < on_ground_thr)
    best = None
    i = 0
    n = len(bottom)
    while i < n:
        if airborne[i]:
            j = i
            while j + 1 < n and airborne[j + 1]:
                j += 1
            seg = bottom[i:j + 1]
            height = ground - np.nanmin(seg)
            score = height * (j - i + 1)
            # require that the run is bounded by on-ground frames (athlete visible)
            if best is None or score > best[0]:
                best = (score, i, j)
            i = j + 1
        else:
            i += 1

    if best is None:
        peak = int(valid[np.argmin(bottom[valid])])
        return max(peak - 1, 0), min(peak + 1, n - 1)

    _, start, end = best
    takeoff = start - 1
    land = end + 1
    # Step outward over missing frames if needed
    while takeoff > 0 and np.isnan(bottom[takeoff]):
        takeoff -= 1
    while land < n - 1 and np.isnan(bottom[land]):
        land += 1
    return int(max(takeoff, 0)), int(min(land, n - 1))


def main():
    video = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_VIDEO
    output = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_OUTPUT

    frames = read_frames(video)
    bottom, _, _ = foot_trajectory(frames)
    takeoff, land = detect_jump(bottom)

    result = {
        "jump_takeoff_frame_number": int(takeoff),
        "jump_land_frame_number": int(land),
    }
    with open(output, "w") as f:
        toml.dump(result, f)
    print(toml.dumps(result), end="")


if __name__ == "__main__":
    main()
