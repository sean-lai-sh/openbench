"""Tensor-parallel linear layers (Megatron-style) implemented with torch.distributed.

Weight layout follows torch.nn.Linear: weight has shape (out_features, in_features)
and y = x @ W^T + b.

* ColumnParallelLinear: W is split along the output dimension (dim 0), so every
  rank computes a slice of the output features. Slices are all-gathered and
  concatenated along the last dimension. Bias is sharded the same way.
* RowParallelLinear: W is split along the input dimension (dim 1), so every rank
  computes a partial sum of the full output. Partial outputs are all-reduced
  (summed). Bias is kept full on each rank and added after the reduction.
"""

import torch
import torch.distributed as dist
import torch.nn as nn


def _world_size():
    if dist.is_available() and dist.is_initialized():
        return dist.get_world_size()
    return 1


def _rank():
    if dist.is_available() and dist.is_initialized():
        return dist.get_rank()
    return 0


def _split_last_dim(x):
    ws = _world_size()
    if ws == 1:
        return x
    last = x.size(-1)
    assert last % ws == 0, f"last dim {last} not divisible by world size {ws}"
    chunk = last // ws
    return x.narrow(-1, _rank() * chunk, chunk).contiguous()


def _gather_last_dim(x):
    ws = _world_size()
    if ws == 1:
        return x
    x = x.contiguous()
    parts = [torch.empty_like(x) for _ in range(ws)]
    dist.all_gather(parts, x)
    return torch.cat(parts, dim=-1).contiguous()


def _all_reduce(x):
    if _world_size() == 1:
        return x
    x = x.contiguous().clone()
    dist.all_reduce(x, op=dist.ReduceOp.SUM)
    return x


class _CopyToParallelRegion(torch.autograd.Function):
    """Forward: identity. Backward: all-reduce of the gradient."""

    @staticmethod
    def forward(ctx, x):
        return x

    @staticmethod
    def backward(ctx, grad):
        return _all_reduce(grad)


class _ReduceFromParallelRegion(torch.autograd.Function):
    """Forward: all-reduce (sum). Backward: identity."""

    @staticmethod
    def forward(ctx, x):
        return _all_reduce(x)

    @staticmethod
    def backward(ctx, grad):
        return grad


class _ScatterToParallelRegion(torch.autograd.Function):
    """Forward: take this rank's slice of the last dim. Backward: all-gather."""

    @staticmethod
    def forward(ctx, x):
        return _split_last_dim(x)

    @staticmethod
    def backward(ctx, grad):
        return _gather_last_dim(grad)


class _GatherFromParallelRegion(torch.autograd.Function):
    """Forward: all-gather along last dim. Backward: take this rank's slice."""

    @staticmethod
    def forward(ctx, x):
        return _gather_last_dim(x)

    @staticmethod
    def backward(ctx, grad):
        return _split_last_dim(grad)


class ColumnParallelLinear(nn.Module):
    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.world_size = _world_size()
        self.rank = _rank()

        assert out_features % self.world_size == 0, (
            "out_features must be divisible by world_size"
        )
        self.out_features_per_partition = out_features // self.world_size

        master_weight = torch.as_tensor(master_weight).detach()
        assert tuple(master_weight.shape) == (out_features, in_features), (
            f"master_weight shape {tuple(master_weight.shape)} != "
            f"{(out_features, in_features)}"
        )
        start = self.rank * self.out_features_per_partition
        end = start + self.out_features_per_partition
        self.weight = nn.Parameter(master_weight[start:end, :].clone().contiguous())

        if bias:
            self.bias = nn.Parameter(
                torch.zeros(
                    self.out_features_per_partition,
                    dtype=master_weight.dtype,
                    device=master_weight.device,
                )
            )
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        x = _CopyToParallelRegion.apply(x)
        out = torch.nn.functional.linear(x, self.weight, self.bias)
        return _GatherFromParallelRegion.apply(out)


class RowParallelLinear(nn.Module):
    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.world_size = _world_size()
        self.rank = _rank()

        assert in_features % self.world_size == 0, (
            "in_features must be divisible by world_size"
        )
        self.in_features_per_partition = in_features // self.world_size

        master_weight = torch.as_tensor(master_weight).detach()
        assert tuple(master_weight.shape) == (out_features, in_features), (
            f"master_weight shape {tuple(master_weight.shape)} != "
            f"{(out_features, in_features)}"
        )
        start = self.rank * self.in_features_per_partition
        end = start + self.in_features_per_partition
        self.weight = nn.Parameter(master_weight[:, start:end].clone().contiguous())

        if bias:
            self.bias = nn.Parameter(
                torch.zeros(
                    out_features,
                    dtype=master_weight.dtype,
                    device=master_weight.device,
                )
            )
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        # Accept either the full input (split it here) or an already-partitioned input.
        if x.size(-1) == self.in_features and self.world_size > 1:
            x = _ScatterToParallelRegion.apply(x)
        elif x.size(-1) != self.in_features_per_partition:
            raise ValueError(
                f"Input last dim {x.size(-1)} must be {self.in_features} (full) "
                f"or {self.in_features_per_partition} (partitioned)"
            )
        partial = torch.nn.functional.linear(x, self.weight)
        out = _ReduceFromParallelRegion.apply(partial)
        if self.bias is not None:
            out = out + self.bias
        return out
