#!/usr/bin/env python
"""Refine cell annotations (rectangles + polylines) into polylines with MobileSAM.

For every row of the metadata CSV, MobileSAM is prompted with the annotation's
bounding box (plus a positive point at the annotation's centroid).  The
resulting masks are then made mutually exclusive (each contested pixel goes to
the cell with the highest SAM logit), reduced to a single contiguous,
hole-free component, and converted to a closed polyline.  The output CSV is
identical to the input except for the xmin, ymin, xmax, ymax, coords_x and
coords_y columns.

Usage:
    python convert_masks.py --weights_path mobile_sam.pt --output_path out/ \
        --rgb_path image.png --csv_path metadata.csv
(positional arguments in the same order are also accepted)
"""

import argparse
import os

import cv2
import numpy as np
import pandas as pd
import torch
from tqdm import tqdm

from mobile_sam import SamPredictor, sam_model_registry


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def parse_args():
    p = argparse.ArgumentParser(description="Convert cell masks to polylines using MobileSAM.")
    names = ["weights_path", "output_path", "rgb_path", "csv_path"]
    helps = [
        "Path to MobileSAM weights (mobile_sam.pt).",
        "Output folder (or .csv file path) for the refined masks.",
        "Path to the RGB image.",
        "Path to the metadata csv.",
    ]
    # Accept both positional and --flag forms.
    for n, h in zip(names, helps):
        p.add_argument(n, nargs="?", default=None, help=h)
        p.add_argument("--" + n, dest=n + "_opt", default=None, help=h)
    a = p.parse_args()
    for n in names:
        val = getattr(a, n + "_opt") or getattr(a, n)
        if val is None:
            p.error("missing required argument: %s" % n)
        setattr(a, n, val)
    return a


def load_rgb(path):
    img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    if img is None:
        raise FileNotFoundError("Could not read image: %s" % path)
    if img.dtype != np.uint8:
        img = img.astype(np.float32)
        img = (255 * (img - img.min()) / max(float(img.max() - img.min()), 1e-6)).astype(np.uint8)
    if img.ndim == 2:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
    elif img.shape[2] == 4:
        img = cv2.cvtColor(img, cv2.COLOR_BGRA2RGB)
    else:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return np.ascontiguousarray(img)


def parse_coords(val):
    if isinstance(val, (list, tuple, np.ndarray)):
        return [float(v) for v in val]
    s = str(val).strip().strip("[]()")
    if not s or s.lower() == "nan":
        return []
    return [float(v) for v in s.replace(";", ",").replace(" ", ",").split(",") if v != ""]


def is_rectangle(xs, ys):
    pts = set(zip(np.round(xs, 3), np.round(ys, 3)))
    return len(pts) <= 4 and len(set(np.round(xs, 3))) <= 2 and len(set(np.round(ys, 3))) <= 2


def clip_box(x0, y0, x1, y1, w, h):
    x0, x1 = sorted((x0, x1))
    y0, y1 = sorted((y0, y1))
    x0 = int(np.clip(np.floor(x0), 0, w - 1))
    y0 = int(np.clip(np.floor(y0), 0, h - 1))
    x1 = int(np.clip(np.ceil(x1), x0 + 1, w - 1)) if w > 1 else x0
    y1 = int(np.clip(np.ceil(y1), y0 + 1, h - 1)) if h > 1 else y0
    return x0, y0, x1, y1


def prior_mask(xs, ys, box, rect, shape):
    """Mask describing the original annotation (ellipse for rectangles)."""
    m = np.zeros(shape, np.uint8)
    x0, y0, x1, y1 = box
    if rect or len(xs) < 3:
        c = (int(round((x0 + x1) / 2)), int(round((y0 + y1) / 2)))
        ax = (max(1, int(round((x1 - x0) / 2))), max(1, int(round((y1 - y0) / 2))))
        cv2.ellipse(m, c, ax, 0, 0, 360, 1, -1)
    else:
        pts = np.round(np.stack([xs, ys], 1)).astype(np.int32)
        cv2.fillPoly(m, [pts], 1)
    if m.sum() == 0:
        m[y0:y1 + 1, x0:x1 + 1] = 1
    return m.astype(bool)


def largest_cc(mask):
    mask = mask.astype(np.uint8)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=4)
    if n <= 1:
        return mask.astype(bool)
    k = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return lab == k


def fill_holes(mask):
    m = mask.astype(np.uint8)
    cnts, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    out = np.zeros_like(m)
    if cnts:
        cv2.drawContours(out, cnts, -1, 1, -1)
    return out.astype(bool) | mask.astype(bool)


def remove_holes_by_cutting(mask):
    """Make a single-component mask simply connected (hole-free) by cutting a
    thin channel from each hole to the outside.  Used only when a hole is
    occupied by another cell (so it cannot simply be filled)."""
    mask = mask.copy()
    for _ in range(20):
        m8 = mask.astype(np.uint8)
        cnts, hier = cv2.findContours(m8, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_NONE)
        if hier is None:
            break
        holes = [c for c, h in zip(cnts, hier[0]) if h[3] >= 0]
        if not holes:
            break
        outside = ~fill_holes(mask)
        oy, ox = np.nonzero(outside)
        if len(oy) == 0:
            break
        for hc in holes:
            hp = hc[:, 0, :].astype(np.float64)
            hpx, hpy = hp[:, 0].mean(), hp[:, 1].mean()
            d = (ox - hpx) ** 2 + (oy - hpy) ** 2
            k = int(np.argmin(d))
            cv2.line(m8, (int(round(hpx)), int(round(hpy))), (int(ox[k]), int(oy[k])), 0, 2)
        mask = largest_cc(m8.astype(bool))
    return mask


def mask_to_polygon(mask):
    cnts, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cnts:
        return None
    c = max(cnts, key=cv2.contourArea)[:, 0, :]
    return c


def polygon_is_rect(poly):
    if poly is None or len(poly) < 3:
        return True
    xs, ys = poly[:, 0], poly[:, 1]
    return len(np.unique(xs)) <= 2 and len(np.unique(ys)) <= 2


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main():
    args = parse_args()
    torch.set_grad_enabled(False)
    device = "cpu"

    image = load_rgb(args.rgb_path)
    H, W = image.shape[:2]
    df = pd.read_csv(args.csv_path)
    n = len(df)

    sam = sam_model_registry["vit_t"](checkpoint=args.weights_path)
    sam.to(device=device)
    sam.eval()
    predictor = SamPredictor(sam)
    predictor.set_image(image)

    logits_all = np.full((n, H, W), -np.inf, dtype=np.float32)
    priors = []
    boxes = []

    for i in tqdm(range(n), desc="MobileSAM"):
        row = df.iloc[i]
        xs = np.asarray(parse_coords(row.get("coords_x", "")), dtype=np.float64)
        ys = np.asarray(parse_coords(row.get("coords_y", "")), dtype=np.float64)
        if len(xs) != len(ys):
            m_ = min(len(xs), len(ys))
            xs, ys = xs[:m_], ys[:m_]
        if len(xs) >= 2:
            bx0, bx1, by0, by1 = xs.min(), xs.max(), ys.min(), ys.max()
        else:
            bx0, by0, bx1, by1 = row["xmin"], row["ymin"], row["xmax"], row["ymax"]
        box = clip_box(bx0, by0, bx1, by1, W, H)
        boxes.append(box)
        rect = (str(row.get("type", "")).lower() == "rectangle") or len(xs) < 3 or is_rectangle(xs, ys)
        prior = prior_mask(xs, ys, box, rect, (H, W))
        priors.append(prior)

        x0, y0, x1, y1 = box
        bw, bh = x1 - x0 + 1, y1 - y0 + 1
        # Positive point at centroid of the prior (inside the cell).
        mom = cv2.moments(prior.astype(np.uint8), binaryImage=True)
        if mom["m00"] > 0:
            cx, cy = mom["m10"] / mom["m00"], mom["m01"] / mom["m00"]
        else:
            cx, cy = (x0 + x1) / 2, (y0 + y1) / 2

        masks, scores, _ = predictor.predict(
            point_coords=np.array([[cx, cy]], dtype=np.float32),
            point_labels=np.array([1]),
            box=np.array([x0, y0, x1, y1], dtype=np.float32),
            multimask_output=True,
            return_logits=True,
        )
        # Restrict to a slightly enlarged box so masks cannot leak far away.
        mx, my = int(round(0.15 * bw)) + 2, int(round(0.15 * bh)) + 2
        allow = np.zeros((H, W), bool)
        allow[max(0, y0 - my):min(H, y1 + my + 1), max(0, x0 - mx):min(W, x1 + mx + 1)] = True
        box_area = float(bw * bh)

        best, best_score = None, -np.inf
        for k in range(masks.shape[0]):
            lg = masks[k]
            m = (lg > 0) & allow
            area = m.sum()
            if area < 3:
                continue
            inter = (m & prior).sum()
            iou = inter / float((m | prior).sum())
            frac = area / box_area
            s = float(scores[k]) + iou
            if frac > 0.97 or frac < 0.05:  # degenerate (box-filling or tiny)
                s -= 1.0
            if s > best_score:
                best, best_score = k, s
        if best is None:
            # SAM failed: fall back on the prior shape (ellipse / polygon).
            lg = np.where(prior, 1.0, -1.0).astype(np.float32)
        else:
            lg = masks[best].astype(np.float32)
            m = largest_cc((lg > 0) & allow)
            m = fill_holes(m)
            lg = np.where(m, np.maximum(lg, 1e-3), -np.inf).astype(np.float32)
        logits_all[i] = lg

    # ---- Resolve overlaps: each pixel goes to the cell with the highest logit.
    fg = np.isfinite(logits_all) & (logits_all > 0)
    masked = np.where(fg, logits_all, -np.inf)
    owner = np.argmax(masked, axis=0)
    owner[~fg.any(axis=0)] = -1
    del masked

    label = np.full((H, W), -1, np.int32)
    order = np.argsort([-(owner == i).sum() for i in range(n)])  # big first
    final_masks = [None] * n
    for i in range(n):
        m = largest_cc(owner == i) if (owner == i).any() else np.zeros((H, W), bool)
        final_masks[i] = m

    # Cells that lost everything get their prior restricted to free pixels.
    claimed = np.zeros((H, W), bool)
    for i in range(n):
        claimed |= final_masks[i]
    for i in range(n):
        if final_masks[i].sum() < 3:
            free = priors[i] & ~claimed
            if free.sum() < 3:
                # steal the prior's core from whoever owns it
                core = cv2.erode(priors[i].astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool)
                if core.sum() < 3:
                    core = priors[i]
                for j in range(n):
                    if j != i:
                        final_masks[j] = final_masks[j] & ~core
                free = core
            final_masks[i] = largest_cc(free)
            claimed |= final_masks[i]

    # Re-ensure single components after any stealing, and remove holes that are
    # occupied by other cells so each outline polygon covers only its own cell.
    for i in order:
        m = largest_cc(final_masks[i]) if final_masks[i].any() else final_masks[i]
        others = (label >= 0) & (label != i)
        m = m & ~others
        m = largest_cc(m) if m.any() else m
        filled = fill_holes(m)
        hole_free = filled & ~m & ~others
        m = m | hole_free  # fill unclaimed holes
        if (filled & ~m).any():  # holes containing other cells -> cut a channel
            m = remove_holes_by_cutting(m)
        label[(label == i)] = -1
        label[m] = i
        final_masks[i] = m

    # ---- Convert to polygons and verify exclusivity by rasterisation.
    occupied = np.zeros((H, W), bool)
    polys = [None] * n
    for i in order:
        m = final_masks[i] & ~occupied
        m = largest_cc(m) if m.any() else m
        poly = mask_to_polygon(m) if m.sum() >= 3 else None
        if poly is not None:
            r = np.zeros((H, W), np.uint8)
            cv2.fillPoly(r, [poly.astype(np.int32)], 1)
            r = r.astype(bool)
            if (r & occupied).any():  # rasterised polygon spills over: shrink
                m2 = largest_cc(m & ~cv2.dilate(occupied.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool))
                poly = mask_to_polygon(m2) if m2.sum() >= 3 else None
                if poly is not None:
                    r = np.zeros((H, W), np.uint8)
                    cv2.fillPoly(r, [poly.astype(np.int32)], 1)
                    r = r.astype(bool)
        if poly is None or polygon_is_rect(poly) or len(poly) < 4:
            # Guarantee a non-rectangular polyline: tiny diamond/octagon at the
            # centre of the remaining free area (or of the box).
            x0, y0, x1, y1 = boxes[i]
            free = priors[i] & ~occupied
            if free.any():
                yy, xx = np.nonzero(free)
                cx, cy = int(np.median(xx)), int(np.median(yy))
            else:
                cx, cy = (x0 + x1) // 2, (y0 + y1) // 2
            rad = max(1, min(x1 - x0, y1 - y0) // 4)
            em = np.zeros((H, W), np.uint8)
            cv2.ellipse(em, (cx, cy), (rad, rad), 0, 0, 360, 1, -1)
            em = largest_cc(em.astype(bool) & ~occupied) if (em.astype(bool) & ~occupied).any() else em.astype(bool)
            poly = mask_to_polygon(em)
            if poly is None or len(poly) < 3:
                poly = np.array([[cx, cy - 1], [cx + 1, cy], [cx, cy + 1], [cx - 1, cy]])
            r = np.zeros((H, W), np.uint8)
            cv2.fillPoly(r, [poly.astype(np.int32)], 1)
            r = r.astype(bool)
        occupied |= r
        polys[i] = poly

    # ---- Write output CSV.
    out = df.copy()
    for col in ["xmin", "ymin", "xmax", "ymax"]:
        if col not in out.columns:
            out[col] = 0
    cx_list, cy_list = [], []
    for i in range(n):
        p = polys[i].astype(int)
        p = np.vstack([p, p[:1]])  # close the polyline (same as input format)
        cx_list.append(",".join(str(v) for v in p[:, 0]))
        cy_list.append(",".join(str(v) for v in p[:, 1]))
        out.at[out.index[i], "xmin"] = int(p[:, 0].min())
        out.at[out.index[i], "xmax"] = int(p[:, 0].max())
        out.at[out.index[i], "ymin"] = int(p[:, 1].min())
        out.at[out.index[i], "ymax"] = int(p[:, 1].max())
    out["coords_x"] = cx_list
    out["coords_y"] = cy_list
    # Keep an unnamed leading index column unnamed, as in the input file.
    out.columns = ["" if str(c).startswith("Unnamed: ") else c for c in out.columns]

    if args.output_path.lower().endswith(".csv"):
        out_file = args.output_path
        d = os.path.dirname(out_file)
        if d:
            os.makedirs(d, exist_ok=True)
    else:
        os.makedirs(args.output_path, exist_ok=True)
        out_file = os.path.join(args.output_path, os.path.basename(args.csv_path))
    out.to_csv(out_file, index=False)
    print("Saved %d refined masks to %s" % (n, out_file))


if __name__ == "__main__":
    main()
