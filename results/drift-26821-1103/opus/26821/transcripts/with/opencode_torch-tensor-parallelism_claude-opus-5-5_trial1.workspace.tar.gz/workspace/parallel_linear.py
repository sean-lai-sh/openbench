"""Tensor-parallel linear layers (Megatron-style).

Weight layout follows torch.nn.Linear: weight has shape (out_features, in_features)
and y = x @ W^T + b.

ColumnParallelLinear: the linear map's output dimension (columns of W^T) is split
across ranks. Each rank computes a slice of the output, and the slices are
all-gathered along the last dimension.

RowParallelLinear: the linear map's input dimension (rows of W^T) is split across
ranks. Each rank computes a partial result from its input slice; the partial
results are summed with all-reduce, then the full bias is added.
"""

import torch
import torch.distributed as dist
import torch.nn.functional as F


def _world_size():
    if dist.is_available() and dist.is_initialized():
        return dist.get_world_size()
    return 1


def _rank():
    if dist.is_available() and dist.is_initialized():
        return dist.get_rank()
    return 0


def _all_reduce(x):
    if _world_size() == 1:
        return x
    x = x.contiguous()
    dist.all_reduce(x, op=dist.ReduceOp.SUM)
    return x


def _split_last(x):
    ws = _world_size()
    if ws == 1:
        return x
    size = x.size(-1) // ws
    r = _rank()
    return x[..., r * size:(r + 1) * size].contiguous()


def _gather_last(x):
    ws = _world_size()
    if ws == 1:
        return x
    x = x.contiguous()
    parts = [torch.empty_like(x) for _ in range(ws)]
    dist.all_gather(parts, x)
    return torch.cat(parts, dim=-1).contiguous()


class _CopyToParallelRegion(torch.autograd.Function):
    """Identity in forward, all-reduce of gradient in backward."""

    @staticmethod
    def forward(ctx, x):
        return x

    @staticmethod
    def backward(ctx, grad):
        return _all_reduce(grad.clone())


class _ReduceFromParallelRegion(torch.autograd.Function):
    """All-reduce in forward, identity in backward."""

    @staticmethod
    def forward(ctx, x):
        return _all_reduce(x.clone())

    @staticmethod
    def backward(ctx, grad):
        return grad


class _ScatterToParallelRegion(torch.autograd.Function):
    """Split along last dim in forward, all-gather in backward."""

    @staticmethod
    def forward(ctx, x):
        return _split_last(x)

    @staticmethod
    def backward(ctx, grad):
        return _gather_last(grad)


class _GatherFromParallelRegion(torch.autograd.Function):
    """All-gather along last dim in forward, split in backward."""

    @staticmethod
    def forward(ctx, x):
        return _gather_last(x)

    @staticmethod
    def backward(ctx, grad):
        return _split_last(grad)


def _divide(n, d):
    assert n % d == 0, f"{n} is not divisible by world_size {d}"
    return n // d


class ColumnParallelLinear(torch.nn.Module):
    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.world_size = _world_size()
        self.rank = _rank()
        self.out_features_per_partition = _divide(out_features, self.world_size)

        assert tuple(master_weight.shape) == (out_features, in_features), (
            f"master_weight must have shape ({out_features}, {in_features}), "
            f"got {tuple(master_weight.shape)}"
        )
        start = self.rank * self.out_features_per_partition
        end = start + self.out_features_per_partition
        with torch.no_grad():
            shard = master_weight.detach()[start:end, :].clone().contiguous()
        self.weight = torch.nn.Parameter(shard)

        if bias:
            self.bias = torch.nn.Parameter(
                torch.zeros(
                    self.out_features_per_partition,
                    dtype=master_weight.dtype,
                    device=master_weight.device,
                )
            )
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        x = _CopyToParallelRegion.apply(x)
        local_out = F.linear(x, self.weight, self.bias)
        return _GatherFromParallelRegion.apply(local_out)


class RowParallelLinear(torch.nn.Module):
    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.world_size = _world_size()
        self.rank = _rank()
        self.in_features_per_partition = _divide(in_features, self.world_size)

        assert tuple(master_weight.shape) == (out_features, in_features), (
            f"master_weight must have shape ({out_features}, {in_features}), "
            f"got {tuple(master_weight.shape)}"
        )
        start = self.rank * self.in_features_per_partition
        end = start + self.in_features_per_partition
        with torch.no_grad():
            shard = master_weight.detach()[:, start:end].clone().contiguous()
        self.weight = torch.nn.Parameter(shard)

        if bias:
            self.bias = torch.nn.Parameter(
                torch.zeros(
                    out_features,
                    dtype=master_weight.dtype,
                    device=master_weight.device,
                )
            )
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        # Accept either the full input (split it here) or an already-partitioned input.
        if self.world_size > 1 and x.size(-1) == self.in_features:
            x = _ScatterToParallelRegion.apply(x)
        partial = F.linear(x, self.weight)
        out = _ReduceFromParallelRegion.apply(partial)
        if self.bias is not None:
            out = out + self.bias
        return out
