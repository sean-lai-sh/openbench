#!/usr/bin/env python
"""Refine cell annotations (rectangles + polylines) into polylines with MobileSAM.

For every row of the metadata csv, the annotation's bounding box is used as a
box prompt for MobileSAM. The predicted masks are then post-processed so that:
  * every cell gets exactly one contiguous (4-connected, hole-free) mask,
  * no two masks overlap (contested pixels go to the cell with the highest
    SAM logit, and a 1-pixel gap is kept between neighbouring cells),
  * no mask is an axis-aligned rectangle.
The masks are converted to closed polylines and written to a csv with the same
layout as the input (only xmin, ymin, xmax, ymax, coords_x, coords_y change).
"""

import argparse
import os

import cv2
import numpy as np
import pandas as pd
import torch
from tqdm import tqdm

from mobile_sam import SamPredictor, sam_model_registry

MIN_AREA = 5  # minimum number of pixels for a valid mask
BATCH_SIZE = 32


# --------------------------------------------------------------------------- #
# I/O helpers
# --------------------------------------------------------------------------- #
def parse_coords(value):
    if isinstance(value, (list, tuple, np.ndarray)):
        return [float(v) for v in value]
    s = str(value).strip().strip("[]()")
    if not s or s.lower() == "nan":
        return []
    return [float(v) for v in s.replace(";", ",").replace(" ", ",").split(",") if v != ""]


def load_image(path):
    img = cv2.imread(path, cv2.IMREAD_COLOR)
    if img is None:
        from PIL import Image

        img = np.array(Image.open(path).convert("RGB"))
        return np.ascontiguousarray(img)
    return np.ascontiguousarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))


def load_model(weights_path, device):
    model = sam_model_registry["vit_t"](checkpoint=None)
    state = torch.load(weights_path, map_location="cpu")
    if isinstance(state, dict) and "model" in state and not any(
        k.startswith("image_encoder") for k in state
    ):
        state = state["model"]
    model.load_state_dict(state)
    model.to(device)
    model.eval()
    return SamPredictor(model)


# --------------------------------------------------------------------------- #
# Mask helpers
# --------------------------------------------------------------------------- #
def largest_component(mask):
    """Largest 4-connected component of a boolean mask."""
    if not mask.any():
        return mask
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask.astype(np.uint8), connectivity=4)
    if n <= 2:
        return lab == 1
    best = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return lab == best


def outer_contour(mask):
    cnts, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cnts:
        return None
    return max(cnts, key=lambda c: (cv2.contourArea(c), len(c)))


def fill_contour(shape, cnt):
    out = np.zeros(shape, np.uint8)
    cv2.drawContours(out, [cnt], -1, 1, thickness=cv2.FILLED)
    return out.astype(bool)


def break_rectangle(mask):
    """If mask exactly fills its bounding box, cut the corners so it is not a rectangle."""
    ys, xs = np.nonzero(mask)
    if len(ys) == 0:
        return mask
    y0, y1, x0, x1 = ys.min(), ys.max(), xs.min(), xs.max()
    if mask[y0:y1 + 1, x0:x1 + 1].all() and (y1 - y0) >= 2 and (x1 - x0) >= 2:
        mask = mask.copy()
        for y, x in ((y0, x0), (y0, x1), (y1, x0), (y1, x1)):
            mask[y, x] = False
    return mask


def clean_mask(mask, forbidden):
    """Make mask a single hole-free 4-connected blob that avoids `forbidden`.

    The returned mask is exactly the rasterisation of its outer contour, so the
    saved polyline reproduces it and does not cover forbidden pixels.
    """
    mask = mask & ~forbidden
    for _ in range(10):
        mask = largest_component(mask)
        if mask.sum() < MIN_AREA:
            return None
        mask = break_rectangle(mask)
        cnt = outer_contour(mask)
        if cnt is None or len(cnt) < 3:
            return None
        filled = fill_contour(mask.shape, cnt)
        if not (filled & forbidden).any():
            # Reject axis-aligned rectangles (only possible for tiny masks).
            ys, xs = np.nonzero(filled)
            if filled[ys.min():ys.max() + 1, xs.min():xs.max() + 1].all():
                return None
            return filled
        mask = filled & ~forbidden
    return None


def fallback_mask(shape, box, forbidden):
    """Ellipse inscribed in the box, or a small diamond in the freest spot."""
    h, w = shape
    x0, y0, x1, y1 = box
    ell = np.zeros(shape, np.uint8)
    cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    ax, ay = max((x1 - x0) / 2.0, 2), max((y1 - y0) / 2.0, 2)
    cv2.ellipse(ell, (int(round(cx)), int(round(cy))), (int(round(ax)), int(round(ay))), 0, 0, 360, 1, -1)
    m = clean_mask(ell.astype(bool), forbidden)
    if m is not None:
        return m
    # diamond at the free pixel furthest from any occupied pixel inside the box
    free = (~forbidden).astype(np.uint8)
    dt = cv2.distanceTransform(free, cv2.DIST_L1, 3)
    bx0, by0 = max(int(x0), 0), max(int(y0), 0)
    bx1, by1 = min(int(x1) + 1, w), min(int(y1) + 1, h)
    sub = dt[by0:by1, bx0:bx1] if (bx1 > bx0 and by1 > by0) else dt
    off = (by0, bx0) if (bx1 > bx0 and by1 > by0) else (0, 0)
    yy, xx = np.unravel_index(int(np.argmax(sub)), sub.shape)
    yy, xx = yy + off[0], xx + off[1]
    r = int(max(1, min(3, dt[yy, xx] - 1)))
    yy = int(np.clip(yy, r, h - 1 - r))
    xx = int(np.clip(xx, r, w - 1 - r))
    pts = np.array([[xx, yy - r], [xx + r, yy], [xx, yy + r], [xx - r, yy]], np.int32)
    d = np.zeros(shape, np.uint8)
    cv2.fillPoly(d, [pts], 1)
    return d.astype(bool)


def mask_to_polyline(mask):
    cnt = outer_contour(mask).reshape(-1, 2)
    xs = [int(v) for v in cnt[:, 0]] + [int(cnt[0, 0])]
    ys = [int(v) for v in cnt[:, 1]] + [int(cnt[0, 1])]
    return xs, ys


# --------------------------------------------------------------------------- #
# Main pipeline
# --------------------------------------------------------------------------- #
def get_boxes(df, h, w):
    boxes, polys = [], []
    for _, row in df.iterrows():
        xs, ys = parse_coords(row.get("coords_x", "")), parse_coords(row.get("coords_y", ""))
        n = min(len(xs), len(ys))
        xs, ys = xs[:n], ys[:n]
        try:
            x0, y0, x1, y1 = float(row["xmin"]), float(row["ymin"]), float(row["xmax"]), float(row["ymax"])
            if any(np.isnan([x0, y0, x1, y1])):
                raise ValueError
        except (KeyError, ValueError, TypeError):
            x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
        if n:
            x0, x1 = min(x0, min(xs)), max(x1, max(xs))
            y0, y1 = min(y0, min(ys)), max(y1, max(ys))
        x0, x1 = float(np.clip(x0, 0, w - 1)), float(np.clip(x1, 0, w - 1))
        y0, y1 = float(np.clip(y0, 0, h - 1)), float(np.clip(y1, 0, h - 1))
        if x1 - x0 < 2:
            x0, x1 = max(0.0, x0 - 1), min(w - 1.0, x1 + 1)
        if y1 - y0 < 2:
            y0, y1 = max(0.0, y0 - 1), min(h - 1.0, y1 + 1)
        boxes.append([x0, y0, x1, y1])
        is_poly = str(row.get("type", "")).lower() != "rectangle" and n >= 3
        if is_poly:
            # polyline is "rectangle-like" if only 2 unique x and 2 unique y values
            if len(set(xs)) <= 2 and len(set(ys)) <= 2:
                is_poly = False
        polys.append(np.stack([xs, ys], 1) if is_poly else None)
    return np.array(boxes, dtype=np.float32), polys


def crop_window(box, h, w, margin):
    x0, y0, x1, y1 = box
    bw, bh = x1 - x0, y1 - y0
    mx, my = max(margin, 0.15 * bw), max(margin, 0.15 * bh)
    cx0, cy0 = int(max(0, np.floor(x0 - mx))), int(max(0, np.floor(y0 - my)))
    cx1, cy1 = int(min(w, np.ceil(x1 + mx) + 1)), int(min(h, np.ceil(y1 + my) + 1))
    return cx0, cy0, cx1, cy1


@torch.no_grad()
def run_sam(predictor, image, boxes, polys, device):
    """Returns, per cell, (window, logits-crop of the selected mask)."""
    h, w = image.shape[:2]
    predictor.set_image(image)
    results = []
    # full-resolution logits are N x 3 x H x W floats: cap memory at ~400MB per batch
    bs = int(max(1, min(BATCH_SIZE, 4e8 // (3 * 4 * h * w))))
    for start in tqdm(range(0, len(boxes), bs), desc="MobileSAM"):
        b = torch.as_tensor(boxes[start:start + bs], device=device)
        tb = predictor.transform.apply_boxes_torch(b, (h, w))
        logits, scores, _ = predictor.predict_torch(
            point_coords=None, point_labels=None, boxes=tb,
            multimask_output=True, return_logits=True,
        )
        logits = logits.cpu().numpy()
        scores = scores.cpu().numpy()
        for j in range(logits.shape[0]):
            i = start + j
            win = crop_window(boxes[i], h, w, margin=4)
            cx0, cy0, cx1, cy1 = win
            cand = logits[j, :, cy0:cy1, cx0:cx1]
            # box region inside the window (with a small tolerance)
            x0, y0, x1, y1 = boxes[i]
            bmask = np.zeros(cand.shape[1:], bool)
            tol = 2
            bmask[max(0, int(y0) - cy0 - tol):int(y1) - cy0 + tol + 1,
                  max(0, int(x0) - cx0 - tol):int(x1) - cx0 + tol + 1] = True
            box_area = max(1.0, (x1 - x0 + 1) * (y1 - y0 + 1))
            ref = None
            if polys[i] is not None:
                ref = np.zeros(cand.shape[1:], np.uint8)
                pts = np.round(polys[i] - [cx0, cy0]).astype(np.int32)
                cv2.fillPoly(ref, [pts], 1)
                ref = ref.astype(bool)
            best, best_val = 0, -np.inf
            for k in range(cand.shape[0]):
                m = (cand[k] > 0) & bmask
                area = m.sum()
                if area < MIN_AREA:
                    continue
                if ref is not None and ref.any():
                    inter = (m & ref).sum()
                    val = inter / float((m | ref).sum()) + 0.1 * scores[j, k]
                else:
                    frac = area / box_area
                    # prefer confident masks that fill a reasonable part of the box
                    val = scores[j, k] - (0.5 if frac > 0.97 else 0.0) - (0.5 if frac < 0.15 else 0.0)
                if val > best_val:
                    best, best_val = k, val
            lg = cand[best].copy()
            lg[~bmask] = -np.inf
            results.append((win, lg, float(scores[j, best])))
    return results


def resolve(results, boxes, shape):
    h, w = shape
    n = len(results)
    # 1) contested pixels -> highest logit (argmax over cells)
    best_logit = np.full(shape, -np.inf, np.float32)
    owner = np.full(shape, -1, np.int32)
    for i, (win, lg, _) in enumerate(results):
        cx0, cy0, cx1, cy1 = win
        sub_b, sub_o = best_logit[cy0:cy1, cx0:cx1], owner[cy0:cy1, cx0:cx1]
        upd = (lg > 0) & (lg > sub_b)
        sub_b[upd] = lg[upd]
        sub_o[upd] = i

    # 2) sequential cleanup guaranteeing contiguity + no overlap (with 1px gap)
    occupied = np.zeros(shape, bool)
    kernel = np.ones((3, 3), np.uint8)
    masks = [None] * n
    order = sorted(range(n), key=lambda i: -results[i][2])
    for i in order:
        win, lg, _ = results[i]
        cx0, cy0, cx1, cy1 = win
        own = owner[cy0:cy1, cx0:cx1] == i
        # pad window by 1 so the dilation of neighbours just outside is respected
        px0, py0 = max(0, cx0 - 1), max(0, cy0 - 1)
        px1, py1 = min(w, cx1 + 1), min(h, cy1 + 1)
        occ = occupied[py0:py1, px0:px1]
        forb = cv2.dilate(occ.astype(np.uint8), kernel).astype(bool)
        forb = forb[cy0 - py0:cy0 - py0 + (cy1 - cy0), cx0 - px0:cx0 - px0 + (cx1 - cx0)]
        m = clean_mask(own, forb)
        if m is None:
            # fall back to SAM's own (uncontested) prediction
            m = clean_mask(lg > 0, forb)
        full = None
        if m is not None:
            full = np.zeros(shape, bool)
            full[cy0:cy1, cx0:cx1] = m
        else:
            forb_full = cv2.dilate(occupied.astype(np.uint8), kernel).astype(bool)
            full = fallback_mask(shape, boxes[i], forb_full)
            # remove the fallback's pixels (+gap) from anyone it might touch
            if (full & forb_full).any():
                grow = cv2.dilate(full.astype(np.uint8), kernel).astype(bool)
                for j in range(n):
                    if masks[j] is not None and (masks[j] & grow).any():
                        occupied &= ~masks[j]
                        fixed = clean_mask(masks[j], grow)
                        if fixed is None:
                            fixed = masks[j] & ~grow
                        masks[j] = fixed
                        occupied |= fixed
        masks[i] = full
        occupied |= full
    return masks


def resolve_output_file(output_path, csv_path):
    if output_path.lower().endswith(".csv"):
        parent = os.path.dirname(os.path.abspath(output_path))
        os.makedirs(parent, exist_ok=True)
        return output_path
    os.makedirs(output_path, exist_ok=True)
    return os.path.join(output_path, os.path.basename(csv_path))


def main():
    parser = argparse.ArgumentParser(description="Convert rectangle/polyline cell masks to polylines with MobileSAM.")
    parser.add_argument("weights_path", type=str, help="Path to MobileSAM weights (mobile_sam.pt)")
    parser.add_argument("output_path", type=str, help="Output folder (or .csv file) for the refined masks")
    parser.add_argument("rgb_path", type=str, help="Path to the RGB image")
    parser.add_argument("csv_path", type=str, help="Path to the metadata csv")
    args = parser.parse_args()

    device = "cpu"
    torch.set_grad_enabled(False)

    # keep the original index column (if any) so the output matches the input layout
    raw = pd.read_csv(args.csv_path)
    has_index = raw.columns[0].startswith("Unnamed") or raw.columns[0] == ""
    df = pd.read_csv(args.csv_path, index_col=0) if has_index else raw

    image = load_image(args.rgb_path)
    h, w = image.shape[:2]
    out_file = resolve_output_file(args.output_path, args.csv_path)

    if len(df) == 0:
        df.to_csv(out_file, index=has_index)
        return

    boxes, polys = get_boxes(df, h, w)
    predictor = load_model(args.weights_path, device)
    results = run_sam(predictor, image, boxes, polys, device)
    masks = resolve(results, boxes, (h, w))

    xmins, ymins, xmaxs, ymaxs, cxs, cys = [], [], [], [], [], []
    for m in masks:
        xs, ys = mask_to_polyline(m)
        xmins.append(min(xs)); xmaxs.append(max(xs))
        ymins.append(min(ys)); ymaxs.append(max(ys))
        cxs.append(",".join(map(str, xs)))
        cys.append(",".join(map(str, ys)))

    df = df.copy()
    df["xmin"], df["ymin"], df["xmax"], df["ymax"] = xmins, ymins, xmaxs, ymaxs
    df["coords_x"], df["coords_y"] = cxs, cys
    df.to_csv(out_file, index=has_index)
    print(f"Saved {len(df)} refined masks to {out_file}")


if __name__ == "__main__":
    main()
