"""Pipeline-parallel training step (AFAB schedule) for HuggingFace LlamaForCausalLM."""

import torch
import torch.distributed as dist
import torch.nn.functional as F

try:
    from transformers.masking_utils import create_causal_mask
except ImportError:  # pragma: no cover - older transformers
    create_causal_mask = None


def _partition_layers(num_layers, world_size, rank):
    """Return [start, end) layer indices for this rank, balanced (sizes differ by <= 1)."""
    base, rem = divmod(num_layers, world_size)
    start = rank * base + min(rank, rem)
    end = start + base + (1 if rank < rem else 0)
    return start, end


def _send(tensor, peer):
    ops = [dist.P2POp(dist.isend, tensor.contiguous(), peer)]
    for req in dist.batch_isend_irecv(ops):
        req.wait()


def _recv(shape, peer, device, dtype):
    buf = torch.empty(shape, device=device, dtype=dtype)
    ops = [dist.P2POp(dist.irecv, buf, peer)]
    for req in dist.batch_isend_irecv(ops):
        req.wait()
    return buf


def _causal_mask(config, hidden_states, position_ids):
    if create_causal_mask is None:
        return None
    try:
        return create_causal_mask(
            config=config,
            inputs_embeds=hidden_states,
            attention_mask=None,
            past_key_values=None,
            position_ids=position_ids,
        )
    except TypeError:
        # Older signature requiring cache_position.
        cache_position = torch.arange(hidden_states.shape[1], device=hidden_states.device)
        return create_causal_mask(
            config=config,
            input_embeds=hidden_states,
            attention_mask=None,
            cache_position=cache_position,
            past_key_values=None,
            position_ids=position_ids,
        )


def train_step_pipeline_afab(model, inputs, targets, device, dtype):
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    is_first = rank == 0
    is_last = rank == world_size - 1

    llama = model.model
    config = model.config
    layers = llama.layers
    num_layers = min(len(layers), config.num_hidden_layers)
    start, end = _partition_layers(num_layers, world_size, rank)
    local_layers = [layers[i] for i in range(start, end)]

    num_mb = len(inputs)
    hidden_size = config.hidden_size

    stage_inputs = []   # tensors received from previous stage (need grad), None on rank 0
    stage_outputs = []  # outputs sent to next stage, or losses on last rank
    total_loss = torch.zeros((), device=device, dtype=torch.float32)

    # ---------------- All forward ----------------
    for mb in range(num_mb):
        input_ids = inputs[mb].to(device)
        batch, seq_len = input_ids.shape[0], input_ids.shape[1]
        shape = (batch, seq_len, hidden_size)

        if is_first:
            hidden = llama.embed_tokens(input_ids).to(device=device, dtype=dtype)
            stage_inputs.append(None)
        else:
            hidden = _recv(shape, rank - 1, device, dtype)
            hidden.requires_grad_(True)
            stage_inputs.append(hidden)

        position_ids = torch.arange(seq_len, device=device).unsqueeze(0)
        position_embeddings = llama.rotary_emb(hidden, position_ids=position_ids)
        mask = _causal_mask(config, hidden, position_ids)

        h = hidden
        for layer in local_layers:
            h = layer(
                h,
                attention_mask=mask,
                position_ids=position_ids,
                position_embeddings=position_embeddings,
                past_key_values=None,
                use_cache=False,
            )
            if isinstance(h, tuple):
                h = h[0]

        if is_last:
            h = llama.norm(h)
            logits = model.lm_head(h)
            tgt = targets[mb].to(device)
            loss = F.cross_entropy(
                logits.reshape(-1, logits.size(-1)).float(), tgt.reshape(-1)
            ) / num_mb
            total_loss = total_loss + loss.detach()
            stage_outputs.append(loss)
        else:
            h = h.to(device=device, dtype=dtype)
            _send(h.detach(), rank + 1)
            stage_outputs.append(h)

    # ---------------- All backward ----------------
    for mb in range(num_mb):
        out = stage_outputs[mb]
        if is_last:
            out.backward()
        else:
            grad = _recv(out.shape, rank + 1, device, dtype)
            out.backward(grad)

        if not is_first:
            inp = stage_inputs[mb]
            g = inp.grad
            if g is None:
                g = torch.zeros_like(inp)
            _send(g.to(device=device, dtype=dtype), rank - 1)

        stage_inputs[mb] = None
        stage_outputs[mb] = None

    return total_loss if is_last else None
