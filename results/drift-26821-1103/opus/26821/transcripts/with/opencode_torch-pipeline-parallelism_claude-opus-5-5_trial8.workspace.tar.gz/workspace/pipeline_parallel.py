"""Pipeline-parallel (AFAB) training step for HuggingFace LlamaForCausalLM."""

import torch
import torch.distributed as dist
import torch.nn.functional as F


# ----------------------------------------------------------------------------
# Partitioning
# ----------------------------------------------------------------------------
def _partition_layers(num_layers, world_size, rank):
    """Return (start, end) layer indices for `rank`, splitting as evenly as possible."""
    base, rem = divmod(num_layers, world_size)
    start = rank * base + min(rank, rem)
    end = start + base + (1 if rank < rem else 0)
    return start, end


# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------
def _causal_mask(model, hidden_states, position_ids):
    """Build the attention mask the same way LlamaModel.forward does."""
    config = model.config
    try:
        from transformers.masking_utils import create_causal_mask

        try:
            return create_causal_mask(
                config=config,
                inputs_embeds=hidden_states,
                attention_mask=None,
                past_key_values=None,
                position_ids=position_ids,
            )
        except TypeError:
            # Older transformers signature.
            cache_position = torch.arange(hidden_states.shape[1], device=hidden_states.device)
            return create_causal_mask(
                config=config,
                input_embeds=hidden_states,
                attention_mask=None,
                cache_position=cache_position,
                past_key_values=None,
                position_ids=position_ids,
            )
    except Exception:
        # Fallback: explicit additive 4D causal mask (works for eager / sdpa).
        bsz, seq_len = hidden_states.shape[:2]
        min_val = torch.finfo(hidden_states.dtype).min
        mask = torch.full(
            (seq_len, seq_len), min_val, device=hidden_states.device, dtype=hidden_states.dtype
        )
        mask = torch.triu(mask, diagonal=1)
        return mask[None, None, :, :].expand(bsz, 1, seq_len, seq_len)


def _p2p(ops):
    if not ops:
        return
    reqs = dist.batch_isend_irecv(ops)
    for r in reqs:
        r.wait()


def _send(tensor, peer):
    _p2p([dist.P2POp(dist.isend, tensor.contiguous(), peer)])


def _recv(shape, peer, device, dtype):
    buf = torch.empty(shape, device=device, dtype=dtype)
    _p2p([dist.P2POp(dist.irecv, buf, peer)])
    return buf


def _hidden_shape(inp, tgt, hidden_size):
    """Hidden-state shape [microbatch, seq_len, hidden_size] for a microbatch."""
    ref = inp if inp is not None else tgt
    return tuple(ref.shape[:2]) + (hidden_size,)


# ----------------------------------------------------------------------------
# Training step
# ----------------------------------------------------------------------------
def train_step_pipeline_afab(model, inputs, targets, device, dtype):
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    is_first = rank == 0
    is_last = rank == world_size - 1

    base = model.model
    config = model.config
    hidden_size = config.hidden_size
    num_layers = len(base.layers)
    start, end = _partition_layers(num_layers, world_size, rank)
    my_layers = [base.layers[i] for i in range(start, end)]

    num_mb = len(inputs)

    stage_inputs = []   # received activations (requires grad) per microbatch
    stage_outputs = []  # outputs (hidden states or loss) per microbatch
    total_loss = torch.zeros((), device=device, dtype=torch.float32)

    # ------------------------------------------------------------------
    # All forward
    # ------------------------------------------------------------------
    for mb in range(num_mb):
        inp = inputs[mb] if inputs is not None else None
        tgt = targets[mb] if targets is not None else None

        if is_first:
            input_ids = inp.to(device)
            hidden = base.embed_tokens(input_ids).to(dtype)
            stage_in = None
        else:
            shape = _hidden_shape(inp, tgt, hidden_size)
            hidden = _recv(shape, rank - 1, device, dtype)
            hidden.requires_grad_(True)
            stage_in = hidden

        seq_len = hidden.shape[1]
        position_ids = torch.arange(seq_len, device=device).unsqueeze(0)
        position_embeddings = base.rotary_emb(hidden, position_ids=position_ids)
        attn_mask = _causal_mask(model, hidden, position_ids)

        for layer in my_layers:
            out = layer(
                hidden,
                attention_mask=attn_mask,
                position_ids=position_ids,
                position_embeddings=position_embeddings,
            )
            hidden = out[0] if isinstance(out, (tuple, list)) else out

        if is_last:
            hidden = base.norm(hidden)
            logits = model.lm_head(hidden)
            tgt = tgt.to(device)
            loss = F.cross_entropy(
                logits.reshape(-1, logits.shape[-1]).float(), tgt.reshape(-1)
            ) / num_mb
            total_loss = total_loss + loss.detach()
            stage_outputs.append(loss)
        else:
            hidden = hidden.to(dtype)
            _send(hidden.detach(), rank + 1)
            stage_outputs.append(hidden)

        stage_inputs.append(stage_in)

    # ------------------------------------------------------------------
    # All backward
    # ------------------------------------------------------------------
    for mb in range(num_mb):
        out = stage_outputs[mb]
        if is_last:
            torch.autograd.backward(out)
        else:
            grad = _recv(out.shape, rank + 1, device, dtype)
            torch.autograd.backward(out, grad_tensors=grad)

        if not is_first:
            stage_in = stage_inputs[mb]
            grad_in = stage_in.grad
            if grad_in is None:
                grad_in = torch.zeros_like(stage_in)
            _send(grad_in.to(device=device, dtype=dtype), rank - 1)

        # Free memory for this microbatch.
        stage_outputs[mb] = None
        stage_inputs[mb] = None

    return total_loss if is_last else None
