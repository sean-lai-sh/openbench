"""Pipeline-parallel training step (AFAB schedule) for LlamaForCausalLM."""

import inspect

import torch
import torch.distributed as dist
import torch.nn.functional as F


# --------------------------------------------------------------------------- #
# Partitioning
# --------------------------------------------------------------------------- #
def _partition_layers(num_layers, rank, world_size):
    """Return [start, end) layer indices for `rank` (balanced split)."""
    base, extra = divmod(num_layers, world_size)
    start = rank * base + min(rank, extra)
    end = start + base + (1 if rank < extra else 0)
    return start, end


# --------------------------------------------------------------------------- #
# Communication helpers
# --------------------------------------------------------------------------- #
def _send(tensor, dst):
    ops = [dist.P2POp(dist.isend, tensor.contiguous(), dst)]
    for req in dist.batch_isend_irecv(ops):
        req.wait()


def _recv(shape, src, device, dtype):
    buf = torch.empty(shape, device=device, dtype=dtype)
    ops = [dist.P2POp(dist.irecv, buf, src)]
    for req in dist.batch_isend_irecv(ops):
        req.wait()
    return buf


# --------------------------------------------------------------------------- #
# Model helpers (robust across transformers versions)
# --------------------------------------------------------------------------- #
def _filter_kwargs(fn, kwargs):
    try:
        params = inspect.signature(fn).parameters
    except (TypeError, ValueError):
        return kwargs
    if any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values()):
        return kwargs
    return {k: v for k, v in kwargs.items() if k in params}


def _causal_mask(base, hidden, position_ids, cache_position):
    """Build the causal mask exactly as the HF model would (may be None)."""
    try:
        from transformers.masking_utils import create_causal_mask

        kwargs = dict(
            config=base.config,
            inputs_embeds=hidden,
            input_embeds=hidden,
            attention_mask=None,
            cache_position=cache_position,
            past_key_values=None,
            position_ids=position_ids,
        )
        return create_causal_mask(**_filter_kwargs(create_causal_mask, kwargs))
    except Exception:
        pass

    if hasattr(base, "_update_causal_mask"):
        try:
            kwargs = dict(
                attention_mask=None,
                input_tensor=hidden,
                cache_position=cache_position,
                past_key_values=None,
                output_attentions=False,
            )
            return base._update_causal_mask(**_filter_kwargs(base._update_causal_mask, kwargs))
        except Exception:
            pass

    # Fallback: explicit additive 4D causal mask.
    seq_len = hidden.shape[1]
    mask = torch.full((seq_len, seq_len), torch.finfo(hidden.dtype).min,
                      device=hidden.device, dtype=hidden.dtype)
    mask = torch.triu(mask, diagonal=1)
    return mask[None, None, :, :].expand(hidden.shape[0], 1, seq_len, seq_len)


def _run_layers(base, layers, hidden):
    """Run a contiguous slice of decoder layers on `hidden`."""
    seq_len = hidden.shape[1]
    cache_position = torch.arange(seq_len, device=hidden.device)
    position_ids = cache_position.unsqueeze(0)

    if len(layers) == 0:
        return hidden

    attention_mask = _causal_mask(base, hidden, position_ids, cache_position)

    position_embeddings = None
    if getattr(base, "rotary_emb", None) is not None:
        position_embeddings = base.rotary_emb(hidden, position_ids)

    kwargs = dict(
        attention_mask=attention_mask,
        position_ids=position_ids,
        past_key_values=None,
        past_key_value=None,
        use_cache=False,
        output_attentions=False,
        cache_position=cache_position,
    )
    if position_embeddings is not None:
        kwargs["position_embeddings"] = position_embeddings
    kwargs = _filter_kwargs(layers[0].forward, kwargs)

    for layer in layers:
        out = layer(hidden, **kwargs)
        hidden = out[0] if isinstance(out, (tuple, list)) else out
    return hidden


# --------------------------------------------------------------------------- #
# Training step
# --------------------------------------------------------------------------- #
def train_step_pipeline_afab(model, inputs, targets, device, dtype):
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    is_first = rank == 0
    is_last = rank == world_size - 1
    num_mb = len(inputs)

    base = model.model
    hidden_size = model.config.hidden_size
    all_layers = base.layers
    start, end = _partition_layers(len(all_layers), rank, world_size)
    local_layers = [all_layers[i] for i in range(start, end)]

    stage_inputs = []   # received hidden states (requires grad) per microbatch
    stage_outputs = []  # outputs (or losses on last stage) per microbatch
    total_loss = torch.zeros((), device=device, dtype=torch.float32)

    # ------------------------------ forward ------------------------------ #
    for mb in range(num_mb):
        if is_first:
            input_ids = inputs[mb].to(device)
            hidden = base.embed_tokens(input_ids).to(dtype)
            stage_in = None
        else:
            mb_size, seq_len = inputs[mb].shape[0], inputs[mb].shape[1]
            hidden = _recv((mb_size, seq_len, hidden_size), rank - 1, device, dtype)
            hidden.requires_grad_(True)
            stage_in = hidden

        hidden = _run_layers(base, local_layers, hidden)

        if is_last:
            hidden = base.norm(hidden)
            logits = model.lm_head(hidden)
            tgt = targets[mb].to(device)
            loss = F.cross_entropy(
                logits.reshape(-1, logits.shape[-1]), tgt.reshape(-1)
            ) / num_mb
            total_loss += loss.detach().float()
            stage_outputs.append(loss)
        else:
            out = hidden.to(device=device, dtype=dtype)
            _send(out.detach(), rank + 1)
            stage_outputs.append(out)

        stage_inputs.append(stage_in)

    # ------------------------------ backward ----------------------------- #
    for mb in range(num_mb):
        out = stage_outputs[mb]
        if is_last:
            out.backward()
        else:
            grad = _recv(out.shape, rank + 1, device, dtype)
            torch.autograd.backward(out, grad_tensors=grad)

        if not is_first:
            stage_in = stage_inputs[mb]
            grad_in = stage_in.grad
            if grad_in is None:
                grad_in = torch.zeros_like(stage_in)
            _send(grad_in.to(device=device, dtype=dtype), rank - 1)

        stage_outputs[mb] = None
        stage_inputs[mb] = None

    return total_loss if is_last else None
