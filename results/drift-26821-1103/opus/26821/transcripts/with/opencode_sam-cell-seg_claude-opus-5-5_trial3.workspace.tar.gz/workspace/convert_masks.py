#!/usr/bin/env python
"""Refine cell masks (rectangles and polylines) into polylines using MobileSAM.

Every annotation in the metadata csv is used as a box prompt for MobileSAM.
The resulting masks are post-processed so that:
  * every cell has exactly one contiguous mask (largest connected component),
  * no two masks overlap (pixels are assigned by highest SAM logit and a
    one-pixel gap is enforced between neighbouring cells),
  * every mask is stored as a closed polyline.

Usage:
    python convert_masks.py --weights_path mobile_sam.pt --output_path out/ \
        --rgb_path image.png --csv_path metadata.csv
(positional arguments in the same order are accepted as well)
"""
import argparse
import os

import cv2
import numpy as np
import pandas as pd
import torch
from tqdm import tqdm

from mobile_sam import SamPredictor, sam_model_registry

TILE = 1024  # max tile side fed to MobileSAM (image encoder resizes to 1024)
TILE_OVERLAP = 256
CROP_MARGIN = 32  # margin around each box used to store logits / masks
K3 = np.ones((3, 3), np.uint8)


# --------------------------------------------------------------------------- #
# Argument parsing
# --------------------------------------------------------------------------- #
def parse_args():
    p = argparse.ArgumentParser(description="Convert cell masks to polylines with MobileSAM")
    names = ["weights_path", "output_path", "rgb_path", "csv_path"]
    helps = [
        "Path to MobileSAM weights (mobile_sam.pt)",
        "Output folder (or .csv file path) for refined masks",
        "Path to the RGB image",
        "Path to the metadata csv",
    ]
    for n, h in zip(names, helps):
        p.add_argument(f"pos_{n}", nargs="?", default=None, help=h)
        p.add_argument(f"--{n}", dest=n, default=None, help=h)
    p.add_argument("--device", default=None, help="cpu / cuda (default: auto, cpu if no gpu)")
    a = p.parse_args()
    for n in names:
        if getattr(a, n) is None:
            setattr(a, n, getattr(a, f"pos_{n}"))
        if getattr(a, n) is None:
            p.error(f"argument {n} is required")
    return a


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def parse_coords(s):
    if isinstance(s, (list, tuple, np.ndarray)):
        return [float(v) for v in s]
    s = str(s).strip().strip("[]()")
    return [float(v) for v in s.replace(";", ",").replace(" ", ",").split(",") if v.strip() != ""]


def largest_component(mask):
    mask = mask.astype(np.uint8)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    if n <= 1:
        return np.zeros(mask.shape, bool)
    idx = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return lab == idx


def fill_holes(mask, forbidden=None):
    """Fill holes of a binary mask (optionally only holes not touching `forbidden`)."""
    mask = mask.astype(bool)
    inv = (~mask).astype(np.uint8)
    n, lab = cv2.connectedComponents(inv, connectivity=4)
    if n <= 1:
        return mask
    border = set(np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]])).tolist())
    out = mask.copy()
    for k in range(1, n):
        if k in border:
            continue
        hole = lab == k
        if forbidden is not None and (hole & forbidden).any():
            continue
        out |= hole
    return out


def mask_to_contour(mask):
    cs, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cs:
        return None
    c = max(cs, key=cv2.contourArea)
    return c.reshape(-1, 2)


def poly_raster(pts, shape):
    m = np.zeros(shape, np.uint8)
    cv2.fillPoly(m, [pts.reshape(-1, 1, 2).astype(np.int32)], 1)
    return m.astype(bool)


def make_tiles(h, w):
    def starts(n):
        if n <= TILE:
            return [0]
        step = TILE - TILE_OVERLAP
        s = list(range(0, n - TILE, step)) + [n - TILE]
        return sorted(set(s))

    return [(y, x, min(y + TILE, h), min(x + TILE, w)) for y in starts(h) for x in starts(w)]


def choose_tile(tiles, box):
    x0, y0, x1, y1 = box
    best, best_d = 0, None
    for i, (ty0, tx0, ty1, tx1) in enumerate(tiles):
        # distance of the box from the tile border (larger = more central)
        d = min(x0 - tx0, y0 - ty0, tx1 - x1, ty1 - y1)
        if best_d is None or d > best_d:
            best, best_d = i, d
    return best


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main():
    args = parse_args()
    device = args.device or ("cuda" if torch.cuda.is_available() else "cpu")

    # ---- inputs ----------------------------------------------------------- #
    bgr = cv2.imread(args.rgb_path, cv2.IMREAD_UNCHANGED)
    if bgr is None:
        raise FileNotFoundError(args.rgb_path)
    if bgr.dtype != np.uint8:
        bgr = cv2.normalize(bgr, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    if bgr.ndim == 2:
        bgr = cv2.cvtColor(bgr, cv2.COLOR_GRAY2BGR)
    elif bgr.shape[2] == 4:
        bgr = cv2.cvtColor(bgr, cv2.COLOR_BGRA2BGR)
    image = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
    H, W = image.shape[:2]

    df = pd.read_csv(args.csv_path, index_col=0)
    n = len(df)

    # ---- model ------------------------------------------------------------ #
    sam = sam_model_registry["vit_t"](checkpoint=None)
    state = torch.load(args.weights_path, map_location="cpu")
    if isinstance(state, dict) and "model" in state and not any(k.startswith("image_encoder") for k in state):
        state = state["model"]
    sam.load_state_dict(state)
    sam.to(device).eval()
    predictor = SamPredictor(sam)

    # ---- prompts ---------------------------------------------------------- #
    boxes, orig_masks, is_poly = [], [], []
    for _, r in df.iterrows():
        xs, ys = parse_coords(r["coords_x"]), parse_coords(r["coords_y"])
        if len(xs) >= 3 and len(xs) == len(ys):
            pts = np.stack([xs, ys], 1)
        else:
            pts = np.array([[r["xmin"], r["ymin"]], [r["xmax"], r["ymin"]],
                            [r["xmax"], r["ymax"]], [r["xmin"], r["ymax"]]], float)
        x0 = float(np.clip(min(r["xmin"], pts[:, 0].min()), 0, W - 1))
        x1 = float(np.clip(max(r["xmax"], pts[:, 0].max()), 0, W - 1))
        y0 = float(np.clip(min(r["ymin"], pts[:, 1].min()), 0, H - 1))
        y1 = float(np.clip(max(r["ymax"], pts[:, 1].max()), 0, H - 1))
        if x1 - x0 < 2:
            x0, x1 = max(0.0, x0 - 2), min(W - 1.0, x1 + 2)
        if y1 - y0 < 2:
            y0, y1 = max(0.0, y0 - 2), min(H - 1.0, y1 + 2)
        boxes.append((x0, y0, x1, y1))
        t = str(r.get("type", "")).lower()
        rect_like = "rect" in t or (len(np.unique(pts[:, 0].round())) <= 2 and len(np.unique(pts[:, 1].round())) <= 2)
        is_poly.append(not rect_like)
        if rect_like:
            # fallback shape for a rectangle: inscribed ellipse
            om = np.zeros((H, W), np.uint8)
            c = (int(round((x0 + x1) / 2)), int(round((y0 + y1) / 2)))
            ax = (max(1, int((x1 - x0) / 2)), max(1, int((y1 - y0) / 2)))
            cv2.ellipse(om, c, ax, 0, 0, 360, 1, -1)
            orig_masks.append(om.astype(bool))
        else:
            orig_masks.append(poly_raster(np.round(pts), (H, W)))

    # crop window for every cell (logits are stored only inside it)
    crops = []
    for (x0, y0, x1, y1) in boxes:
        cx0, cy0 = max(0, int(x0) - CROP_MARGIN), max(0, int(y0) - CROP_MARGIN)
        cx1, cy1 = min(W, int(np.ceil(x1)) + CROP_MARGIN + 1), min(H, int(np.ceil(y1)) + CROP_MARGIN + 1)
        crops.append((cy0, cx0, cy1, cx1))

    # ---- MobileSAM inference (tiled for large images) --------------------- #
    tiles = make_tiles(H, W)
    tile_of = [choose_tile([(t[0], t[1], t[2], t[3]) for t in tiles], b) for b in boxes]
    logits = [None] * n  # per-cell logits inside its crop
    with torch.no_grad():
        for ti, (ty0, tx0, ty1, tx1) in enumerate(tqdm(tiles, desc="tiles", disable=len(tiles) == 1)):
            ids = [i for i in range(n) if tile_of[i] == ti]
            if not ids:
                continue
            predictor.set_image(np.ascontiguousarray(image[ty0:ty1, tx0:tx1]))
            for i in tqdm(ids, desc="cells"):
                x0, y0, x1, y1 = boxes[i]
                box = np.array([x0 - tx0, y0 - ty0, x1 - tx0, y1 - ty0], np.float32)
                ms, scores, _ = predictor.predict(box=box, multimask_output=True, return_logits=True)
                cy0, cx0, cy1, cx1 = crops[i]
                # crop coordinates relative to tile (crop may exceed tile: pad with -inf)
                lg_full = np.full((len(ms), cy1 - cy0, cx1 - cx0), -20.0, np.float32)
                sy0, sx0 = max(cy0, ty0), max(cx0, tx0)
                sy1, sx1 = min(cy1, ty1), min(cx1, tx1)
                lg_full[:, sy0 - cy0:sy1 - cy0, sx0 - cx0:sx1 - cx0] = ms[:, sy0 - ty0:sy1 - ty0, sx0 - tx0:sx1 - tx0]

                # choose among the candidate masks
                ref = orig_masks[i][cy0:cy1, cx0:cx1]
                bx = np.zeros_like(ref)
                bx[int(y0) - cy0:int(np.ceil(y1)) - cy0 + 1, int(x0) - cx0:int(np.ceil(x1)) - cx0 + 1] = True
                best, best_val = 0, -1e9
                for k in range(len(ms)):
                    m = lg_full[k] > 0
                    area = m.sum()
                    if area == 0:
                        continue
                    inside = (m & bx).sum() / area  # fraction inside the prompt box
                    iou = (m & ref).sum() / max(1, (m | ref).sum())
                    if is_poly[i]:
                        val = iou + 0.25 * scores[k]
                    else:
                        val = scores[k] + 0.5 * inside + 0.25 * iou
                    if inside < 0.6:
                        val -= 1.0
                    if val > best_val:
                        best, best_val = k, val
                logits[i] = lg_full[best]

    # ---- per-cell clean up ------------------------------------------------ #
    cell = []  # (binary crop, logit crop)
    for i in range(n):
        cy0, cx0, cy1, cx1 = crops[i]
        lg = logits[i]
        m = largest_component(lg > 0)
        if m.sum() > 0:
            opened = cv2.morphologyEx(m.astype(np.uint8), cv2.MORPH_OPEN, K3) > 0
            if opened.any():
                m = largest_component(opened)
            m = fill_holes(m)
        ref = orig_masks[i][cy0:cy1, cx0:cx1]
        # reject degenerate predictions -> fall back to original shape
        if m.sum() < max(10, 0.1 * ref.sum()):
            m = ref.copy()
            lg = np.where(m, np.maximum(lg, 0.5), lg)
        cell.append((m, lg))

    # ---- resolve overlaps: assign each pixel to the highest-logit cell ---- #
    best = np.full((H, W), -np.inf, np.float32)
    label = np.full((H, W), -1, np.int32)
    for i in range(n):
        cy0, cx0, cy1, cx1 = crops[i]
        m, lg = cell[i]
        sub_b, sub_l = best[cy0:cy1, cx0:cx1], label[cy0:cy1, cx0:cx1]
        win = m & (lg > sub_b)
        sub_b[win] = lg[win]
        sub_l[win] = i

    part = []
    for i in range(n):
        cy0, cx0, cy1, cx1 = crops[i]
        part.append(int((label[cy0:cy1, cx0:cx1] == i).sum()))

    # ---- sequential claiming with a 1 px gap between cells ---------------- #
    final = np.full((H, W), -1, np.int32)
    order = sorted(range(n), key=lambda i: part[i])  # small/contested cells first
    contours = [None] * n
    for i in order:
        cy0, cx0, cy1, cx1 = crops[i]
        m_own, _ = cell[i]
        lab_c = label[cy0:cy1, cx0:cx1]
        fin_c = final[cy0:cy1, cx0:cx1]
        claimed = fin_c >= 0
        blocked = cv2.dilate(claimed.astype(np.uint8), K3) > 0
        shape = (cy1 - cy0, cx1 - cx0)

        candidates = [lab_c == i, m_own, orig_masks[i][cy0:cy1, cx0:cx1]]
        region = np.zeros(shape, bool)
        for cand in candidates:
            r = cand & ~blocked
            if r.sum() > 0:
                o = cv2.morphologyEx(r.astype(np.uint8), cv2.MORPH_OPEN, K3) > 0
                if o.sum() >= 0.5 * r.sum():
                    r = o
                r = largest_component(r)
                if r.sum() > 0:
                    region = r
                    break
        if region.sum() == 0:
            # last resort: any free pixel nearest to the box centre
            free = ~blocked
            if not free.any():
                free = ~claimed
            ys, xs = np.nonzero(free)
            x0, y0, x1, y1 = boxes[i]
            ccx, ccy = (x0 + x1) / 2 - cx0, (y0 + y1) / 2 - cy0
            if len(xs):
                j = int(np.argmin((xs - ccx) ** 2 + (ys - ccy) ** 2))
                region[ys[j], xs[j]] = True
            else:
                region[int(np.clip(ccy, 0, shape[0] - 1)), int(np.clip(ccx, 0, shape[1] - 1))] = True

        region = fill_holes(region, forbidden=blocked)

        # make sure the polygon raster does not swallow other cells
        pts = None
        for _ in range(20):
            pts = mask_to_contour(region)
            pr = poly_raster(pts, shape)
            bad = pr & blocked
            if not bad.any():
                region = pr | region
                break
            # cut a channel from an offending pixel to the outside of the region
            ys, xs = np.nonzero(bad)
            y, x = int(ys[0]), int(xs[0])
            reg_u8 = region.astype(np.uint8)
            cv2.line(reg_u8, (x, y), (x, 0), 0, 3)
            region = largest_component(reg_u8 > 0) & ~blocked
            if region.sum() == 0:
                region[y, x] = False
                break
        fin_c[region] = i
        contours[i] = mask_to_contour(fin_c == i)

    # ---- write output ----------------------------------------------------- #
    out = df.copy()
    for col in ["xmin", "xmax", "ymin", "ymax", "coords_x", "coords_y"]:
        if col in out.columns:
            out[col] = out[col].astype(object)
    for row_i, idx in enumerate(df.index):
        cy0, cx0, cy1, cx1 = crops[row_i]
        pts = contours[row_i]
        if pts is None or len(pts) == 0:
            x0, y0, x1, y1 = boxes[row_i]
            pts = np.array([[int((x0 + x1) / 2) - cx0, int((y0 + y1) / 2) - cy0]])
        pts = pts.astype(int) + np.array([cx0, cy0])
        if len(pts) < 3:  # degenerate tiny mask -> make a small triangle/polygon around it
            p = pts[0]
            pts = np.array([p, p + [1, 0], p + [0, 1]])
            pts[:, 0] = np.clip(pts[:, 0], 0, W - 1)
            pts[:, 1] = np.clip(pts[:, 1], 0, H - 1)
        closed = np.vstack([pts, pts[:1]])
        out.at[idx, "xmin"] = int(pts[:, 0].min())
        out.at[idx, "xmax"] = int(pts[:, 0].max())
        out.at[idx, "ymin"] = int(pts[:, 1].min())
        out.at[idx, "ymax"] = int(pts[:, 1].max())
        out.at[idx, "coords_x"] = ",".join(str(int(v)) for v in closed[:, 0])
        out.at[idx, "coords_y"] = ",".join(str(int(v)) for v in closed[:, 1])
        if "type" in out.columns:
            out.at[idx, "type"] = "polyline"

    if args.output_path.lower().endswith(".csv"):
        out_file = args.output_path
        d = os.path.dirname(out_file)
        if d:
            os.makedirs(d, exist_ok=True)
    else:
        os.makedirs(args.output_path, exist_ok=True)
        out_file = os.path.join(args.output_path, os.path.basename(args.csv_path))
    out.to_csv(out_file)
    print(f"Saved {len(out)} refined masks to {out_file}")


if __name__ == "__main__":
    main()
