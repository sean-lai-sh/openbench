"""Extract A1 (up to row permutation and scaling) from a 1-hidden-layer ReLU
network using only black-box queries to forward(x).

Method: along random lines, locate the "kinks" (points where one hidden
neuron switches on/off). At each kink, the gradient of the network jumps by
a2_i * A1[i, :]; the jump direction recovers row i of A1 up to scale.
"""
import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(x)


def grad(x, h=1e-6):
    g = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        g[j] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def find_kinks(x0, d, lo, hi, flo, fhi, out, tol=1e-11, min_w=1e-7):
    """Recursively find t in [lo, hi] where g(t)=f(x0+t d) is non-linear."""
    mid = 0.5 * (lo + hi)
    fmid = f(x0 + mid * d)
    scale = max(1.0, abs(flo), abs(fhi))
    if abs(fmid - 0.5 * (flo + fhi)) < tol * scale:
        # also check quarter points to reduce chance of missing cancelling kinks
        q1, q3 = lo + 0.25 * (hi - lo), lo + 0.75 * (hi - lo)
        f1, f3 = f(x0 + q1 * d), f(x0 + q3 * d)
        if (abs(f1 - (0.75 * flo + 0.25 * fhi)) < tol * scale and
                abs(f3 - (0.25 * flo + 0.75 * fhi)) < tol * scale):
            return
    if hi - lo < min_w:
        out.append(mid)
        return
    find_kinks(x0, d, lo, mid, flo, fmid, out, tol, min_w)
    find_kinks(x0, d, mid, hi, fmid, fhi, out, tol, min_w)


def refine_kink(x0, d, t, w=1e-4, h=1e-7):
    """Locate the kink precisely by intersecting the linear pieces on each side."""
    a, b = t - w, t + w
    sa = (f(x0 + (a + h) * d) - f(x0 + (a - h) * d)) / (2 * h)
    sb = (f(x0 + (b + h) * d) - f(x0 + (b - h) * d)) / (2 * h)
    fa, fb = f(x0 + a * d), f(x0 + b * d)
    if abs(sa - sb) < 1e-12:
        return t
    tk = (fb - fa + sa * a - sb * b) / (sa - sb)
    return tk if a <= tk <= b else t


def normalize(v):
    v = v / np.linalg.norm(v)
    i = np.argmax(np.abs(v))
    return v * np.sign(v[i])


def steal(n_lines=200, T=20.0, patience=40, min_count=2):
    rows, counts = [], []
    no_new = 0
    for _ in range(n_lines):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        ts = []
        find_kinks(x0, d, -T, T, f(x0 - T * d), f(x0 + T * d), ts)
        # merge kinks found in adjacent tiny intervals
        ts = sorted(ts)
        merged = []
        for t in ts:
            if not merged or t - merged[-1] > 1e-5:
                merged.append(t)
        found_new = False
        for t in merged:
            t = refine_kink(x0, d, t)
            eps = 1e-5
            gl, gl2 = grad(x0 + (t - eps) * d), grad(x0 + (t - 3 * eps) * d)
            gr, gr2 = grad(x0 + (t + eps) * d), grad(x0 + (t + 3 * eps) * d)
            dg = gr - gl
            nd = np.linalg.norm(dg)
            if nd < 1e-8:
                continue
            # make sure both sides are clean linear regions (single kink)
            if (np.linalg.norm(gl - gl2) > 1e-4 * nd or
                    np.linalg.norm(gr - gr2) > 1e-4 * nd):
                continue
            v = normalize(dg)
            for k, r in enumerate(rows):
                if abs(np.dot(v, r)) > 1 - 1e-4:
                    counts[k] += 1
                    break
            else:
                rows.append(v)
                counts.append(1)
                found_new = True
        no_new = 0 if found_new else no_new + 1
        if no_new >= patience:
            break
    rows = [r for r, c in zip(rows, counts) if c >= min_count]
    return np.array(rows)


if __name__ == "__main__":
    A1_hat = steal()
    np.save(OUT, A1_hat)
    print(f"Recovered {A1_hat.shape[0]} neurons; shape {A1_hat.shape}")
    print(A1_hat)
