"""Extract A1 (up to neuron permutation and row scaling) from a 1-hidden-layer
ReLU network using only black-box queries to forward(x).

Method: along random lines x(t) = x0 + t*d the function is piecewise linear;
each kink corresponds to a hidden neuron crossing zero. At a kink, the
difference of input-gradients on either side equals A2_i * A1_i, i.e. row i
of A1 up to scale. Collect these across many lines and deduplicate.
"""
import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, a, b, fa, fb, out, depth=0):
    """Recursively find kinks of g(t)=f(x0+t d) in [a,b]."""
    g = lambda t: f(x0 + t * d)
    m = 0.5 * (a + b)
    fm = g(m)
    q1, q3 = 0.75 * a + 0.25 * b, 0.25 * a + 0.75 * b
    fq1, fq3 = g(q1), g(q3)
    scale = 1e-9 * (1 + abs(fa) + abs(fb))
    lin = (abs(fm - 0.5 * (fa + fb)) < scale and
           abs(fq1 - (0.75 * fa + 0.25 * fb)) < scale and
           abs(fq3 - (0.25 * fa + 0.75 * fb)) < scale)
    if lin:
        return
    if b - a < 1e-4 or depth > 40:
        # Assume single kink: intersect left and right linear pieces.
        h = (b - a) * 1e-3
        sl = (g(a + h) - fa) / h
        sr = (fb - g(b - h)) / h
        if abs(sr - sl) < 1e-12:
            return
        t = (fb - fa + sl * a - sr * b) / (sl - sr)
        if a <= t <= b:
            # Validate: a single kink means g(t) lies on both pieces.
            pred = fa + sl * (t - a)
            if abs(g(t) - pred) < 1e-9 * (1 + abs(pred)):
                out.append(t)
        return
    find_kinks(x0, d, a, m, fa, fm, out, depth + 1)
    find_kinks(x0, d, m, b, fm, fb, out, depth + 1)


def grad(x, h=1e-6):
    gr = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        gr[j] = (f(x + e) - f(x - e)) / (2 * h)
    return gr


def main():
    rows = []
    n_lines = 60
    T = 20.0
    for _ in range(n_lines):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        kinks = []
        find_kinks(x0, d, -T, T, f(x0 - T * d), f(x0 + T * d), kinks)
        kinks = sorted(kinks)
        for i, t in enumerate(kinks):
            # stay away from neighbouring kinks
            gap = min([abs(t - s) for j, s in enumerate(kinks) if j != i] + [1.0])
            delta = min(1e-3, gap / 4)
            p = x0 + t * d
            vs = []
            for dl in (delta, delta / 7):
                g1 = grad(p - dl * d, h=dl / 10)
                g2 = grad(p + dl * d, h=dl / 10)
                vs.append(g2 - g1)
            n0, n1 = np.linalg.norm(vs[0]), np.linalg.norm(vs[1])
            if n0 < 1e-8 or n1 < 1e-8:
                continue
            if np.linalg.norm(vs[0] - vs[1]) > 1e-4 * n0:
                continue  # inconsistent: probe crossed another boundary
            rows.append(vs[0] / n0)

    # Deduplicate directions (up to sign).
    clusters = []
    for v in rows:
        for c in clusters:
            if abs(np.dot(c["rep"], v)) > 0.99999:
                s = np.sign(np.dot(c["rep"], v))
                c["members"].append(s * v)
                break
        else:
            clusters.append({"rep": v, "members": [v]})
    # Discard spurious clusters seen only once if most are seen often.
    counts = np.array([len(c["members"]) for c in clusters])
    keep = [c for c in clusters if len(c["members"]) >= max(3, 0.2 * counts.max())]
    A = []
    for c in keep:
        m = np.mean(c["members"], axis=0)
        m /= np.linalg.norm(m)
        A.append(m)
    A = np.array(A)
    np.save(OUT, A)
    print(f"Recovered {A.shape[0]} neurons (rows normalized to unit norm):")
    print(A)
    return A


if __name__ == "__main__":
    main()
