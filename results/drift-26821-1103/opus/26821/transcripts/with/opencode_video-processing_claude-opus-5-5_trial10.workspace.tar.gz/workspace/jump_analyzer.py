#!/usr/bin/env python3
"""Detect hurdle jump takeoff and landing frames in a stationary-camera video.

Approach
--------
1. The first frame contains no runner, so it (median of the first few frames)
   is used as the background model.
2. For each frame, the absolute difference to the background (after a global
   brightness compensation for auto-exposure changes) is thresholded inside the
   track region, cleaned with morphology, and the largest blob is taken as the
   runner.
3. The lowest point of the runner (feet) is tracked. The ground level of the
   runner's lane is estimated from the frames in which the feet are lowest.
4. Frames in which the feet are clearly above the ground are "airborne". The
   longest airborne run is the hurdle clearance (normal running strides only
   have very short flight phases).
   - takeoff = last frame with ground contact before that flight
   - landing = first frame with ground contact after that flight

Usage: python3 jump_analyzer.py [video.mp4] [output.toml]
"""
import os
import sys

import cv2
import numpy as np
import toml

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_VIDEO = os.path.join(HERE, "example_video.mp4")
DEFAULT_OUTPUT = os.path.join(HERE, "output.toml")


def read_frames(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise RuntimeError("Cannot open video: %s" % path)
    frames = []
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frames.append(frame)
    cap.release()
    if not frames:
        raise RuntimeError("No frames read from %s" % path)
    return frames


def preprocess(frame):
    g = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    return cv2.GaussianBlur(g, (5, 5), 0).astype(np.float32)


def analyze(frames):
    h, w = frames[0].shape[:2]
    # Region of interest: the track / lower background where the runner's
    # body and legs are (scaled to the frame size; reference 960x540).
    y0 = int(0.20 * h)
    y1 = int(0.80 * h)

    grays = [preprocess(f) for f in frames]
    bg = grays[0]
    win = cv2.createHanningWindow((w, h), cv2.CV_32F)
    tol_kernel = np.ones((3, 3), np.uint8)

    kernel_open = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    kernel_close = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
    min_area = 0.0015 * w * h  # ~780 px at 960x540

    n = len(frames)
    lowest = np.full(n, np.nan)
    cx = np.full(n, np.nan)
    touching_edge = np.zeros(n, dtype=bool)

    for i in range(1, n):
        # Compensate small camera shake / drift: align background to frame.
        # (copies: some OpenCV builds apply the window in place)
        (dx, dy), _ = cv2.phaseCorrelate(bg.copy(), grays[i].copy(), win)
        M = np.float32([[1, 0, dx], [0, 1, dy]])
        bg_al = cv2.warpAffine(bg, M, (w, h), borderMode=cv2.BORDER_REPLICATE)
        roi = grays[i][y0:y1]
        bg_roi = bg_al[y0:y1]
        # Global gain compensation (camera auto exposure).
        ratio = np.median(roi) / max(np.median(bg_roi), 1.0)
        bg_roi = bg_roi * ratio
        # Tolerate residual sub-pixel misalignment: compare against the local
        # min/max of the background instead of the pixel value itself.
        bmax = cv2.dilate(bg_roi, tol_kernel)
        bmin = cv2.erode(bg_roi, tol_kernel)
        diff = np.maximum(roi - bmax, bmin - roi)
        mask = (diff > 28).astype(np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel_open)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel_close)
        num, labels, stats, cents = cv2.connectedComponentsWithStats(mask, 8)
        if num <= 1:
            continue
        areas = stats[1:, cv2.CC_STAT_AREA]
        k = int(np.argmax(areas)) + 1
        if stats[k, cv2.CC_STAT_AREA] < min_area:
            continue
        # Runner blob: largest component plus big components close to it
        # (legs may get separated from the torso).
        gx0, gy0, gw, gh = stats[k, :4]
        gx1, gy1 = gx0 + gw, gy0 + gh
        sel = np.zeros(num, dtype=bool)
        sel[k] = True
        pad_x, pad_y = int(0.06 * w), int(0.12 * h)
        changed = True
        while changed:
            changed = False
            for j in range(1, num):
                if sel[j] or stats[j, cv2.CC_STAT_AREA] < 30:
                    continue
                jx, jy, jw, jh = stats[j, :4]
                if (jx < gx1 + pad_x and jx + jw > gx0 - pad_x and
                        jy < gy1 + pad_y and jy + jh > gy0 - pad_y):
                    sel[j] = True
                    changed = True
                    gx0, gy0 = min(gx0, jx), min(gy0, jy)
                    gx1, gy1 = max(gx1, jx + jw), max(gy1, jy + jh)
        blob = sel[labels]
        ys, xs = np.nonzero(blob)
        # Lowest point of the runner (feet).
        lowest[i] = ys.max() + y0
        cx[i] = xs.mean()
        touching_edge[i] = xs.min() <= 2 or xs.max() >= w - 3

    return lowest, cx, touching_edge, h


def find_jump(lowest, touching_edge, h):
    n = len(lowest)
    valid = ~np.isnan(lowest)
    if valid.sum() < 3:
        return 0, max(n - 1, 0)

    vals = lowest[valid & ~touching_edge]
    if len(vals) < 3:
        vals = lowest[valid]
    # Ground level of the runner's lane: feet are lowest when in contact.
    ground = np.percentile(vals, 85)
    margin = max(8.0, 0.025 * h)  # ~13 px at 540p

    present = valid.copy()
    airborne = present & (lowest < ground - margin)

    # Find the longest run of airborne frames (gaps of missing detection
    # inside the run are tolerated only if surrounded by airborne frames).
    best = None
    i = 0
    while i < n:
        if airborne[i]:
            j = i
            while j + 1 < n and airborne[j + 1]:
                j += 1
            # Height of the flight as a tie-breaker.
            height = ground - np.nanmin(lowest[i:j + 1])
            score = (j - i + 1, height)
            if best is None or score > best[0]:
                best = (score, i, j)
            i = j + 1
        else:
            i += 1

    if best is None:
        idx = np.nonzero(valid)[0]
        k = idx[int(np.nanargmin(lowest[idx]))]
        return int(max(k - 1, 0)), int(min(k + 1, n - 1))

    _, s, e = best
    takeoff = s - 1 if s > 0 else s
    landing = e + 1 if e + 1 < n else e
    return int(takeoff), int(landing)


def main():
    video = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_VIDEO
    out = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_OUTPUT

    frames = read_frames(video)
    lowest, cx, touching_edge, h = analyze(frames)
    takeoff, landing = find_jump(lowest, touching_edge, h)

    if os.environ.get("JUMP_DEBUG"):
        for i in range(len(lowest)):
            if not np.isnan(lowest[i]):
                print(i, round(float(lowest[i]), 1), round(float(cx[i]), 1), bool(touching_edge[i]))

    result = {
        "jump_takeoff_frame_number": takeoff,
        "jump_land_frame_number": landing,
    }
    with open(out, "w") as f:
        toml.dump(result, f)
    print(toml.dumps(result), end="")


if __name__ == "__main__":
    main()
