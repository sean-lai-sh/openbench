/* /* */
#if 0
// */
// Rust section (C++ skips this via #if 0; Rust sees nested comments differently)
fn add(a: &Vec<u64>, b: &Vec<u64>) -> Vec<u64> {
    let base: u64 = 1000000000;
    let mut r: Vec<u64> = Vec::new();
    let mut carry: u64 = 0;
    let n = if a.len() > b.len() { a.len() } else { b.len() };
    for i in 0..n {
        let x = if i < a.len() { a[i] } else { 0 };
        let y = if i < b.len() { b[i] } else { 0 };
        let s = x + y + carry;
        r.push(s % base);
        carry = s / base;
    }
    if carry > 0 { r.push(carry); }
    r
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let n: u64 = if args.len() > 1 { args[1].trim().parse().unwrap_or(0) } else { 0 };
    let mut a: Vec<u64> = vec![1];
    let mut b: Vec<u64> = vec![1];
    for _ in 0..n {
        let c = add(&a, &b);
        a = b;
        b = c;
    }
    let mut s = format!("{}", a[a.len() - 1]);
    for i in (0..a.len() - 1).rev() {
        s.push_str(&format!("{:09}", a[i]));
    }
    println!("{}", s);
}
/* /* */
#endif
#include <cstdio>
#include <cstdlib>
#include <vector>
typedef unsigned long long u64;
static std::vector<u64> add(const std::vector<u64>& a, const std::vector<u64>& b) {
    const u64 base = 1000000000ULL;
    std::vector<u64> r;
    u64 carry = 0;
    size_t n = a.size() > b.size() ? a.size() : b.size();
    for (size_t i = 0; i < n; i++) {
        u64 x = i < a.size() ? a[i] : 0;
        u64 y = i < b.size() ? b[i] : 0;
        u64 s = x + y + carry;
        r.push_back(s % base);
        carry = s / base;
    }
    if (carry) r.push_back(carry);
    return r;
}
int main(int argc, char** argv) {
    long long n = argc > 1 ? atoll(argv[1]) : 0;
    std::vector<u64> a(1, 1), b(1, 1);
    for (long long i = 0; i < n; i++) {
        std::vector<u64> c = add(a, b);
        a.swap(b);
        b.swap(c);
    }
    printf("%llu", a.back());
    for (size_t i = a.size() - 1; i-- > 0;) printf("%09llu", a[i]);
    printf("\n");
    return 0;
}
// */
