import json, re, random, sys, time
import chess

rules = [(re.compile(p), r) for p, r in json.load(open("re.json"))]


def run(fen):
    for p, r in rules:
        fen = p.sub(r, fen)
    return [" ".join(x.split(" ")[:-2]) for x in fen.split("\n")]


def expected(fen):
    b = chess.Board(fen)
    out = set()
    for m in b.legal_moves:
        if m.promotion and m.promotion != chess.QUEEN:
            continue
        c = b.copy(); c.push(m)
        out.add(" ".join(c.fen().split(" ")[:-2]))
    return out


def check(fen):
    ours = run(fen)
    exp = expected(fen)
    bad = [x for x in ours if not (x in exp or x.rpartition(" ")[0] + " -" in exp)]
    if bad or len(ours) != len(exp):
        print("FAIL", fen, bad, len(ours), len(exp))
        print(sorted(set(exp) - set(ours)))
        return False
    return True


s = "rnb1k1nr/p2p1ppp/3B4/1p1NPN1P/6P1/3P1Q2/P1P5/q4Kb1 w kq - 0 1"
print(run(s))
random.seed(int(sys.argv[1]) if len(sys.argv) > 1 else 0)
n = 0; fails = 0; t = time.time()
for g in range(300):
    b = chess.Board()
    while not b.is_game_over() and b.ply() < 200:
        if b.turn == chess.WHITE and any(True for _ in b.legal_moves):
            n += 1
            if not check(b.fen()):
                fails += 1
                if fails > 5: sys.exit()
        moves = list(b.legal_moves)
        # bias toward captures/pawn moves/castling for variety
        b.push(random.choice(moves))
print("tested", n, "fails", fails, "time", time.time() - t)
