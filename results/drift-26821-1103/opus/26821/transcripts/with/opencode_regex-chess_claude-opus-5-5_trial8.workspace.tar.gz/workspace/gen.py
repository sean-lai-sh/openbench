import json

FILES = "abcdefgh"
rules = []


def idx(r, f):
    return r * 8 + f


def ok(r, f):
    return 0 <= r < 8 and 0 <= f < 8


# ---------------- normalization ----------------
rules.append([r" \d+ \d+\s*$", ""])
rules.append([r" ([a-h])[36]$", r" \1"])
import itertools
for mask in itertools.product([0, 1], repeat=4):
    full = "".join(c if m else "-" for c, m in zip("KQkq", mask))
    short = full.replace("-", "") or "-"
    rules.append([" w " + short + " ", " w " + full + " "])
for d in range(8, 0, -1):
    rules.append([str(d), "." * d])
rules.append(["/", ""])
rules.append([r"^(.{64}) w (.{4}) (.)$", "@\\1 \\2 \\3\n"])


# ---------------- move generation ----------------
def move_rule(conds, newvals, prefix="#", castpat="....", eppat=".", newep="-"):
    segs = []
    i = 0
    while i < 64:
        if i in conds:
            segs.append(("sq", i, conds[i]))
            i += 1
        else:
            j = i
            while j < 64 and j not in conds:
                j += 1
            segs.append(("run", i, j - i))
            i = j
    pat = ""
    orig = ""
    g = 0
    gmap = {}
    seggroups = []
    for s in segs:
        g += 1
        seggroups.append(g)
        if s[0] == "sq":
            pat += "(" + s[2] + ")"
            gmap[s[1]] = g
        else:
            pat += "(.{%d})" % s[2]
        orig += "\\g<%d>" % g
    new = ""
    for s, gg in zip(segs, seggroups):
        if s[0] == "sq" and s[1] in newvals:
            v = newvals[s[1]]
            if isinstance(v, tuple):
                new += "\\g<%d>" % gmap[v[1]]
            else:
                new += v
        else:
            new += "\\g<%d>" % gg
    gc = g + 1
    ge = g + 2
    pattern = r"\A@" + pat + r" (" + castpat + r") (" + eppat + r")(?=\n)"
    repl = ("@" + orig + " \\g<%d> \\g<%d>" % (gc, ge) + "\n" + prefix + new
            + " \\g<%d> " % gc + newep)
    rules.append([pattern, repl])


EMPTY = r"\."
TARGET = r"[a-z.]"
ENEMY = r"[a-z]"

KNIGHT = [(1, 2), (2, 1), (-1, 2), (-2, 1), (1, -2), (2, -1), (-1, -2), (-2, -1)]
KING = [(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)]
ROOKD = [(1, 0), (-1, 0), (0, 1), (0, -1)]
BISHD = [(1, 1), (1, -1), (-1, 1), (-1, -1)]

for r in range(8):
    for f in range(8):
        s = idx(r, f)
        # knights & king
        for piece, offs in (("N", KNIGHT), ("K", KING)):
            for dr, df in offs:
                if ok(r + dr, f + df):
                    t = idx(r + dr, f + df)
                    move_rule({s: piece, t: TARGET}, {s: ".", t: piece})
        # sliders
        for cls, dirs in (("[RQ]", ROOKD), ("[BQ]", BISHD)):
            for dr, df in dirs:
                path = []
                k = 1
                while ok(r + dr * k, f + df * k):
                    t = idx(r + dr * k, f + df * k)
                    conds = {s: cls, t: TARGET}
                    for p in path:
                        conds[p] = EMPTY
                    move_rule(conds, {s: ".", t: ("ref", s)})
                    path.append(t)
                    k += 1
        # pawns
        if 1 <= r <= 6:
            t = idx(r - 1, f)
            np = "Q" if r - 1 == 0 else "P"
            move_rule({s: "P", t: EMPTY}, {s: ".", t: np})
            if r == 6:
                t2 = idx(r - 2, f)
                move_rule({s: "P", t: EMPTY, t2: EMPTY}, {s: ".", t2: "P"},
                          newep=FILES[f])
            for df in (-1, 1):
                if ok(r - 1, f + df):
                    t = idx(r - 1, f + df)
                    move_rule({s: "P", t: ENEMY}, {s: ".", t: np})
            if r == 3:
                for df in (-1, 1):
                    if ok(r - 1, f + df):
                        t = idx(2, f + df)
                        c = idx(3, f + df)
                        move_rule({s: "P", t: EMPTY, c: "p"},
                                  {s: ".", t: "P", c: "."}, eppat=FILES[f + df])

# castling
move_rule({60: "K", 61: EMPTY, 62: EMPTY, 63: "R"}, {61: "K", 62: "K"},
          prefix="$", castpat="K...")
move_rule({56: "R", 57: EMPTY, 58: EMPTY, 59: EMPTY, 60: "K"}, {58: "K", 59: "K"},
          prefix="%", castpat=".Q..")


# ---------------- legality filter ----------------
def plain(conds):
    out = ""
    i = 0
    m = max(conds)
    while i <= m:
        if i in conds:
            out += conds[i]
            i += 1
        else:
            j = i
            while j not in conds:
                j += 1
            out += ".{%d}" % (j - i)
            i = j
    return out


for r in range(8):
    for f in range(8):
        s = idx(r, f)
        alts = []
        for dr, df in KNIGHT:
            if ok(r + dr, f + df):
                alts.append({s: "K", idx(r + dr, f + df): "n"})
        for dr, df in KING:
            if ok(r + dr, f + df):
                alts.append({s: "K", idx(r + dr, f + df): "k"})
        for df in (-1, 1):
            if ok(r - 1, f + df):
                alts.append({s: "K", idx(r - 1, f + df): "p"})
        for cls, dirs in (("[rq]", ROOKD), ("[bq]", BISHD)):
            for dr, df in dirs:
                path = []
                k = 1
                while ok(r + dr * k, f + df * k):
                    t = idx(r + dr * k, f + df * k)
                    c = {s: "K", t: cls}
                    for p in path:
                        c[p] = EMPTY
                    alts.append(c)
                    path.append(t)
                    k += 1
        pat = "(?m)^[#$%%](?=.{%d}K)(?:" % s + "|".join(
            "(?=" + plain(c) + ")" for c in alts) + ").*\n"
        rules.append([pat, ""])

# castle conversion
rules.append([r"(?m)^\$(.{60})KKKR", r"#\1.RK."])
rules.append([r"(?m)^%(.{56})R.KKK", r"#\1..KR."])

# castling rights update
rules.append([r"(?m)^(#(?!.{60}K).{64} )..", r"\1--"])
rules.append([r"(?m)^(#(?!.{63}R).{64} ).", r"\1-"])
rules.append([r"(?m)^(#(?!.{56}R).{64} .).", r"\1-"])
rules.append([r"(?m)^(#(?!.{7}r).{64} ..).", r"\1-"])
rules.append([r"(?m)^(#(?!.{0}r).{64} ...).", r"\1-"])

# ---------------- formatting ----------------
rules.append([r"\A@.*\n", ""])
rules.append([r"(?m)^#" + "(.{8})" * 8 + " ",
              "/".join("\\%d" % i for i in range(1, 9)) + " b "])
for d in range(8, 0, -1):
    rules.append([r"\." * d, str(d)])
for mask in itertools.product([0, 1], repeat=4):
    full = "".join(c if m else "-" for c, m in zip("KQkq", mask))
    short = full.replace("-", "") or "-"
    rules.append([" b " + full + " ", " b " + short + " "])
rules.append([r" ([a-h])\n", r" \g<1>3 0 0\n"])
rules.append([r" -\n", r" - 0 0\n"])
rules.append([r"\n\Z", ""])

json.dump(rules, open("re.json", "w"))
print(len(rules))
