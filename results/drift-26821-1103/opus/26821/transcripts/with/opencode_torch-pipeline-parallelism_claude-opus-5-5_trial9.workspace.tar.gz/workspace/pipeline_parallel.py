"""Pipeline-parallel training step (AFAB schedule) for LlamaForCausalLM."""

import torch
import torch.distributed as dist
import torch.nn.functional as F


def _partition_layers(num_layers, world_size, rank):
    """Return [start, end) layer indices for `rank` in a balanced split."""
    base, rem = divmod(num_layers, world_size)
    start = rank * base + min(rank, rem)
    end = start + base + (1 if rank < rem else 0)
    return start, end


def _p2p(op, tensor, peer):
    reqs = dist.batch_isend_irecv([dist.P2POp(op, tensor, peer)])
    for req in reqs:
        req.wait()


def _send(tensor, dst):
    _p2p(dist.isend, tensor.contiguous(), dst)


def _recv(shape, src, device, dtype):
    buf = torch.empty(shape, device=device, dtype=dtype)
    _p2p(dist.irecv, buf, src)
    return buf


def _build_mask(config, hidden_states, position_ids):
    try:
        from transformers.masking_utils import create_causal_mask
    except Exception:  # pragma: no cover
        return None
    try:
        return create_causal_mask(
            config=config,
            inputs_embeds=hidden_states,
            attention_mask=None,
            past_key_values=None,
            position_ids=position_ids,
        )
    except TypeError:  # older transformers signature
        cache_position = torch.arange(hidden_states.shape[1], device=hidden_states.device)
        return create_causal_mask(
            config=config,
            input_embeds=hidden_states,
            attention_mask=None,
            cache_position=cache_position,
            past_key_values=None,
            position_ids=position_ids,
        )


def train_step_pipeline_afab(model, inputs, targets, device, dtype):
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    is_first = rank == 0
    is_last = rank == world_size - 1

    llama = model.model
    config = model.config
    layers = llama.layers
    start, end = _partition_layers(len(layers), world_size, rank)
    local_layers = [layers[i] for i in range(start, end)]

    num_mb = len(inputs)
    hidden_size = config.hidden_size

    input_buffers = []   # stage inputs (hidden states received from prev stage)
    output_buffers = []  # stage outputs (hidden states or loss)
    total_loss = torch.zeros((), device=device, dtype=torch.float32)

    # ---------------- All forward ----------------
    for mb in range(num_mb):
        input_ids = inputs[mb].to(device)
        mb_size, seq_len = input_ids.shape[0], input_ids.shape[1]

        if is_first:
            hidden = llama.embed_tokens(input_ids).to(dtype)
            stage_input = None
        else:
            hidden = _recv((mb_size, seq_len, hidden_size), rank - 1, device, dtype)
            hidden.requires_grad_(True)
            stage_input = hidden

        position_ids = torch.arange(seq_len, device=device).unsqueeze(0)
        position_embeddings = llama.rotary_emb(hidden, position_ids=position_ids)
        mask = _build_mask(config, hidden, position_ids)

        for layer in local_layers:
            hidden = layer(
                hidden,
                attention_mask=mask,
                position_ids=position_ids,
                position_embeddings=position_embeddings,
            )
            if isinstance(hidden, tuple):
                hidden = hidden[0]

        if is_last:
            hidden = llama.norm(hidden)
            logits = model.lm_head(hidden)
            tgt = targets[mb].to(device)
            loss = F.cross_entropy(
                logits.reshape(-1, logits.shape[-1]), tgt.reshape(-1)
            ) / num_mb
            total_loss = total_loss + loss.detach().float()
            output = loss
        else:
            output = hidden.to(dtype)
            _send(output.detach(), rank + 1)

        input_buffers.append(stage_input)
        output_buffers.append(output)

    # ---------------- All backward ----------------
    for mb in range(num_mb):
        stage_input = input_buffers[mb]
        output = output_buffers[mb]

        if is_last:
            output.backward()
        else:
            grad = _recv(output.shape, rank + 1, device, dtype)
            torch.autograd.backward(output, grad_tensors=grad)

        if not is_first:
            _send(stage_input.grad.to(device=device, dtype=dtype), rank - 1)

        input_buffers[mb] = None
        output_buffers[mb] = None

    return total_loss if is_last else None
