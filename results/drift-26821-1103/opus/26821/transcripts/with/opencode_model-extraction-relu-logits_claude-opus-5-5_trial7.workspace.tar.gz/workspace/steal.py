import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(1234)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, a, b, fa, fb, depth=0, out=None):
    """Find t values in [a,b] where g(t)=f(x0+t d) is non-linear."""
    if out is None:
        out = []
    h = 1e-7 * max(1.0, b - a)
    # slopes at the ends (one-sided, inward)
    sa = (f(x0 + (a + h) * d) - fa) / h
    sb = (fb - f(x0 + (b - h) * d)) / h
    scale = max(1e-12, abs(sa), abs(sb))
    if abs(sa - sb) < 1e-6 * scale + 1e-10:
        mid = 0.5 * (a + b)
        fm = f(x0 + mid * d)
        if abs(fm - (fa + sa * (mid - a))) < 1e-9 * (1 + abs(fm)):
            return out  # linear on the interval
    if b - a < 1e-9 or depth > 60:
        out.append(0.5 * (a + b))
        return out
    # try single kink: intersection of the two end lines
    if abs(sa - sb) > 1e-12:
        tk = (fb - fa + sa * a - sb * b) / (sa - sb)
        if a < tk < b:
            fk = f(x0 + tk * d)
            if abs(fk - (fa + sa * (tk - a))) < 1e-9 * (1 + abs(fk)):
                # verify: both sides linear
                l = find_linear(x0, d, a, tk, fa, fk, sa)
                r = find_linear(x0, d, tk, b, fk, fb, sb)
                if l and r:
                    out.append(tk)
                    return out
    mid = 0.5 * (a + b)
    fm = f(x0 + mid * d)
    find_kinks(x0, d, a, mid, fa, fm, depth + 1, out)
    find_kinks(x0, d, mid, b, fm, fb, depth + 1, out)
    return out


def find_linear(x0, d, a, b, fa, fb, s):
    for q in (0.25, 0.5, 0.75):
        t = a + q * (b - a)
        ft = f(x0 + t * d)
        if abs(ft - (fa + s * (t - a))) > 1e-9 * (1 + abs(ft)):
            return False
    return True


def grad(x, eps=1e-6):
    g = np.zeros(DIM)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = eps
        g[i] = (f(x + e) - f(x - e)) / (2 * eps)
    return g


rows = []
counts = []
for trial in range(60):
    x0 = rng.normal(size=DIM) * 2
    d = rng.normal(size=DIM)
    d /= np.linalg.norm(d)
    T = 30.0
    kinks = find_kinks(x0, d, -T, T, f(x0 - T * d), f(x0 + T * d))
    kinks = sorted(kinks)
    for i, t in enumerate(kinks):
        # need spacing from neighbouring kinks
        gap = min([abs(t - k) for j, k in enumerate(kinks) if j != i] + [1.0])
        delta = min(1e-3, gap / 4)
        if delta < 1e-7:
            continue
        eps = delta / 20
        gl = grad(x0 + (t - delta) * d, eps)
        gr = grad(x0 + (t + delta) * d, eps)
        diff = gr - gl
        n = np.linalg.norm(diff)
        if n < 1e-9:
            continue
        v = diff / n
        k = np.argmax(np.abs(v))
        v = v * np.sign(v[k])
        for j, r in enumerate(rows):
            if abs(r @ v) > 1 - 1e-5:
                counts[j] += 1
                break
        else:
            rows.append(v)
            counts.append(1)

# keep only directions observed repeatedly (filters numerical artifacts)
counts = np.array(counts)
print("counts:", sorted(counts))
A = np.array(rows)[counts >= 3]
print("recovered neurons:", A.shape[0])
print(A)
np.save(OUT, A)
