"""Extract A1 (up to row permutation and scaling) from a 1-hidden-layer ReLU net
using only black-box queries to forward(x).

Method: walk along random lines, locate the kinks (critical points where one
hidden neuron switches on/off), and measure the jump in the gradient across each
kink. That jump is proportional to the corresponding row of A1.
"""
import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(1234)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi, flo, fhi, depth=0, out=None):
    """Recursively find kink locations t of g(t)=f(x0+t d) on [lo, hi]."""
    if out is None:
        out = []
    mid = 0.5 * (lo + hi)
    fmid = f(x0 + mid * d)
    lin = 0.5 * (flo + fhi)
    scale = max(1.0, abs(flo), abs(fhi))
    if abs(fmid - lin) < 1e-12 * scale and depth > 3:
        return out  # linear on this segment (with high probability)
    if hi - lo < 1e-3:
        # Small segment containing (probably) a single kink: refine it.
        t = refine_kink(x0, d, lo, hi)
        if t is not None:
            out.append(t)
        return out
    find_kinks(x0, d, lo, mid, flo, fmid, depth + 1, out)
    find_kinks(x0, d, mid, hi, fmid, fhi, depth + 1, out)
    return out


def refine_kink(x0, d, lo, hi):
    """Locate a kink in [lo, hi] by intersecting the two outer linear pieces."""
    h = (hi - lo) * 1e-3
    g = lambda t: f(x0 + t * d)
    sl = (g(lo + h) - g(lo)) / h
    sr = (g(hi) - g(hi - h)) / h
    if abs(sl - sr) < 1e-9:
        return None
    # g(lo) + sl (t-lo) = g(hi) + sr (t-hi)
    t = (g(hi) - g(lo) + sl * lo - sr * hi) / (sl - sr)
    if not (lo - 1e-9 <= t <= hi + 1e-9):
        return None
    return t


def gradient(x, eps=1e-6):
    g = np.zeros(DIM)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = eps
        g[i] = (f(x + e) - f(x - e)) / (2 * eps)
    return g


def _row(x0, d, t, delta):
    diff = gradient(x0 + (t + delta) * d) - gradient(x0 + (t - delta) * d)
    n = np.linalg.norm(diff)
    return None if n < 1e-8 else diff / n


def row_at_kink(x0, d, t):
    # Measure at two different offsets; reject if inconsistent (e.g. two
    # kinks very close together or an imprecisely located kink).
    a = _row(x0, d, t, 1e-4)
    b = _row(x0, d, t, 1e-5)
    if a is None or b is None or abs(np.dot(a, b)) < 0.99999:
        return None
    return a


def canon(v):
    # Fix the sign so that the largest-magnitude entry is positive.
    return v if v[np.argmax(np.abs(v))] > 0 else -v


def main():
    rows = []
    counts = []
    no_new = 0
    trials = 0
    while no_new < 30 and trials < 500:
        trials += 1
        x0 = rng.normal(size=DIM) * 0.5
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        T = 20.0
        kinks = find_kinks(x0, d, -T, T, f(x0 - T * d), f(x0 + T * d))
        found_new = False
        for t in kinks:
            v = row_at_kink(x0, d, t)
            if v is None:
                continue
            v = canon(v)
            for k, r in enumerate(rows):
                if abs(np.dot(v, r)) > 0.9999:
                    counts[k] += 1
                    if counts[k] == 2:
                        found_new = True
                    break
            else:
                rows.append(v)
                counts.append(1)
        no_new = 0 if found_new else no_new + 1

    # Keep only neurons confirmed on at least two independent lines.
    A = np.array([r for r, c in zip(rows, counts) if c >= 2])
    np.save(OUT, A)
    print(f"Recovered {A.shape[0]} neurons; saved to {OUT}")
    print(A)


if __name__ == "__main__":
    main()
