#!/usr/bin/env python
"""Refine cell annotations (rectangles + polylines) into polyline masks with MobileSAM.

For each annotation in the metadata csv, MobileSAM is prompted with the
annotation's bounding box (plus, for polylines, the annotated outline is used
to pick the best of SAM's candidate masks).  The resulting masks are then
post-processed so that:

  * every cell gets exactly one contiguous (simply connected) mask,
  * no two masks overlap (a 1px gap is kept between neighbouring masks so the
    resulting polygons do not intersect either),
  * every mask is a polyline (never an axis aligned rectangle).

The output csv is identical to the input one except for the updated
xmin, ymin, xmax, ymax, coords_x and coords_y columns.

Usage:
    python convert_masks.py --weights_path mobile_sam.pt --output_path out/ \
        --rgb_path demo_rgb.png --csv_path demo_metadata.csv
"""

import argparse
import os
import warnings

import cv2
import numpy as np
import pandas as pd
import torch
from PIL import Image
from tqdm import tqdm

warnings.filterwarnings("ignore")

from mobile_sam import SamPredictor, sam_model_registry  # noqa: E402

# Tiling parameters for large images (MobileSAM resizes its input to 1024px).
MAX_FULL_IMAGE = 1024
TILE_SIZE = 512
TILE_STRIDE = 384
BATCH_SIZE = 32
MIN_PIXELS = 5


# --------------------------------------------------------------------------- #
# Argument parsing / IO
# --------------------------------------------------------------------------- #
def parse_args():
    """Accepts either positional args (weights output rgb csv) or --flags."""
    names = {
        "weights_path": "Path to MobileSAM weights (mobile_sam.pt).",
        "output_path": "Output folder (or .csv file path) where the refined masks csv is saved.",
        "rgb_path": "Path to the RGB image.",
        "csv_path": "Path to the metadata csv.",
    }
    p = argparse.ArgumentParser(description="Convert cell masks to polylines with MobileSAM.")
    for name, help_ in names.items():
        p.add_argument(f"pos_{name}", nargs="?", default=None, metavar=name, help=help_)
    for name, help_ in names.items():
        p.add_argument(f"--{name}", f"--{name.replace('_', '-')}", dest=name, type=str, default=None, help=help_)
    args = p.parse_args()
    for name in names:
        if getattr(args, name) is None:
            setattr(args, name, getattr(args, f"pos_{name}"))
        if getattr(args, name) is None:
            p.error(f"missing required argument: {name}")
    return args


def resolve_output_file(output_path, csv_path):
    if output_path.lower().endswith(".csv"):
        parent = os.path.dirname(os.path.abspath(output_path))
        os.makedirs(parent, exist_ok=True)
        return output_path
    os.makedirs(output_path, exist_ok=True)
    return os.path.join(output_path, os.path.basename(csv_path))


def parse_coords(s):
    if isinstance(s, (list, tuple, np.ndarray)):
        return [float(v) for v in s]
    if s is None or (isinstance(s, float) and np.isnan(s)):
        return []
    s = str(s).strip().strip("[]()")
    return [float(v) for v in s.replace(";", ",").replace(" ", ",").split(",") if v.strip() != ""]


def load_model(weights_path, device):
    model = sam_model_registry["vit_t"](checkpoint=None)
    state = torch.load(weights_path, map_location="cpu")
    if isinstance(state, dict) and "model" in state and not any(k.startswith("image_encoder") for k in state):
        state = state["model"]
    model.load_state_dict(state)
    model.to(device)
    model.eval()
    return SamPredictor(model)


# --------------------------------------------------------------------------- #
# Mask helpers
# --------------------------------------------------------------------------- #
def polygon_mask(xs, ys, shape):
    m = np.zeros(shape, np.uint8)
    if len(xs) >= 3:
        pts = np.round(np.stack([xs, ys], 1)).astype(np.int32)
        cv2.fillPoly(m, [pts], 1)
    return m.astype(bool)


def ellipse_mask(box, shape):
    x0, y0, x1, y1 = box
    m = np.zeros(shape, np.uint8)
    cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    ax, ay = max(1, int(round((x1 - x0) / 2.0 * 0.9))), max(1, int(round((y1 - y0) / 2.0 * 0.9)))
    cv2.ellipse(m, (int(round(cx)), int(round(cy))), (ax, ay), 0, 0, 360, 1, -1)
    return m.astype(bool)


def largest_component(mask):
    """Largest 4-connected component (4-connectivity avoids pinch points)."""
    mask = mask.astype(np.uint8)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=4)
    if n <= 1:
        return np.zeros(mask.shape, bool)
    idx = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return lab == idx


def fill_holes(mask):
    m = mask.astype(np.uint8)
    contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    out = np.zeros_like(m)
    cv2.drawContours(out, contours, -1, 1, -1)
    return out.astype(bool) | mask


def iou(a, b):
    inter = np.logical_and(a, b).sum()
    union = np.logical_or(a, b).sum()
    return inter / union if union else 0.0


def smooth(mask):
    """Light morphological cleanup that does not grow the mask outside itself."""
    area = int(mask.sum())
    ksize = 5 if area > 400 else 3
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (ksize, ksize))
    opened = cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_OPEN, k).astype(bool)
    if opened.sum() < max(MIN_PIXELS, 0.5 * area):
        return mask
    return opened


def make_simple(mask, max_iter=20):
    """Remove 1px spurs / pinch points (pixels visited twice by the boundary
    trace) so the extracted contour is a simple, valid polygon.  Only removes
    pixels, so it can never create overlaps."""
    m = mask.copy()
    for _ in range(max_iter):
        m = fill_holes(largest_component(m))
        if m.sum() == 0:
            return m
        contours, _ = cv2.findContours(m.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        c = max(contours, key=len)[:, 0, :]
        if len(c) < 3:
            return m
        keys = c[:, 1].astype(np.int64) * (m.shape[1] + 1) + c[:, 0]
        uniq, counts = np.unique(keys, return_counts=True)
        dup = uniq[counts > 1]
        if len(dup) == 0:
            return m
        m[dup // (m.shape[1] + 1), dup % (m.shape[1] + 1)] = False
    return fill_holes(largest_component(m))


def mask_to_polygon(mask):
    """External contour of a single-component mask -> (xs, ys) closed polyline."""
    contours, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    c = max(contours, key=lambda c: (cv2.contourArea(c), len(c)))[:, 0, :]
    if len(c) < 3:
        return None
    xs, ys = c[:, 0].astype(int).tolist(), c[:, 1].astype(int).tolist()
    return xs, ys


def is_rectangle(xs, ys):
    pts = set(zip(xs, ys))
    if len(pts) > 4:
        return False
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    return all(x in (x0, x1) and y in (y0, y1) for x, y in pts)


# --------------------------------------------------------------------------- #
# SAM inference
# --------------------------------------------------------------------------- #
def make_tiles(h, w):
    if max(h, w) <= MAX_FULL_IMAGE:
        return [(0, 0, w, h)]

    def starts(n):
        if n <= TILE_SIZE:
            return [0]
        s = list(range(0, n - TILE_SIZE + 1, TILE_STRIDE))
        if s[-1] != n - TILE_SIZE:
            s.append(n - TILE_SIZE)
        return s

    return [(x, y, min(x + TILE_SIZE, w), min(y + TILE_SIZE, h)) for y in starts(h) for x in starts(w)]


def assign_tile(box, tiles, full):
    x0, y0, x1, y1 = box
    best, best_margin = None, -1
    for i, (tx0, ty0, tx1, ty1) in enumerate(tiles):
        margin = min(x0 - tx0, y0 - ty0, tx1 - x1, ty1 - y1)
        if margin >= 0 and margin > best_margin:
            best, best_margin = i, margin
    return best if best is not None else full


@torch.no_grad()
def run_sam(predictor, image, boxes, windows, device):
    """Run MobileSAM with box prompts.

    Returns, per box, (logits (3, wh, ww) cropped to the cell's window, scores (3,)).
    """
    h, w = image.shape[:2]
    tiles = make_tiles(h, w)
    full_idx = len(tiles)
    all_tiles = tiles + [(0, 0, w, h)]
    groups = {}
    for i, b in enumerate(boxes):
        groups.setdefault(assign_tile(b, tiles, full_idx), []).append(i)

    results = [None] * len(boxes)
    for t, idxs in tqdm(groups.items(), desc="SAM tiles", disable=len(groups) <= 1):
        tx0, ty0, tx1, ty1 = all_tiles[t]
        predictor.set_image(np.ascontiguousarray(image[ty0:ty1, tx0:tx1]))
        th, tw = ty1 - ty0, tx1 - tx0
        for s in tqdm(range(0, len(idxs), BATCH_SIZE), desc="SAM boxes", leave=False):
            batch = idxs[s:s + BATCH_SIZE]
            bx = np.array([boxes[i] for i in batch], dtype=np.float32)
            bx[:, [0, 2]] -= tx0
            bx[:, [1, 3]] -= ty0
            tb = predictor.transform.apply_boxes_torch(torch.as_tensor(bx, device=device), (th, tw))
            logits, scores, _ = predictor.predict_torch(
                point_coords=None, point_labels=None, boxes=tb,
                multimask_output=True, return_logits=True)
            for j, i in enumerate(batch):
                wx0, wy0, wx1, wy1 = windows[i]
                crop = np.full((3, wy1 - wy0, wx1 - wx0), -20.0, np.float32)
                ix0, iy0 = max(wx0, tx0), max(wy0, ty0)
                ix1, iy1 = min(wx1, tx1), min(wy1, ty1)
                if ix1 > ix0 and iy1 > iy0:
                    crop[:, iy0 - wy0:iy1 - wy0, ix0 - wx0:ix1 - wx0] = \
                        logits[j, :, iy0 - ty0:iy1 - ty0, ix0 - tx0:ix1 - tx0].cpu().numpy()
                results[i] = (crop, scores[j].cpu().numpy())
    return results


def choose_mask(cands, scores, box_area, ref_mask):
    """Pick the best of SAM's candidate masks; returns (binary mask, logit map)."""
    best, best_val = None, -np.inf
    for k in range(cands.shape[0]):
        m = cands[k] > 0
        area = m.sum()
        if area < MIN_PIXELS:
            continue
        if ref_mask is not None:
            # polyline annotation: stay faithful to the annotated outline
            val = iou(m, ref_mask) + 0.25 * scores[k]
        else:
            val = scores[k]
            frac = area / box_area
            if frac < 0.15 or frac > 1.0:
                val -= 1.0
        if val > best_val:
            best, best_val = k, val
    if best is None:
        return None, None
    return cands[best] > 0, cands[best]


# --------------------------------------------------------------------------- #
# Post-processing
# --------------------------------------------------------------------------- #
def cut_slits(candidate, filled):
    """Turn a ring-shaped mask into a simply connected one by cutting a slit
    from each hole up to the mask's outer boundary."""
    holes = filled & ~candidate
    n, lab = cv2.connectedComponents(holes.astype(np.uint8), connectivity=8)
    cand = candidate.copy()
    for h_id in range(1, n):
        ys, xs = np.nonzero(lab == h_id)
        k = int(np.argmin(ys))
        cx, cy = xs[k], ys[k]
        cand[:cy + 1, max(0, cx - 1):cx + 2] = False
    return cand


def finalize(candidate, blocked):
    """Return a simply-connected (hole free) mask not touching `blocked` (or None)."""
    cand = candidate & ~blocked
    for _ in range(5):
        cand = largest_component(cand)
        if cand.sum() < 1:
            return None
        filled = fill_holes(cand)
        if not (filled & blocked).any():
            return filled
        cand = cut_slits(cand & ~blocked, filled)
    cand = largest_component(cand)
    if cand.sum() < 1:
        return None
    return cand if not (fill_holes(cand) & blocked).any() else None


def fallback_mask(box, blocked):
    """Inscribed ellipse, or a small diamond at the free pixel closest to the box centre."""
    shape = blocked.shape
    res = finalize(ellipse_mask(box, shape), blocked)
    if res is not None and res.sum() >= MIN_PIXELS:
        return res
    x0, y0, x1, y1 = box
    cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    ys, xs = np.nonzero(~blocked)
    if len(xs) == 0:
        return None
    order = np.argsort((xs - cx) ** 2 + (ys - cy) ** 2)
    for o in order[:2000]:
        px, py = int(xs[o]), int(ys[o])
        for r in (2, 1):
            d = np.zeros(shape, np.uint8)
            pts = np.array([[px, py - r], [px + r, py], [px, py + r], [px - r, py]], np.int32)
            cv2.fillPoly(d, [pts], 1)
            d = d.astype(bool)
            if not (d & blocked).any():
                return d
    d = np.zeros(shape, bool)
    d[int(ys[order[0]]), int(xs[order[0]])] = True
    return d


def blocked_in(occupied, win, kernel):
    """Pixels inside `win` that are occupied or 8-adjacent to an occupied pixel."""
    h, w = occupied.shape
    wx0, wy0, wx1, wy1 = win
    ex0, ey0, ex1, ey1 = max(0, wx0 - 1), max(0, wy0 - 1), min(w, wx1 + 1), min(h, wy1 + 1)
    d = cv2.dilate(occupied[ey0:ey1, ex0:ex1], kernel).astype(bool)
    return d[wy0 - ey0:wy1 - ey0, wx0 - ex0:wx1 - ex0]


def main():
    args = parse_args()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    torch.set_grad_enabled(False)

    image = np.array(Image.open(args.rgb_path).convert("RGB"))
    h, w = image.shape[:2]
    df = pd.read_csv(args.csv_path)
    n = len(df)
    out_file = resolve_output_file(args.output_path, args.csv_path)

    if n == 0:
        df.to_csv(out_file, index=False)
        return

    # ---- parse annotations ----
    boxes, windows, inner, ref_masks = [], [], [], []
    for _, row in df.iterrows():
        xs, ys = parse_coords(row.get("coords_x")), parse_coords(row.get("coords_y"))
        if len(xs) and len(xs) == len(ys):
            x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
        else:
            x0, y0, x1, y1 = row["xmin"], row["ymin"], row["xmax"], row["ymax"]
            xs, ys = [], []
        x0, x1 = float(np.clip(x0, 0, w - 1)), float(np.clip(x1, 0, w - 1))
        y0, y1 = float(np.clip(y0, 0, h - 1)), float(np.clip(y1, 0, h - 1))
        if x1 - x0 < 2:
            x0, x1 = max(0.0, x0 - 1), min(w - 1.0, x1 + 1)
        if y1 - y0 < 2:
            y0, y1 = max(0.0, y0 - 1), min(h - 1.0, y1 + 1)
        boxes.append((x0, y0, x1, y1))
        # SAM masks are restricted to the box padded by `pad`; the window adds a
        # small margin around that so local morphology is exact.
        pad = max(2, int(0.1 * max(x1 - x0, y1 - y0)))
        ix0, iy0 = max(0, int(x0) - pad), max(0, int(y0) - pad)
        ix1, iy1 = min(w, int(np.ceil(x1)) + pad + 1), min(h, int(np.ceil(y1)) + pad + 1)
        wx0, wy0, wx1, wy1 = max(0, ix0 - 3), max(0, iy0 - 3), min(w, ix1 + 3), min(h, iy1 + 3)
        windows.append((wx0, wy0, wx1, wy1))
        inner.append((ix0 - wx0, iy0 - wy0, ix1 - wx0, iy1 - wy0))
        rtype = str(row.get("type", "")).lower()
        rect = rtype == "rectangle" or (len(xs) >= 3 and is_rectangle([int(round(v)) for v in xs],
                                                                      [int(round(v)) for v in ys]))
        if not rect and len(xs) >= 3:
            ref_masks.append(polygon_mask(np.clip(xs, 0, w - 1) - wx0, np.clip(ys, 0, h - 1) - wy0,
                                          (wy1 - wy0, wx1 - wx0)))
        else:
            ref_masks.append(None)

    # ---- MobileSAM ----
    predictor = load_model(args.weights_path, device)
    sam_out = run_sam(predictor, image, boxes, windows, device)

    # ---- choose candidate per cell; contested pixels go to the most confident mask ----
    masks = [None] * n
    best_val = np.full((h, w), -np.inf, np.float32)
    best_idx = np.full((h, w), -1, np.int64)
    for i in range(n):
        logits, scores = sam_out[i]
        wx0, wy0, wx1, wy1 = windows[i]
        lshape = (wy1 - wy0, wx1 - wx0)
        x0, y0, x1, y1 = boxes[i]
        lbox = (x0 - wx0, y0 - wy0, x1 - wx0, y1 - wy0)
        region = np.zeros(lshape, bool)
        a, b, c, d = inner[i]
        region[b:d, a:c] = True
        logits[:, ~region] = -20.0
        box_area = max(1.0, (x1 - x0 + 1) * (y1 - y0 + 1))
        m, lg = choose_mask(logits, scores, box_area, ref_masks[i])
        if m is not None:
            m = fill_holes(largest_component(m))
            if m.sum() < MIN_PIXELS:
                m = None
        if m is None:  # SAM failed -> annotation polygon / inscribed ellipse
            r = ref_masks[i]
            m = r if r is not None and r.sum() >= MIN_PIXELS else ellipse_mask(lbox, lshape)
            lg = np.ones(lshape, np.float32)
        masks[i] = m
        lg = np.where(m, np.maximum(lg, 1e-3), -np.inf).astype(np.float32)
        bv = best_val[wy0:wy1, wx0:wx1]
        upd = lg > bv
        bv[upd] = lg[upd]
        best_idx[wy0:wy1, wx0:wx1][upd] = i
        sam_out[i] = None

    # ---- sequential finalisation with a 1px gap between masks ----
    kernel = np.ones((3, 3), np.uint8)
    occupied = np.zeros((h, w), np.uint8)
    assigned = []
    for i in range(n):
        wx0, wy0, wx1, wy1 = windows[i]
        assigned.append((best_idx[wy0:wy1, wx0:wx1] == i) & masks[i])
    order = sorted(range(n), key=lambda i: assigned[i].sum())  # small cells first
    final = [None] * n  # (local mask, x offset, y offset)
    for i in order:
        wx0, wy0, wx1, wy1 = windows[i]
        x0, y0, x1, y1 = boxes[i]
        blocked = blocked_in(occupied, windows[i], kernel)
        cand = smooth(assigned[i]) if assigned[i].sum() >= MIN_PIXELS else assigned[i]
        res = finalize(cand, blocked) if cand.any() else None
        res = make_simple(res) if res is not None else None
        if res is None or res.sum() < MIN_PIXELS:
            # try the full (unassigned) SAM mask minus what is already taken
            res2 = finalize(masks[i], blocked)
            res2 = make_simple(res2) if res2 is not None else None
            if res2 is not None and (res is None or res2.sum() > res.sum()):
                res = res2
        ox, oy = wx0, wy0
        if res is None or res.sum() < MIN_PIXELS:
            res3 = fallback_mask((x0 - wx0, y0 - wy0, x1 - wx0, y1 - wy0), blocked)
            res3 = make_simple(res3) if res3 is not None else None
            if res3 is not None and (res is None or res3.sum() > res.sum()):
                res = res3
        if res is None or not res.any():  # window completely taken: search the whole image
            gblocked = cv2.dilate(occupied, kernel).astype(bool)
            res = fallback_mask(boxes[i], gblocked)
            res = make_simple(res) if res is not None else None
            ox, oy = 0, 0
            if res is None:
                res = np.zeros((h, w), bool)
        final[i] = (res, ox, oy)
        rh, rw = res.shape
        occupied[oy:oy + rh, ox:ox + rw] |= res.astype(np.uint8)

    # ---- polygons ----
    out = df.copy()
    xmin, ymin, xmax, ymax, cxs, cys = [], [], [], [], [], []
    for i in range(n):
        fm, ox, oy = final[i]
        poly = mask_to_polygon(fm) if fm.any() else None
        if poly is None:
            # degenerate (1-2 px) mask: emit a tiny diamond around it
            if fm.any():
                ys_, xs_ = np.nonzero(fm)
                px, py = int(np.mean(xs_)) + ox, int(np.mean(ys_)) + oy
            else:
                px, py = int((boxes[i][0] + boxes[i][2]) / 2), int((boxes[i][1] + boxes[i][3]) / 2)
            xs, ys = [px, min(w - 1, px + 1), px, max(0, px - 1)], [max(0, py - 1), py, min(h - 1, py + 1), py]
        else:
            xs, ys = [v + ox for v in poly[0]], [v + oy for v in poly[1]]
            if is_rectangle(xs, ys):
                # chop a corner so the mask is a genuine polyline, not a rectangle
                x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
                if x1 - x0 >= 1 and y1 - y0 >= 1:
                    xs, ys = [x0 + 1, x1, x1, x0, x0], [y0, y0, y1, y1, y0 + 1]
        xs, ys = list(xs) + [xs[0]], list(ys) + [ys[0]]  # close the polyline
        xmin.append(int(min(xs)))
        xmax.append(int(max(xs)))
        ymin.append(int(min(ys)))
        ymax.append(int(max(ys)))
        cxs.append(",".join(str(int(v)) for v in xs))
        cys.append(",".join(str(int(v)) for v in ys))

    out["xmin"], out["ymin"], out["xmax"], out["ymax"] = xmin, ymin, xmax, ymax
    out["coords_x"], out["coords_y"] = cxs, cys

    # keep the exact same layout as the input (e.g. unnamed index column)
    first_col = df.columns[0] if len(df.columns) else None
    if first_col is not None and str(first_col).startswith("Unnamed"):
        out = out.rename(columns={first_col: ""})
    out.to_csv(out_file, index=False)
    print(f"Saved {n} refined polyline masks to {out_file}")


if __name__ == "__main__":
    main()
