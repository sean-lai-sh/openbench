/* /* */
#include <cstdio>
#include <cstdlib>
#include <vector>
int main(int argc, char** argv) {
    if (argc < 2) return 1;
    long n = atol(argv[1]);
    const unsigned B = 1000000000u;
    std::vector<unsigned> a(1, 1), b(1, 1);
    for (long k = 0; k < n; k++) {
        std::vector<unsigned> c;
        unsigned carry = 0;
        size_t m = a.size() > b.size() ? a.size() : b.size();
        for (size_t i = 0; i < m; i++) {
            unsigned s = carry + (i < a.size() ? a[i] : 0) + (i < b.size() ? b[i] : 0);
            c.push_back(s % B);
            carry = s / B;
        }
        if (carry) c.push_back(carry);
        a.swap(b);
        b.swap(c);
    }
    printf("%u", a.back());
    for (size_t i = a.size() - 1; i-- > 0;) printf("%09u", a[i]);
    printf("\n");
    return 0;
}
/* */
// */
//\
fn main(){let n:usize=std::env::args().nth(1).expect("need N").trim().parse().expect("bad N");const B:u32=1000000000;let mut a:Vec<u32>=vec![1];let mut b:Vec<u32>=vec![1];for _ in 0..n{let mut c=Vec::new();let mut carry=0u32;for i in 0..a.len().max(b.len()){let s=carry+a.get(i).copied().unwrap_or(0)+b.get(i).copied().unwrap_or(0);c.push(s%B);carry=s/B;}if carry>0{c.push(carry);}a=b;b=c;}let mut out=format!("{}",a[a.len()-1]);for i in (0..a.len()-1).rev(){out.push_str(&format!("{:09}",a[i]));}println!("{}",out);}
