"""Extract A1 (up to permutation and row scaling) from black-box queries to forward().

Method: f is piecewise linear. Along random lines x0 + t*d we locate kinks
(points where some hidden neuron crosses zero). At each kink, the gradient
jump between the two sides is proportional to a2_i * A1[i], i.e. it gives the
row of A1 for that neuron up to scale. Collect unique directions.
"""
import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def grad(x, h=1e-7):
    g = np.zeros(DIM)
    for k in range(DIM):
        e = np.zeros(DIM)
        e[k] = h
        g[k] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def find_kinks(x0, d, a, b, fa=None, fb=None, depth=0, out=None, tol=1e-9):
    """Return t values of kinks of g(t)=f(x0+t d) in [a, b]."""
    if out is None:
        out = []
    g = lambda t: f(x0 + t * d)
    if fa is None:
        fa = g(a)
    if fb is None:
        fb = g(b)
    m = 0.5 * (a + b)
    fm = g(m)
    # Linear on [a,b]?  (check midpoint and quarter points)
    q1, q3 = a + 0.25 * (b - a), a + 0.75 * (b - a)
    fq1, fq3 = g(q1), g(q3)
    scale = 1e-10 * (1 + abs(fa) + abs(fb))
    lin = lambda t: fa + (fb - fa) * (t - a) / (b - a)
    if (abs(fm - lin(m)) < scale and abs(fq1 - lin(q1)) < scale
            and abs(fq3 - lin(q3)) < scale):
        return out
    if b - a < tol or depth > 60:
        out.append(m)
        return out
    # Try single-kink hypothesis: intersect the line through (a,q1) and (q3,b)
    sl = (fq1 - fa) / (q1 - a)
    sr = (fb - fq3) / (b - q3)
    if abs(sl - sr) > 1e-12:
        tk = (fq3 - sr * q3 - fa + sl * a) / (sl - sr)
        if a < tk < b:
            pred = fa + sl * (tk - a)
            # verify: point slightly left and right follow the respective lines
            ok = abs(g(tk) - pred) < scale * 10
            for t in (0.5 * (a + tk), 0.5 * (tk + b)):
                p = fa + sl * (t - a) if t < tk else fq3 + sr * (t - q3)
                ok = ok and abs(g(t) - p) < scale * 10
            if ok and abs(fm - (fa + sl * (m - a) if m < tk else fq3 + sr * (m - q3))) < scale * 10:
                out.append(tk)
                return out
    find_kinks(x0, d, a, m, fa, fm, depth + 1, out, tol)
    find_kinks(x0, d, m, b, fm, fb, depth + 1, out, tol)
    return out


def direction_at_kink(x0, d, t):
    # step off the kink; must stay much larger than gradient step h
    eps = 1e-4
    gl = grad(x0 + (t - eps) * d)
    gr = grad(x0 + (t + eps) * d)
    diff = gr - gl
    n = np.linalg.norm(diff)
    if n < 1e-8:
        return None
    return diff / n


def main():
    rows = []
    no_new = 0
    lines = 0
    while no_new < 30 and lines < 500:
        lines += 1
        x0 = rng.normal(size=DIM) * 0.5
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        kinks = find_kinks(x0, d, -20.0, 20.0)
        new = False
        for t in kinks:
            v = direction_at_kink(x0, d, t)
            if v is None:
                continue
            # canonical sign
            v = v * np.sign(v[np.argmax(np.abs(v))])
            if not any(abs(abs(np.dot(v, r)) - 1) < 1e-4 for r in rows):
                rows.append(v)
                new = True
        no_new = 0 if new else no_new + 1
    A = np.array(rows)
    np.save(OUT, A)
    print(f"Recovered {A.shape[0]} neurons after {lines} lines")
    print(A)
    return A


if __name__ == "__main__":
    main()
