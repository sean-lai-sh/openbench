import torch
import torch.distributed as dist
import torch.nn as nn
import torch.nn.functional as F


def _world_size():
    if dist.is_available() and dist.is_initialized():
        return dist.get_world_size()
    return 1


def _rank():
    if dist.is_available() and dist.is_initialized():
        return dist.get_rank()
    return 0


def _all_reduce(x):
    if _world_size() == 1:
        return x
    x = x.contiguous().clone()
    dist.all_reduce(x, op=dist.ReduceOp.SUM)
    return x


def _split_last(x):
    ws = _world_size()
    if ws == 1:
        return x
    return torch.chunk(x, ws, dim=-1)[_rank()].contiguous()


def _gather_last(x):
    ws = _world_size()
    if ws == 1:
        return x
    x = x.contiguous()
    parts = [torch.empty_like(x) for _ in range(ws)]
    dist.all_gather(parts, x)
    return torch.cat(parts, dim=-1).contiguous()


class _CopyToParallel(torch.autograd.Function):
    """Identity in forward, all-reduce in backward."""

    @staticmethod
    def forward(ctx, x):
        return x

    @staticmethod
    def backward(ctx, grad):
        return _all_reduce(grad)


class _ReduceFromParallel(torch.autograd.Function):
    """All-reduce in forward, identity in backward."""

    @staticmethod
    def forward(ctx, x):
        return _all_reduce(x)

    @staticmethod
    def backward(ctx, grad):
        return grad


class _ScatterToParallel(torch.autograd.Function):
    """Split along last dim in forward, all-gather in backward."""

    @staticmethod
    def forward(ctx, x):
        return _split_last(x)

    @staticmethod
    def backward(ctx, grad):
        return _gather_last(grad)


class _GatherFromParallel(torch.autograd.Function):
    """All-gather along last dim in forward, split in backward."""

    @staticmethod
    def forward(ctx, x):
        return _gather_last(x)

    @staticmethod
    def backward(ctx, grad):
        return _split_last(grad)


class ColumnParallelLinear(nn.Module):
    """Y = X A + b with A split along its columns (output features).

    The weight is stored as (out_features, in_features) like nn.Linear, so each
    rank holds a contiguous block of rows of the master weight.
    """

    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.world_size = _world_size()
        self.rank = _rank()
        assert out_features % self.world_size == 0, \
            "out_features must be divisible by world_size"
        self.in_features = in_features
        self.out_features = out_features
        self.output_size_per_partition = out_features // self.world_size

        master_weight = master_weight.detach()
        assert tuple(master_weight.shape) == (out_features, in_features)
        shard = torch.chunk(master_weight, self.world_size, dim=0)[self.rank]
        self.weight = nn.Parameter(shard.clone().contiguous())

        if bias:
            self.bias = nn.Parameter(torch.zeros(
                self.output_size_per_partition,
                dtype=master_weight.dtype, device=master_weight.device))
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        x = _CopyToParallel.apply(x)
        out = F.linear(x, self.weight, self.bias)
        return _GatherFromParallel.apply(out)


class RowParallelLinear(nn.Module):
    """Y = X A + b with A split along its rows (input features).

    The weight is stored as (out_features, in_features) like nn.Linear, so each
    rank holds a contiguous block of columns of the master weight. Partial
    outputs are summed with all-reduce; the bias is full on every rank and is
    added once after the reduction.
    """

    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.world_size = _world_size()
        self.rank = _rank()
        assert in_features % self.world_size == 0, \
            "in_features must be divisible by world_size"
        self.in_features = in_features
        self.out_features = out_features
        self.input_size_per_partition = in_features // self.world_size

        master_weight = master_weight.detach()
        assert tuple(master_weight.shape) == (out_features, in_features)
        shard = torch.chunk(master_weight, self.world_size, dim=1)[self.rank]
        self.weight = nn.Parameter(shard.clone().contiguous())

        if bias:
            self.bias = nn.Parameter(torch.zeros(
                out_features,
                dtype=master_weight.dtype, device=master_weight.device))
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        # Accept either the full input or an already-partitioned input.
        if self.world_size > 1 and x.shape[-1] == self.in_features:
            x = _ScatterToParallel.apply(x)
        partial = F.linear(x, self.weight)
        out = _ReduceFromParallel.apply(partial)
        if self.bias is not None:
            out = out + self.bias
        return out
