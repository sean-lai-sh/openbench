/* /* */
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
int main(int argc, char **argv) {
    long n = argc > 1 ? atol(argv[1]) : 0;
    std::vector<int> a(1, 1), b(1, 1);
    for (long i = 0; i < n; i++) {
        std::vector<int> c;
        int carry = 0;
        for (size_t j = 0; j < a.size() || j < b.size() || carry; j++) {
            int s = carry + (j < a.size() ? a[j] : 0) + (j < b.size() ? b[j] : 0);
            c.push_back(s % 10);
            carry = s / 10;
        }
        a = b;
        b = c;
    }
    std::string s;
    for (auto it = a.rbegin(); it != a.rend(); ++it) s += char('0' + *it);
    printf("%s\n", s.c_str());
    return 0;
}
// */ //\
fn main() {                                                                    //\
    let n: u64 = std::env::args().nth(1).and_then(|s| s.trim().parse().ok()).unwrap_or(0); //\
    let mut a: Vec<u8> = vec![1];                                              //\
    let mut b: Vec<u8> = vec![1];                                              //\
    for _ in 0..n {                                                            //\
        let mut c: Vec<u8> = Vec::with_capacity(b.len() + 1);                  //\
        let mut carry = 0u8;                                                   //\
        let mut j = 0;                                                         //\
        while j < a.len() || j < b.len() || carry > 0 {                        //\
            let s = carry + a.get(j).copied().unwrap_or(0) + b.get(j).copied().unwrap_or(0); //\
            c.push(s % 10);                                                    //\
            carry = s / 10;                                                    //\
            j += 1;                                                            //\
        }                                                                      //\
        a = std::mem::replace(&mut b, c);                                      //\
    }                                                                          //\
    let s: String = a.iter().rev().map(|d| (b'0' + d) as char).collect();      //\
    println!("{}", s);                                                         //\
}                                                                              //\
// end of polyglot
