#!/usr/bin/env python3
"""Hurdle jump analyzer.

Detects the takeoff and landing frames of a single hurdle jump in an MP4
video recorded from a (nearly) stationary camera.

Approach
--------
1. Frame 0 (no runner) is used as the background.
2. Every frame is registered to the background with ECC (homography) to
   remove small camera shake, then background-subtracted.
3. The athlete is the largest foreground blob; its lowest pixel (feet) is
   tracked over time.
4. The ground level of the athlete's feet is estimated from the frames where
   the athlete is running. The hurdle clearance is the period around the
   highest "lowest point" in which the feet stay clearly above the ground.
   Takeoff = last ground-contact frame before the clearance,
   landing = first ground-contact frame after it.

Usage: python jump_analyzer.py [video.mp4] [output.toml]
"""
import os
import sys

import cv2
import numpy as np

try:
    import toml
except ImportError:  # pragma: no cover - minimal fallback writer
    toml = None

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_VIDEO = os.path.join(HERE, "example_video.mp4")
DEFAULT_OUTPUT = os.path.join(HERE, "output.toml")

ECC_SCALE = 0.5
DIFF_THRESH = 35
MIN_BLOB_AREA = 1500
BORDER_MARGIN = 6


def read_frames(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open video: {path}")
    frames = []
    while True:
        ok, f = cap.read()
        if not ok:
            break
        frames.append(f)
    cap.release()
    if not frames:
        raise RuntimeError("Video contains no frames")
    return frames


def athlete_bottoms(frames):
    """Return per-frame (bottom_y, center_x, area, touches_border) of athlete."""
    bg = frames[0]
    H, W = bg.shape[:2]
    k3 = np.ones((3, 3), np.uint8)

    g0 = cv2.GaussianBlur(cv2.cvtColor(bg, cv2.COLOR_BGR2GRAY), (5, 5), 0)
    g0s = cv2.resize(g0, None, fx=ECC_SCALE, fy=ECC_SCALE)
    bgf = cv2.GaussianBlur(bg, (5, 5), 0).astype(np.int16)
    # Tolerate small residual misalignment: compare to local max/min of bg.
    bgmax = cv2.dilate(bgf, k3)
    bgmin = cv2.erode(bgf, k3)

    S_up = np.diag([1 / ECC_SCALE, 1 / ECC_SCALE, 1]).astype(np.float32)
    S_dn = np.diag([ECC_SCALE, ECC_SCALE, 1]).astype(np.float32)
    ones = np.ones((H, W), np.uint8)
    criteria = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 50, 1e-4)

    warp = np.eye(3, dtype=np.float32)
    results = []
    for f in frames:
        g = cv2.GaussianBlur(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY), (5, 5), 0)
        gs = cv2.resize(g, None, fx=ECC_SCALE, fy=ECC_SCALE)
        try:
            _, new_warp = cv2.findTransformECC(
                g0s, gs, warp.copy(), cv2.MOTION_HOMOGRAPHY, criteria, None, 1)
            warp = new_warp
        except cv2.error:
            pass
        Wf = S_up @ warp @ S_dn
        flags = cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP
        al = cv2.warpPerspective(cv2.GaussianBlur(f, (5, 5), 0), Wf, (W, H),
                                 flags=flags).astype(np.int16)
        valid = cv2.warpPerspective(ones, Wf, (W, H), flags=cv2.INTER_NEAREST
                                    | cv2.WARP_INVERSE_MAP)
        valid = cv2.erode(valid, np.ones((2 * BORDER_MARGIN + 1,) * 2, np.uint8))

        d = np.maximum(al - bgmax, bgmin - al).clip(0).max(axis=2)
        m = ((d > DIFF_THRESH) & (valid > 0)).astype(np.uint8)
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, k3)
        m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))

        # Merge nearby fragments of the body, keep the largest group.
        merged = cv2.dilate(m, np.ones((25, 25), np.uint8))
        n, lab, stats, _ = cv2.connectedComponentsWithStats(merged)
        best, best_area = -1, 0
        for j in range(1, n):
            area = int(m[lab == j].sum())
            if area > best_area:
                best, best_area = j, area
        if best < 0 or best_area < MIN_BLOB_AREA:
            results.append(None)
            continue
        body = (m > 0) & (lab == best)
        ys, xs = np.nonzero(body)
        bottom = int(np.percentile(ys, 99.8))
        touches = xs.min() <= BORDER_MARGIN + 2 or xs.max() >= W - BORDER_MARGIN - 3
        results.append((bottom, float(xs.mean()), best_area, bool(touches)))
    return results


def detect_jump(results):
    n = len(results)
    bottoms = np.full(n, np.nan)
    for i, r in enumerate(results):
        if r is not None:
            bottoms[i] = r[0]

    present = np.where(~np.isnan(bottoms))[0]
    if len(present) == 0:
        return 0, n - 1

    # Ground level of the feet: high percentile of the lowest point while
    # the athlete is fully in view (fallback: all present frames).
    full = [i for i in present if not results[i][3]]
    ref = full if len(full) >= 3 else list(present)
    ground = float(np.percentile(bottoms[ref], 75))
    # Tolerance proportional to athlete scale is overkill here (fixed scene);
    # use a fixed pixel margin.
    tol = 12.0
    contact = ~np.isnan(bottoms) & (bottoms >= ground - tol)
    airborne = ~np.isnan(bottoms) & (bottoms < ground - tol)

    # Find airborne runs (allowing NaN gaps of at most 1 frame) and pick the
    # one with the greatest height clearance (hurdle flight).
    best = None
    i = 0
    while i < n:
        if airborne[i]:
            j = i
            while j + 1 < n and (airborne[j + 1] or
                                 (np.isnan(bottoms[j + 1]) and j + 2 < n
                                  and airborne[j + 2])):
                j += 1
            seg = bottoms[i:j + 1]
            height = ground - np.nanmin(seg)
            score = height * (j - i + 1)
            if best is None or score > best[0]:
                best = (score, i, j)
            i = j + 1
        else:
            i += 1

    if best is None:
        # No flight found: fall back to the frame of minimum bottom.
        k = int(np.nanargmin(bottoms))
        return max(k - 1, 0), min(k + 1, n - 1)

    _, a, b = best
    takeoff = a - 1
    while takeoff > 0 and not contact[takeoff]:
        takeoff -= 1
    land = b + 1
    while land < n - 1 and not contact[land]:
        land += 1
    return max(takeoff, 0), min(land, n - 1)


def main():
    video = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_VIDEO
    out = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_OUTPUT
    frames = read_frames(video)
    results = athlete_bottoms(frames)
    takeoff, land = detect_jump(results)
    data = {
        "jump_takeoff_frame_number": int(takeoff),
        "jump_land_frame_number": int(land),
    }
    if toml is not None:
        text = toml.dumps(data)
    else:
        text = "".join(f"{k} = {v}\n" for k, v in data.items())
    with open(out, "w") as fh:
        fh.write(text)
    print(text, end="")


if __name__ == "__main__":
    main()
