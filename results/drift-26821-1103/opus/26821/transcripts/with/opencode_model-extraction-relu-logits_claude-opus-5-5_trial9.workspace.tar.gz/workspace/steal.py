"""Recover A1 (up to row permutation and scaling) of f(x) = A2 relu(A1 x + b1) + b2
using only black-box queries to forward(x).

Method: along random lines, locate the kinks of the piecewise-linear function
(each kink = one hidden neuron crossing zero). At each kink, the jump in the
gradient equals A2_i * A1_i, i.e. a scaled copy of row i of A1. Collect these
across many lines, normalise, and cluster to get one row per neuron.
"""
import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, a, b, fa, fb, sa, sb, depth=0, out=None):
    """Find kink parameters t in [a,b] of g(t)=f(x0+t d).
    sa = slope just right of a, sb = slope just left of b."""
    if out is None:
        out = []
    scale = max(1.0, abs(sa), abs(sb))
    if abs(sa - sb) < 1e-9 * scale or depth > 60:
        return out
    # Intersection of the two boundary lines
    tstar = (fb - fa + sa * a - sb * b) / (sa - sb)
    if a < tstar < b:
        ft = f(x0 + tstar * d)
        pred = fa + sa * (tstar - a)
        if abs(ft - pred) < 1e-9 * max(1.0, abs(ft)):
            out.append(tstar)  # exactly one kink
            return out
    m = 0.5 * (a + b)
    h = 1e-7 * max(1.0, b - a)
    fm = f(x0 + m * d)
    sl = (fm - f(x0 + (m - h) * d)) / h
    sr = (f(x0 + (m + h) * d) - fm) / h
    find_kinks(x0, d, a, m, fa, fm, sa, sl, depth + 1, out)
    find_kinks(x0, d, m, b, fm, fb, sr, sb, depth + 1, out)
    return out


def grad(x, h=1e-6):
    f0 = f(x)
    g = np.empty(DIM)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = h
        g[i] = (f(x + e) - f0) / h
    return g


def collect(n_lines=60, T=20.0):
    rows = []
    for _ in range(n_lines):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        a, b = -T, T
        h = 1e-6
        fa, fb = f(x0 + a * d), f(x0 + b * d)
        sa = (f(x0 + (a + h) * d) - fa) / h
        sb = (fb - f(x0 + (b - h) * d)) / h
        for t in find_kinks(x0, d, a, b, fa, fb, sa, sb):
            eps = 1e-4
            g1 = grad(x0 + (t - eps) * d)
            g2 = grad(x0 + (t + eps) * d)
            dg = g2 - g1
            n = np.linalg.norm(dg)
            if n < 1e-7:
                continue
            v = dg / n
            v *= np.sign(v[np.argmax(np.abs(v))])  # canonical sign
            rows.append(v)
    return np.array(rows)


def cluster(rows, tol=1e-3):
    centers, members = [], []
    for v in rows:
        for k, c in enumerate(centers):
            if abs(np.dot(c, v)) > 1 - tol:
                if np.dot(c, v) < 0:
                    v = -v
                members[k].append(v)
                centers[k] = np.mean(members[k], axis=0)
                centers[k] /= np.linalg.norm(centers[k])
                break
        else:
            centers.append(v)
            members.append([v])
    counts = np.array([len(m) for m in members])
    return np.array(centers), counts


def main():
    rows = collect()
    centers, counts = cluster(rows)
    # Drop spurious clusters seen only once if most neurons are seen many times
    keep = counts >= max(2, int(0.1 * np.median(counts)))
    A1_hat = centers[keep]
    np.save(OUT, A1_hat)
    print(f"Recovered {A1_hat.shape[0]} neurons (cluster counts: {sorted(counts.tolist())})")
    print(A1_hat)
    return A1_hat


if __name__ == "__main__":
    main()
