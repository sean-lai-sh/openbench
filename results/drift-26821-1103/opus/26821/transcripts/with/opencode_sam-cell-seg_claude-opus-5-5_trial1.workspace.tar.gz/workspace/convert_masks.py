#!/usr/bin/env python
"""Refine cell masks (rectangles and polylines) into polylines using MobileSAM.

For every annotation in the metadata csv, the bounding box (and, for polyline
annotations, the original polygon) is used to prompt MobileSAM. The predicted
masks are then post-processed so that:
  * every cell has exactly one contiguous mask,
  * no two masks overlap,
  * every mask is stored as a (non-rectangular) closed polyline.

Usage:
    python convert_masks.py --weights_path mobile_sam.pt --output_path out/ \
        --rgb_path demo_rgb.png --csv_path demo_metadata.csv
"""

import argparse
import os

import cv2
import numpy as np
import pandas as pd
import torch
from tqdm import tqdm

from mobile_sam import SamPredictor, sam_model_registry


# --------------------------------------------------------------------------- #
# Argument parsing / IO
# --------------------------------------------------------------------------- #
def parse_args():
    parser = argparse.ArgumentParser(
        description="Convert rectangle/polyline cell masks to refined polylines with MobileSAM."
    )
    names = {
        "weights_path": "Path to the MobileSAM weights (mobile_sam.pt).",
        "output_path": "Output folder (or .csv file path) where the new masks are saved.",
        "rgb_path": "Path to the RGB image.",
        "csv_path": "Path to the metadata csv.",
    }
    # Accept both positional usage (weights output rgb csv) and --flag usage.
    for name, help_str in names.items():
        parser.add_argument(f"pos_{name}", nargs="?", default=None, metavar=name, help=help_str)
    for name, help_str in names.items():
        parser.add_argument(f"--{name}", f"--{name.replace('_', '-')}", dest=name, type=str,
                            default=None, help=help_str)
    args = parser.parse_args()
    for name in names:
        if getattr(args, name) is None:
            setattr(args, name, getattr(args, f"pos_{name}"))
        if getattr(args, name) is None:
            parser.error(f"missing required argument: {name}")
    return args


def load_rgb(path):
    img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    if img is None:
        raise FileNotFoundError(f"Could not read image: {path}")
    if img.dtype != np.uint8:
        img = img.astype(np.float32)
        img = (255.0 * (img - img.min()) / max(float(img.max() - img.min()), 1e-6)).astype(np.uint8)
    if img.ndim == 2:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
    elif img.shape[2] == 4:
        img = cv2.cvtColor(img, cv2.COLOR_BGRA2RGB)
    else:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return np.ascontiguousarray(img)


def parse_coords(value):
    if isinstance(value, (list, tuple, np.ndarray)):
        return [float(v) for v in value]
    s = str(value).strip().strip("[]()")
    if not s or s.lower() == "nan":
        return []
    return [float(v) for v in s.replace(";", ",").replace(" ", ",").split(",") if v != ""]


def resolve_output_file(output_path, csv_path):
    if output_path.lower().endswith(".csv"):
        parent = os.path.dirname(os.path.abspath(output_path))
        os.makedirs(parent, exist_ok=True)
        return output_path
    os.makedirs(output_path, exist_ok=True)
    return os.path.join(output_path, os.path.basename(csv_path))


# --------------------------------------------------------------------------- #
# Geometry helpers
# --------------------------------------------------------------------------- #
def polygon_mask(xs, ys, shape):
    m = np.zeros(shape, dtype=np.uint8)
    if len(xs) >= 3:
        pts = np.round(np.stack([xs, ys], axis=1)).astype(np.int32)
        cv2.fillPoly(m, [pts], 1)
    elif len(xs) > 0:
        for x, y in zip(xs, ys):
            xi, yi = int(round(x)), int(round(y))
            if 0 <= yi < shape[0] and 0 <= xi < shape[1]:
                m[yi, xi] = 1
    return m.astype(bool)


def ellipse_mask(box, shape):
    """Ellipse inscribed in a box; used as a non-rectangular fallback."""
    x0, y0, x1, y1 = box
    m = np.zeros(shape, dtype=np.uint8)
    cx, cy = int(round((x0 + x1) / 2)), int(round((y0 + y1) / 2))
    ax, ay = max(int(round((x1 - x0) / 2)) - 1, 2), max(int(round((y1 - y0) / 2)) - 1, 2)
    cv2.ellipse(m, (cx, cy), (ax, ay), 0, 0, 360, 1, -1)
    return m.astype(bool)


def largest_component(mask):
    mask = mask.astype(np.uint8)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=4)
    if n <= 1:
        return mask.astype(bool)
    idx = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return lab == idx


def fill_holes(mask):
    mask_u8 = mask.astype(np.uint8)
    contours, _ = cv2.findContours(mask_u8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    filled = np.zeros_like(mask_u8)
    cv2.drawContours(filled, contours, -1, 1, thickness=-1)
    return filled.astype(bool)


def is_axis_aligned_rectangle(xs, ys):
    pts = set(zip(np.round(xs).astype(int).tolist(), np.round(ys).astype(int).tolist()))
    if len(pts) != 4:
        return False
    ux = {p[0] for p in pts}
    uy = {p[1] for p in pts}
    return len(ux) == 2 and len(uy) == 2


def mask_to_polyline(mask):
    """Return (xs, ys) of the outer contour of a single-component mask, closed."""
    mask_u8 = mask.astype(np.uint8)
    contours, _ = cv2.findContours(mask_u8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    c = max(contours, key=cv2.contourArea).reshape(-1, 2)
    if len(c) < 3:
        return None
    c = np.concatenate([c, c[:1]], axis=0)  # close polyline (first == last)
    return c[:, 0].astype(int), c[:, 1].astype(int)


# --------------------------------------------------------------------------- #
# SAM prediction
# --------------------------------------------------------------------------- #
def iou(a, b):
    inter = np.logical_and(a, b).sum()
    union = np.logical_or(a, b).sum()
    return inter / union if union > 0 else 0.0


def predict_cell(predictor, box, prior_mask, is_rect, shape):
    """Run MobileSAM for one cell. Returns (binary mask, logits map)."""
    H, W = shape
    x0, y0, x1, y1 = box
    bw, bh = x1 - x0, y1 - y0

    # Small padding: polygon annotations are drawn tight, SAM likes a bit of context.
    pad = 2 if not is_rect else 0
    prompt_box = np.array([max(x0 - pad, 0), max(y0 - pad, 0),
                           min(x1 + pad, W - 1), min(y1 + pad, H - 1)], dtype=np.float32)

    # Positive point: a point well inside the prior mask (distance transform max).
    dist = cv2.distanceTransform(prior_mask.astype(np.uint8), cv2.DIST_L2, 3)
    if dist.max() > 0:
        py, px = np.unravel_index(int(np.argmax(dist)), dist.shape)
    else:
        px, py = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    point = np.array([[px, py]], dtype=np.float32)

    candidates = []
    for use_point in (False, True):
        masks, scores, _ = predictor.predict(
            point_coords=point if use_point else None,
            point_labels=np.array([1]) if use_point else None,
            box=prompt_box,
            multimask_output=True,
            return_logits=True,
        )
        for logit, score in zip(masks, scores):
            candidates.append((logit, float(score)))

    # Restrict every candidate to a region slightly larger than the box
    margin = int(round(0.15 * max(bw, bh))) + 2
    region = np.zeros(shape, dtype=bool)
    region[max(y0 - margin, 0):min(y1 + margin, H - 1) + 1,
           max(x0 - margin, 0):min(x1 + margin, W - 1) + 1] = True
    box_region = np.zeros(shape, dtype=bool)
    box_region[max(y0, 0):min(y1, H - 1) + 1, max(x0, 0):min(x1, W - 1) + 1] = True
    box_area = max(box_region.sum(), 1)

    best, best_score = None, -np.inf
    for logit, score in candidates:
        m = (logit > predictor.model.mask_threshold) & region
        area = m.sum()
        if area < 5:
            continue
        m = largest_component(m)
        inside = np.logical_and(m, box_region).sum() / max(m.sum(), 1)
        fill = m.sum() / box_area
        if is_rect:
            # Rectangle: cell should lie inside the box and occupy a good part of it,
            # but not the whole rectangle (that would just be background/box).
            fill_term = 1.0 - abs(fill - 0.6) if fill <= 0.95 else 0.2
            s = score + 1.0 * inside + 0.5 * fill_term
        else:
            s = score + 2.0 * iou(m, prior_mask) + 0.5 * inside
        if s > best_score:
            best_score, best = s, (m, logit)

    if best is None:
        fallback = prior_mask if not is_rect else ellipse_mask(box, shape)
        logit = np.where(fallback, 1.0, -1.0).astype(np.float32)
        return fallback, logit
    m, logit = best
    return m, np.where(region, logit, -np.inf).astype(np.float32)


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main():
    args = parse_args()
    torch.set_grad_enabled(False)
    device = "cpu"

    image = load_rgb(args.rgb_path)
    H, W = image.shape[:2]

    # Preserve the csv structure (a leading unnamed index column if present).
    with open(args.csv_path, "r") as f:
        header = f.readline()
    has_index_col = header.startswith(",")
    df = pd.read_csv(args.csv_path, index_col=0 if has_index_col else None)
    n = len(df)

    sam = sam_model_registry["vit_t"](checkpoint=args.weights_path)
    sam.to(device=device)
    sam.eval()
    predictor = SamPredictor(sam)
    predictor.set_image(image)

    masks = []
    logits = []
    boxes = []
    for i in tqdm(range(n), desc="MobileSAM"):
        row = df.iloc[i]
        xs = np.asarray(parse_coords(row["coords_x"]), dtype=float)
        ys = np.asarray(parse_coords(row["coords_y"]), dtype=float)
        if len(xs) == 0 or len(xs) != len(ys):
            xs = np.array([row["xmin"], row["xmax"], row["xmax"], row["xmin"]], dtype=float)
            ys = np.array([row["ymin"], row["ymin"], row["ymax"], row["ymax"]], dtype=float)
        x0 = int(np.clip(np.floor(min(xs.min(), row["xmin"])), 0, W - 1))
        x1 = int(np.clip(np.ceil(max(xs.max(), row["xmax"])), 0, W - 1))
        y0 = int(np.clip(np.floor(min(ys.min(), row["ymin"])), 0, H - 1))
        y1 = int(np.clip(np.ceil(max(ys.max(), row["ymax"])), 0, H - 1))
        if x1 <= x0:
            x1 = min(x0 + 1, W - 1); x0 = max(x1 - 1, 0)
        if y1 <= y0:
            y1 = min(y0 + 1, H - 1); y0 = max(y1 - 1, 0)
        box = (x0, y0, x1, y1)

        type_str = str(row["type"]).lower() if "type" in df.columns else ""
        is_rect = ("rect" in type_str) or is_axis_aligned_rectangle(xs, ys)
        prior = ellipse_mask(box, (H, W)) if is_rect else polygon_mask(xs, ys, (H, W))
        if prior.sum() == 0:
            prior = ellipse_mask(box, (H, W))

        m, lg = predict_cell(predictor, box, prior, is_rect, (H, W))
        masks.append(m)
        logits.append(lg)
        boxes.append(box)

    # ---------------- Resolve overlaps: contested pixel -> highest SAM logit --- #
    stack_logits = np.full((n, H, W), -np.inf, dtype=np.float32) if n else None
    for i in range(n):
        stack_logits[i][masks[i]] = logits[i][masks[i]]
    labels = np.full((H, W), -1, dtype=np.int32)
    if n:
        claimed = np.isfinite(stack_logits).any(axis=0)
        labels[claimed] = np.argmax(stack_logits, axis=0)[claimed]
    del stack_logits

    final_masks = [None] * n
    # Process small cells first so they get priority over leftovers of big ones.
    order = sorted(range(n), key=lambda k: masks[k].sum())
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    for i in order:
        m = labels == i
        if m.sum() == 0:
            continue
        m = largest_component(m)
        # Fill holes only with pixels that nobody else owns.
        filled = fill_holes(m)
        m = m | (filled & (labels == -1))
        # Light smoothing to remove spurs / one pixel bridges.
        if m.sum() > 30:
            opened = cv2.morphologyEx(m.astype(np.uint8), cv2.MORPH_OPEN, kernel).astype(bool)
            if opened.sum() > 0.5 * m.sum():
                m = largest_component(opened)
        labels[(labels == i) & ~m] = -1
        labels[m] = i

    # Guarantee a one-pixel gap between neighbouring cells so polygons never overlap.
    for i in range(n):
        m = labels == i
        if not m.any():
            continue
        # Only the later cell gives up border pixels, the earlier one keeps them.
        others_earlier = (labels >= 0) & (labels < i)
        near = cv2.dilate(others_earlier.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool)
        m2 = m & ~near
        m2 = largest_component(m2) if m2.sum() >= 3 else np.zeros_like(m)
        labels[m & ~m2] = -1
        final_masks[i] = m2

    # Rebuild any cell that ended up empty (fallback: small ellipse in free space).
    occupied = labels >= 0
    for i in range(n):
        m = final_masks[i]
        if m is not None and m.sum() >= 3:
            continue
        free = ~cv2.dilate(occupied.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool)
        cand = ellipse_mask(boxes[i], (H, W)) & free
        if cand.sum() < 3:
            cand = masks[i] & free
        if cand.sum() < 3:
            # last resort: a tiny diamond around the box centre in free space
            x0, y0, x1, y1 = boxes[i]
            cx, cy = (x0 + x1) // 2, (y0 + y1) // 2
            cand = np.zeros((H, W), dtype=bool)
            cv2.fillPoly(cand.view(np.uint8), [np.array([[cx, cy - 2], [cx + 2, cy],
                                                         [cx, cy + 2], [cx - 2, cy]])], 1)
        cand = largest_component(cand)
        final_masks[i] = cand
        occupied |= cand
        labels[cand] = i

    # ---------------- Convert to polylines and write csv ---------------------- #
    out = df.copy()
    for col in ("coords_x", "coords_y"):
        out[col] = out[col].astype(object)
    new_xmin, new_xmax, new_ymin, new_ymax, new_cx, new_cy = [], [], [], [], [], []
    for i in range(n):
        poly = mask_to_polyline(final_masks[i])
        if poly is None or is_axis_aligned_rectangle(poly[0][:-1], poly[1][:-1]):
            # Make sure the result is never a rectangle: fall back to an octagon-like
            # shape obtained from the (cut) ellipse contour.
            m = final_masks[i]
            ys_, xs_ = np.nonzero(m)
            if len(xs_) == 0:
                x0, y0, x1, y1 = boxes[i]
            else:
                x0, y0, x1, y1 = xs_.min(), ys_.min(), xs_.max(), ys_.max()
            cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
            rx, ry = max((x1 - x0) / 2.0, 1.0), max((y1 - y0) / 2.0, 1.0)
            ang = np.linspace(0, 2 * np.pi, 9)
            px = np.clip(np.round(cx + rx * np.cos(ang)), x0, x1).astype(int)
            py = np.clip(np.round(cy + ry * np.sin(ang)), y0, y1).astype(int)
            px[-1], py[-1] = px[0], py[0]
            poly = (px, py)
        px, py = poly
        new_xmin.append(int(px.min())); new_xmax.append(int(px.max()))
        new_ymin.append(int(py.min())); new_ymax.append(int(py.max()))
        new_cx.append(",".join(str(int(v)) for v in px))
        new_cy.append(",".join(str(int(v)) for v in py))

    out["xmin"] = new_xmin
    out["xmax"] = new_xmax
    out["ymin"] = new_ymin
    out["ymax"] = new_ymax
    out["coords_x"] = new_cx
    out["coords_y"] = new_cy
    if "type" in out.columns:
        out["type"] = "polyline"

    out_file = resolve_output_file(args.output_path, args.csv_path)
    out.to_csv(out_file, index=has_index_col)
    print(f"Saved {n} refined polyline masks to {out_file}")


if __name__ == "__main__":
    main()
