"""Pipeline-parallel training step (AFAB schedule) for LlamaForCausalLM."""

import torch
import torch.distributed as dist
import torch.nn.functional as F

try:
    from transformers.masking_utils import create_causal_mask
except Exception:  # pragma: no cover - older transformers
    create_causal_mask = None


# ----------------------------------------------------------------------------
# Partitioning
# ----------------------------------------------------------------------------
def get_layer_range(num_layers, rank, world_size):
    """Split ``num_layers`` contiguous layers across ``world_size`` stages as
    evenly as possible (earlier stages get the remainder)."""
    base, rem = divmod(num_layers, world_size)
    start = rank * base + min(rank, rem)
    end = start + base + (1 if rank < rem else 0)
    return start, end


# ----------------------------------------------------------------------------
# Communication helpers
# ----------------------------------------------------------------------------
def _p2p(op, tensor, peer):
    reqs = dist.batch_isend_irecv([dist.P2POp(op, tensor, peer)])
    for r in reqs:
        r.wait()


def _send(tensor, dst):
    _p2p(dist.isend, tensor.contiguous(), dst)


def _recv(shape, src, device, dtype):
    buf = torch.empty(shape, device=device, dtype=dtype)
    _p2p(dist.irecv, buf, src)
    return buf


# ----------------------------------------------------------------------------
# Stage forward
# ----------------------------------------------------------------------------
def _build_mask(model, hidden_states, position_ids):
    config = model.config
    if create_causal_mask is not None:
        try:
            return create_causal_mask(
                config=config,
                inputs_embeds=hidden_states,
                attention_mask=None,
                past_key_values=None,
                position_ids=position_ids,
            )
        except TypeError:
            pass
    # Fallback: explicit additive causal mask.
    bsz, seq_len = hidden_states.shape[:2]
    mask = torch.full(
        (seq_len, seq_len), torch.finfo(hidden_states.dtype).min,
        device=hidden_states.device, dtype=hidden_states.dtype,
    ).triu(1)
    return mask[None, None].expand(bsz, 1, seq_len, seq_len)


def _stage_forward(model, hidden_states, start, end):
    """Run decoder layers [start, end) of ``model`` on ``hidden_states``."""
    llama = model.model
    seq_len = hidden_states.shape[1]
    position_ids = torch.arange(seq_len, device=hidden_states.device).unsqueeze(0)
    mask = _build_mask(model, hidden_states, position_ids)
    position_embeddings = llama.rotary_emb(hidden_states, position_ids=position_ids)
    for layer in llama.layers[start:end]:
        out = layer(
            hidden_states,
            attention_mask=mask,
            position_ids=position_ids,
            position_embeddings=position_embeddings,
            use_cache=False,
        )
        hidden_states = out[0] if isinstance(out, (tuple, list)) else out
    return hidden_states


# ----------------------------------------------------------------------------
# Training step
# ----------------------------------------------------------------------------
def train_step_pipeline_afab(model, inputs, targets, device, dtype):
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    is_first = rank == 0
    is_last = rank == world_size - 1
    prev_rank, next_rank = rank - 1, rank + 1

    num_layers = model.config.num_hidden_layers
    start, end = get_layer_range(num_layers, rank, world_size)
    hidden_size = model.config.hidden_size
    num_micro = len(inputs)

    stage_inputs = []   # per-microbatch input activations of this stage
    stage_outputs = []  # per-microbatch outputs (hidden states or loss)
    total_loss = torch.zeros((), device=device, dtype=torch.float32)

    # ------------------------- all forward -------------------------
    for i in range(num_micro):
        mb_shape = tuple(inputs[i].shape[:2])  # [microbatch, seq_len]
        if is_first:
            input_ids = inputs[i].to(device)
            hidden = model.model.embed_tokens(input_ids).to(device=device, dtype=dtype)
            stage_in = None
        else:
            hidden = _recv(mb_shape + (hidden_size,), prev_rank, device, dtype)
            hidden.requires_grad_(True)
            stage_in = hidden

        out = _stage_forward(model, hidden, start, end)

        if is_last:
            out = model.model.norm(out)
            logits = model.lm_head(out)
            tgt = targets[i].to(device)
            loss = F.cross_entropy(
                logits.reshape(-1, logits.size(-1)).float(), tgt.reshape(-1)
            ) / num_micro
            total_loss = total_loss + loss.detach()
            stage_outputs.append(loss)
        else:
            out = out.to(device=device, dtype=dtype)
            _send(out.detach(), next_rank)
            stage_outputs.append(out)
        stage_inputs.append(stage_in)

    # ------------------------- all backward ------------------------
    for i in range(num_micro):
        mb_shape = tuple(inputs[i].shape[:2])
        out = stage_outputs[i]
        if is_last:
            out.backward()
        else:
            grad = _recv(mb_shape + (hidden_size,), next_rank, device, dtype)
            torch.autograd.backward(out, grad_tensors=grad)

        if not is_first:
            stage_in = stage_inputs[i]
            grad_in = stage_in.grad
            if grad_in is None:
                grad_in = torch.zeros_like(stage_in)
            _send(grad_in.to(device=device, dtype=dtype), prev_rank)

        stage_inputs[i] = None
        stage_outputs[i] = None

    return total_loss if is_last else None
