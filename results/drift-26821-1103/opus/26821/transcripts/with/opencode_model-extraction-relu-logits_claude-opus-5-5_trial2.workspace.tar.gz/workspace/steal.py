"""Extract A1 (up to neuron permutation and row scaling) from a 1-hidden-layer
ReLU network using only black-box queries to forward(x).

Method: along random lines the network is piecewise linear; each kink is a
point where some hidden neuron's pre-activation crosses zero. At each kink we
measure the gradient on both sides; the jump in gradient is proportional to the
corresponding row of A1. Rows are then deduplicated.
"""
import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi):
    """Return t values of kinks of g(t)=f(x0+t d) in [lo, hi]."""
    g = lambda t: f(x0 + t * d)
    kinks = []

    def rec(a, ga, b, gb, depth):
        m = 0.5 * (a + b)
        gm = g(m)
        lin = 0.5 * (ga + gb)
        scale = max(1.0, abs(ga), abs(gb))
        if abs(gm - lin) <= 1e-11 * scale and depth > 4:
            return
        if b - a < 1e-6:
            # locate kink precisely by intersecting the two adjacent linear pieces
            h = (b - a) * 1e-3
            sl = (g(a + h) - ga) / h
            sr = (gb - g(b - h)) / h
            if abs(sl - sr) < 1e-9:
                return
            t = (gb - ga + sl * a - sr * b) / (sl - sr)
            if a - 1e-9 <= t <= b + 1e-9:
                kinks.append(t)
            return
        rec(a, ga, m, gm, depth + 1)
        rec(m, gm, b, gb, depth + 1)

    rec(lo, g(lo), hi, g(hi), 0)
    return kinks


def gradient(x, h=1e-7):
    f0 = f(x)
    gr = np.zeros(DIM)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = h
        gr[i] = (f(x + e) - f(x - e)) / (2 * h)
    return gr


def row_at_kink(x0, d, t, eps=1e-4):
    gp = gradient(x0 + (t + eps) * d)
    gm = gradient(x0 + (t - eps) * d)
    diff = gp - gm
    n = np.linalg.norm(diff)
    if n < 1e-8:
        return None
    v = diff / n
    k = np.argmax(np.abs(v))
    return v * np.sign(v[k])


def main():
    rows = []
    no_new = 0
    for it in range(400):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        found_new = False
        for t in find_kinks(x0, d, -20.0, 20.0):
            v = row_at_kink(x0, d, t)
            if v is None:
                continue
            if not any(abs(np.dot(v, r)) > 0.9999 for r in rows):
                rows.append(v)
                found_new = True
        no_new = 0 if found_new else no_new + 1
        if no_new >= 30 and len(rows) > 0:
            break

    A = np.array(rows)
    np.save(OUT, A)
    print(f"Recovered {A.shape[0]} neurons; saved to {OUT}")
    print(A)
    return A


if __name__ == "__main__":
    main()
