"""Pipeline-parallel training step (all-forward-all-backward) for LlamaForCausalLM."""

import torch
import torch.distributed as dist
import torch.nn.functional as F


def _partition_layers(num_layers, world_size, rank):
    """Return (start, end) indices of decoder layers owned by `rank`.

    Layers are split as evenly as possible; leftover layers go to the first ranks.
    """
    base, rem = divmod(num_layers, world_size)
    start = rank * base + min(rank, rem)
    end = start + base + (1 if rank < rem else 0)
    return start, end


def _build_causal_mask(model, hidden_states, position_ids):
    """Build the attention mask exactly as LlamaModel.forward would."""
    config = model.config
    try:
        from transformers.masking_utils import create_causal_mask

        try:
            return create_causal_mask(
                config=config,
                inputs_embeds=hidden_states,
                attention_mask=None,
                past_key_values=None,
                position_ids=position_ids,
            )
        except TypeError:
            # Older transformers versions require cache_position.
            seq_len = hidden_states.shape[1]
            cache_position = torch.arange(seq_len, device=hidden_states.device)
            return create_causal_mask(
                config=config,
                input_embeds=hidden_states,
                attention_mask=None,
                cache_position=cache_position,
                past_key_values=None,
                position_ids=position_ids,
            )
    except Exception:
        pass

    # Fallback: explicit additive 4D causal mask.
    bsz, seq_len = hidden_states.shape[:2]
    min_val = torch.finfo(hidden_states.dtype).min
    mask = torch.full(
        (seq_len, seq_len), min_val, device=hidden_states.device, dtype=hidden_states.dtype
    )
    mask = torch.triu(mask, diagonal=1)
    return mask[None, None, :, :].expand(bsz, 1, seq_len, seq_len)


def _p2p(op, tensor, peer):
    """Blocking point-to-point communication using P2POp."""
    reqs = dist.batch_isend_irecv([dist.P2POp(op, tensor, peer)])
    for req in reqs:
        req.wait()


def _stage_forward(model, x, rank, world_size, start, end, device, dtype):
    """Run this rank's portion of the model on input `x`."""
    base = model.model

    if rank == 0:
        hidden = base.embed_tokens(x.to(device)).to(dtype)
    else:
        hidden = x

    seq_len = hidden.shape[1]
    position_ids = torch.arange(seq_len, device=device).unsqueeze(0)
    position_embeddings = base.rotary_emb(hidden, position_ids=position_ids)
    attention_mask = _build_causal_mask(model, hidden, position_ids)

    for layer in base.layers[start:end]:
        out = layer(
            hidden,
            attention_mask=attention_mask,
            position_ids=position_ids,
            position_embeddings=position_embeddings,
            past_key_values=None,
            use_cache=False,
        )
        hidden = out[0] if isinstance(out, tuple) else out

    if rank == world_size - 1:
        hidden = base.norm(hidden)
        return model.lm_head(hidden)

    return hidden.to(dtype)


def train_step_pipeline_afab(model, inputs, targets, device, dtype):
    """One training step with AFAB pipeline-parallel scheduling.

    Returns the accumulated (microbatch-scaled) loss on the last rank, None elsewhere.
    """
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    prev_rank = rank - 1
    next_rank = rank + 1
    is_first = rank == 0
    is_last = rank == world_size - 1

    num_layers = len(model.model.layers)
    start, end = _partition_layers(num_layers, world_size, rank)
    hidden_size = model.config.hidden_size
    num_microbatches = len(inputs)

    stage_inputs = []
    stage_outputs = []
    total_loss = None

    # ---------------- All forward ----------------
    for i in range(num_microbatches):
        mb_shape = inputs[i].shape  # [microbatch, seq_len]

        if is_first:
            x = inputs[i].to(device)
            input_tensor = None
        else:
            x = torch.empty(
                (mb_shape[0], mb_shape[1], hidden_size), device=device, dtype=dtype
            )
            _p2p(dist.irecv, x, prev_rank)
            x = x.to(device=device, dtype=dtype).requires_grad_(True)
            input_tensor = x

        out = _stage_forward(model, x, rank, world_size, start, end, device, dtype)

        if is_last:
            logits = out
            tgt = targets[i].to(device)
            loss = F.cross_entropy(
                logits.reshape(-1, logits.shape[-1]).float(), tgt.reshape(-1)
            )
            loss = loss / num_microbatches
            total_loss = loss.detach() if total_loss is None else total_loss + loss.detach()
            out = loss
        else:
            send_t = out.detach().to(device=device, dtype=dtype).contiguous()
            _p2p(dist.isend, send_t, next_rank)

        stage_inputs.append(input_tensor)
        stage_outputs.append(out)

    # ---------------- All backward ----------------
    for i in range(num_microbatches):
        input_tensor = stage_inputs.pop(0)
        output = stage_outputs.pop(0)
        mb_shape = inputs[i].shape

        if is_last:
            torch.autograd.backward(output)
        else:
            grad = torch.empty(
                (mb_shape[0], mb_shape[1], hidden_size), device=device, dtype=dtype
            )
            _p2p(dist.irecv, grad, next_rank)
            grad = grad.to(device=device, dtype=dtype)
            torch.autograd.backward(output, grad_tensors=grad.to(output.dtype))

        if not is_first:
            g = input_tensor.grad
            if g is None:
                g = torch.zeros_like(input_tensor)
            g = g.to(device=device, dtype=dtype).contiguous()
            _p2p(dist.isend, g, prev_rank)

    return total_loss
