#!/usr/bin/env python3
"""Detect hurdle jump takeoff and landing frames in an MP4 video.

Approach:
  1. Use the first frame (empty track) as the background model.
  2. For every frame, segment the athlete via background subtraction.
  3. Track the lowest point of the athlete (foot position) over time.
  4. Estimate the ground-contact level of the feet; frames where the lowest
     point is clearly above it are "airborne".
  5. The hurdle clearance is the longest airborne phase (preferring the one
     that crosses the hurdle). Takeoff = last ground-contact frame before it,
     landing = first ground-contact frame after it.

Usage: python3 jump_analyzer.py [video.mp4] [output.toml]
"""
import os
import sys

import cv2
import numpy as np
import toml

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_VIDEO = os.path.join(SCRIPT_DIR, "example_video.mp4")
DEFAULT_OUTPUT = os.path.join(SCRIPT_DIR, "output.toml")

DIFF_THRESH = 35        # per-channel abs difference to count as foreground
MIN_ROW = 150           # ignore region above (trees / sky flicker)
MIN_BLOB_AREA = 1500    # minimum athlete blob area (lower body region)
EDGE_MARGIN = 3         # blob touching the image border => partially visible
HURDLE_X = 490          # approximate x position of the hurdle (fixed camera)


def read_frames(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise RuntimeError("Cannot open video: %s" % path)
    frames = []
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frames.append(frame)
    cap.release()
    if not frames:
        raise RuntimeError("No frames in video: %s" % path)
    return frames


def athlete_measure(frame, bg):
    """Return (bottom_y, x_min, x_max, center_x, full_visible) or None."""
    h, w = frame.shape[:2]
    f = cv2.GaussianBlur(frame, (5, 5), 0).astype(np.int16)
    d = np.abs(f - bg).max(axis=2)
    m = (d > DIFF_THRESH).astype(np.uint8)
    m[:MIN_ROW] = 0
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((15, 15), np.uint8))
    n, labels, st, _ = cv2.connectedComponentsWithStats(m)
    if n < 2:
        return None
    areas = st[1:, cv2.CC_STAT_AREA]
    k = 1 + int(np.argmax(areas))
    if st[k, cv2.CC_STAT_AREA] < MIN_BLOB_AREA:
        return None
    x0 = st[k, cv2.CC_STAT_LEFT]
    x1 = x0 + st[k, cv2.CC_STAT_WIDTH]
    # merge nearby fragments (feet / limbs that got split from the body)
    pad = 80
    bottom = st[k, cv2.CC_STAT_TOP] + st[k, cv2.CC_STAT_HEIGHT] - 1
    xmin, xmax = x0, x1
    for j in range(1, n):
        if j == k or st[j, cv2.CC_STAT_AREA] < 40:
            continue
        jx0 = st[j, cv2.CC_STAT_LEFT]
        jx1 = jx0 + st[j, cv2.CC_STAT_WIDTH]
        if jx1 >= x0 - pad and jx0 <= x1 + pad:
            bottom = max(bottom, st[j, cv2.CC_STAT_TOP] + st[j, cv2.CC_STAT_HEIGHT] - 1)
            xmin = min(xmin, jx0)
            xmax = max(xmax, jx1)
    full = xmin > EDGE_MARGIN and xmax < w - EDGE_MARGIN
    return bottom, xmin, xmax, 0.5 * (xmin + xmax), full


def runs(mask):
    out, start = [], None
    for i, v in enumerate(mask):
        if v and start is None:
            start = i
        elif not v and start is not None:
            out.append((start, i - 1))
            start = None
    if start is not None:
        out.append((start, len(mask) - 1))
    return out


def analyze(path):
    frames = read_frames(path)
    bg = cv2.GaussianBlur(frames[0], (5, 5), 0).astype(np.int16)
    meas = [athlete_measure(fr, bg) for fr in frames]
    n = len(frames)

    valid = [i for i, m in enumerate(meas) if m is not None]
    if not valid:
        return 0, 0
    bottoms = np.array([meas[i][0] for i in valid], dtype=float)
    full_b = [meas[i][0] for i in valid if meas[i][4]]
    ref = np.array(full_b if len(full_b) >= 3 else bottoms, dtype=float)
    ground = np.percentile(ref, 90)
    # Feet in stance are within a few px of the ground level; even a slight
    # lift of the foot moves its lowest point up >15 px at this scale.
    margin = 12.0

    airborne = np.zeros(n, dtype=bool)
    for i in valid:
        airborne[i] = meas[i][0] < ground - margin

    # Fill single missing detections inside an airborne phase
    for i in range(1, n - 1):
        if meas[i] is None and airborne[i - 1] and airborne[i + 1]:
            airborne[i] = True

    candidates = []
    for s, e in runs(airborne):
        # need a ground contact frame on both sides
        if s - 1 < 0 or e + 1 >= n or meas[s - 1] is None or meas[e + 1] is None:
            continue
        xs = [meas[i][3] for i in range(s - 1, e + 2) if meas[i] is not None]
        crosses = min(xs) - 40 <= HURDLE_X <= max(xs) + 40
        candidates.append(((crosses, e - s + 1), s, e))
    if not candidates:
        # fall back to any airborne run
        rs = runs(airborne)
        if not rs:
            i = valid[int(np.argmin(bottoms))]
            return max(i - 1, 0), min(i + 1, n - 1)
        s, e = max(rs, key=lambda r: r[1] - r[0])
    else:
        _, s, e = max(candidates, key=lambda c: c[0])

    takeoff = max(s - 1, 0)
    land = min(e + 1, n - 1)
    return int(takeoff), int(land)


def main():
    video = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_VIDEO
    out = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_OUTPUT
    takeoff, land = analyze(video)
    result = {
        "jump_takeoff_frame_number": takeoff,
        "jump_land_frame_number": land,
    }
    with open(out, "w") as fh:
        toml.dump(result, fh)
    print(toml.dumps(result), end="")


if __name__ == "__main__":
    main()
