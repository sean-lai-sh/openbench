/* /* */
#include <cstdio>
#include <cstdlib>
#include <string>
int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "usage: %s N\n", argv[0]); return 1; }
    long n = atol(argv[1]);
    unsigned __int128 a = 1, b = 1;
    for (long i = 0; i < n; i++) { unsigned __int128 t = a + b; a = b; b = t; }
    std::string s;
    do { s.insert(s.begin(), (char)(48 + (int)(a % 10))); a /= 10; } while (a > 0);
    printf("%s\n", s.c_str());
    return 0;
}
#if 0
// */
fn main() {
    let n: u64 = std::env::args().nth(1).expect("usage: main N").trim().parse().expect("N must be a non-negative integer");
    let (mut a, mut b): (u128, u128) = (1, 1);
    for _ in 0..n {
        let t = a + b;
        a = b;
        b = t;
    }
    println!("{}", a);
}
/* /* */
#endif
// */
