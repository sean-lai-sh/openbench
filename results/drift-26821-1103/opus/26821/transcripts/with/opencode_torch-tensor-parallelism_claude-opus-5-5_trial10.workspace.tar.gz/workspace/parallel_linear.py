import torch
import torch.distributed as dist
import torch.nn as nn
import torch.nn.functional as F


def _world_size():
    if dist.is_available() and dist.is_initialized():
        return dist.get_world_size()
    return 1


def _rank():
    if dist.is_available() and dist.is_initialized():
        return dist.get_rank()
    return 0


def _all_reduce(x):
    if _world_size() == 1:
        return x
    x = x.contiguous().clone()
    dist.all_reduce(x, op=dist.ReduceOp.SUM)
    return x


def _all_gather_last_dim(x):
    ws = _world_size()
    if ws == 1:
        return x
    x = x.contiguous()
    parts = [torch.empty_like(x) for _ in range(ws)]
    dist.all_gather(parts, x)
    return torch.cat(parts, dim=-1).contiguous()


def _split_last_dim(x):
    ws = _world_size()
    if ws == 1:
        return x
    return torch.chunk(x, ws, dim=-1)[_rank()].contiguous()


class _CopyToParallelRegion(torch.autograd.Function):
    """Forward: identity. Backward: all-reduce gradient."""

    @staticmethod
    def forward(ctx, x):
        return x

    @staticmethod
    def backward(ctx, grad):
        return _all_reduce(grad)


class _ReduceFromParallelRegion(torch.autograd.Function):
    """Forward: all-reduce. Backward: identity."""

    @staticmethod
    def forward(ctx, x):
        return _all_reduce(x)

    @staticmethod
    def backward(ctx, grad):
        return grad


class _ScatterToParallelRegion(torch.autograd.Function):
    """Forward: take local chunk of last dim. Backward: all-gather gradient."""

    @staticmethod
    def forward(ctx, x):
        return _split_last_dim(x)

    @staticmethod
    def backward(ctx, grad):
        return _all_gather_last_dim(grad)


class _GatherFromParallelRegion(torch.autograd.Function):
    """Forward: all-gather along last dim. Backward: take local chunk."""

    @staticmethod
    def forward(ctx, x):
        return _all_gather_last_dim(x)

    @staticmethod
    def backward(ctx, grad):
        return _split_last_dim(grad)


class ColumnParallelLinear(nn.Module):
    """Y = X W^T + b, with W (out_features, in_features) split along the
    output dimension (columns of A = W^T). Outputs are all-gathered."""

    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        ws = _world_size()
        rank = _rank()
        assert out_features % ws == 0, "out_features must be divisible by world_size"
        self.in_features = in_features
        self.out_features = out_features
        self.world_size = ws
        self.rank = rank
        self.out_features_per_partition = out_features // ws

        master_weight = master_weight.detach()
        assert tuple(master_weight.shape) == (out_features, in_features)
        shard = torch.chunk(master_weight, ws, dim=0)[rank].clone().contiguous()
        self.weight = nn.Parameter(shard)

        if bias:
            self.bias = nn.Parameter(
                torch.zeros(self.out_features_per_partition,
                            dtype=master_weight.dtype, device=master_weight.device)
            )
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        x = _CopyToParallelRegion.apply(x)
        local_out = F.linear(x, self.weight, self.bias)
        return _GatherFromParallelRegion.apply(local_out)


class RowParallelLinear(nn.Module):
    """Y = X W^T + b, with W (out_features, in_features) split along the
    input dimension (rows of A = W^T). Partial outputs are all-reduced."""

    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        ws = _world_size()
        rank = _rank()
        assert in_features % ws == 0, "in_features must be divisible by world_size"
        self.in_features = in_features
        self.out_features = out_features
        self.world_size = ws
        self.rank = rank
        self.in_features_per_partition = in_features // ws

        master_weight = master_weight.detach()
        assert tuple(master_weight.shape) == (out_features, in_features)
        shard = torch.chunk(master_weight, ws, dim=1)[rank].clone().contiguous()
        self.weight = nn.Parameter(shard)

        if bias:
            self.bias = nn.Parameter(
                torch.zeros(out_features,
                            dtype=master_weight.dtype, device=master_weight.device)
            )
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        # Accept either the full input or an already-partitioned input.
        if x.shape[-1] == self.in_features and self.world_size > 1:
            x = _ScatterToParallelRegion.apply(x)
        partial = F.linear(x, self.weight)
        out = _ReduceFromParallelRegion.apply(partial)
        if self.bias is not None:
            out = out + self.bias
        return out
