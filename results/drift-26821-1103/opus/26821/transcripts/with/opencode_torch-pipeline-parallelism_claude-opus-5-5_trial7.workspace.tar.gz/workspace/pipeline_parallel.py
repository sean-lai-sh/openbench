"""Pipeline-parallel training step (AFAB schedule) for HuggingFace LlamaForCausalLM."""

import torch
import torch.distributed as dist
import torch.nn.functional as F


def _partition_layers(num_layers, world_size, rank):
    """Return [start, end) layer range for `rank`, spreading the remainder over the first ranks."""
    base, rem = divmod(num_layers, world_size)
    start = rank * base + min(rank, rem)
    end = start + base + (1 if rank < rem else 0)
    return start, end


def _build_causal_mask(model, hidden_states, position_ids):
    """Build the attention mask exactly as LlamaModel.forward would (no padding mask)."""
    try:
        from transformers.masking_utils import create_causal_mask

        return create_causal_mask(
            config=model.config,
            inputs_embeds=hidden_states,
            attention_mask=None,
            past_key_values=None,
            position_ids=position_ids,
        )
    except Exception:
        # Fallback: explicit additive 4D causal mask [1, 1, seq, seq].
        seq_len = hidden_states.shape[1]
        min_val = torch.finfo(hidden_states.dtype).min
        mask = torch.full((seq_len, seq_len), min_val, device=hidden_states.device, dtype=hidden_states.dtype)
        mask = torch.triu(mask, diagonal=1)
        return mask[None, None, :, :]


def _p2p(op, tensor, peer):
    reqs = dist.batch_isend_irecv([dist.P2POp(op, tensor, peer)])
    for req in reqs:
        req.wait()


def train_step_pipeline_afab(model, inputs, targets, device, dtype):
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    is_first = rank == 0
    is_last = rank == world_size - 1

    llama = model.model
    config = model.config
    hidden_size = config.hidden_size
    num_layers = config.num_hidden_layers
    start, end = _partition_layers(num_layers, world_size, rank)
    local_layers = [llama.layers[i] for i in range(start, end)]

    num_micro = len(inputs)
    input_tensors = []   # stage inputs (hidden states received from previous stage), per microbatch
    output_tensors = []  # stage outputs (hidden states or loss), per microbatch
    total_loss = torch.zeros((), device=device, dtype=torch.float32) if is_last else None

    # ------------------------------------------------------------------ #
    # All forward
    # ------------------------------------------------------------------ #
    for mb in range(num_micro):
        input_ids = inputs[mb].to(device)
        mb_size, seq_len = input_ids.shape[0], input_ids.shape[1]

        if is_first:
            hidden = llama.embed_tokens(input_ids).to(device=device, dtype=dtype)
            stage_input = None
        else:
            stage_input = torch.empty((mb_size, seq_len, hidden_size), device=device, dtype=dtype)
            _p2p(dist.irecv, stage_input, rank - 1)
            stage_input.requires_grad_(True)
            hidden = stage_input

        position_ids = torch.arange(seq_len, device=device).unsqueeze(0)
        causal_mask = _build_causal_mask(llama, hidden, position_ids)
        position_embeddings = llama.rotary_emb(hidden, position_ids=position_ids)

        for layer in local_layers:
            hidden = layer(
                hidden,
                attention_mask=causal_mask,
                position_embeddings=position_embeddings,
                position_ids=position_ids,
                past_key_values=None,
                use_cache=False,
            )
            if isinstance(hidden, (tuple, list)):
                hidden = hidden[0]

        if is_last:
            hidden = llama.norm(hidden)
            logits = model.lm_head(hidden)
            tgt = targets[mb].to(device)
            loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), tgt.reshape(-1))
            loss = loss / num_micro
            total_loss += loss.detach().float()
            output = loss
        else:
            output = hidden
            _p2p(dist.isend, hidden.detach().to(device=device, dtype=dtype).contiguous(), rank + 1)

        input_tensors.append(stage_input)
        output_tensors.append(output)

    # ------------------------------------------------------------------ #
    # All backward
    # ------------------------------------------------------------------ #
    for mb in range(num_micro):
        stage_input = input_tensors[mb]
        output = output_tensors[mb]

        if is_last:
            output.backward()
        else:
            grad_output = torch.empty_like(output, device=device, dtype=dtype)
            _p2p(dist.irecv, grad_output, rank + 1)
            torch.autograd.backward(output, grad_tensors=grad_output.to(output.dtype))

        if not is_first:
            grad_input = stage_input.grad
            if grad_input is None:
                grad_input = torch.zeros_like(stage_input)
            _p2p(dist.isend, grad_input.to(device=device, dtype=dtype).contiguous(), rank - 1)

        input_tensors[mb] = None
        output_tensors[mb] = None

    return total_loss
