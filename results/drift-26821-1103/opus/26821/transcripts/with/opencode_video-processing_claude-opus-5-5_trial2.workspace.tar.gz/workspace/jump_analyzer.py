#!/usr/bin/env python3
"""Hurdle jump analyzer.

Detects the takeoff and landing frames of a single hurdle jump in a video
recorded from a stationary camera. The first frame is assumed to contain no
runner and is used as the background model.

Usage:
    python jump_analyzer.py [input.mp4] [output.toml]
"""
import os
import sys

import cv2
import numpy as np
try:
    import toml
except ImportError:  # pragma: no cover
    toml = None

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_INPUT = os.path.join(SCRIPT_DIR, "example_video.mp4")
DEFAULT_OUTPUT = os.path.join(SCRIPT_DIR, "output.toml")

DIFF_THRESH = 35          # per-pixel colour difference threshold
MIN_BLOB_AREA = 1500      # minimum area (pixels) of the runner blob
AIR_MARGIN = 9            # px above ground level considered "airborne"
HURDLE_X = (480, 630)     # horizontal extent of the hurdle in the image


def read_frames(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise RuntimeError("Cannot open video: %s" % path)
    frames = []
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frames.append(frame)
    cap.release()
    if not frames:
        raise RuntimeError("Video contains no frames: %s" % path)
    return frames


def preprocess(frame):
    return cv2.GaussianBlur(frame, (5, 5), 0).astype(np.int16)


def align_to_background(frame, g0, win):
    """Compensate small camera shake by a global translation."""
    g = np.float32(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY))
    (dx, dy), _ = cv2.phaseCorrelate(g0, g, win)
    if abs(dx) < 0.05 and abs(dy) < 0.05:
        return frame
    M = np.float32([[1, 0, -dx], [0, 1, -dy]])
    return cv2.warpAffine(frame, M, (frame.shape[1], frame.shape[0]),
                          flags=cv2.INTER_LINEAR,
                          borderMode=cv2.BORDER_REPLICATE)


def detect_runner(frame_p, bg_p, kernel_open, kernel_close):
    """Return (bottom_y, top_y, x_min, x_max, area) of the runner blob or None."""
    diff = np.abs(frame_p - bg_p)
    # Compensate global illumination changes (clouds / auto exposure)
    med = np.median(diff.reshape(-1, 3), axis=0)
    diff = np.clip(diff - med, 0, None).max(axis=2)
    mask = (diff > DIFF_THRESH).astype(np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel_open)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel_close)

    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask, 8)
    if n <= 1:
        return None
    idx = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    area = stats[idx, cv2.CC_STAT_AREA]
    if area < MIN_BLOB_AREA:
        return None
    x, y, w, h = (stats[idx, cv2.CC_STAT_LEFT], stats[idx, cv2.CC_STAT_TOP],
                  stats[idx, cv2.CC_STAT_WIDTH], stats[idx, cv2.CC_STAT_HEIGHT])
    # A person is taller than a thin strip of noise
    if h < 60:
        return None
    return (y + h - 1, y, x, x + w - 1, area)


def analyze(path):
    frames = read_frames(path)
    H, W = frames[0].shape[:2]
    bg = preprocess(frames[0])
    k_open = np.ones((3, 3), np.uint8)
    k_close = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))

    g0 = np.float32(cv2.cvtColor(frames[0], cv2.COLOR_BGR2GRAY))
    win = cv2.createHanningWindow((W, H), cv2.CV_32F)
    dets = [None]
    for f in frames[1:]:
        f = align_to_background(f, g0, win)
        dets.append(detect_runner(preprocess(f), bg, k_open, k_close))
    n = len(frames)
    bottom = np.full(n, np.nan)
    for i, d in enumerate(dets):
        if d is not None:
            bottom[i] = d[0]

    valid = np.where(~np.isnan(bottom))[0]
    if len(valid) < 3:
        return 0, max(0, n - 1)

    # Ground level of the feet: robust high percentile of the blob bottoms
    # among frames where the runner is reasonably inside the image.
    inside = [i for i in valid
              if dets[i][2] > 2 and dets[i][3] < W - 3]
    ref = inside if len(inside) >= 3 else list(valid)
    ground = float(np.percentile(bottom[ref], 75))

    # Height of the lowest point above the ground per frame
    elev = ground - bottom  # NaN where undetected

    # Find longest run of consecutive airborne frames (the hurdle clearance)
    air = np.zeros(n, bool)
    for i in valid:
        air[i] = elev[i] > AIR_MARGIN
    best = None
    i = 0
    while i < n:
        if air[i]:
            j = i
            while j + 1 < n and air[j + 1]:
                j += 1
            over = any(dets[k] is not None and
                       dets[k][2] <= HURDLE_X[1] and dets[k][3] >= HURDLE_X[0]
                       for k in range(i, j + 1))
            score = (int(over), j - i + 1, float(np.nanmax(elev[i:j + 1])))
            if best is None or score > best[0]:
                best = (score, i, j)
            i = j + 1
        else:
            i += 1

    if best is None:
        # Fallback: frame of maximum elevation +/- a few frames
        peak = int(valid[np.nanargmax(elev[valid])])
        return max(0, peak - 4), min(n - 1, peak + 4)

    _, s, e = best
    takeoff = max(0, s - 1)      # last frame with ground contact before flight
    land = min(n - 1, e + 1)     # first frame with ground contact after flight
    return int(takeoff), int(land)


def main():
    inp = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_INPUT
    out = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_OUTPUT
    takeoff, land = analyze(inp)
    result = {
        "jump_takeoff_frame_number": int(takeoff),
        "jump_land_frame_number": int(land),
    }
    if toml is not None:
        text = toml.dumps(result)
    else:
        text = "".join("%s = %d\n" % (k, v) for k, v in result.items())
    with open(out, "w") as f:
        f.write(text)
    print(text, end="")


if __name__ == "__main__":
    main()
