import json, os

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "re.json")
rules = []
R = lambda p, r: rules.append([p, r])

FILES = "abcdefgh"
EMPTY = "[.*]"
TARGET = "[^PNBRQK]"  # empty, ep-square or black piece


def rc(i):
    return divmod(i, 8)


def idx(r, c):
    return r * 8 + c


def onb(r, c):
    return 0 <= r < 8 and 0 <= c < 8


# ---------------- 1. parse FEN ----------------
R(r"^(\S+) w (\S+) (\S+) \S+ \S+$", r"S\1 \2 \3")
for n in range(8, 0, -1):
    R(str(n) + r"(?=\S* )", "." * n)
R(r"/", "")
CASTLES = []
for m in range(16):
    full = "".join(ch if m >> i & 1 else "-" for i, ch in enumerate("KQkq"))
    fen = full.replace("-", "") or "-"
    CASTLES.append((full, fen))
for full, fen in CASTLES:
    R(r"^(S.{64}) " + fen + " ", r"\1 " + full + " ")
for f in range(8):
    R(r"^(S.{%d}).(.{%d} .{4}) %s6$" % (16 + f, 47 - f, FILES[f]), r"\1*\2")
R(r"^(S.{64} .{4}) -$", r"\1")

# ---------------- 2. move generation ----------------


ORTH = [(-1, 0), (1, 0), (0, -1), (0, 1)]
DIAG = [(-1, -1), (-1, 1), (1, -1), (1, 1)]
KN = [(1, 2), (2, 1), (-1, 2), (-2, 1), (1, -2), (2, -1), (-1, -2), (-2, -1)]

# Piece-carrying moves need the moving piece's char copied to dst.


def carry_rule(s, d, pcs, empties, newpiece=None, ep="-", extra=None, rest=r" .{4}"):
    # build pattern capturing piece at s, replace s with '.', d with piece
    conds = {p: EMPTY for p in empties}
    if extra:
        conds.update(extra)
    allidx = sorted(set(conds) | {s, d})
    pat = "(?m)^S"
    rep = r"\g<0>" + "\nM"
    g = 0
    pos = 0
    parts = []
    pg = None
    for i in allidx:
        pat += "(.{%d})" % (i - pos)
        g += 1
        parts.append(r"\g<%d>" % g)
        if i == s:
            pat += "([" + pcs + "])"
            g += 1
            pg = g
            parts.append(".")
        elif i == d:
            pat += TARGET if d not in conds else conds[d]
            parts.append("@D@")
        else:
            if conds[i] is None:  # removal square (ep): set to '.'
                pat += "."
                parts.append(".")
            else:
                pat += "(" + conds[i] + ")"
                g += 1
                parts.append(r"\g<%d>" % g)
        pos = i + 1
    pat += "(.{%d})(%s)$" % (64 - pos, rest)
    pieces = newpiece if newpiece else r"\g<%d>" % pg
    rep += "".join(pieces if p == "@D@" else p for p in parts)
    rep += r"\g<%d>\g<%d> %s" % (g + 1, g + 2, ep)
    R(pat, rep)


for s in range(64):
    r, c = rc(s)
    for dirs, sl in ((ORTH, "QR"), (DIAG, "QB")):
        for dr, dc in dirs:
            path = []
            m = 1
            while onb(r + dr * m, c + dc * m):
                d = idx(r + dr * m, c + dc * m)
                carry_rule(s, d, sl + ("K" if m == 1 else ""), list(path))
                path.append(d)
                m += 1
    for dr, dc in KN:
        if onb(r + dr, c + dc):
            carry_rule(s, idx(r + dr, c + dc), "N", [])
    # pawns
    if 1 <= r <= 6:
        d = s - 8
        promo = "Q" if r == 1 else None
        carry_rule(s, d, "P", [], newpiece=promo, extra={d: EMPTY})
        if r == 6:
            carry_rule(s, s - 16, "P", [s - 8], ep=FILES[c] + "3", extra={s - 16: EMPTY})
        for dc in (-1, 1):
            if 0 <= c + dc < 8:
                d = s - 8 + dc
                carry_rule(s, d, "P", [], newpiece=promo, extra={d: "[pnbrq]"})
                if r == 3:  # en passant
                    carry_rule(s, d, "P", [], extra={d: r"\*", d + 8: None})

# castling
carry_rule(60, 62, "K", [61], extra={62: EMPTY, 63: "R"}, rest=r" K.{3}")
carry_rule(60, 58, "K", [57, 59], extra={58: EMPTY, 56: "R"}, rest=r" .Q.{2}")

# The castle rules above produce K on g1/c1 with '.' on e1; mark passing squares with X
# by post-fixup that identifies castle lines via a tag. Simpler: tweak replacements now.
rules[-2][1] = rules[-2][1].replace("\nM", "\nC")
rules[-1][1] = rules[-1][1].replace("\nM", "\nC")

# remove source line
R(r"(?m)^S.*\n?", "")
R(r"\*", ".")
# castle lines: kingside e1 . f1 . g1 K h1 R  -> X X K R ; queenside R . K . . -> R . K X X
R(r"(?m)^C(.{60})\.\.KR", r"M\1XXKR")
R(r"(?m)^C(.{56})R\.K\.\.", r"M\1R.KXX")

# ---------------- 3. legality filter ----------------


def lin(conds):
    items = sorted(conds.items())
    out = ""
    pos = 0
    for i, cl in items:
        out += ".{%d}" % (i - pos) + cl
        pos = i + 1
    return out


for k in range(64):
    r, c = rc(k)
    alts = []
    for dc in (-1, 1):
        if onb(r - 1, c + dc):
            alts.append(lin({idx(r - 1, c + dc): "p"}))
    for dr, dc in KN:
        if onb(r + dr, c + dc):
            alts.append(lin({idx(r + dr, c + dc): "n"}))
    for dr, dc in ORTH + DIAG:
        if onb(r + dr, c + dc):
            alts.append(lin({idx(r + dr, c + dc): "k"}))
    for dirs, cl in ((ORTH, "[qr]"), (DIAG, "[qb]")):
        for dr, dc in dirs:
            path = []
            m = 1
            while onb(r + dr * m, c + dc * m):
                d = idx(r + dr * m, c + dc * m)
                cd = {p: r"\." for p in path}
                cd[d] = cl
                alts.append(lin(cd))
                path.append(d)
                m += 1
    R(r"(?m)^M(?=.{%d}[KX])(?=%s).*\n?" % (k, "|".join(alts)), "")

R(r"(?m)^M(.{60})XXKR", r"M\1.RK.")
R(r"(?m)^M(.{56})R\.KXX", r"M\1..KR.")

# ---------------- 4. castling rights ----------------
R(r"(?m)^(M(?=.{60}[^K]).{64} )..", r"\1--")
R(r"(?m)^(M(?=.{63}[^R]).{64} ).", r"\1-")
R(r"(?m)^(M(?=.{56}[^R]).{64} .).", r"\1-")
R(r"(?m)^(M(?=.{4}[^k]).{64} ..)..", r"\1--")
R(r"(?m)^(M(?=.{7}[^r]).{64} ..).", r"\1-")
R(r"(?m)^(M(?=[^r]).{64} ...).", r"\1-")

# ---------------- 5. output ----------------
R(r"\n+", "\n")
R(r"\A\n", "")
R(r"\n\Z", "")
R(r"(?m)^M" + "(.{8})" * 8 + " ", "/".join(r"\%d" % i for i in range(1, 9)).join(["M", " b "]))
for n in range(8, 0, -1):
    R(r"\." * n, str(n))
for full, fen in CASTLES:
    R(" b " + full + " ", " b " + fen + " ")
R(r"(?m)^M(.*)$", r"\1 0 0")

json.dump(rules, open(OUT, "w"))
print(len(rules), os.path.getsize(OUT))
