import torch
import torch.distributed as dist
import torch.nn as nn
import torch.nn.functional as F


def _world_size():
    if dist.is_available() and dist.is_initialized():
        return dist.get_world_size()
    return 1


def _rank():
    if dist.is_available() and dist.is_initialized():
        return dist.get_rank()
    return 0


def _all_reduce(x):
    if _world_size() == 1:
        return x
    x = x.contiguous().clone()
    dist.all_reduce(x, op=dist.ReduceOp.SUM)
    return x


def _split_last(x):
    ws = _world_size()
    if ws == 1:
        return x
    return torch.chunk(x, ws, dim=-1)[_rank()].contiguous()


def _gather_last(x):
    ws = _world_size()
    if ws == 1:
        return x
    x = x.contiguous()
    parts = [torch.empty_like(x) for _ in range(ws)]
    dist.all_gather(parts, x)
    return torch.cat(parts, dim=-1).contiguous()


class _CopyToParallelRegion(torch.autograd.Function):
    """Identity in forward, all-reduce of gradient in backward."""

    @staticmethod
    def forward(ctx, x):
        return x

    @staticmethod
    def backward(ctx, grad):
        return _all_reduce(grad)


class _ReduceFromParallelRegion(torch.autograd.Function):
    """All-reduce in forward, identity in backward."""

    @staticmethod
    def forward(ctx, x):
        return _all_reduce(x)

    @staticmethod
    def backward(ctx, grad):
        return grad


class _ScatterToParallelRegion(torch.autograd.Function):
    """Split along last dim in forward, all-gather in backward."""

    @staticmethod
    def forward(ctx, x):
        return _split_last(x)

    @staticmethod
    def backward(ctx, grad):
        return _gather_last(grad)


class _GatherFromParallelRegion(torch.autograd.Function):
    """All-gather along last dim in forward, split in backward."""

    @staticmethod
    def forward(ctx, x):
        return _gather_last(x)

    @staticmethod
    def backward(ctx, grad):
        return _split_last(grad)


class ColumnParallelLinear(nn.Module):
    """Y = XA + b with A split along its output dimension.

    master_weight has shape (out_features, in_features) (nn.Linear layout).
    Each rank holds weight of shape (out_features // world_size, in_features)
    and bias of shape (out_features // world_size,). The output is gathered
    along the last dimension so each rank returns the full output.
    """

    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.world_size = _world_size()
        self.rank = _rank()
        assert out_features % self.world_size == 0, \
            "out_features must be divisible by world_size"
        self.out_features_per_partition = out_features // self.world_size

        master_weight = torch.as_tensor(master_weight)
        assert tuple(master_weight.shape) == (out_features, in_features)
        start = self.rank * self.out_features_per_partition
        end = start + self.out_features_per_partition
        self.weight = nn.Parameter(master_weight[start:end, :].detach().clone().contiguous())

        if bias:
            self.bias = nn.Parameter(torch.zeros(
                self.out_features_per_partition,
                dtype=self.weight.dtype, device=self.weight.device))
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        x = _CopyToParallelRegion.apply(x)
        out = F.linear(x, self.weight, self.bias)
        return _GatherFromParallelRegion.apply(out)


class RowParallelLinear(nn.Module):
    """Y = XA + b with A split along its input dimension.

    master_weight has shape (out_features, in_features) (nn.Linear layout).
    Each rank holds weight of shape (out_features, in_features // world_size).
    Partial outputs are summed (all-reduce); the bias is kept full on each
    rank and added once after the reduction.

    The input may be either the full input (last dim == in_features), in which
    case it is split across ranks, or the already-partitioned input
    (last dim == in_features // world_size).
    """

    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.world_size = _world_size()
        self.rank = _rank()
        assert in_features % self.world_size == 0, \
            "in_features must be divisible by world_size"
        self.in_features_per_partition = in_features // self.world_size

        master_weight = torch.as_tensor(master_weight)
        assert tuple(master_weight.shape) == (out_features, in_features)
        start = self.rank * self.in_features_per_partition
        end = start + self.in_features_per_partition
        self.weight = nn.Parameter(master_weight[:, start:end].detach().clone().contiguous())

        if bias:
            self.bias = nn.Parameter(torch.zeros(
                out_features, dtype=self.weight.dtype, device=self.weight.device))
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        if self.world_size > 1 and x.shape[-1] == self.in_features:
            x = _ScatterToParallelRegion.apply(x)
        partial = F.linear(x, self.weight)
        out = _ReduceFromParallelRegion.apply(partial)
        if self.bias is not None:
            out = out + self.bias
        return out
