import json
from itertools import product

# Internal line layout (white-to-move source line starts with "O-"):
#   pos 0: status  O (original) / M (candidate move) / X (illegal)
#   pos 1: tag     '-' normal, 'k' kingside castle, 'q' queenside castle
#   pos 2..65: board, index 0 = a8 ... 63 = h1, '.' = empty
#   pos 66..69: castling rights "KQkq" with '-' for missing
#   pos 70: en-passant file letter or '-'
# Below "rel" positions are relative to pos 2 (board index i -> rel i,
# castling 64..67, ep 68).

R = []


def add(p, r):
    R.append([p, r])


# ---------------- Phase 1: parse ----------------
for d in range(8, 0, -1):
    add(r"%d(?=[^ ]* w )" % d, "." * d)
add(r"/", "")
add(r"^(\S+) w (\S+) ([a-h])6 \S+ \S+$", r"\g<1> w \g<2> \g<3>")
add(r"^(\S+) w (\S+) - \S+ \S+$", r"\g<1> w \g<2> -")
CAST = "KQkq"
combos = []
for bits in product([0, 1], repeat=4):
    s = "".join(c for c, b in zip(CAST, bits) if b) or "-"
    f = "".join(c if b else "-" for c, b in zip(CAST, bits))
    combos.append((s, f))
for s, f in combos:
    add(r"^(\S+) w %s " % s, r"O-\g<1>%s" % f)


# ---------------- Phase 2: move generation ----------------
def move(conds, changes, tag="-", ep="-"):
    changes = dict(changes)
    changes[68] = ep
    parts, repl = [], []
    g = 0
    run = 0

    def flush():
        nonlocal run, g
        if run:
            g += 1
            parts.append("(.{%d})" % run)
            repl.append(r"\g<%d>" % g)
            run = 0

    for p in range(69):
        if p not in conds and p not in changes:
            run += 1
            continue
        flush()
        c = conds.get(p, ".")
        if p in changes:
            parts.append(c)
            repl.append(changes[p])
        else:
            g += 1
            parts.append("(%s)" % c)
            repl.append(r"\g<%d>" % g)
    flush()
    add("(?m)^(?=O-" + "".join(parts) + "$)", "M" + tag + "".join(repl) + "\n")


def sq(r, c):
    return r * 8 + c


def inb(r, c):
    return 0 <= r < 8 and 0 <= c < 8


TARGET = "[.a-z]"
KN = [(1, 2), (2, 1), (-1, 2), (-2, 1), (1, -2), (2, -1), (-1, -2), (-2, -1)]
KG = [(a, b) for a in (-1, 0, 1) for b in (-1, 0, 1) if (a, b) != (0, 0)]
ORTH = [(0, 1), (0, -1), (1, 0), (-1, 0)]
DIAG = [(1, 1), (1, -1), (-1, 1), (-1, -1)]

for r in range(8):
    for c in range(8):
        s = sq(r, c)
        # leapers
        for piece, offs in (("N", KN), ("K", KG)):
            for dr, dc in offs:
                if inb(r + dr, c + dc):
                    t = sq(r + dr, c + dc)
                    move({s: piece, t: TARGET}, {s: ".", t: piece})
        # sliders
        for piece, dirs in (("R", ORTH), ("B", DIAG), ("Q", ORTH + DIAG)):
            for dr, dc in dirs:
                path = []
                rr, cc = r + dr, c + dc
                while inb(rr, cc):
                    t = sq(rr, cc)
                    conds = {s: piece, t: TARGET}
                    for p in path:
                        conds[p] = r"\."
                    move(conds, {s: ".", t: piece})
                    path.append(t)
                    rr += dr
                    cc += dc
        # pawns
        if 1 <= r <= 6:
            promo = "Q" if r == 1 else "P"
            t = sq(r - 1, c)
            move({s: "P", t: r"\."}, {s: ".", t: promo})
            if r == 6:
                t2 = sq(r - 2, c)
                move({s: "P", t: r"\.", t2: r"\."}, {s: ".", t2: "P"},
                     ep="abcdefgh"[c])
            for dc in (-1, 1):
                if inb(r - 1, c + dc):
                    t = sq(r - 1, c + dc)
                    move({s: "P", t: "[a-z]"}, {s: ".", t: promo})
                    if r == 3:
                        cap = sq(r, c + dc)
                        move({s: "P", t: r"\.", cap: "p", 68: "abcdefgh"[c + dc]},
                             {s: ".", t: "P", cap: "."})

# castling (temporarily mark every king-traversed square with K)
move({60: "K", 61: r"\.", 62: r"\.", 63: "R", 64: "K"},
     {60: "K", 61: "K", 62: "K", 63: "."}, tag="k")
move({60: "K", 59: r"\.", 58: r"\.", 57: r"\.", 56: "R", 65: "Q"},
     {60: "K", 59: "K", 58: "K", 57: ".", 56: "."}, tag="q")


# ---------------- Phase 3: legality filter ----------------
def linear(conds):
    # conds: rel pos -> class; build pattern starting at rel pos 0 (pos 2)
    out, cur = [], 0
    for p in sorted(conds):
        if p > cur:
            out.append(".{%d}" % (p - cur))
        out.append(conds[p])
        cur = p + 1
    return "".join(out)


for r in range(8):
    for c in range(8):
        k = sq(r, c)
        alts = []
        for dc in (-1, 1):
            if inb(r - 1, c + dc):
                alts.append({sq(r - 1, c + dc): "p"})
        for dr, dc in KN:
            if inb(r + dr, c + dc):
                alts.append({sq(r + dr, c + dc): "n"})
        for dr, dc in KG:
            if inb(r + dr, c + dc):
                alts.append({sq(r + dr, c + dc): "k"})
        for cls, dirs in (("[rq]", ORTH), ("[bq]", DIAG)):
            for dr, dc in dirs:
                path = []
                rr, cc = r + dr, c + dc
                while inb(rr, cc):
                    a = sq(rr, cc)
                    d = {a: cls}
                    for p in path:
                        d[p] = r"\."
                    alts.append(d)
                    path.append(a)
                    rr += dr
                    cc += dc
        pat = "(?m)^M(?=.{%d}K)(?=.(?:%s))" % (k + 1, "|".join(linear(a) for a in alts))
        add(pat, "X")

add(r"(?m)^[XO].*\n", "")
add(r"(?m)\n[XO].*", "")
add(r"^[XO].*", "")

# castling fixups
add(r"(?m)^Mk(.{60})KKK", r"M-\g<1>.RK")
add(r"(?m)^Mq(.{58})KKK", r"M-\g<1>KR.")


# castling-right updates
def lose(sqi, piece, idx):
    after = 66 + idx - (2 + sqi) - 1
    add(r"(?m)^(M.{%d}[^%s].{%d})%s" % (sqi + 1, piece, after, CAST[idx]), r"\g<1>-")


lose(60, "K", 0)
lose(60, "K", 1)
lose(63, "R", 0)
lose(56, "R", 1)
lose(7, "r", 2)
lose(0, "r", 3)

# ---------------- Phase 4: output ----------------
add(r"(?m)^(M.{69})-$", r"\g<1> - 0 0")
add(r"(?m)^(M.{69})([a-h])$", r"\g<1> \g<2>3 0 0")
for s, f in combos:
    add(r"(?m)^(M.{65})%s " % f, r"\g<1>%s " % s)
add(r"(?m)^M." + "(.{8})" * 8, "/".join(r"\g<%d>" % i for i in range(1, 9)) + " b ")
for d in range(8, 0, -1):
    add(r"\.{%d}" % d, str(d))

json.dump(R, open("/tmp/obench-cell-i8gsjpth/bench_opencode_regex-chess_4k68zkx0/re.json", "w"))
print(len(R))
