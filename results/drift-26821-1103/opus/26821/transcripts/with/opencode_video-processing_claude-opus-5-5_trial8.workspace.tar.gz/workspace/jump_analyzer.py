#!/usr/bin/env python3
"""Hurdle jump analyzer.

Detects the takeoff and landing frames of a single hurdle jump in an MP4 video
recorded with a static camera.

Approach:
  1. The first frame contains no runner -> use it as background.
  2. For each frame, segment the athlete by background subtraction and keep the
     largest connected blob (after dilation, so that body parts split by the
     segmentation are merged).
  3. Track the lowest point (max y) of the athlete silhouette = lowest foot.
  4. Estimate the ground level of the foot contacts, and mark frames where the
     lowest point is clearly above the ground as "airborne".
  5. The hurdle clearance is the longest airborne run. Takeoff is the last
     frame with ground contact before it, landing the first frame with ground
     contact after it.

Usage:
    python3 jump_analyzer.py [input.mp4] [output.toml]
"""

import os
import sys

import cv2
import numpy as np
import toml

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_INPUT = os.path.join(HERE, "example_video.mp4")
DEFAULT_OUTPUT = os.path.join(HERE, "output.toml")

DIFF_THRESHOLD = 35        # per-channel abs difference to background
MIN_ATHLETE_AREA = 1500    # min foreground pixels of the athlete blob
EDGE_MARGIN = 5            # px; blobs touching the side borders are partial
AIR_MARGIN = 9             # px above ground to be considered airborne


def read_frames(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open video: {path}")
    frames = []
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frames.append(frame)
    cap.release()
    if not frames:
        raise RuntimeError(f"No frames in video: {path}")
    return frames


def athlete_measure(frame, background):
    """Return (bottom_y, x_center, touches_edge, area) or None."""
    blur = cv2.GaussianBlur(frame, (5, 5), 0).astype(np.int16)
    diff = np.abs(blur - background).max(axis=2)
    mask = (diff > DIFF_THRESHOLD).astype(np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    if int(mask.sum()) < MIN_ATHLETE_AREA:
        return None

    # Merge fragmented body parts and pick the largest blob.
    merged = cv2.dilate(mask, np.ones((25, 25), np.uint8))
    n, labels, stats, _ = cv2.connectedComponentsWithStats(merged)
    if n <= 1:
        return None
    best, best_area = None, 0
    for lbl in range(1, n):
        area = int(mask[labels == lbl].sum())
        if area > best_area:
            best, best_area = lbl, area
    if best_area < MIN_ATHLETE_AREA:
        return None

    athlete = (labels == best) & (mask > 0)
    ys, xs = np.nonzero(athlete)
    bottom = int(ys.max())
    w = frame.shape[1]
    touches = xs.min() <= EDGE_MARGIN or xs.max() >= w - 1 - EDGE_MARGIN
    return bottom, float(xs.mean()), bool(touches), best_area


def find_jump(bottoms, valid):
    """bottoms: array of lowest silhouette y per frame (nan if absent)."""
    idx = np.where(valid)[0]
    if len(idx) < 3:
        raise RuntimeError("Athlete not detected reliably")
    vals = bottoms[idx]

    # Ground level: foot contacts are the lowest points of the silhouette.
    # Use a robust high percentile, refined with a linear trend over x is not
    # needed since the track is nearly horizontal in the image.
    ground = float(np.percentile(vals, 80))
    airborne = np.zeros(len(bottoms), dtype=bool)
    airborne[idx] = bottoms[idx] < ground - AIR_MARGIN

    # Runs of airborne frames (only through valid frames).
    runs = []
    start = None
    for i in range(len(bottoms)):
        if airborne[i]:
            if start is None:
                start = i
        else:
            if start is not None:
                runs.append((start, i - 1))
                start = None
    if start is not None:
        runs.append((start, len(bottoms) - 1))

    # Only keep runs bounded by ground contacts on both sides when possible.
    def score(run):
        s, e = run
        length = e - s + 1
        rise = ground - np.nanmin(bottoms[s:e + 1])
        bounded = (s - 1 >= 0 and valid[s - 1]) and (e + 1 < len(bottoms) and valid[e + 1])
        return (bounded, length, rise)

    if not runs:
        # Fallback: highest point of the feet; take neighbouring frames.
        top = int(idx[np.argmin(vals)])
        return max(top - 1, 0), min(top + 1, len(bottoms) - 1)

    s, e = max(runs, key=score)
    takeoff = s - 1 if s - 1 >= 0 else s
    landing = e + 1 if e + 1 < len(bottoms) else e
    return int(takeoff), int(landing)


def analyze(path):
    frames = read_frames(path)
    background = cv2.GaussianBlur(frames[0], (5, 5), 0).astype(np.int16)

    n = len(frames)
    bottoms = np.full(n, np.nan)
    valid = np.zeros(n, dtype=bool)
    for i in range(1, n):
        m = athlete_measure(frames[i], background)
        if m is None:
            continue
        bottom, _, touches, _ = m
        bottoms[i] = bottom
        # Partially visible athlete (entering/leaving) gives unreliable feet.
        valid[i] = not touches

    # If edge filtering removed everything, fall back to any detection.
    if valid.sum() < 3:
        valid = ~np.isnan(bottoms)

    return find_jump(bottoms, valid)


def main():
    in_path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_INPUT
    out_path = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_OUTPUT
    takeoff, landing = analyze(in_path)
    result = {
        "jump_takeoff_frame_number": int(takeoff),
        "jump_land_frame_number": int(landing),
    }
    with open(out_path, "w") as f:
        toml.dump(result, f)
    print(toml.dumps(result), end="")


if __name__ == "__main__":
    main()
