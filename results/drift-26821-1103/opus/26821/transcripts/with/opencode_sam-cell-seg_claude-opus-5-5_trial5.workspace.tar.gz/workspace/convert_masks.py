#!/usr/bin/env python
"""Refine cell annotations (rectangles and polylines) into polylines with MobileSAM.

For every row of the metadata csv, MobileSAM is prompted with the annotation's
bounding box (plus the original polygon as a dense mask prompt when the
annotation already is a polyline). The predicted masks are then post-processed so
that:
  * each cell is represented by exactly one contiguous polygon,
  * no two polygons overlap,
  * no polygon is a plain rectangle.

The output csv is identical to the input csv except for the updated
xmin, ymin, xmax, ymax, coords_x and coords_y columns.
"""

import argparse
import os

import cv2
import numpy as np
import pandas as pd
import torch
from tqdm import tqdm

from mobile_sam import SamPredictor, sam_model_registry


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def parse_coords(value):
    if isinstance(value, (list, tuple, np.ndarray)):
        return [float(v) for v in value]
    s = str(value).strip().strip("[]()")
    return [float(v) for v in s.replace(";", ",").split(",") if v.strip() != ""]


def fmt_coords(values):
    return ",".join(str(int(v)) for v in values)


def load_rgb(path):
    img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    if img is None:
        raise FileNotFoundError(f"Could not read image: {path}")
    if img.dtype != np.uint8:
        img = cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    if img.ndim == 2:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
    elif img.shape[2] == 4:
        img = cv2.cvtColor(img, cv2.COLOR_BGRA2RGB)
    else:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return np.ascontiguousarray(img)


def polygon_mask(xs, ys, shape):
    mask = np.zeros(shape, dtype=np.uint8)
    if len(xs) >= 3:
        pts = np.round(np.stack([xs, ys], axis=1)).astype(np.int32)
        cv2.fillPoly(mask, [pts], 1)
    return mask.astype(bool)


def ellipse_mask(box, shape):
    x0, y0, x1, y1 = box
    mask = np.zeros(shape, dtype=np.uint8)
    cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    ax, ay = max((x1 - x0) / 2.0, 1.5), max((y1 - y0) / 2.0, 1.5)
    cv2.ellipse(mask, (int(round(cx)), int(round(cy))),
                (int(round(ax)), int(round(ay))), 0, 0, 360, 1, -1)
    return mask.astype(bool)


def largest_component(mask):
    mask = mask.astype(np.uint8)
    if mask.sum() == 0:
        return mask.astype(bool)
    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=4)
    if n <= 2:
        return mask.astype(bool)
    idx = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return labels == idx


def fill_holes(mask):
    mask = mask.astype(np.uint8)
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    out = np.zeros_like(mask)
    cv2.drawContours(out, contours, -1, 1, thickness=-1)
    return out.astype(bool)


def smooth(mask):
    """Light morphological opening to remove thin spurs, keep largest part."""
    if mask.sum() < 20:
        return mask
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    opened = cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_OPEN, k).astype(bool)
    if opened.sum() >= 0.5 * mask.sum():
        return opened
    return mask


def is_rectangular(mask):
    ys, xs = np.nonzero(mask)
    if len(xs) == 0:
        return True
    area_box = (xs.max() - xs.min() + 1) * (ys.max() - ys.min() + 1)
    return mask.sum() >= 0.97 * area_box


def iou(a, b):
    inter = np.logical_and(a, b).sum()
    union = np.logical_or(a, b).sum()
    return inter / union if union else 0.0


def mask_to_polygon(mask):
    """Return (N,2) int contour of the (single) outer boundary of `mask`."""
    contours, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL,
                                   cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    c = max(contours, key=cv2.contourArea).reshape(-1, 2)
    return c


def polygon_is_rectangle(poly):
    if poly is None:
        return True
    xs, ys = poly[:, 0], poly[:, 1]
    on_edge = (np.isin(xs, [xs.min(), xs.max()]) | np.isin(ys, [ys.min(), ys.max()]))
    return bool(on_edge.all()) and len(np.unique(poly, axis=0)) <= 4


# --------------------------------------------------------------------------- #
# SAM inference
# --------------------------------------------------------------------------- #
def polygon_to_mask_prompt(poly_mask, predictor):
    """Convert a full-res binary mask to a 256x256 low-res logit prompt."""
    h, w = poly_mask.shape
    size = predictor.model.image_encoder.img_size
    new_h, new_w = predictor.transform.get_preprocess_shape(h, w, size)
    resized = cv2.resize(poly_mask.astype(np.float32), (new_w, new_h),
                         interpolation=cv2.INTER_LINEAR)
    padded = np.zeros((size, size), dtype=np.float32)
    padded[:new_h, :new_w] = resized
    low = cv2.resize(padded, (256, 256), interpolation=cv2.INTER_AREA)
    logits = (low * 2.0 - 1.0) * 10.0  # +10 inside, -10 outside
    return logits[None, :, :].astype(np.float32)


def predict_cell(predictor, box, prior_mask, is_poly, shape):
    """Run MobileSAM on one cell. Returns (binary mask, logits, score)."""
    x0, y0, x1, y1 = box
    box_np = np.array([x0, y0, x1, y1], dtype=np.float32)
    cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0

    candidates = []  # (mask, logits, score)

    # 1) box prompt, multi-mask
    masks, scores, _ = predictor.predict(box=box_np, multimask_output=True,
                                         return_logits=True)
    for m, s in zip(masks, scores):
        candidates.append((m, float(s)))

    # 2) box + center point prompt
    if prior_mask is not None and prior_mask.any():
        ys, xs = np.nonzero(prior_mask)
        # point inside the prior that is farthest from its border
        dist = cv2.distanceTransform(prior_mask.astype(np.uint8), cv2.DIST_L2, 3)
        iy, ix = np.unravel_index(np.argmax(dist), dist.shape)
        pt = np.array([[ix, iy]], dtype=np.float32)
    else:
        pt = np.array([[cx, cy]], dtype=np.float32)
    masks, scores, _ = predictor.predict(point_coords=pt, point_labels=np.array([1]),
                                         box=box_np, multimask_output=True,
                                         return_logits=True)
    for m, s in zip(masks, scores):
        candidates.append((m, float(s)))

    # 3) for polylines, also use the annotated polygon as a dense mask prompt
    if is_poly and prior_mask is not None and prior_mask.any():
        mp = polygon_to_mask_prompt(prior_mask, predictor)
        masks, scores, _ = predictor.predict(point_coords=pt, point_labels=np.array([1]),
                                             box=box_np, mask_input=mp,
                                             multimask_output=False,
                                             return_logits=True)
        for m, s in zip(masks, scores):
            candidates.append((m, float(s)))

    thr = predictor.model.mask_threshold
    box_area = max((x1 - x0) * (y1 - y0), 1.0)
    # region where the cell is allowed to be: box expanded by a small margin
    mw, mh = max(2, 0.1 * (x1 - x0)), max(2, 0.1 * (y1 - y0))
    allowed = np.zeros(shape, dtype=bool)
    allowed[int(max(0, np.floor(y0 - mh))):int(min(shape[0], np.ceil(y1 + mh)) + 1),
            int(max(0, np.floor(x0 - mw))):int(min(shape[1], np.ceil(x1 + mw)) + 1)] = True

    best, best_val = None, -np.inf
    for logit, score in candidates:
        m = (logit > thr) & allowed
        area = m.sum()
        if area < 4:
            continue
        frac = area / box_area
        val = score
        if prior_mask is not None and prior_mask.any():
            val += (1.0 if is_poly else 0.5) * iou(m, prior_mask)
        # penalise masks that are far too small or too large for the box
        if frac < 0.15:
            val -= 1.0
        if frac > 1.3:
            val -= 1.0
        if val > best_val:
            best_val, best = val, (m, logit, score)

    if best is None:
        fallback = ellipse_mask(box, shape)
        logit = np.where(fallback, 1.0, -1.0).astype(np.float32)
        return fallback, logit, 0.0

    m, logit, score = best
    m = fill_holes(largest_component(smooth(m)))
    return m, np.where(allowed, logit, -1e4).astype(np.float32), score


# --------------------------------------------------------------------------- #
# Main pipeline
# --------------------------------------------------------------------------- #
def resolve_overlaps(masks, logits, shape):
    """Assign every pixel to at most one cell (highest SAM logit wins)."""
    n = len(masks)
    h, w = shape
    label = np.full(shape, -1, dtype=np.int32)
    best = np.full(shape, -np.inf, dtype=np.float32)
    for i in range(n):
        m = masks[i]
        if not m.any():
            continue
        # normalise logits so cells of different confidence compete fairly
        lg = logits[i]
        val = np.where(m, lg, -np.inf)
        upd = val > best
        best[upd] = val[upd]
        label[upd] = i
    return [label == i for i in range(n)]


def separate(masks, shape):
    """Enforce a 1px gap between different cells so that rasterised polygons
    never overlap regardless of the rasterisation convention."""
    k = np.ones((3, 3), np.uint8)
    occupied = np.zeros(shape, dtype=bool)
    out = []
    # process larger cells first so small cells lose fewer pixels
    order = np.argsort([-m.sum() for m in masks])
    res = [None] * len(masks)
    for i in order:
        m = masks[i].copy()
        if occupied.any():
            grown = cv2.dilate(occupied.astype(np.uint8), k).astype(bool)
            m &= ~grown
        m = fill_holes(largest_component(m))
        res[i] = m
        occupied |= m
    out = res
    return out


def finalize_polygons(masks, boxes, shape):
    """Convert masks to polygons, ensuring validity, non-rectangularity and
    no overlap among rasterised polygons."""
    h, w = shape
    polys = []
    occupied = np.zeros(shape, dtype=bool)
    k = np.ones((3, 3), np.uint8)
    for i, m in enumerate(masks):
        if m.sum() < 6 or is_rectangular(m):
            # fallback: inscribed ellipse (intersected with SAM mask if useful)
            ell = ellipse_mask(boxes[i], shape)
            cand = m & ell if (m & ell).sum() >= 6 else ell
            cand &= ~cv2.dilate(occupied.astype(np.uint8), k).astype(bool)
            cand = largest_component(cand)
            if cand.sum() < 6:
                # last resort: tiny diamond at a free location near the centre
                cand = np.zeros(shape, dtype=np.uint8)
                x0, y0, x1, y1 = boxes[i]
                cx = int(np.clip(round((x0 + x1) / 2), 2, w - 3))
                cy = int(np.clip(round((y0 + y1) / 2), 2, h - 3))
                pts = np.array([[cx, cy - 2], [cx + 2, cy], [cx, cy + 2], [cx - 2, cy]])
                cv2.fillPoly(cand, [pts.astype(np.int32)], 1)
                cand = cand.astype(bool)
            m = cand
        poly = mask_to_polygon(m)
        if poly is None or len(poly) < 3 or polygon_is_rectangle(poly):
            m = ellipse_mask(boxes[i], shape) & ~cv2.dilate(
                occupied.astype(np.uint8), k).astype(bool)
            m = largest_component(m)
            poly = mask_to_polygon(m)
        raster = polygon_mask(poly[:, 0], poly[:, 1], shape) if poly is not None else m
        # guard against overlap introduced by rasterisation of the polygon
        if (raster & occupied).any():
            m2 = m & ~cv2.dilate(occupied.astype(np.uint8), k, iterations=2).astype(bool)
            m2 = largest_component(m2)
            if m2.sum() >= 3:
                poly = mask_to_polygon(m2)
                raster = polygon_mask(poly[:, 0], poly[:, 1], shape)
        occupied |= raster
        polys.append(poly)
    return polys


def resolve_output_file(output_path, csv_path):
    if output_path.lower().endswith(".csv"):
        parent = os.path.dirname(os.path.abspath(output_path))
        os.makedirs(parent, exist_ok=True)
        return output_path
    os.makedirs(output_path, exist_ok=True)
    return os.path.join(output_path, os.path.basename(csv_path))


def main():
    parser = argparse.ArgumentParser(description="Refine cell masks with MobileSAM.")
    parser.add_argument("weights_path", type=str, help="Path to MobileSAM weights (mobile_sam.pt)")
    parser.add_argument("output_path", type=str, help="Output folder (or .csv file path)")
    parser.add_argument("rgb_path", type=str, help="Path to the RGB image")
    parser.add_argument("csv_path", type=str, help="Path to the metadata csv")
    args = parser.parse_args()

    torch.set_grad_enabled(False)
    device = "cpu"

    # ---- load data --------------------------------------------------------
    image = load_rgb(args.rgb_path)
    h, w = image.shape[:2]
    with open(args.csv_path, "r") as f:
        header = f.readline()
    has_index = header.startswith(",")
    df = pd.read_csv(args.csv_path, index_col=0 if has_index else None)

    # ---- load model -------------------------------------------------------
    model = sam_model_registry["vit_t"](checkpoint=None)
    state = torch.load(args.weights_path, map_location=device)
    if isinstance(state, dict) and "model" in state and not any(
            k.startswith("image_encoder") for k in state):
        state = state["model"]
    model.load_state_dict(state)
    model.to(device).eval()
    predictor = SamPredictor(model)
    predictor.set_image(image)

    # ---- per-cell predictions ---------------------------------------------
    masks, logits, boxes = [], [], []
    for _, row in tqdm(df.iterrows(), total=len(df), desc="MobileSAM"):
        xs = np.array(parse_coords(row["coords_x"]), dtype=np.float32)
        ys = np.array(parse_coords(row["coords_y"]), dtype=np.float32)
        x0 = float(np.clip(min(row["xmin"], xs.min() if len(xs) else row["xmin"]), 0, w - 1))
        x1 = float(np.clip(max(row["xmax"], xs.max() if len(xs) else row["xmax"]), 0, w - 1))
        y0 = float(np.clip(min(row["ymin"], ys.min() if len(ys) else row["ymin"]), 0, h - 1))
        y1 = float(np.clip(max(row["ymax"], ys.max() if len(ys) else row["ymax"]), 0, h - 1))
        if x1 - x0 < 2:
            x0, x1 = max(0.0, x0 - 1), min(w - 1.0, x1 + 1)
        if y1 - y0 < 2:
            y0, y1 = max(0.0, y0 - 1), min(h - 1.0, y1 + 1)
        box = (x0, y0, x1, y1)

        typ = str(row.get("type", "")).lower()
        prior = polygon_mask(xs, ys, (h, w)) if len(xs) >= 3 else None
        is_rect = typ == "rectangle" or (prior is not None and is_rectangular(prior))
        is_poly = not is_rect
        if is_rect:
            # a rectangle is weak prior: use the inscribed ellipse instead
            prior = ellipse_mask(box, (h, w))

        m, lg, _ = predict_cell(predictor, box, prior, is_poly, (h, w))
        masks.append(m)
        logits.append(lg)
        boxes.append(box)

    # ---- make masks disjoint & contiguous --------------------------------
    masks = resolve_overlaps(masks, logits, (h, w))
    masks = [fill_holes(largest_component(m)) for m in masks]
    masks = separate(masks, (h, w))
    polys = finalize_polygons(masks, boxes, (h, w))

    # ---- write output -----------------------------------------------------
    df = df.copy()
    for col in ["xmin", "ymin", "xmax", "ymax"]:
        if col in df.columns:
            df[col] = df[col].astype(object)
    for idx, poly in zip(df.index, polys):
        px = [int(v) for v in poly[:, 0]]
        py = [int(v) for v in poly[:, 1]]
        # close the polyline (same convention as the input annotations)
        px.append(px[0])
        py.append(py[0])
        df.at[idx, "xmin"] = int(min(px))
        df.at[idx, "xmax"] = int(max(px))
        df.at[idx, "ymin"] = int(min(py))
        df.at[idx, "ymax"] = int(max(py))
        df.at[idx, "coords_x"] = fmt_coords(px)
        df.at[idx, "coords_y"] = fmt_coords(py)

    out_file = resolve_output_file(args.output_path, args.csv_path)
    df.to_csv(out_file, index=has_index)
    print(f"Saved {len(df)} refined masks to {out_file}")


if __name__ == "__main__":
    main()
