import torch
import torch.distributed as dist
import torch.nn.functional as F


def _world_size():
    if dist.is_available() and dist.is_initialized():
        return dist.get_world_size()
    return 1


def _rank():
    if dist.is_available() and dist.is_initialized():
        return dist.get_rank()
    return 0


def _split_last_dim(x):
    ws = _world_size()
    if ws == 1:
        return x
    return torch.chunk(x, ws, dim=-1)[_rank()].contiguous()


def _gather_last_dim(x):
    ws = _world_size()
    if ws == 1:
        return x
    x = x.contiguous()
    parts = [torch.empty_like(x) for _ in range(ws)]
    dist.all_gather(parts, x)
    return torch.cat(parts, dim=-1).contiguous()


def _all_reduce(x):
    if _world_size() == 1:
        return x
    x = x.contiguous().clone()
    dist.all_reduce(x, op=dist.ReduceOp.SUM)
    return x


class _CopyToParallelRegion(torch.autograd.Function):
    """Forward: identity. Backward: all-reduce gradient."""

    @staticmethod
    def forward(ctx, x):
        return x

    @staticmethod
    def backward(ctx, grad):
        return _all_reduce(grad)


class _ReduceFromParallelRegion(torch.autograd.Function):
    """Forward: all-reduce. Backward: identity."""

    @staticmethod
    def forward(ctx, x):
        return _all_reduce(x)

    @staticmethod
    def backward(ctx, grad):
        return grad


class _ScatterToParallelRegion(torch.autograd.Function):
    """Forward: take local slice of last dim. Backward: all-gather."""

    @staticmethod
    def forward(ctx, x):
        return _split_last_dim(x)

    @staticmethod
    def backward(ctx, grad):
        return _gather_last_dim(grad)


class _GatherFromParallelRegion(torch.autograd.Function):
    """Forward: all-gather along last dim. Backward: take local slice."""

    @staticmethod
    def forward(ctx, x):
        return _gather_last_dim(x)

    @staticmethod
    def backward(ctx, grad):
        return _split_last_dim(grad)


class ColumnParallelLinear(torch.nn.Module):
    """Y = X W^T + b, with W (out_features x in_features) split along the
    output dimension. Each rank computes a slice of the output; slices are
    all-gathered along the last dimension."""

    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.world_size = _world_size()
        self.rank = _rank()
        assert out_features % self.world_size == 0, \
            "out_features must be divisible by world_size"
        self.in_features = in_features
        self.out_features = out_features
        self.out_features_per_partition = out_features // self.world_size

        master_weight = torch.as_tensor(master_weight).detach()
        assert tuple(master_weight.shape) == (out_features, in_features)
        start = self.rank * self.out_features_per_partition
        end = start + self.out_features_per_partition
        self.weight = torch.nn.Parameter(master_weight[start:end, :].clone().contiguous())

        if bias:
            self.bias = torch.nn.Parameter(
                torch.zeros(self.out_features_per_partition,
                            dtype=self.weight.dtype, device=self.weight.device))
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        x = _CopyToParallelRegion.apply(x)
        out = F.linear(x, self.weight, self.bias)
        return _GatherFromParallelRegion.apply(out)


class RowParallelLinear(torch.nn.Module):
    """Y = X W^T + b, with W (out_features x in_features) split along the
    input dimension. Each rank computes a partial output from its slice of
    the input; partial outputs are all-reduced (summed), then the full bias
    is added."""

    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.world_size = _world_size()
        self.rank = _rank()
        assert in_features % self.world_size == 0, \
            "in_features must be divisible by world_size"
        self.in_features = in_features
        self.out_features = out_features
        self.in_features_per_partition = in_features // self.world_size

        master_weight = torch.as_tensor(master_weight).detach()
        assert tuple(master_weight.shape) == (out_features, in_features)
        start = self.rank * self.in_features_per_partition
        end = start + self.in_features_per_partition
        self.weight = torch.nn.Parameter(master_weight[:, start:end].clone().contiguous())

        if bias:
            self.bias = torch.nn.Parameter(
                torch.zeros(out_features, dtype=self.weight.dtype,
                            device=self.weight.device))
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        # Accept either the full input or an already-partitioned input.
        if self.world_size > 1 and x.shape[-1] == self.in_features:
            x = _ScatterToParallelRegion.apply(x)
        partial = F.linear(x, self.weight)
        out = _ReduceFromParallelRegion.apply(partial)
        if self.bias is not None:
            out = out + self.bias
        return out
