#!/usr/bin/env python3
"""Hurdle jump analyzer.

Detects the takeoff and landing frames of a single hurdle jump in an MP4
video recorded from a static camera, and writes them to a TOML file.

Approach:
  1. The first frame (no runner) is used as background.
  2. For each frame, a gain-compensated absolute difference against the
     background yields a foreground mask of the athlete.
  3. The lowest foreground row (the feet) is tracked per frame, along with
     the horizontal position of the athlete.
  4. The ground level is estimated from the frames where the athlete is
     fully visible. Frames whose lowest point is clearly above the ground
     are "airborne".
  5. The airborne run in which the athlete crosses the hurdle is the jump.
     Takeoff = last ground-contact frame before it; landing = first
     ground-contact frame after it.

Usage: python3 jump_analyzer.py [input.mp4] [output.toml]
"""
import os
import sys

import cv2
import numpy as np
import toml

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_INPUT = os.path.join(HERE, "example_video.mp4")
DEFAULT_OUTPUT = os.path.join(HERE, "output.toml")

# Scene constants (camera, background and hurdle are fixed across videos).
REF_W, REF_H = 960, 540
HURDLE_X = 455          # x position of the hurdle in reference resolution
MAX_Y = 450             # ignore foreground below this row (reference res)
DIFF_T = 35             # foreground difference threshold
MIN_FG_PIXELS = 1500    # minimum foreground pixels for the athlete to be present
AIR_TOL = 12            # pixels above ground to count as airborne


def read_frames(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise IOError("Cannot open video: %s" % path)
    frames = []
    while True:
        ok, f = cap.read()
        if not ok:
            break
        if f.shape[1] != REF_W or f.shape[0] != REF_H:
            f = cv2.resize(f, (REF_W, REF_H))
        frames.append(f)
    cap.release()
    return frames


class Background(object):
    """Background model tolerant to small camera shake and exposure drift."""

    def __init__(self, frame):
        self.gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY).astype(np.float32)
        self.win = cv2.createHanningWindow(self.gray.shape[::-1], cv2.CV_32F)
        bg = cv2.GaussianBlur(frame, (5, 5), 0).astype(np.float32)
        self.med = np.median(bg[::4, ::4], axis=(0, 1))
        k = np.ones((5, 5), np.uint8)
        # Local max / min of the background: a pixel only counts as changed
        # if it falls outside the range of its background neighbourhood,
        # which makes the comparison robust to 1-2 px misalignment.
        self.hi = cv2.dilate(bg, k)
        self.lo = cv2.erode(bg, k)


def foreground(frame, bgm, _unused=None):
    g = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY).astype(np.float32)
    (dx, dy), _ = cv2.phaseCorrelate(bgm.gray, g, bgm.win)
    if abs(dx) < 20 and abs(dy) < 20:
        M = np.float32([[1, 0, -dx], [0, 1, -dy]])
        frame = cv2.warpAffine(frame, M, (frame.shape[1], frame.shape[0]),
                               borderMode=cv2.BORDER_REPLICATE)
    f = cv2.GaussianBlur(frame, (5, 5), 0).astype(np.float32)
    med = np.median(f[::4, ::4], axis=(0, 1))
    f = f * (bgm.med / np.maximum(med, 1.0))
    d = np.maximum(f - bgm.hi, bgm.lo - f).max(axis=2)
    m = (d > DIFF_T).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    m[MAX_Y:] = 0
    return m


def analyze_frame(mask):
    """Return (present, bottom_y, center_x, x0, x1) for the athlete."""
    if int(mask.sum()) < MIN_FG_PIXELS:
        return None
    closed = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((15, 15), np.uint8))
    n, lab, st, _ = cv2.connectedComponentsWithStats(closed)
    if n <= 1:
        return None
    k = 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA]))
    if st[k, cv2.CC_STAT_AREA] < MIN_FG_PIXELS:
        return None
    x, y, w, h = st[k, :4]
    # Union of components overlapping the main blob's horizontal range
    # (feet are sometimes disconnected from the body).
    x0, x1 = max(0, x - 60), min(REF_W, x + w + 60)
    sub = mask[:, x0:x1]
    ys, xs = np.nonzero(sub)
    if len(ys) == 0:
        return None
    rows = np.bincount(ys, minlength=REF_H)
    good = np.nonzero(rows >= 3)[0]
    if len(good) == 0:
        return None
    bottom = int(good.max())
    cx = float(np.mean(xs)) + x0
    return dict(bottom=bottom, cx=cx, x0=int(x), x1=int(x + w))


def find_runs(flags):
    runs, start = [], None
    for i, f in enumerate(flags):
        if f and start is None:
            start = i
        elif not f and start is not None:
            runs.append((start, i - 1))
            start = None
    if start is not None:
        runs.append((start, len(flags) - 1))
    return runs


def analyze(path):
    frames = read_frames(path)
    if len(frames) < 3:
        return 0, 0
    bgm = Background(frames[0])

    info = [None] * len(frames)
    for i in range(1, len(frames)):
        info[i] = analyze_frame(foreground(frames[i], bgm))

    present = [i for i, d in enumerate(info) if d is not None]
    if not present:
        return 0, 0

    # Ground level from frames where the athlete is fully inside the image.
    full = [info[i]["bottom"] for i in present
            if info[i]["x0"] > 5 and info[i]["x1"] < REF_W - 5]
    if not full:
        full = [info[i]["bottom"] for i in present]
    ground = float(np.percentile(full, 85))

    # Restrict analysis to the contiguous segment where the athlete is visible
    # (largest contiguous block of present frames, allowing small gaps).
    pres_flags = [d is not None for d in info]
    segs = find_runs(pres_flags)
    seg = max(segs, key=lambda r: r[1] - r[0])
    s0, s1 = seg

    airborne = [False] * len(frames)
    for i in range(s0, s1 + 1):
        d = info[i]
        if d is not None and d["bottom"] < ground - AIR_TOL:
            airborne[i] = True
    runs = [r for r in find_runs(airborne) if s0 <= r[0] and r[1] <= s1]

    def crosses(r):
        a = max(s0, r[0] - 1)
        b = min(s1, r[1] + 1)
        xs = [info[i]["cx"] for i in range(a, b + 1) if info[i] is not None]
        if not xs:
            return False
        return min(xs) - 40 <= HURDLE_X <= max(xs) + 40

    def height(r):
        return ground - min(info[i]["bottom"] for i in range(r[0], r[1] + 1))

    if runs:
        cand = [r for r in runs if crosses(r)] or runs
        # Prefer the longest / highest flight phase.
        best = max(cand, key=lambda r: (r[1] - r[0] + 1) * 10 + height(r))
        takeoff = max(0, best[0] - 1)
        land = min(len(frames) - 1, best[1] + 1)
    else:
        # Fallback: frame where athlete is closest to the hurdle.
        mid = min(present, key=lambda i: abs(info[i]["cx"] - HURDLE_X))
        takeoff, land = max(0, mid - 4), min(len(frames) - 1, mid + 4)
    return int(takeoff), int(land)


def main():
    inp = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_INPUT
    out = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_OUTPUT
    takeoff, land = analyze(inp)
    result = {
        "jump_takeoff_frame_number": takeoff,
        "jump_land_frame_number": land,
    }
    with open(out, "w") as fh:
        toml.dump(result, fh)
    print(toml.dumps(result), end="")


if __name__ == "__main__":
    main()
