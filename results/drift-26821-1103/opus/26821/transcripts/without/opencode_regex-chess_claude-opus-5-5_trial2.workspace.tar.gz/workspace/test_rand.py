import json, re, random, sys, time
import chess

RULES = [(re.compile(p), r) for p, r in json.load(open("/tmp/obench-cell-9bu5s8xy/bench_opencode_regex-chess_byak0ql_/re.json"))]


def run(fen):
    for p, r in RULES:
        fen = p.sub(r, fen)
    return [" ".join(x.split(" ")[:-2]) for x in fen.split("\n")]


def expected(fen):
    b = chess.Board(fen)
    s = set()
    for m in b.legal_moves:
        if m.promotion and m.promotion != chess.QUEEN:
            continue
        c = b.copy(); c.push(m)
        s.add(" ".join(c.fen().split(" ")[:-2]))
    return s


def check(fen):
    ours = run(fen)
    exp = expected(fen)
    ok = len(ours) == len(exp) and all(x in exp or x.rpartition(" ")[0] + " -" in exp for x in ours)
    if not ok:
        print("FAIL", fen)
        print(" extra:", [x for x in ours if not (x in exp or x.rpartition(" ")[0] + " -" in exp)])
        print(" missing:", exp - set(ours) - {x.rpartition(" ")[0] + " -" for x in ours})
        sys.exit(1)


f0 = "rnb1k1nr/p2p1ppp/3B4/1p1NPN1P/6P1/3P1Q2/P1P5/q4Kb1 w kq - 0 1"
print(run(f0))
check(f0)
random.seed(int(sys.argv[1]) if len(sys.argv) > 1 else 0)
n = 0
t = time.time()
for g in range(int(sys.argv[2]) if len(sys.argv) > 2 else 300):
    b = chess.Board()
    while not b.is_game_over() and b.ply() < 300:
        if b.turn == chess.WHITE:
            check(b.fen()); n += 1
        ms = list(b.legal_moves)
        # bias toward captures/pawn moves for variety
        b.push(random.choice(ms))
print("ok", n, time.time() - t)
