import json

OUT = "/tmp/obench-cell-9bu5s8xy/bench_opencode_regex-chess_byak0ql_/re.json"
FILES = "abcdefgh"
TARGET = "[1pnbrq]"   # empty or capturable black piece
BLACK = "[pnbrq]"


def rc(i):
    return i // 8, i % 8


def idx(r, f):
    return r * 8 + f


def name(i):
    r, f = rc(i)
    return FILES[f] + str(8 - r)


def onb(r, f):
    return 0 <= r < 8 and 0 <= f < 8


def frag(cons):
    """Regex matching board from index 0 with constraints {idx: class}."""
    out, pos = "", 0
    for i in sorted(cons):
        gap = i - pos
        if gap:
            out += ".{%d}" % gap if gap > 1 else "."
        out += cons[i]
        pos = i + 1
    return out


def attack_frags(t):
    """List of lookahead fragments: square t attacked by black."""
    r, f = rc(t)
    res = []
    for dr, df in [(1, 2), (2, 1), (-1, 2), (-2, 1), (1, -2), (2, -1), (-1, -2), (-2, -1)]:
        if onb(r + dr, f + df):
            res.append({idx(r + dr, f + df): "n"})
    for dr in (-1, 0, 1):
        for df in (-1, 0, 1):
            if (dr or df) and onb(r + dr, f + df):
                res.append({idx(r + dr, f + df): "k"})
    for df in (-1, 1):
        if onb(r - 1, f + df):
            res.append({idx(r - 1, f + df): "p"})
    for dr in (-1, 0, 1):
        for df in (-1, 0, 1):
            if not (dr or df):
                continue
            cls = "[rq]" if (dr == 0 or df == 0) else "[bq]"
            between = []
            for d in range(1, 8):
                rr, ff = r + dr * d, f + df * d
                if not onb(rr, ff):
                    break
                c = {b: "1" for b in between}
                c[idx(rr, ff)] = cls
                res.append(c)
                between.append(idx(rr, ff))
    return ["(?=" + frag(c) + ")" for c in res]


def board_pat(cons, changes):
    pat, rep, run, ng = "", "", [], 0
    groups = []

    def flush():
        nonlocal pat, rep, run, ng
        if run:
            ng += 1
            pat_part = frag({k - run[0]: cons[k] for k in run if k in cons})
            tail = run[-1] - max([k for k in run if k in cons], default=run[0] - 1)
            if tail > 0:
                pat_part += ".{%d}" % tail if tail > 1 else "."
            pat += "(" + pat_part + ")"
            rep += "\\g<%d>" % ng
            run = []

    for i in range(64):
        if i in changes:
            flush()
            pat += cons.get(i, ".")
            rep += changes[i]
        else:
            run.append(i)
    flush()
    return pat, rep, ng


def move_rule(cons, changes, clear=(), ep_pat=r"\S+", new_ep="-", extra=""):
    """clear: castling slots to clear (0=K,1=Q,2=k,3=q)."""
    frm = [i for i in changes if changes[i] == "1"]
    clear = set(clear)
    for i in changes:
        if changes[i] == "1" and i == 60:
            clear |= {0, 1}
        if i == 63:
            clear.add(0)
        if i == 56:
            clear.add(1)
        if i == 7:
            clear.add(2)
        if i == 0:
            clear.add(3)
    bp, br, ng = board_pat(cons, changes)
    pat = r"\AO" + extra + bp + r" (.)(.)(.)(.) " + ep_pat
    cr = ""
    for s in range(4):
        cr += "-" if s in clear else "\\g<%d>" % (ng + 1 + s)
    rep = "\\g<0>\nM" + br + " " + cr + " " + new_ep
    return [pat, rep]


rules = []
# --- parse input ---
for d in range(8, 1, -1):
    rules.append(["%d(?=[^ ]* w )" % d, "1" * d])
rules.append(["/(?=[^ ]* w )", ""])
rules.append([r"^(\S+) w (\S+) (\S+).*$", r"O\1 \2 \3"])
subsets = []
for m in range(1, 16):
    s = "".join(c for k, c in enumerate("KQkq") if m >> k & 1)
    full = "".join(c if m >> k & 1 else "-" for k, c in enumerate("KQkq"))
    subsets.append((s, full))
    rules.append([r"\A(O\S+) %s " % s, r"\1 %s " % full])
rules.append([r"\A(O\S+) - ", r"\1 ---- "])

# --- move generation ---
for i in range(64):
    r, f = rc(i)
    # knights
    for dr, df in [(1, 2), (2, 1), (-1, 2), (-2, 1), (1, -2), (2, -1), (-1, -2), (-2, -1)]:
        if onb(r + dr, f + df):
            j = idx(r + dr, f + df)
            rules.append(move_rule({i: "N", j: TARGET}, {i: "1", j: "N"}))
    # king
    for dr in (-1, 0, 1):
        for df in (-1, 0, 1):
            if (dr or df) and onb(r + dr, f + df):
                j = idx(r + dr, f + df)
                rules.append(move_rule({i: "K", j: TARGET}, {i: "1", j: "K"}, clear=(0, 1)))
    # sliders
    for P, dirs in [("R", [(0, 1), (0, -1), (1, 0), (-1, 0)]),
                    ("B", [(1, 1), (1, -1), (-1, 1), (-1, -1)]),
                    ("Q", [(0, 1), (0, -1), (1, 0), (-1, 0), (1, 1), (1, -1), (-1, 1), (-1, -1)])]:
        for dr, df in dirs:
            between = []
            for d in range(1, 8):
                rr, ff = r + dr * d, f + df * d
                if not onb(rr, ff):
                    break
                j = idx(rr, ff)
                cons = {b: "1" for b in between}
                cons[i] = P
                cons[j] = TARGET
                rules.append(move_rule(cons, {i: "1", j: P}))
                between.append(j)
    # pawns
    if 1 <= r <= 6:
        np = "Q" if r == 1 else "P"
        j = idx(r - 1, f)
        rules.append(move_rule({i: "P", j: "1"}, {i: "1", j: np}))
        if r == 6:
            j2 = idx(r - 2, f)
            rules.append(move_rule({i: "P", j: "1", j2: "1"}, {i: "1", j2: "P"}, new_ep=name(j)))
        for df in (-1, 1):
            if onb(r - 1, f + df):
                j = idx(r - 1, f + df)
                rules.append(move_rule({i: "P", j: BLACK}, {i: "1", j: np}))
        # en passant
        if r == 3:
            for df in (-1, 1):
                if onb(r, f + df):
                    j = idx(r - 1, f + df)
                    cap = idx(r, f + df)
                    rules.append(move_rule({i: "P", j: "1", cap: "p"}, {i: "1", j: "P", cap: "1"},
                                           ep_pat=name(j)))


def no_attack(squares):
    alts = []
    for s in squares:
        alts += attack_frags(s)
    return "(?!" + "|".join(alts) + ")"


# castling (attack checks on original position)
rules.append(move_rule({60: "K", 61: "1", 62: "1", 63: "R"}, {60: "1", 61: "R", 62: "K", 63: "1"},
                       extra=r"(?=.{65}K)" + no_attack([60, 61, 62])))
rules.append(move_rule({60: "K", 59: "1", 58: "1", 57: "1", 56: "R"},
                       {60: "1", 59: "R", 58: "K", 56: "1"},
                       extra=r"(?=.{66}Q)" + no_attack([60, 59, 58])))

# remove original line
rules.append([r"\AO[^\n]*\n?", ""])

# --- legality filter: remove lines where white king attacked ---
for t in range(64):
    rules.append([r"(?m)^M(?=.{%d}K)(?:%s)[^\n]*\n?" % (t, "|".join(attack_frags(t))), ""])

# --- format output ---
rules.append([r"(?m)^M" + "(.{8})" * 8 + " ", "/".join("\\g<%d>" % k for k in range(1, 9)) + " "])
for d in range(8, 1, -1):
    rules.append(["1" * d, str(d)])
for s, full in subsets:
    rules.append([" %s " % full, " b %s " % s])
rules.append([" ---- ", " b - "])
rules.append([r"\n+\Z", ""])
rules.append([r"(?m)(\S)$", r"\1 0 0"])

json.dump(rules, open(OUT, "w"))
print(len(rules))
