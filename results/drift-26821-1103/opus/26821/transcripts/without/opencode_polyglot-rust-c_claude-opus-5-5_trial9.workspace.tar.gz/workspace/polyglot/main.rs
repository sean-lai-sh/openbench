/* /* */ #if 0
*/
fn main() {
    let n: u64 = std::env::args().nth(1).and_then(|s| s.trim().parse().ok()).unwrap_or(0);
    let (mut a, mut b): (u128, u128) = (1, 1);
    for _ in 0..n {
        let t = a.wrapping_add(b);
        a = b;
        b = t;
    }
    println!("{}", a);
}
/* /* */ #endif
#include <cstdio>
#include <cstdlib>
int main(int argc, char** argv) {
    unsigned long long n = argc > 1 ? strtoull(argv[1], nullptr, 10) : 0;
    unsigned __int128 a = 1, b = 1;
    for (unsigned long long i = 0; i < n; i++) {
        unsigned __int128 t = a + b;
        a = b;
        b = t;
    }
    char buf[64];
    int p = 63;
    buf[p] = 0;
    do { buf[--p] = (char)(48 + (int)(a % 10)); a /= 10; } while (a);
    printf("%s\n", buf + p);
    return 0;
}
// */
