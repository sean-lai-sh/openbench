"""Extract A1 (up to neuron permutation and row scaling) from a 1-hidden-layer
ReLU network using only black-box queries to forward(x)."""
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from forward import forward  # noqa: E402

DIM = 10
rng = np.random.default_rng(12345)
QUERIES = 0


def f(x):
    global QUERIES
    QUERIES += 1
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi, out, depth=0):
    """Recursively find t values where g(t) = f(x0 + t d) is non-linear."""
    g = lambda t: f(x0 + t * d)
    _find(g, lo, hi, g(lo), g(hi), out, depth)


def _find(g, a, b, ga, gb, out, depth):
    m = 0.5 * (a + b)
    gm = g(m)
    q1, q3 = a + 0.25 * (b - a), a + 0.75 * (b - a)
    g1, g3 = g(q1), g(q3)
    # Check linearity at several interior points
    lin = lambda t: ga + (gb - ga) * (t - a) / (b - a)
    scale = 1e-9 * (1 + abs(ga) + abs(gb))
    if (abs(gm - lin(m)) < scale and abs(g1 - lin(q1)) < scale
            and abs(g3 - lin(q3)) < scale):
        return
    if b - a < 1e-3 or depth > 40:
        # Try to resolve a single kink via intersection of the two end lines
        h = 1e-7 * (b - a)
        sa = (g(a + h) - ga) / h
        sb = (gb - g(b - h)) / h
        if abs(sa - sb) < 1e-12:
            return
        t = (gb - ga + sa * a - sb * b) / (sa - sb)
        if a < t < b:
            pred = ga + sa * (t - a)
            if abs(g(t) - pred) < 1e-9 * (1 + abs(pred)):
                out.append(t)
                return
        if b - a < 1e-9:
            out.append(m)
            return
    _find(g, a, m, ga, gm, out, depth + 1)
    _find(g, m, b, gm, gb, out, depth + 1)


def grad(x, h=1e-6):
    f0 = f(x)
    gr = np.zeros(DIM)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = h
        gr[i] = (f(x + e) - f0) / h
    return gr


def normalize(v):
    v = v / np.linalg.norm(v)
    k = np.argmax(np.abs(v))
    return v * np.sign(v[k])


def main():
    rows = []  # list of (unit vector, count)
    n_lines = 60
    for _ in range(n_lines):
        x0 = rng.normal(size=DIM) * 0.5
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        kinks = []
        find_kinks(x0, d, -20.0, 20.0, kinks)
        kinks = sorted(kinks)
        for j, t in enumerate(kinks):
            # stay away from neighbouring kinks
            gap = min([abs(t - s) for k, s in enumerate(kinks) if k != j] + [1.0])
            eps = min(1e-4, gap / 4)
            xs = x0 + t * d
            gp = grad(xs + eps * d, h=eps / 100)
            gm = grad(xs - eps * d, h=eps / 100)
            diff = gp - gm
            if np.linalg.norm(diff) < 1e-8:
                continue
            v = normalize(diff)
            for r in rows:
                if np.abs(r[0] @ v) > 0.9999:
                    r[1].append(v)
                    break
            else:
                rows.append([v, [v]])

    # keep directions observed more than once (robust to spurious points)
    A = []
    for v, vs in rows:
        if len(vs) >= 2 or n_lines < 5:
            A.append(normalize(np.mean(vs, axis=0)))
    A = np.array(A)
    out = os.path.join(HERE, "stolen_A1.npy")
    np.save(out, A)
    print(f"Recovered {A.shape[0]} neurons using {QUERIES} queries")
    print(A)


if __name__ == "__main__":
    main()
