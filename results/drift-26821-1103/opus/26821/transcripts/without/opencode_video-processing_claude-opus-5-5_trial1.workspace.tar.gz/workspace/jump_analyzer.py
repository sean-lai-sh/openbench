#!/usr/bin/env python3
"""
Hurdle jump analyzer.

Detects the takeoff and landing frames of a single hurdle jump in an MP4 video
recorded with a static camera, and writes them to a TOML file.

Approach
--------
1. Frame 0 (no runner) is used as background.
2. For every frame a foreground mask is computed (gain-compensated colour
   difference to the background, plus "dark object on light track" mask that
   reliably captures shoes).
3. The runner's horizontal extent is found from the full-frame mask; within
   that extent the lowest foreground point in the track region is taken as the
   position of the lowest foot.
4. A ground line is fitted through the lowest-foot points that lie on the
   ground; a frame is a "contact" frame when the lowest foot lies on that line.
5. The jump is the flight phase (gap between contacts) that crosses the hurdle;
   takeoff = last contact frame before it, landing = first contact frame after.

Usage: python3 jump_analyzer.py [video.mp4] [output.toml]
"""
import os
import sys

import cv2
import numpy as np
try:
    import toml
except ImportError:  # minimal fallback for flat integer tables
    class _TomlFallback:
        @staticmethod
        def dumps(d):
            return "".join("%s = %d\n" % (k, v) for k, v in d.items())

        @classmethod
        def dump(cls, d, fh):
            fh.write(cls.dumps(d))

    toml = _TomlFallback()

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_VIDEO = os.path.join(HERE, "example_video.mp4")
DEFAULT_OUTPUT = os.path.join(HERE, "output.toml")

# Scene constants (camera / hurdle are fixed in all videos, 960x540 frames).
REF_W = 960.0
HURDLE_X = 495.0          # x position of hurdle upright (reference scale)
TRACK_TOP_Y = 240.0       # everything below this is the track surface
DIFF_THR = 45.0           # colour difference threshold for foreground
MIN_RUNNER_PIXELS = 1500  # minimum foreground pixels for the runner to be present


def read_frames(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise RuntimeError("Cannot open video: %s" % path)
    frames = []
    while True:
        ok, f = cap.read()
        if not ok:
            break
        frames.append(f)
    cap.release()
    if not frames:
        raise RuntimeError("Video has no frames: %s" % path)
    return frames


def foreground_masks(frame, bg_f, bg_gray, track_top):
    """Return (full_mask, lower_mask) uint8 masks."""
    f = frame.astype(np.float32)
    # global gain compensation (camera auto exposure)
    med_f = np.median(f[track_top:].reshape(-1, 3), axis=0)
    med_b = np.median(bg_f[track_top:].reshape(-1, 3), axis=0)
    gain = np.where(med_b > 1, med_f / np.maximum(med_b, 1), 1.0)
    gain = np.clip(gain, 0.5, 2.0)
    diff = np.abs(f / gain - bg_f).max(axis=2)
    m = (diff > DIFF_THR).astype(np.uint8)

    # dark objects (shoes, clothing) on a light background
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY).astype(np.int16)
    dark = ((gray < 80) & (bg_gray - gray > 50)).astype(np.uint8)
    m = np.maximum(m, dark)

    k3 = np.ones((3, 3), np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, k3)
    lower = m.copy()
    lower[:track_top] = 0
    lower = cv2.morphologyEx(lower, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    return m, lower


def runner_x_range(mask):
    """Horizontal extent of the runner from column foreground counts."""
    n, lab, st, _ = cv2.connectedComponentsWithStats(mask)
    if n <= 1:
        return None
    areas = st[1:, cv2.CC_STAT_AREA]
    if areas.sum() < MIN_RUNNER_PIXELS:
        return None
    # take the biggest component and all big components close to it
    order = np.argsort(areas)[::-1] + 1
    main = order[0]
    if st[main, cv2.CC_STAT_AREA] < MIN_RUNNER_PIXELS * 0.3:
        return None
    x0 = st[main, cv2.CC_STAT_LEFT]
    x1 = x0 + st[main, cv2.CC_STAT_WIDTH]
    for k in order[1:]:
        if st[k, cv2.CC_STAT_AREA] < 200:
            break
        kx0 = st[k, cv2.CC_STAT_LEFT]
        kx1 = kx0 + st[k, cv2.CC_STAT_WIDTH]
        if kx1 >= x0 - 60 and kx0 <= x1 + 60:
            x0, x1 = min(x0, kx0), max(x1, kx1)
    cx = float(np.mean(np.nonzero(lab == main)[1]))
    return x0, x1, cx


def lowest_foot(lower, xr, min_area):
    """Lowest foreground point of the runner in the track region."""
    x0, x1, _ = xr
    n, lab, st, _ = cv2.connectedComponentsWithStats(lower)
    best = None
    for k in range(1, n):
        a = st[k, cv2.CC_STAT_AREA]
        if a < min_area:
            continue
        bx0 = st[k, cv2.CC_STAT_LEFT]
        bx1 = bx0 + st[k, cv2.CC_STAT_WIDTH]
        if bx1 < x0 - 40 or bx0 > x1 + 40:
            continue
        ys, xs = np.nonzero(lab == k)
        ymax = ys.max()
        sel = ys >= ymax - 2
        pt = (float(np.median(xs[sel])), float(ymax))
        if best is None or pt[1] > best[1]:
            best = pt
    return best


def fit_ground(points):
    """Fit ground line y = a*x + b through lowest-foot points that touch ground."""
    pts = np.array(points, dtype=np.float64)
    ys = pts[:, 1]
    ref = np.percentile(ys, 85)
    cand = pts[ys >= ref - 12]
    for _ in range(3):
        if len(cand) >= 4 and np.ptp(cand[:, 0]) > 150:
            a, b = np.polyfit(cand[:, 0], cand[:, 1], 1)
            a = float(np.clip(a, -0.05, 0.05))
            b = float(np.median(cand[:, 1] - a * cand[:, 0]))
        else:
            a, b = 0.0, float(np.median(cand[:, 1]))
        res = pts[:, 1] - (a * pts[:, 0] + b)
        new = pts[np.abs(res) <= 8]
        if len(new) < 2:
            break
        cand = new
    return a, b


def analyze(path):
    frames = read_frames(path)
    h, w = frames[0].shape[:2]
    s = w / REF_W
    track_top = int(round(TRACK_TOP_Y * s))
    hurdle_x = HURDLE_X * s
    min_area = max(20, int(150 * s * s))

    bg = frames[0]
    bg_f = bg.astype(np.float32)
    bg_gray = cv2.cvtColor(bg, cv2.COLOR_BGR2GRAY).astype(np.int16)

    feet = {}      # frame -> (x, y) lowest foot
    centers = {}   # frame -> runner centre x
    for i in range(1, len(frames)):
        full, lower = foreground_masks(frames[i], bg_f, bg_gray, track_top)
        xr = runner_x_range(full)
        if xr is None:
            continue
        centers[i] = xr[2]
        p = lowest_foot(lower, xr, min_area)
        if p is not None:
            feet[i] = p

    if len(feet) < 3:
        n = len(frames)
        return n // 2, min(n - 1, n // 2 + 10)

    a, b = fit_ground(list(feet.values()))
    tol = 8.0 * s
    contact = {}
    for i, (x, y) in feet.items():
        contact[i] = y >= a * x + b - tol

    contact_frames = sorted(i for i, c in contact.items() if c)
    if len(contact_frames) < 2:
        fs = sorted(feet)
        return fs[0], fs[-1]

    # group consecutive contact frames into stances
    stances = []
    for i in contact_frames:
        if stances and i - stances[-1][-1] <= 1:
            stances[-1].append(i)
        else:
            stances.append([i])

    def stance_x(st):
        return float(np.median([feet[i][0] for i in st]))

    # flight phases between consecutive stances
    best = None
    for s0, s1 in zip(stances[:-1], stances[1:]):
        x0, x1 = stance_x(s0), stance_x(s1)
        crosses = (x0 - hurdle_x) * (x1 - hurdle_x) < 0
        gap = s1[0] - s0[-1]
        # score: crossing the hurdle is decisive, then flight length,
        # then proximity of the flight to the hurdle
        mid = 0.5 * (x0 + x1)
        score = (1 if crosses else 0, gap, -abs(mid - hurdle_x))
        if best is None or score > best[0]:
            best = (score, s0[-1], s1[0])

    return int(best[1]), int(best[2])


def main():
    video = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_VIDEO
    out = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_OUTPUT
    takeoff, land = analyze(video)
    result = {
        "jump_takeoff_frame_number": int(takeoff),
        "jump_land_frame_number": int(land),
    }
    with open(out, "w") as fh:
        toml.dump(result, fh)
    print(toml.dumps(result), end="")


if __name__ == "__main__":
    main()
