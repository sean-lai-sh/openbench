#!/usr/bin/env python
"""Refine cell annotations (rectangles + polylines) into polylines with MobileSAM.

Every row of the metadata csv is used as a box prompt for MobileSAM. The
resulting masks are post-processed so that

  * every cell gets exactly one contiguous (single connected component) mask,
  * no two masks overlap (a >=1 px gap is kept between neighbouring cells),
  * every mask is stored as a closed, non-rectangular polyline.

The output csv is identical to the input csv except for the xmin, ymin, xmax,
ymax, coords_x and coords_y columns.
"""

import argparse
import os

import cv2
import numpy as np
import pandas as pd
import torch
from tqdm import tqdm

from mobile_sam import SamPredictor, sam_model_registry

# Images whose long side is larger than this are processed in tiles so that
# small cells keep enough resolution inside the 1024x1024 SAM input.
TILE_SIZE = 1024
TILE_STRIDE = 768
CROP_MARGIN = 32  # context margin (px) around a box required inside a tile


# --------------------------------------------------------------------------- #
# I/O helpers
# --------------------------------------------------------------------------- #
def parse_args():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("weights_path", type=str, help="Path to MobileSAM weights (mobile_sam.pt)")
    p.add_argument("output_path", type=str,
                   help="Output folder (or explicit .csv file path) for the refined masks")
    p.add_argument("rgb_path", type=str, help="Path to the RGB image")
    p.add_argument("csv_path", type=str, help="Path to the metadata csv")
    return p.parse_args()


def load_rgb(path):
    img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    if img is None:
        raise FileNotFoundError(f"Could not read image: {path}")
    if img.dtype != np.uint8:
        img = img.astype(np.float32)
        img = (255.0 * (img - img.min()) / max(float(img.max() - img.min()), 1e-6))
        img = img.astype(np.uint8)
    if img.ndim == 2:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
    elif img.shape[2] == 4:
        img = cv2.cvtColor(img, cv2.COLOR_BGRA2RGB)
    else:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return np.ascontiguousarray(img)


def parse_coords(val):
    if isinstance(val, (list, tuple, np.ndarray)):
        return [float(v) for v in val]
    s = str(val).strip().strip("[]()")
    if not s or s.lower() == "nan":
        return []
    return [float(v) for v in s.replace(";", ",").replace(" ", ",").split(",") if v != ""]


def resolve_output_file(output_path, csv_path):
    if output_path.lower().endswith(".csv"):
        parent = os.path.dirname(os.path.abspath(output_path))
        os.makedirs(parent, exist_ok=True)
        return output_path
    os.makedirs(output_path, exist_ok=True)
    return os.path.join(output_path, os.path.basename(csv_path))


# --------------------------------------------------------------------------- #
# Model
# --------------------------------------------------------------------------- #
def load_predictor(weights_path):
    model = sam_model_registry["vit_t"](checkpoint=None)
    state = torch.load(weights_path, map_location="cpu")
    if isinstance(state, dict) and "model" in state and isinstance(state["model"], dict):
        state = state["model"]
    model.load_state_dict(state)
    model.to("cpu").eval()
    return SamPredictor(model)


# --------------------------------------------------------------------------- #
# Mask utilities
# --------------------------------------------------------------------------- #
def largest_cc(mask):
    mask = mask.astype(np.uint8)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=4)
    if n <= 1:
        return np.zeros(mask.shape, bool)
    k = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return lab == k


def fill_holes(mask):
    m = mask.astype(np.uint8)
    contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    out = np.zeros_like(m)
    cv2.drawContours(out, contours, -1, 1, thickness=cv2.FILLED)
    return out.astype(bool)


def polygon_mask(xs, ys, shape):
    m = np.zeros(shape, np.uint8)
    if len(xs) >= 3:
        pts = np.round(np.stack([xs, ys], 1)).astype(np.int32)
        cv2.fillPoly(m, [pts], 1)
    return m.astype(bool)


def smooth(mask):
    """Morphological opening to remove 1-px spurs; keeps one component."""
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    opened = cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_OPEN, k).astype(bool)
    opened = largest_cc(opened)
    return opened if opened.sum() >= 5 else mask


def cut_enclosures(mask, forbidden):
    """If filling `mask`'s holes would swallow forbidden pixels, cut a channel
    from each such hole to the outside so the outer contour no longer encloses
    them."""
    for _ in range(10):
        filled = fill_holes(mask)
        bad = filled & ~mask & forbidden
        if not bad.any():
            return mask
        ys, xs = np.nonzero(bad)
        cy, cx = int(ys.min()), int(np.round(xs.mean()))
        x0, x1 = max(cx - 1, 0), min(cx + 2, mask.shape[1])
        mask = mask.copy()
        mask[:cy + 1, x0:x1] = False
        mask = largest_cc(mask)
        if not mask.any():
            return mask
    return mask


def mask_to_polyline(mask):
    m = mask.astype(np.uint8)
    contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if not contours:
        return None
    c = max(contours, key=cv2.contourArea)[:, 0, :]
    if len(c) < 3:
        return None
    xs = [int(v) for v in c[:, 0]] + [int(c[0, 0])]
    ys = [int(v) for v in c[:, 1]] + [int(c[0, 1])]
    return xs, ys


def is_rectangle(mask):
    ys, xs = np.nonzero(mask)
    if len(xs) == 0:
        return False
    return len(xs) == (xs.max() - xs.min() + 1) * (ys.max() - ys.min() + 1)


def derectangle(mask):
    """Chip the corners of an axis-aligned rectangular mask."""
    ys, xs = np.nonzero(mask)
    y0, y1, x0, x1 = ys.min(), ys.max(), xs.min(), xs.max()
    m = mask.copy()
    for y, x in ((y0, x0), (y0, x1), (y1, x0), (y1, x1)):
        m[y, x] = False
    return m


def plus_shape(shape, cy, cx, r=2):
    m = np.zeros(shape, bool)
    m[max(cy - r, 0):cy + r + 1, max(cx - 1, 0):cx + 2] = True
    m[max(cy - 1, 0):cy + 2, max(cx - r, 0):cx + r + 1] = True
    return m


# --------------------------------------------------------------------------- #
# Tiling
# --------------------------------------------------------------------------- #
def tile_starts(length):
    if length <= TILE_SIZE:
        return [0]
    starts = list(range(0, length - TILE_SIZE + 1, TILE_STRIDE))
    if starts[-1] != length - TILE_SIZE:
        starts.append(length - TILE_SIZE)
    return starts


def assign_crops(boxes, H, W):
    """Return a crop (x0, y0, x1, y1) for every box."""
    if max(H, W) <= TILE_SIZE:
        return [(0, 0, W, H)] * len(boxes)
    tiles = [(x, y, min(x + TILE_SIZE, W), min(y + TILE_SIZE, H))
             for y in tile_starts(H) for x in tile_starts(W)]
    crops = []
    for (bx0, by0, bx1, by1) in boxes:
        need = (max(bx0 - CROP_MARGIN, 0), max(by0 - CROP_MARGIN, 0),
                min(bx1 + CROP_MARGIN, W - 1), min(by1 + CROP_MARGIN, H - 1))
        best, best_d = None, None
        cx, cy = (bx0 + bx1) / 2, (by0 + by1) / 2
        for t in tiles:
            if t[0] <= need[0] and t[1] <= need[1] and t[2] > need[2] and t[3] > need[3]:
                d = (cx - (t[0] + t[2]) / 2) ** 2 + (cy - (t[1] + t[3]) / 2) ** 2
                if best is None or d < best_d:
                    best, best_d = t, d
        if best is None:  # very large box: dedicated crop
            best = (int(need[0]), int(need[1]), int(need[2]) + 1, int(need[3]) + 1)
        crops.append(best)
    return crops


# --------------------------------------------------------------------------- #
# Main pipeline
# --------------------------------------------------------------------------- #
def run_sam(predictor, img, df):
    H, W = img.shape[:2]
    n = len(df)
    boxes, orig_masks, is_rect = [], [], []
    for _, row in df.iterrows():
        xs = parse_coords(row.get("coords_x", ""))
        ys = parse_coords(row.get("coords_y", ""))
        if len(xs) >= 2 and len(xs) == len(ys):
            x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
        else:
            x0, x1, y0, y1 = (float(row["xmin"]), float(row["xmax"]),
                              float(row["ymin"]), float(row["ymax"]))
            xs, ys = [x0, x1, x1, x0], [y0, y0, y1, y1]
        x0, x1 = np.clip([x0, x1], 0, W - 1)
        y0, y1 = np.clip([y0, y1], 0, H - 1)
        if x1 - x0 < 2:
            x0, x1 = max(x0 - 2, 0), min(x1 + 2, W - 1)
        if y1 - y0 < 2:
            y0, y1 = max(y0 - 2, 0), min(y1 + 2, H - 1)
        boxes.append((float(x0), float(y0), float(x1), float(y1)))
        rect = str(row.get("type", "")).strip().lower() == "rectangle" or len(set(zip(xs, ys))) <= 4
        is_rect.append(rect)
        orig_masks.append(None if rect else polygon_mask(np.array(xs), np.array(ys), (H, W)))

    crops = assign_crops(boxes, H, W)
    order = sorted(range(n), key=lambda i: crops[i])

    # Per-cell results: (region slice, logits in region, score)
    results = [None] * n
    current = None
    for i in tqdm(order, desc="MobileSAM", unit="cell"):
        crop = crops[i]
        cx0, cy0, cx1, cy1 = crop
        if crop != current:
            predictor.set_image(img[cy0:cy1, cx0:cx1])
            current = crop
        bx0, by0, bx1, by1 = boxes[i]
        box = np.array([bx0 - cx0, by0 - cy0, bx1 - cx0, by1 - cy0], np.float32)
        with torch.no_grad():
            masks, scores, _ = predictor.predict(box=box, multimask_output=True,
                                                 return_logits=True)
        bin_masks = masks > predictor.model.mask_threshold
        box_area = max((bx1 - bx0 + 1) * (by1 - by0 + 1), 1.0)

        # pick the best of the 3 candidate masks
        best_k, best_val = 0, -np.inf
        for k in range(masks.shape[0]):
            bm = bin_masks[k]
            area = bm.sum()
            if area == 0:
                continue
            if orig_masks[i] is not None:
                om = orig_masks[i][cy0:cy1, cx0:cx1]
                inter = np.logical_and(bm, om).sum()
                union = np.logical_or(bm, om).sum()
                val = inter / max(union, 1) + 0.25 * float(scores[k])
            else:
                frac = area / box_area
                val = float(scores[k])
                if frac < 0.15 or frac > 1.3:
                    val -= 1.0
            if val > best_val:
                best_k, best_val = k, val

        # region of interest around the box (logits outside are irrelevant)
        m = int(max(bx1 - bx0, by1 - by0) * 0.5) + 8
        rx0, ry0 = int(max(bx0 - m, cx0)), int(max(by0 - m, cy0))
        rx1, ry1 = int(min(bx1 + m + 1, cx1)), int(min(by1 + m + 1, cy1))
        logit = masks[best_k][ry0 - cy0:ry1 - cy0, rx0 - cx0:rx1 - cx0].astype(np.float32)
        results[i] = ((ry0, ry1, rx0, rx1), logit, float(scores[best_k]))
    return boxes, orig_masks, results


def resolve(H, W, boxes, orig_masks, results):
    n = len(results)
    # 1) pixel-wise arbitration: a pixel belongs to the cell with highest logit
    best = np.full((H, W), -np.inf, np.float32)
    label = np.full((H, W), -1, np.int32)
    for i, ((y0, y1, x0, x1), logit, _) in enumerate(results):
        cand = largest_cc(logit > 0)
        if not cand.any():
            continue
        cand = fill_holes(cand)
        sub_best = best[y0:y1, x0:x1]
        upd = cand & (logit > sub_best)
        sub_best[upd] = logit[upd]
        label[y0:y1, x0:x1][upd] = i

    # 2) sequential clean-up, most confident cells first, enforcing a 1 px gap
    occupied = np.zeros((H, W), bool)
    kernel = np.ones((3, 3), np.uint8)
    final = [None] * n
    order = sorted(range(n), key=lambda i: -results[i][2])
    for i in order:
        y0, y1, x0, x1 = results[i][0]
        y0, y1 = max(y0 - 2, 0), min(y1 + 2, H)
        x0, x1 = max(x0 - 2, 0), min(x1 + 2, W)
        sub_occ = occupied[y0:y1, x0:x1]
        forbidden = cv2.dilate(sub_occ.astype(np.uint8), kernel).astype(bool)

        m = (label[y0:y1, x0:x1] == i) & ~forbidden
        m = largest_cc(m)
        if m.sum() >= 5:
            m = smooth(m)
        m = cut_enclosures(m, forbidden)

        if m.sum() < 5:
            m = fallback_mask(boxes[i], orig_masks[i], forbidden, (y0, y1, x0, x1), H, W)
            if m is None:
                final[i] = None
                continue

        if is_rectangle(m):
            m = derectangle(m)
        poly = mask_to_polyline(m)
        if poly is None:
            final[i] = None
            continue
        xs, ys = poly
        xs = [x + x0 for x in xs]
        ys = [y + y0 for y in ys]
        # what the polygon actually covers when rasterised -> occupancy
        filled = polygon_mask(np.array(xs), np.array(ys), (H, W))
        occupied |= filled
        final[i] = (xs, ys)

    # 3) any cell still without a mask gets a tiny free blob near its box
    for i in range(n):
        if final[i] is None:
            final[i] = emergency_mask(boxes[i], occupied, kernel, H, W)
            if final[i] is not None:
                occupied |= polygon_mask(np.array(final[i][0]), np.array(final[i][1]), (H, W))
    return final


def fallback_mask(box, orig_mask, forbidden, region, H, W):
    """SAM produced nothing usable: use the original polygon, or an ellipse
    inscribed in the box, restricted to free space."""
    y0, y1, x0, x1 = region
    if orig_mask is not None:
        m = orig_mask[y0:y1, x0:x1].copy()
    else:
        m = np.zeros((y1 - y0, x1 - x0), np.uint8)
        bx0, by0, bx1, by1 = box
        c = (int(round((bx0 + bx1) / 2 - x0)), int(round((by0 + by1) / 2 - y0)))
        ax = (max(int((bx1 - bx0) / 2), 2), max(int((by1 - by0) / 2), 2))
        cv2.ellipse(m, c, ax, 0, 0, 360, 1, -1)
        m = m.astype(bool)
    m = largest_cc(m & ~forbidden)
    if m.sum() >= 5:
        m = smooth(m)
        m = cut_enclosures(m, forbidden)
    return m if m.sum() >= 5 else None


def emergency_mask(box, occupied, kernel, H, W):
    free = ~cv2.dilate(occupied.astype(np.uint8), kernel).astype(bool)
    dist = cv2.distanceTransform(free.astype(np.uint8), cv2.DIST_L2, 3)
    ok = dist >= 3
    if not ok.any():
        return None
    ys, xs = np.nonzero(ok)
    cx, cy = (box[0] + box[2]) / 2, (box[1] + box[3]) / 2
    j = int(np.argmin((xs - cx) ** 2 + (ys - cy) ** 2))
    m = plus_shape((H, W), int(ys[j]), int(xs[j])) & free
    return mask_to_polyline(largest_cc(m))


def main():
    args = parse_args()
    torch.set_grad_enabled(False)

    img = load_rgb(args.rgb_path)
    H, W = img.shape[:2]

    # keep the csv layout (incl. an unnamed index column) identical on output
    with open(args.csv_path, "r") as f:
        header = f.readline()
    has_index = header.startswith(",")
    df = pd.read_csv(args.csv_path, index_col=0 if has_index else None)

    predictor = load_predictor(args.weights_path)
    boxes, orig_masks, results = run_sam(predictor, img, df)
    final = resolve(H, W, boxes, orig_masks, results)

    df = df.copy()
    for col in ("xmin", "ymin", "xmax", "ymax"):
        df[col] = df[col].astype("int64") if col in df else 0
    df["coords_x"] = df["coords_x"].astype(object)
    df["coords_y"] = df["coords_y"].astype(object)
    for pos, poly in enumerate(final):
        if poly is None:
            continue
        xs, ys = poly
        idx = df.index[pos]
        df.at[idx, "xmin"] = int(min(xs))
        df.at[idx, "xmax"] = int(max(xs))
        df.at[idx, "ymin"] = int(min(ys))
        df.at[idx, "ymax"] = int(max(ys))
        df.at[idx, "coords_x"] = ",".join(str(int(v)) for v in xs)
        df.at[idx, "coords_y"] = ",".join(str(int(v)) for v in ys)

    out_file = resolve_output_file(args.output_path, args.csv_path)
    df.to_csv(out_file, index=has_index)
    print(f"Saved {len(df)} refined masks to {out_file}")


if __name__ == "__main__":
    main()
