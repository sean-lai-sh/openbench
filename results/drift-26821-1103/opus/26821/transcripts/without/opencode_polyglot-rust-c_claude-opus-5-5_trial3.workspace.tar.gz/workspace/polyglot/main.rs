/* /* */
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <cstdint>
int main(int argc, char** argv) {
    long long n = argc > 1 ? atoll(argv[1]) : 0;
    std::vector<uint32_t> a{1}, b{1};
    const uint32_t BASE = 1000000000u;
    for (long long i = 0; i < n; i++) {
        std::vector<uint32_t> t;
        uint32_t carry = 0;
        for (size_t j = 0; j < b.size() || carry; j++) {
            uint64_t s = carry;
            if (j < a.size()) s += a[j];
            if (j < b.size()) s += b[j];
            t.push_back((uint32_t)(s % BASE));
            carry = (uint32_t)(s / BASE);
        }
        a.swap(b);
        b.swap(t);
    }
    printf("%u", a.back());
    for (size_t j = a.size() - 1; j-- > 0;) printf("%09u", a[j]);
    printf("\n");
    return 0;
}
#if 0
/* */ // */
fn main() {
    let n: u64 = std::env::args().nth(1).and_then(|s| s.trim().parse().ok()).unwrap_or(0);
    const BASE: u64 = 1_000_000_000;
    let mut a: Vec<u64> = vec![1];
    let mut b: Vec<u64> = vec![1];
    for _ in 0..n {
        let mut t: Vec<u64> = Vec::with_capacity(b.len() + 1);
        let mut carry = 0u64;
        let mut j = 0;
        while j < b.len() || carry > 0 {
            let mut s = carry;
            if j < a.len() { s += a[j]; }
            if j < b.len() { s += b[j]; }
            t.push(s % BASE);
            carry = s / BASE;
            j += 1;
        }
        a = b;
        b = t;
    }
    let mut out = format!("{}", a[a.len() - 1]);
    for j in (0..a.len() - 1).rev() {
        out.push_str(&format!("{:09}", a[j]));
    }
    println!("{}", out);
}
/* /* */
#endif
/* */ // */
