/* /* */
#include <cstdio>
#include <cstdlib>
#include <string>
int main(int argc, char **argv) {
    if (argc < 2) return 1;
    unsigned long long n = strtoull(argv[1], 0, 10);
    unsigned __int128 a = 1, b = 1;
    for (unsigned long long i = 0; i < n; i++) { unsigned __int128 t = a + b; a = b; b = t; }
    std::string s;
    do { s.insert(s.begin(), char('0' + (int)(a % 10))); a /= 10; } while (a);
    printf("%s\n", s.c_str());
    return 0;
}
/* */ // */
//\
fn main() { let n: u64 = std::env::args().nth(1).unwrap().trim().parse().unwrap(); let (mut a, mut b) = (1u128, 1u128); for _ in 0..n { let t = a + b; a = b; b = t; } println!("{}", a); }
