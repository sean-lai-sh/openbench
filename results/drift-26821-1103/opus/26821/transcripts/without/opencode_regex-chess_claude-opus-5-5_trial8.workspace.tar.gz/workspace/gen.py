import json

rules = []
FILES = "abcdefgh"


def sq(i):
    return FILES[i % 8] + str(8 - i // 8)


def fr(i):
    return i % 8, i // 8  # file, row (row 0 = rank 8)


def idx(f, r):
    return r * 8 + f


def onboard(f, r):
    return 0 <= f < 8 and 0 <= r < 8


# ---------- parse ----------
rules.append([r" \d+ \d+$", ""])
for n in range(8, 0, -1):
    rules.append([str(n) + r"(?=.* w )", "." * n])
rules.append(["/", ""])
rules.append([" w ", " "])
rules.append(["^", "O:"])


# ---------- move generation ----------
def move_rule(cond, change, newep="-", castle=r"\S+", ep=r"\S+", tag="M"):
    """cond: {index: regex class}, change: {index: char or None (keep captured)}."""
    pat = "(?m)^O:"
    rep = r"\g<0>" + "\n" + tag + ":"
    g = 0
    pos = 0
    keys = sorted(set(cond) | set(change))
    for k in keys:
        if k > pos:
            g += 1
            pat += "(.{%d})" % (k - pos)
            rep += r"\g<%d>" % g
        c = cond.get(k, ".")
        g += 1
        pat += "(" + c + ")"
        if k in change and change[k] is not None:
            rep += change[k]
        else:
            rep += r"\g<%d>" % g
        pos = k + 1
    if pos < 64:
        g += 1
        pat += "(.{%d})" % (64 - pos)
        rep += r"\g<%d>" % g
    g += 1
    pat += "( " + castle + ")"
    rep += r"\g<%d>" % g
    pat += " " + ep + "$"
    rep += " " + newep
    rules.append([pat, rep])


def piece_move(f, t, pclass, path, moved=None):
    # moved: char to place on t; None -> the captured piece char from f
    cond = {f: pclass, t: "[.a-z]"}
    for p in path:
        cond[p] = r"\."
    pat_change = {f: "."}
    rules_before = len(rules)
    # need the moved piece char: build with group reference trick
    if moved is not None:
        pat_change[t] = moved
        move_rule(cond, pat_change)
    else:
        # one rule per piece letter in the class
        for ch in pclass.strip("[]"):
            c2 = dict(cond)
            c2[f] = ch
            pc = dict(pat_change)
            pc[t] = ch
            move_rule(c2, pc)


# knights
for i in range(64):
    f0, r0 = fr(i)
    for df, dr in [(1, 2), (2, 1), (-1, 2), (-2, 1), (1, -2), (2, -1), (-1, -2), (-2, -1)]:
        if onboard(f0 + df, r0 + dr):
            piece_move(i, idx(f0 + df, r0 + dr), "N", [], "N")
# king
for i in range(64):
    f0, r0 = fr(i)
    for df in (-1, 0, 1):
        for dr in (-1, 0, 1):
            if (df or dr) and onboard(f0 + df, r0 + dr):
                piece_move(i, idx(f0 + df, r0 + dr), "K", [], "K")
# sliders
for i in range(64):
    f0, r0 = fr(i)
    for df, dr in [(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)]:
        cls = "[RQ]" if (df == 0 or dr == 0) else "[BQ]"
        path = []
        f, r = f0 + df, r0 + dr
        while onboard(f, r):
            piece_move(i, idx(f, r), cls, list(path))
            path.append(idx(f, r))
            f += df
            r += dr
# pawns
for i in range(8, 56):
    f0, r0 = fr(i)
    t = i - 8
    nc = "Q" if r0 == 1 else "P"
    move_rule({i: "P", t: r"\."}, {i: ".", t: nc})
    for df in (-1, 1):
        if onboard(f0 + df, r0 - 1):
            t = idx(f0 + df, r0 - 1)
            move_rule({i: "P", t: "[a-z]"}, {i: ".", t: nc})
    if r0 == 6:
        move_rule({i: "P", i - 8: r"\.", i - 16: r"\."}, {i: ".", i - 16: "P"}, newep=sq(i - 8))
    if r0 == 3:
        for df in (-1, 1):
            if onboard(f0 + df, r0):
                t = idx(f0 + df, 2)
                cap = idx(f0 + df, 3)
                move_rule({i: "P", t: r"\.", cap: "p"}, {i: ".", t: "P", cap: "."}, ep=sq(t))
# castling (king placed on all traversed squares for attack check)
move_rule({60: "K", 61: r"\.", 62: r"\.", 63: "R"}, {61: "K", 62: "K", 63: "."},
          castle=r"\S*K\S*", tag="C")
move_rule({56: "R", 57: r"\.", 58: r"\.", 59: r"\.", 60: "K"}, {56: ".", 58: "K", 59: "K"},
          castle=r"\S*Q\S*", tag="C")

# ---------- check detection ----------
for k in range(64):
    f0, r0 = fr(k)
    alts = []
    # knights
    for df, dr in [(1, 2), (2, 1), (-1, 2), (-2, 1), (1, -2), (2, -1), (-1, -2), (-2, -1)]:
        if onboard(f0 + df, r0 + dr):
            alts.append("(?=.{%d}n)" % idx(f0 + df, r0 + dr))
    # king
    for df in (-1, 0, 1):
        for dr in (-1, 0, 1):
            if (df or dr) and onboard(f0 + df, r0 + dr):
                alts.append("(?=.{%d}k)" % idx(f0 + df, r0 + dr))
    # pawns (black pawns attack downward: pawn at row r0-1)
    for df in (-1, 1):
        if onboard(f0 + df, r0 - 1):
            alts.append("(?=.{%d}p)" % idx(f0 + df, r0 - 1))
    # sliders
    for df, dr in [(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)]:
        cls = "[rq]" if (df == 0 or dr == 0) else "[bq]"
        path = []
        f, r = f0 + df, r0 + dr
        while onboard(f, r):
            s = idx(f, r)
            a = "(?=.{%d}%s)" % (s, cls)
            for p in path:
                a += r"(?=.{%d}\.)" % p
            alts.append(a)
            path.append(s)
            f += df
            r += dr
    rules.append(["(?m)^[MC]:(?=.{%d}K)(?:%s)" % (k, "|".join(alts)), "X:"])

# remove illegal lines and original
rules.append([r"\nX:[^\n]*", ""])
rules.append([r"^O:[^\n]*\n?", ""])
# finalize castling moves
rules.append([r"(?m)^C:(.{60})KKK\.", r"M:\1.RK."])
rules.append([r"(?m)^C:(.{56})\.\.KKK", r"M:\1..KR."])
# castling rights
rules.append([r"(?m)^(M:.{60}[^K].{3} [^ K]*)K", r"\1"])
rules.append([r"(?m)^(M:.{60}[^K].{3} [^ Q]*)Q", r"\1"])
rules.append([r"(?m)^(M:.{63}[^R] [^ K]*)K", r"\1"])
rules.append([r"(?m)^(M:.{56}[^R].{7} [^ Q]*)Q", r"\1"])
rules.append([r"(?m)^(M:[^r].{63} [^ q]*)q", r"\1"])
rules.append([r"(?m)^(M:.{7}[^r].{56} [^ k]*)k", r"\1"])
rules.append([r"(?m)^(M:.{64})  ", r"\1 - "])
# to FEN
rules.append([r"(?m)^M:" + "(.{8})" * 8 + r" (\S+) (\S+)$",
              "/".join(r"\g<%d>" % i for i in range(1, 9)) + r" b \g<9> \g<10> 0 0"])
for n in range(8, 0, -1):
    rules.append([r"\." * n if n == 1 else r"\.{%d}" % n, str(n)])

json.dump(rules, open("/tmp/obench-cell-ez2mdw3o/bench_opencode_regex-chess_gxc162zv/re.json", "w"))
print(len(rules))
