import json, re, random, time, chess

R = json.load(open("/tmp/obench-cell-ez2mdw3o/bench_opencode_regex-chess_gxc162zv/re.json"))


def run(fen):
    for p, r in R:
        fen = re.sub(p, r, fen)
    return [" ".join(x.split(" ")[:-2]) for x in fen.split("\n")]


def expected(board):
    s = set()
    for m in board.legal_moves:
        if m.promotion and m.promotion != chess.QUEEN:
            continue
        b = board.copy(); b.push(m)
        s.add(" ".join(b.fen().split(" ")[:-2]))
    return s


ex = run("rnb1k1nr/p2p1ppp/3B4/1p1NPN1P/6P1/3P1Q2/P1P5/q4Kb1 w kq - 0 1")
print(ex)
random.seed(1)
n = 0; t0 = time.time(); bad = 0
for g in range(400):
    b = chess.Board()
    for ply in range(random.randint(0, 150)):
        if b.is_game_over():
            break
        if b.turn == chess.WHITE:
            n += 1
            ours = run(b.fen())
            exp = expected(b)
            ok = len(ours) == len(exp) and all(x in exp or x.rpartition(" ")[0] + " -" in exp for x in ours)
            if not ok:
                bad += 1
                if bad < 5:
                    print("FAIL", b.fen()); print(sorted(ours)); print(sorted(exp))
        ms = list(b.legal_moves)
        caps = [m for m in ms if b.is_capture(m) or m.promotion or b.is_castling(m)]
        b.push(random.choice(caps if caps and random.random() < 0.5 else ms))
print(n, bad, time.time() - t0)
