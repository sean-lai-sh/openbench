#!/usr/bin/env python3
"""Hurdle jump analyzer.

Detects the takeoff and landing frames of a single hurdle jump in a video
recorded from a static camera, and writes them to a TOML file.

Approach:
  * The first frame is an empty background plate.
  * Each frame is background-subtracted to obtain the athlete silhouette.
  * The lowest silhouette point (feet) is tracked per frame.
  * A ground line (y as a function of x) is fitted to the lower envelope of
    these foot points (frames where the athlete stands on the track).
  * The flight phase is the run of consecutive frames, nearest the hurdle,
    where the feet are clearly above the ground line.
  * takeoff = last ground-contact frame before the flight,
    landing = first ground-contact frame after the flight.

Usage: python jump_analyzer.py [video.mp4] [output.toml]
"""
import os
import sys

import cv2
import numpy as np
import toml

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_VIDEO = os.path.join(HERE, "example_video.mp4")
DEFAULT_OUTPUT = os.path.join(HERE, "output.toml")

# Hurdle location (pixels) in the reference 960x540 geometry.
HURDLE_X = (490.0, 625.0)
REF_W, REF_H = 960.0, 540.0

DIFF_THRESH = 40       # per-pixel colour difference to count as foreground
MIN_AREA_FRAC = 1500.0 / (REF_W * REF_H)   # min silhouette area
AIR_TOL_FRAC = 10.0 / REF_H                # feet this far above ground => airborne


def read_frames(path):
    cap = cv2.VideoCapture(path)
    frames = []
    while True:
        ok, f = cap.read()
        if not ok:
            break
        frames.append(f)
    cap.release()
    return frames


def silhouette(frame, bg_blur, bg_med):
    f = cv2.GaussianBlur(frame, (5, 5), 0).astype(np.float32)
    # Compensate small global exposure changes.
    med = np.median(f.reshape(-1, 3), axis=0) + 1e-3
    f *= (bg_med / med)[None, None, :]
    d = np.abs(f - bg_blur).max(axis=2)
    m = (d > DIFF_THRESH).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
    return m


def foot_point(mask, min_area):
    """Return (x_of_lowest_point, y_lowest, x_min, x_max) of the athlete or None."""
    n, lab, st, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    if n < 2:
        return None
    areas = st[1:, cv2.CC_STAT_AREA]
    k = int(np.argmax(areas)) + 1
    if st[k, cv2.CC_STAT_AREA] < min_area:
        return None
    # Bounding box of the main blob, expanded to collect detached limbs.
    x, y, w, h = st[k, :4]
    pad = max(20, int(0.25 * h))
    x0, x1 = x - pad, x + w + pad
    y0, y1 = y - pad, y + h + pad
    keep = [k]
    for j in range(1, n):
        if j == k or st[j, cv2.CC_STAT_AREA] < 60:
            continue
        jx, jy, jw, jh = st[j, :4]
        if jx < x1 and jx + jw > x0 and jy < y1 and jy + jh > y0:
            keep.append(j)
    ys, xs = np.where(np.isin(lab, keep))
    ymax = ys.max()
    xb = float(np.median(xs[ys >= ymax - 2]))
    return xb, float(ymax), float(xs.min()), float(xs.max())


def fit_ground(points):
    """Fit y = a + b*x to the lower envelope (largest y) of the foot points."""
    pts = np.array(points, dtype=np.float64)
    if len(pts) < 3:
        return 0.0, float(pts[:, 1].max())
    xs, ys = pts[:, 0], pts[:, 1]
    b, a = 0.0, float(np.percentile(ys, 90))
    sel = np.ones(len(pts), bool)
    for _ in range(10):
        res = ys - (a + b * xs)
        # Keep points close to or below the current line (ground contacts).
        sel = res > -6
        if sel.sum() < 3:
            sel = res >= np.percentile(res, 50)
        if np.ptp(xs[sel]) > 50:
            b, a = np.polyfit(xs[sel], ys[sel], 1)
        else:
            b, a = 0.0, float(np.median(ys[sel]))
        # Pull towards the envelope: robust shift to the upper part of residuals.
        res = ys[sel] - (a + b * xs[sel])
        a += float(np.median(res))
    return float(a), float(b)


def analyze(path):
    frames = read_frames(path)
    if not frames:
        raise RuntimeError("Could not read video: %s" % path)
    H, W = frames[0].shape[:2]
    sx, sy = W / REF_W, H / REF_H
    min_area = MIN_AREA_FRAC * W * H
    air_tol = AIR_TOL_FRAC * H
    hx0, hx1 = HURDLE_X[0] * sx, HURDLE_X[1] * sx
    hc = 0.5 * (hx0 + hx1)

    bg_blur = cv2.GaussianBlur(frames[0], (5, 5), 0).astype(np.float32)
    bg_med = np.median(bg_blur.reshape(-1, 3), axis=0) + 1e-3

    info = [None] * len(frames)
    for i, f in enumerate(frames):
        if i == 0:
            continue
        info[i] = foot_point(silhouette(f, bg_blur, bg_med), min_area)

    # Segment of frames where athlete is visible, choose the one passing the hurdle.
    present = [i for i, v in enumerate(info) if v is not None]
    if not present:
        return 0, 0
    segs, cur = [], [present[0]]
    for i in present[1:]:
        if i - cur[-1] <= 2:
            cur.append(i)
        else:
            segs.append(cur)
            cur = [i]
    segs.append(cur)

    def seg_score(s):
        crosses = any(info[i][2] < hc < info[i][3] for i in s)
        return (crosses, len(s))

    seg = max(segs, key=seg_score)
    seg = list(range(seg[0], seg[-1] + 1))

    pts = [(info[i][0], info[i][1]) for i in seg if info[i] is not None]
    a, b = fit_ground(pts)

    height = {}
    for i in seg:
        if info[i] is None:
            continue
        xb, yb = info[i][0], info[i][1]
        height[i] = (a + b * xb) - yb  # >0 means feet above the ground
    air = {i: h > air_tol for i, h in height.items()}

    # Runs of airborne frames.
    runs, cur = [], []
    for i in seg:
        if air.get(i, False):
            cur.append(i)
        else:
            if cur:
                runs.append(cur)
            cur = []
    if cur:
        runs.append(cur)

    if not runs:
        # Fallback: frame closest to hurdle centre with max foot height.
        i = max(height, key=lambda k: height[k])
        return max(seg[0], i - 1), min(seg[-1], i + 1)

    def run_score(r):
        xs = [info[i][0] for i in r]
        ext = [(info[i][2], info[i][3]) for i in r]
        over = any(e0 < hc < e1 for e0, e1 in ext)
        dist = min(abs(x - hc) for x in xs)
        peak = max(height[i] for i in r)
        return (over, len(r) >= 2, -dist + 2.0 * peak + 3.0 * len(r))

    run = max(runs, key=run_score)

    # Merge adjacent runs separated by a single noisy "contact" frame.
    idx = runs.index(run)
    start, end = run[0], run[-1]
    j = idx - 1
    while j >= 0 and start - runs[j][-1] <= 2 and \
            height.get(start - 1, 0) > 0.5 * air_tol:
        start = runs[j][0]
        j -= 1
    j = idx + 1
    while j < len(runs) and runs[j][0] - end <= 2 and \
            height.get(end + 1, 0) > 0.5 * air_tol:
        end = runs[j][-1]
        j += 1

    takeoff = start - 1
    land = end + 1
    takeoff = max(takeoff, 0)
    land = min(land, len(frames) - 1)
    return int(takeoff), int(land)


def main():
    video = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_VIDEO
    out = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_OUTPUT
    takeoff, land = analyze(video)
    result = {
        "jump_takeoff_frame_number": int(takeoff),
        "jump_land_frame_number": int(land),
    }
    with open(out, "w") as fh:
        toml.dump(result, fh)
    print(toml.dumps(result), end="")


if __name__ == "__main__":
    main()
