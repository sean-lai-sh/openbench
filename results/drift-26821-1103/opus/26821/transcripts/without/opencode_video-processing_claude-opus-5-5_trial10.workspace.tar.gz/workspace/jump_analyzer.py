#!/usr/bin/env python3
"""Hurdle jump analyzer.

Detects the takeoff and landing frames of a single hurdle jump in an MP4
video recorded from a static camera.

Approach:
  1. The first frame (no runner) is used as background.
  2. Each frame is brightness-normalised against the background (handles
     auto-exposure drift) and differenced to obtain a foreground mask.
  3. The athlete is the largest connected foreground blob; its lowest
     point gives the foot height for every frame.
  4. The ground level is estimated from frames where the athlete is in
     contact with the ground. Frames where the lowest point is clearly
     above the ground are "airborne".
  5. The jump is the longest airborne run (normal running flight phases
     are only 1-3 frames). Takeoff = first airborne frame, landing = first
     frame where a foot touches the ground again.

Usage: python jump_analyzer.py [video.mp4] [output.toml]
"""
import os
import sys

import cv2
import numpy as np
import toml

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_VIDEO = os.path.join(HERE, "example_video.mp4")
DEFAULT_OUTPUT = os.path.join(HERE, "output.toml")

DIFF_THRESH = 25        # colour difference threshold for foreground
MIN_BLOB_AREA = 800     # minimum athlete blob area (pixels)
AIR_MARGIN = 10         # pixels above ground to count as airborne


def read_frames(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open video: {path}")
    frames = []
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frames.append(frame)
    cap.release()
    if not frames:
        raise RuntimeError(f"No frames read from: {path}")
    return frames


def athlete_mask(frame, bg):
    f = cv2.GaussianBlur(frame.astype(np.float32), (5, 5), 0)
    # Global brightness normalisation (per channel)
    ratio = np.median(f / (bg + 1.0), axis=(0, 1))
    diff = np.abs(f - bg * ratio).max(axis=2)
    mask = (diff > DIFF_THRESH).astype(np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    return mask


def largest_blob(mask):
    """Return the mask of the largest blob (after closing to join limbs)."""
    closed = cv2.morphologyEx(mask, cv2.MORPH_CLOSE,
                              cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15)))
    n, labels, stats, _ = cv2.connectedComponentsWithStats(closed)
    if n <= 1:
        return None
    idx = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    blob = (labels == idx) & (mask > 0)
    if blob.sum() < MIN_BLOB_AREA:
        return None
    return blob


def analyze(path):
    frames = read_frames(path)
    bg = cv2.GaussianBlur(frames[0].astype(np.float32), (5, 5), 0)
    h, w = frames[0].shape[:2]

    n = len(frames)
    bottom = np.full(n, np.nan)
    top = np.full(n, np.nan)
    area = np.zeros(n)
    for i, fr in enumerate(frames):
        blob = largest_blob(athlete_mask(fr, bg))
        if blob is None:
            continue
        rows = blob.sum(axis=1)
        ys = np.nonzero(rows >= 2)[0]
        if len(ys) == 0:
            continue
        xs = np.nonzero(blob.any(axis=0))[0]
        bh = ys.max() - ys.min()
        bw = xs.max() - xs.min()
        # Plausible person shape: tall enough, not spanning the whole frame
        if bh < 0.25 * h or bw > 0.45 * w:
            continue
        bottom[i] = ys.max()
        top[i] = ys.min()
        area[i] = blob.sum()

    cand = ~np.isnan(bottom)
    if cand.sum() < 3:
        return 0, 0

    # Pick the main contiguous segment of athlete detections (gaps <= 2
    # frames allowed) with the largest total area. This rejects sporadic
    # false detections caused by background/lighting changes.
    segs = []
    idx = np.nonzero(cand)[0]
    s = p = idx[0]
    for k in idx[1:]:
        if k - p > 3:
            segs.append((s, p))
            s = k
        p = k
    segs.append((s, p))
    s0, e0 = max(segs, key=lambda se: area[se[0]:se[1] + 1].sum())
    valid = np.zeros(n, bool)
    valid[s0:e0 + 1] = cand[s0:e0 + 1]

    vb = bottom[valid]
    # Ground level: feet are on the ground in the majority of frames, so a
    # high percentile of the lowest point gives the contact height.
    ground = np.percentile(vb, 75)
    contact = vb[vb >= ground - AIR_MARGIN]
    if len(contact):
        ground = np.median(contact)

    airborne = valid & (bottom < ground - AIR_MARGIN)

    # Find airborne runs (only within the valid athlete span)
    runs = []
    i = 0
    while i < n:
        if airborne[i]:
            j = i
            while j + 1 < n and airborne[j + 1]:
                j += 1
            runs.append((i, j))
            i = j + 1
        else:
            i += 1

    # Ignore runs touching the start/end of the athlete visibility (partial)
    vidx = np.nonzero(valid)[0]
    first_v, last_v = vidx.min(), vidx.max()

    def score(run):
        s, e = run
        length = e - s + 1
        # Height of flight: how far above ground the feet get
        lift = ground - np.nanmin(bottom[s:e + 1])
        penalty = 0.5 if (s <= first_v or e >= last_v) else 1.0
        return length * penalty * (1.0 + lift / 100.0)

    if not runs:
        # Fallback: frame with highest feet
        k = int(np.nanargmin(np.where(valid, bottom, np.inf)))
        return max(k - 1, 0), min(k + 1, n - 1)

    s, e = max(runs, key=score)
    takeoff = int(s)
    land = int(min(e + 1, n - 1))
    return takeoff, land


def main():
    video = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_VIDEO
    out = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_OUTPUT
    takeoff, land = analyze(video)
    result = {
        "jump_takeoff_frame_number": int(takeoff),
        "jump_land_frame_number": int(land),
    }
    with open(out, "w") as f:
        toml.dump(result, f)
    print(toml.dumps(result), end="")


if __name__ == "__main__":
    main()
