import json, re, random, chess, sys

RULES = [(re.compile(p), r) for p, r in json.load(open("re.json"))]


def run(fen):
    for p, r in RULES:
        fen = p.sub(r, fen)
    return fen.split("\n")


def expected(board):
    out = set()
    for m in board.legal_moves:
        if m.promotion and m.promotion != chess.QUEEN:
            continue
        b = board.copy()
        b.push(m)
        out.add(" ".join(b.fen().split(" ")[:-2]))
    return out


def check(fen):
    ours = [" ".join(x.split(" ")[:-2]) for x in run(fen)]
    exp = expected(chess.Board(fen))
    ok = len(ours) == len(exp) and all(
        x in exp or x.rpartition(" ")[0] + " -" in exp for x in ours)
    if not ok:
        print("FAIL", fen)
        print(" extra", [x for x in ours if x not in exp and x.rpartition(" ")[0] + " -" not in exp])
        print(" missing", exp - set(ours))
        print(" dup", len(ours), len(set(ours)))
    return ok


s = "rnb1k1nr/p2p1ppp/3B4/1p1NPN1P/6P1/3P1Q2/P1P5/q4Kb1 w kq - 0 1"
print(run(s))
random.seed(int(sys.argv[1]) if len(sys.argv) > 1 else 0)
n = fails = 0
for g in range(300):
    b = chess.Board()
    while not b.is_game_over() and b.ply() < 200:
        if b.turn == chess.WHITE:
            n += 1
            if not check(b.fen()):
                fails += 1
                if fails > 5:
                    sys.exit()
        moves = list(b.legal_moves)
        # prefer captures/promotions/castling sometimes
        b.push(random.choice(moves))
print("tested", n, "fails", fails)
