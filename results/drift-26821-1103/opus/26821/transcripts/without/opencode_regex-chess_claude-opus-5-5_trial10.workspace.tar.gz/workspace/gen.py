import json

rules = []


def add(p, r):
    rules.append([p, r])


def idx(f, r):  # file 0-7, rank 1-8
    return (8 - r) * 8 + f


def fr(i):
    return i % 8, 8 - i // 8


# ---------- 1. parse FEN into internal form ----------
add(r"^(\S+) w (\S+) (\S+) \S+ \S+\s*$", r"\1 \2 \3")
for d in range(8, 0, -1):
    add(str(d) + r"(?=\S* )", "." * d)
add(r"/", "")
for m in range(16):
    full = "".join(c if m >> k & 1 else "-" for k, c in enumerate("KQkq"))
    short = full.replace("-", "") or "-"
    add(r"^(\S+) " + short + " ", r"\1 " + full + " ")
add(r"^", "@")

# ---------- 2. pseudo-legal move generation ----------


def move_rule(conds, mods, newep="-", extra=""):
    look = "".join("(?=.{%d}%s)" % (i, c) for i, c in sorted(conds.items())) + extra
    pat = "@" + look
    g = 0
    orig, new = [], []
    cgroup = {}
    pos = 0
    for i in sorted(mods):
        if i > pos:
            pat += "(.{%d})" % (i - pos)
            g += 1
            orig.append(g)
            new.append(("g", g))
        pat += "(.)"
        g += 1
        cgroup[i] = g
        orig.append(g)
        new.append(("m", i))
        pos = i + 1
    if pos < 64:
        pat += "(.{%d})" % (64 - pos)
        g += 1
        orig.append(g)
        new.append(("g", g))
    pat += r" (\S+) (\S+)"
    cg, eg = g + 1, g + 2
    rep = "@" + "".join("\\g<%d>" % n for n in orig) + " \\g<%d> \\g<%d>\n" % (cg, eg)
    for kind, v in new:
        if kind == "g":
            rep += "\\g<%d>" % v
        else:
            m = mods[v]
            if m[0] == "lit":
                rep += m[1]
            else:
                rep += "\\g<%d>" % cgroup[m[1]]
    rep += " \\g<%d> " % cg + newep
    add(pat, rep)


TGT = "[a-z.]"
KN = [(1, 2), (2, 1), (2, -1), (1, -2), (-1, -2), (-2, -1), (-2, 1), (-1, 2)]
KG = [(1, 0), (1, 1), (0, 1), (-1, 1), (-1, 0), (-1, -1), (0, -1), (1, -1)]
ORTH = [(1, 0), (-1, 0), (0, 1), (0, -1)]
DIAG = [(1, 1), (1, -1), (-1, 1), (-1, -1)]


def onb(f, r):
    return 0 <= f < 8 and 1 <= r <= 8


for s in range(64):
    f, r = fr(s)
    # knights / king steps
    for piece, deltas in (("N", KN), ("K", KG)):
        for df, dr in deltas:
            if onb(f + df, r + dr):
                t = idx(f + df, r + dr)
                move_rule({s: piece, t: TGT}, {s: ("lit", "."), t: ("copy", s)})
    # sliders
    for dirs, cls in ((ORTH, "[QR]"), (DIAG, "[QB]")):
        for df, dr in dirs:
            between = []
            k = 1
            while onb(f + df * k, r + dr * k):
                t = idx(f + df * k, r + dr * k)
                conds = {s: cls, t: TGT}
                for b in between:
                    conds[b] = r"\."
                move_rule(conds, {s: ("lit", "."), t: ("copy", s)})
                between.append(t)
                k += 1
    # pawns
    if 2 <= r <= 7:
        promo = "Q" if r == 7 else "P"
        t = idx(f, r + 1)
        move_rule({s: "P", t: r"\."}, {s: ("lit", "."), t: ("lit", promo)})
        if r == 2:
            t2 = idx(f, 4)
            move_rule({s: "P", t: r"\.", t2: r"\."}, {s: ("lit", "."), t2: ("lit", "P")},
                      newep="abcdefgh"[f] + "3")
        for df in (-1, 1):
            if onb(f + df, r + 1):
                t = idx(f + df, r + 1)
                move_rule({s: "P", t: "[a-z]"}, {s: ("lit", "."), t: ("lit", promo)})
                if r == 5:
                    cap = idx(f + df, 5)
                    sq = "abcdefgh"[f + df] + "6"
                    move_rule({s: "P", t: r"\.", cap: "p"},
                              {s: ("lit", "."), t: ("lit", "P"), cap: ("lit", ".")},
                              extra="(?=.{64} \\S{4} %s)" % sq)

# castling (fake kings on transit squares, fixed up after legality filter)
e1, f1, g1, h1, d1, c1, b1, a1 = (idx(x, 1) for x in (4, 5, 6, 7, 3, 2, 1, 0))
move_rule({e1: "K", f1: r"\.", g1: r"\.", h1: "R"},
          {f1: ("lit", "K"), g1: ("lit", "K"), h1: ("lit", ".")},
          extra=r"(?=.{64} K)")
move_rule({e1: "K", d1: r"\.", c1: r"\.", b1: r"\.", a1: "R"},
          {d1: ("lit", "K"), c1: ("lit", "K"), a1: ("lit", ".")},
          extra=r"(?=.{64} .Q)")

# remove original line
add(r"@[^\n]*\n?", "")

# ---------- 3. legality filter: delete lines with an attacked K ----------


def kill(conds):
    look = "".join("(?=.{%d}%s)" % (i, c) for i, c in sorted(conds.items()))
    add("(?m)^" + look + r"[^\n]*\n?", "")


for k in range(64):
    f, r = fr(k)
    for df, dr in KN:
        if onb(f + df, r + dr):
            kill({k: "K", idx(f + df, r + dr): "n"})
    for df, dr in KG:
        if onb(f + df, r + dr):
            kill({k: "K", idx(f + df, r + dr): "k"})
    for df in (-1, 1):
        if onb(f + df, r + 1):
            kill({k: "K", idx(f + df, r + 1): "p"})
    for dirs, cls in ((ORTH, "[qr]"), (DIAG, "[qb]")):
        for df, dr in dirs:
            between = []
            j = 1
            while onb(f + df * j, r + dr * j):
                t = idx(f + df * j, r + dr * j)
                conds = {k: "K", t: cls}
                for b in between:
                    conds[b] = r"\."
                kill(conds)
                between.append(t)
                j += 1

# ---------- 4. post-processing ----------
add(r"(?m)^(.{60})KKK\.", r"\1.RK.")
add(r"(?m)^(.{56})\.\.KKK", r"\1..KR.")
# castling rights from piece placement
add(r"(?m)^(.{60}[^K].{3} )..", r"\1--")
add(r"(?m)^(.{63}[^R] ).", r"\1-")
add(r"(?m)^(.{56}[^R].{7} .).", r"\1-")
add(r"(?m)^(.{4}[^k].{59} ..)..", r"\1--")
add(r"(?m)^(.{7}[^r].{56} ..).", r"\1-")
add(r"(?m)^([^r].{63} ...).", r"\1-")
# format castling field
for _ in range(4):
    add(r"(?m)^(\S{64} [KQkq]*)-", r"\1")
add(r"(?m)^(\S{64})  ", r"\1 - ")
# board -> FEN
add(r"(?m)^" + "(.{8})" * 8 + " ", "/".join("\\%d" % i for i in range(1, 9)) + " ")
for d in range(8, 0, -1):
    add(r"\." * d, str(d))
add(r"(?m)^(\S+) (\S+) (\S+)$", r"\1 b \2 \3 0 0")
add(r"\n+\Z", "")

json.dump(rules, open("re.json", "w"))
print(len(rules))
