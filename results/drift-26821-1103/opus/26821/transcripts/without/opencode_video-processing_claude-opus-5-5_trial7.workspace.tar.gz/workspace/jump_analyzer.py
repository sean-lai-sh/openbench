#!/usr/bin/env python3
"""Hurdle jump analyzer.

Detects the takeoff and landing frames of a single hurdle jump in an MP4
video recorded with a static camera, and writes them to a TOML file.

Approach:
  1. Read all frames, convert to (blurred) grayscale and register each frame
     to the first one with phase correlation (compensates small camera drift).
  2. Build a clean background as the per-pixel median of the aligned frames.
  3. Background-subtract each frame, merge the foreground fragments into the
     runner blob and record the lowest foreground pixel (the feet).
  4. The jump is the airborne interval around the frame where the feet are
     highest. The takeoff frame is the last ground-contact frame before it,
     the landing frame is the first ground-contact frame after it.

Usage:
  python3 jump_analyzer.py [input.mp4] [output.toml]
"""
import os
import sys

import cv2
import numpy as np
import toml

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_INPUT = os.path.join(HERE, "example_video.mp4")
DEFAULT_OUTPUT = os.path.join(HERE, "output.toml")

DIFF_THRESH = 25          # gray-level difference to count as foreground
MIN_BLOB_AREA = 3000      # min (dilated) blob area to be considered the runner
AIR_MARGIN = 10           # px above local ground level to count as airborne
GROUND_WINDOW = 8         # frames on each side used to estimate local ground


def read_aligned_frames(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise RuntimeError("Cannot open video: %s" % path)
    frames = []
    ref = None
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        g = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY).astype(np.float32)
        h, w = g.shape
        if ref is None:
            ref = g
            dx = dy = 0.0
        else:
            (dx, dy), _ = cv2.phaseCorrelate(ref, g)
        g = cv2.GaussianBlur(g, (5, 5), 0)
        if dx or dy:
            M = np.float32([[1, 0, -dx], [0, 1, -dy]])
            g = cv2.warpAffine(g, M, (w, h), borderMode=cv2.BORDER_REPLICATE)
        frames.append(np.clip(g, 0, 255).astype(np.uint8))
    cap.release()
    if not frames:
        raise RuntimeError("Video has no frames: %s" % path)
    return frames


def build_background(frames):
    n = len(frames)
    step = max(1, n // 80)
    sample = np.stack(frames[::step], axis=0)
    return np.median(sample, axis=0).astype(np.int16)


def runner_measurements(frames, bg):
    """Return per-frame (bottom_y, center_x) of the runner, or None."""
    k_open = np.ones((3, 3), np.uint8)
    k_dil = np.ones((25, 25), np.uint8)
    out = []
    for g in frames:
        m = (np.abs(g.astype(np.int16) - bg) > DIFF_THRESH).astype(np.uint8)
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, k_open)
        d = cv2.dilate(m, k_dil)
        n, lab, st, _ = cv2.connectedComponentsWithStats(d)
        if n < 2:
            out.append(None)
            continue
        k = 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA]))
        if st[k, cv2.CC_STAT_AREA] < MIN_BLOB_AREA:
            out.append(None)
            continue
        ys, xs = np.nonzero(m * (lab == k))
        if len(ys) < 100:
            out.append(None)
            continue
        out.append((int(ys.max()), float(xs.mean()), int(ys.min())))
    return out


def detect_jump(meas):
    n = len(meas)
    valid = [i for i in range(n) if meas[i] is not None]
    if not valid:
        return 0, max(0, n - 1)
    bottom = np.full(n, np.nan)
    for i in valid:
        bottom[i] = meas[i][0]

    def local_ground(i):
        lo, hi = max(0, i - GROUND_WINDOW), min(n, i + GROUND_WINDOW + 1)
        w = bottom[lo:hi]
        w = w[~np.isnan(w)]
        return np.max(w) if len(w) else np.nan

    def airborne(i):
        if np.isnan(bottom[i]):
            return False
        return bottom[i] < local_ground(i) - AIR_MARGIN

    # Peak of the jump: frame where the feet are highest relative to ground.
    height = np.array([local_ground(i) - bottom[i] if not np.isnan(bottom[i])
                       else -np.inf for i in range(n)])
    # Ignore frames where the runner is only partially visible at the edges
    # with tiny blobs; prefer frames with a complete body (top well above feet)
    for i in valid:
        if meas[i][0] - meas[i][2] < 100:
            height[i] = -np.inf
    peak = int(np.argmax(height))

    a = peak
    while a - 1 >= 0 and airborne(a - 1):
        a -= 1
    b = peak
    while b + 1 < n and airborne(b + 1):
        b += 1
    takeoff = max(0, a - 1)
    land = min(n - 1, b + 1)
    return takeoff, land


def main():
    inp = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_INPUT
    outp = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_OUTPUT
    frames = read_aligned_frames(inp)
    bg = build_background(frames)
    meas = runner_measurements(frames, bg)
    takeoff, land = detect_jump(meas)
    result = {
        "jump_takeoff_frame_number": int(takeoff),
        "jump_land_frame_number": int(land),
    }
    with open(outp, "w") as f:
        toml.dump(result, f)
    print(toml.dumps(result), end="")


if __name__ == "__main__":
    main()
