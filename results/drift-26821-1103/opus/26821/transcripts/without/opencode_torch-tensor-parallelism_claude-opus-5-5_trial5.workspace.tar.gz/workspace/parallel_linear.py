"""Tensor-parallel linear layers (Megatron-style) implemented with torch.distributed.

Weight layout follows torch.nn.Linear: weight has shape (out_features, in_features)
and y = x @ W^T + b.

* ColumnParallelLinear: the output dimension is partitioned (columns of A in Y = XA,
  i.e. rows of the nn.Linear weight). Each rank computes a slice of the output and
  the slices are all-gathered along the last dimension. Bias is sharded likewise.
* RowParallelLinear: the input dimension is partitioned (rows of A in Y = XA,
  i.e. columns of the nn.Linear weight). Each rank computes a partial output, and
  the partial outputs are summed with all-reduce. Bias is kept full on every rank
  and added once after the reduction.
"""

import torch
import torch.distributed as dist
import torch.nn as nn
import torch.nn.functional as F


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _dist_ready():
    return dist.is_available() and dist.is_initialized()


def _world_size():
    return dist.get_world_size() if _dist_ready() else 1


def _rank():
    return dist.get_rank() if _dist_ready() else 0


def _split_last_dim(x, world_size, rank):
    if world_size == 1:
        return x
    size = x.shape[-1] // world_size
    return x.narrow(-1, rank * size, size).contiguous()


def _gather_last_dim(x, world_size):
    if world_size == 1:
        return x
    x = x.contiguous()
    parts = [torch.empty_like(x) for _ in range(world_size)]
    dist.all_gather(parts, x)
    return torch.cat(parts, dim=-1).contiguous()


def _all_reduce(x, world_size):
    if world_size == 1:
        return x
    x = x.contiguous().clone()
    dist.all_reduce(x, op=dist.ReduceOp.SUM)
    return x


# ---------------------------------------------------------------------------
# Autograd-aware communication primitives
# ---------------------------------------------------------------------------
class _CopyToParallelRegion(torch.autograd.Function):
    """Forward: identity. Backward: all-reduce (sum) the gradient."""

    @staticmethod
    def forward(ctx, x):
        return x

    @staticmethod
    def backward(ctx, grad):
        return _all_reduce(grad, _world_size())


class _ReduceFromParallelRegion(torch.autograd.Function):
    """Forward: all-reduce (sum). Backward: identity."""

    @staticmethod
    def forward(ctx, x):
        return _all_reduce(x, _world_size())

    @staticmethod
    def backward(ctx, grad):
        return grad


class _ScatterToParallelRegion(torch.autograd.Function):
    """Forward: keep this rank's slice of the last dim. Backward: all-gather."""

    @staticmethod
    def forward(ctx, x):
        return _split_last_dim(x, _world_size(), _rank())

    @staticmethod
    def backward(ctx, grad):
        return _gather_last_dim(grad, _world_size())


class _GatherFromParallelRegion(torch.autograd.Function):
    """Forward: all-gather along the last dim. Backward: keep this rank's slice."""

    @staticmethod
    def forward(ctx, x):
        return _gather_last_dim(x, _world_size())

    @staticmethod
    def backward(ctx, grad):
        return _split_last_dim(grad, _world_size(), _rank())


# ---------------------------------------------------------------------------
# Layers
# ---------------------------------------------------------------------------
class ColumnParallelLinear(nn.Module):
    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.world_size = _world_size()
        self.rank = _rank()
        if out_features % self.world_size != 0:
            raise ValueError(
                f"out_features ({out_features}) must be divisible by world_size ({self.world_size})"
            )
        self.in_features = in_features
        self.out_features = out_features
        self.output_size_per_partition = out_features // self.world_size

        master_weight = torch.as_tensor(master_weight).detach()
        if tuple(master_weight.shape) != (out_features, in_features):
            raise ValueError(
                f"master_weight shape {tuple(master_weight.shape)} != "
                f"({out_features}, {in_features})"
            )
        start = self.rank * self.output_size_per_partition
        shard = master_weight[start:start + self.output_size_per_partition, :]
        self.weight = nn.Parameter(shard.clone().contiguous())

        if bias:
            self.bias = nn.Parameter(
                torch.zeros(self.output_size_per_partition,
                            dtype=self.weight.dtype, device=self.weight.device)
            )
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        x = _CopyToParallelRegion.apply(x)
        local_out = F.linear(x, self.weight, self.bias)
        return _GatherFromParallelRegion.apply(local_out)


class RowParallelLinear(nn.Module):
    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.world_size = _world_size()
        self.rank = _rank()
        if in_features % self.world_size != 0:
            raise ValueError(
                f"in_features ({in_features}) must be divisible by world_size ({self.world_size})"
            )
        self.in_features = in_features
        self.out_features = out_features
        self.input_size_per_partition = in_features // self.world_size

        master_weight = torch.as_tensor(master_weight).detach()
        if tuple(master_weight.shape) != (out_features, in_features):
            raise ValueError(
                f"master_weight shape {tuple(master_weight.shape)} != "
                f"({out_features}, {in_features})"
            )
        start = self.rank * self.input_size_per_partition
        shard = master_weight[:, start:start + self.input_size_per_partition]
        self.weight = nn.Parameter(shard.clone().contiguous())

        if bias:
            self.bias = nn.Parameter(
                torch.zeros(out_features, dtype=self.weight.dtype, device=self.weight.device)
            )
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        # Accept either the full input (split it here) or an already-partitioned input.
        if x.shape[-1] == self.in_features and self.world_size > 1:
            x = _ScatterToParallelRegion.apply(x)
        elif x.shape[-1] != self.input_size_per_partition:
            raise ValueError(
                f"Input last dim {x.shape[-1]} matches neither in_features "
                f"({self.in_features}) nor the partition size ({self.input_size_per_partition})"
            )
        partial = F.linear(x, self.weight)
        out = _ReduceFromParallelRegion.apply(partial)
        if self.bias is not None:
            out = out + self.bias
        return out
