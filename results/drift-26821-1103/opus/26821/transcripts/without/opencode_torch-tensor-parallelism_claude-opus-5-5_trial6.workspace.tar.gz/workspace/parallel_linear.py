"""Tensor-parallel linear layers (Megatron-style).

Weight layout follows torch.nn.Linear: weight has shape (out_features, in_features)
and y = x @ W^T + b.

* ColumnParallelLinear: W is split along the output dimension (the columns of
  W^T). Each rank computes a slice of the output; the slices are all-gathered
  and concatenated along the last dimension. The bias is sharded likewise.
* RowParallelLinear: W is split along the input dimension (the rows of W^T).
  Each rank computes a partial output from its slice of the input; the partial
  outputs are all-reduced (summed). The bias is kept full on each rank and added
  after the reduction.
"""

import torch
import torch.distributed as dist
import torch.nn as nn
import torch.nn.functional as F


def _world_size():
    if dist.is_available() and dist.is_initialized():
        return dist.get_world_size()
    return 1


def _rank():
    if dist.is_available() and dist.is_initialized():
        return dist.get_rank()
    return 0


def _divide(numerator, denominator):
    if numerator % denominator != 0:
        raise ValueError(f"{numerator} is not divisible by {denominator}")
    return numerator // denominator


def _split_last_dim(x):
    ws = _world_size()
    if ws == 1:
        return x
    chunk = _divide(x.shape[-1], ws)
    r = _rank()
    return x[..., r * chunk:(r + 1) * chunk].contiguous()


def _gather_last_dim(x):
    ws = _world_size()
    if ws == 1:
        return x
    x = x.contiguous()
    parts = [torch.empty_like(x) for _ in range(ws)]
    dist.all_gather(parts, x)
    return torch.cat(parts, dim=-1).contiguous()


def _all_reduce(x):
    if _world_size() == 1:
        return x
    x = x.contiguous().clone()
    dist.all_reduce(x, op=dist.ReduceOp.SUM)
    return x


# --------------------------------------------------------------------------- #
# Autograd-aware communication primitives
# --------------------------------------------------------------------------- #
class _CopyToParallelRegion(torch.autograd.Function):
    """Forward: identity. Backward: all-reduce the gradient."""

    @staticmethod
    def forward(ctx, x):
        return x

    @staticmethod
    def backward(ctx, grad):
        return _all_reduce(grad)


class _ReduceFromParallelRegion(torch.autograd.Function):
    """Forward: all-reduce. Backward: identity."""

    @staticmethod
    def forward(ctx, x):
        return _all_reduce(x)

    @staticmethod
    def backward(ctx, grad):
        return grad


class _ScatterToParallelRegion(torch.autograd.Function):
    """Forward: take this rank's slice of the last dim. Backward: all-gather."""

    @staticmethod
    def forward(ctx, x):
        return _split_last_dim(x)

    @staticmethod
    def backward(ctx, grad):
        return _gather_last_dim(grad)


class _GatherFromParallelRegion(torch.autograd.Function):
    """Forward: all-gather along last dim. Backward: take this rank's slice."""

    @staticmethod
    def forward(ctx, x):
        return _gather_last_dim(x)

    @staticmethod
    def backward(ctx, grad):
        return _split_last_dim(grad)


def copy_to_parallel_region(x):
    return _CopyToParallelRegion.apply(x)


def reduce_from_parallel_region(x):
    return _ReduceFromParallelRegion.apply(x)


def scatter_to_parallel_region(x):
    return _ScatterToParallelRegion.apply(x)


def gather_from_parallel_region(x):
    return _GatherFromParallelRegion.apply(x)


# --------------------------------------------------------------------------- #
# Layers
# --------------------------------------------------------------------------- #
class ColumnParallelLinear(nn.Module):
    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.world_size = _world_size()
        self.rank = _rank()
        self.out_features_per_partition = _divide(out_features, self.world_size)

        master_weight = torch.as_tensor(master_weight)
        if tuple(master_weight.shape) != (out_features, in_features):
            raise ValueError(
                f"master_weight must have shape ({out_features}, {in_features}), "
                f"got {tuple(master_weight.shape)}"
            )

        start = self.rank * self.out_features_per_partition
        end = start + self.out_features_per_partition
        self.weight = nn.Parameter(master_weight.detach()[start:end, :].clone().contiguous())

        if bias:
            self.bias = nn.Parameter(
                torch.zeros(
                    self.out_features_per_partition,
                    dtype=self.weight.dtype,
                    device=self.weight.device,
                )
            )
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        x = copy_to_parallel_region(x)
        local_out = F.linear(x, self.weight, self.bias)
        return gather_from_parallel_region(local_out)


class RowParallelLinear(nn.Module):
    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.world_size = _world_size()
        self.rank = _rank()
        self.in_features_per_partition = _divide(in_features, self.world_size)

        master_weight = torch.as_tensor(master_weight)
        if tuple(master_weight.shape) != (out_features, in_features):
            raise ValueError(
                f"master_weight must have shape ({out_features}, {in_features}), "
                f"got {tuple(master_weight.shape)}"
            )

        start = self.rank * self.in_features_per_partition
        end = start + self.in_features_per_partition
        self.weight = nn.Parameter(master_weight.detach()[:, start:end].clone().contiguous())

        if bias:
            self.bias = nn.Parameter(
                torch.zeros(out_features, dtype=self.weight.dtype, device=self.weight.device)
            )
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        # Accept either the full input (split it here) or an already-partitioned input.
        if x.shape[-1] == self.in_features and self.world_size > 1:
            x = scatter_to_parallel_region(x)
        elif x.shape[-1] != self.in_features_per_partition:
            raise ValueError(
                f"Expected input last dim {self.in_features} (full) or "
                f"{self.in_features_per_partition} (partitioned), got {x.shape[-1]}"
            )
        partial = F.linear(x, self.weight)
        out = reduce_from_parallel_region(partial)
        if self.bias is not None:
            out = out + self.bias
        return out
