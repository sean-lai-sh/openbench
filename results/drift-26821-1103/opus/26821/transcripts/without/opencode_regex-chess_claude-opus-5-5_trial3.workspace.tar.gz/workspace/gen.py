import json

rules = []
def R(p, r):
    rules.append([p, r])

def sq(name):
    f = ord(name[0]) - 97
    rank = int(name[1])
    return (8 - rank) * 8 + f

def rc(i):
    return i // 8, i % 8

def idx(r, c):
    return r * 8 + c

def onb(r, c):
    return 0 <= r < 8 and 0 <= c < 8

# ---------- parsing ----------
R(r'^(\S+) w (\S+) (\S+)(?: \S+ \S+)?\s*$', r'O\g<1> \g<2> \g<3>')
for d in range(8, 1, -1):
    R(str(d) + r'(?=\S* )', '1' * d)
R('/', '')
subsets = []
for m in range(16):
    full = ''.join(ch if m >> i & 1 else '' for i, ch in enumerate('KQkq'))
    pad = ''.join(ch if m >> i & 1 else '-' for i, ch in enumerate('KQkq'))
    subsets.append((full or '-', pad))
for full, pad in subsets:
    R(' ' + full + ' ', ' ' + pad + ' ')

# ---------- generation ----------
def gen(cons, changes, marker='M', ep='-', castle=r'\S{4}', epreq=r'\S+'):
    """cons: pos->regex class; changes: pos->new char"""
    pos = sorted(set(cons) | set(changes))
    pat = '(?m)^O'
    rep = r'\g<0>' + '\n' + marker
    g = 0
    cur = 0
    for p in pos:
        if p > cur:
            g += 1
            pat += '(.{%d})' % (p - cur)
            rep += r'\g<%d>' % g
        g += 1
        pat += '(%s)' % cons.get(p, '.')
        rep += changes[p] if p in changes else r'\g<%d>' % g
        cur = p + 1
    if cur < 64:
        g += 1
        pat += '(.{%d})' % (64 - cur)
        rep += r'\g<%d>' % g
    g += 1
    pat += ' (%s) %s$' % (castle, epreq)
    rep += r' \g<%d> %s' % (g, ep)
    R(pat, rep)

TGT = '[1a-z]'
# pawns
for s in range(64):
    r, c = rc(s)
    if r == 0 or r == 7:
        continue
    promo = (r == 1)
    np = 'Q' if promo else 'P'
    t = idx(r - 1, c)
    gen({s: 'P', t: '1'}, {s: '1', t: np})
    if r == 6:
        t2 = idx(r - 2, c)
        gen({s: 'P', t: '1', t2: '1'}, {s: '1', t2: 'P'}, ep=chr(97 + c) + '3')
    for dc in (-1, 1):
        if onb(r - 1, c + dc):
            t = idx(r - 1, c + dc)
            gen({s: 'P', t: '[a-z]'}, {s: '1', t: np})
            if r == 3:
                cap = idx(r, c + dc)
                gen({s: 'P', t: '1', cap: 'p'}, {s: '1', t: 'P', cap: '1'},
                    epreq=chr(97 + c + dc) + '6')

# knights & kings
KN = [(1, 2), (2, 1), (-1, 2), (-2, 1), (1, -2), (2, -1), (-1, -2), (-2, -1)]
KG = [(a, b) for a in (-1, 0, 1) for b in (-1, 0, 1) if (a, b) != (0, 0)]
for s in range(64):
    r, c = rc(s)
    for piece, ds in (('N', KN), ('K', KG)):
        for dr, dc in ds:
            if onb(r + dr, c + dc):
                t = idx(r + dr, c + dc)
                gen({s: piece, t: TGT}, {s: '1', t: piece})
# sliders
ORTH = [(1, 0), (-1, 0), (0, 1), (0, -1)]
DIAG = [(1, 1), (1, -1), (-1, 1), (-1, -1)]
for s in range(64):
    r, c = rc(s)
    for cls, ds in (('[RQ]', ORTH), ('[BQ]', DIAG)):
        for dr, dc in ds:
            between = []
            n = 1
            while onb(r + dr * n, c + dc * n):
                t = idx(r + dr * n, c + dc * n)
                cons = {s: cls, t: TGT}
                for b in between:
                    cons[b] = '1'
                # moving piece: reuse captured group of source
                pos = sorted(set(cons))
                # build manually since new char = source char
                pat = '(?m)^O'
                rep = r'\g<0>' + '\n' + 'M'
                g = 0
                cur = 0
                srcg = None
                parts = []
                for p in pos:
                    if p > cur:
                        g += 1
                        pat += '(.{%d})' % (p - cur)
                        parts.append(r'\g<%d>' % g)
                    g += 1
                    pat += '(%s)' % cons[p]
                    if p == s:
                        srcg = g
                        parts.append('1')
                    elif p == t:
                        parts.append(('T',))
                    else:
                        parts.append(r'\g<%d>' % g)
                    cur = p + 1
                if cur < 64:
                    g += 1
                    pat += '(.{%d})' % (64 - cur)
                    parts.append(r'\g<%d>' % g)
                g += 1
                pat += r' (\S{4}) \S+$'
                parts.append(r' \g<%d> -' % g)
                rep += ''.join(r'\g<%d>' % srcg if x == ('T',) else x for x in parts)
                R(pat, rep)
                between.append(t)
                n += 1

# castling
e1, f1, g1, h1, d1, c1, b1, a1 = (sq(x) for x in ['e1', 'f1', 'g1', 'h1', 'd1', 'c1', 'b1', 'a1'])
gen({e1: 'K', f1: '1', g1: '1', h1: 'R'}, {f1: 'K', g1: 'K'}, marker='C', castle=r'K\S{3}')
gen({e1: 'K', d1: '1', c1: '1', b1: '1', a1: 'R'}, {d1: 'K', c1: 'K'}, marker='C', castle=r'\SQ\S{2}')

R(r'(?m)^O.*\n?', '')

# ---------- check filter ----------
def seqpat(cons):
    out = ''
    cur = 0
    for p in sorted(cons):
        if p > cur:
            out += '.{%d}' % (p - cur)
        out += cons[p]
        cur = p + 1
    return out

for k in range(64):
    r, c = rc(k)
    alts = []
    for dr, dc in KN:
        if onb(r + dr, c + dc):
            alts.append(seqpat({idx(r + dr, c + dc): 'n'}))
    for dr, dc in KG:
        if onb(r + dr, c + dc):
            alts.append(seqpat({idx(r + dr, c + dc): 'k'}))
    for dc in (-1, 1):
        if onb(r - 1, c + dc):
            alts.append(seqpat({idx(r - 1, c + dc): 'p'}))
    for cls, ds in (('[rq]', ORTH), ('[bq]', DIAG)):
        for dr, dc in ds:
            between = []
            n = 1
            while onb(r + dr * n, c + dc * n):
                t = idx(r + dr * n, c + dc * n)
                cons = {t: cls}
                for b in between:
                    cons[b] = '1'
                alts.append(seqpat(cons))
                between.append(t)
                n += 1
    R('(?m)^[MC](?=%s)(?=%s)' % (seqpat({k: 'K'}), '|'.join(alts)), 'X')

R(r'(?m)^X.*\n?', '')

# convert castling lines
R(r'(?m)^C(.{60})KKKR', r'M\g<1>1RK1')
R(r'(?m)^C(.{56})R1KKK', r'M\g<1>11KR1')

# castling rights update
R(r'(?m)^M(?=.{60}[^K]|.{63}[^R])(.{65})K', r'M\g<1>-')
R(r'(?m)^M(?=.{60}[^K]|.{56}[^R])(.{66})Q', r'M\g<1>-')
R(r'(?m)^M(?=.{4}[^k]|.{7}[^r])(.{67})k', r'M\g<1>-')
R(r'(?m)^M(?=.{4}[^k]|.{0}[^r])(.{68})q', r'M\g<1>-')

# ---------- output ----------
R(r'(?m)^M' + '(.{8})' * 8 + r' (\S{4}) (\S+)$',
  '/'.join(r'\g<%d>' % i for i in range(1, 9)) + r' b \g<9> \g<10> 0 0')
for full, pad in subsets:
    R(' ' + pad + ' ', ' ' + full + ' ')
for d in range(8, 1, -1):
    R('1' * d, str(d))
R(r'\n\n+', '\n')
R(r'^\n+|\n+$', '')

json.dump(rules, open('/tmp/obench-cell-ccx0q2my/bench_opencode_regex-chess_m0d87f_r/re.json', 'w'))
print(len(rules))
