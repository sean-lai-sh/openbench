import json, re, random, chess, sys
rules = json.load(open("re.json"))
def run(fen):
    for p, r in rules: fen = re.sub(p, r, fen)
    return fen.split("\n")
def ref(fen):
    b = chess.Board(fen); s=set()
    for m in b.legal_moves:
        if m.promotion and m.promotion != chess.QUEEN: continue
        c=b.copy(); c.push(m); s.add(" ".join(c.fen().split(" ")[:-2]))
    return s
def check(fen):
    ours = [" ".join(x.split(" ")[:-2]) for x in run(fen)]
    exp = ref(fen)
    if not exp: return True
    ok = len(ours)==len(exp) and all(x in exp or x.rpartition(" ")[0]+" -" in exp for x in ours)
    if not ok:
        print("FAIL", fen); print(sorted(set(ours)-exp)); print(sorted(exp-set(ours)), len(ours), len(exp)); 
    return ok
print(run("rnb1k1nr/p2p1ppp/3B4/1p1NPN1P/6P1/3P1Q2/P1P5/q4Kb1 w kq - 0 1"))
random.seed(int(sys.argv[1]) if len(sys.argv)>1 else 0)
n=0; bad=0
for g in range(300):
    b = chess.Board()
    while not b.is_game_over() and b.ply()<200:
        if b.turn == chess.WHITE:
            n+=1
            if not check(b.fen()): bad+=1
            if bad>3: sys.exit()
        ms=list(b.legal_moves)
        caps=[m for m in ms if b.is_capture(m) or m.promotion or b.is_castling(m)]
        b.push(random.choice(caps if caps and random.random()<0.5 else ms))
print(n, "positions", bad, "bad")
