"""Recover A1 (up to row permutation and scaling) using only black-box queries
to forward(x).

Method: along random lines x0 + t*d, the network output is piecewise linear
with a kink wherever a hidden neuron's pre-activation crosses zero. At each
kink we measure the input gradient just before and just after it; the
difference equals (a2_i * sign) * A1[i], i.e. the neuron's weight row up to
scale. Rows found on many lines are deduplicated by cosine similarity.
"""
import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi, flo, fhi, depth=0, out=None):
    """Recursively find t values in [lo, hi] where f(x0+t d) is non-linear."""
    if out is None:
        out = []
    mid = 0.5 * (lo + hi)
    if hi - lo < 1e-7:
        out.append(mid)
        return out
    fmid = f(x0 + mid * d)
    lin = 0.5 * (flo + fhi)
    scale = max(1.0, abs(flo), abs(fhi))
    if abs(fmid - lin) < 1e-13 * scale and depth > 6:
        # Check quarter points too to avoid missing paired kinks that cancel.
        q1, q3 = lo + 0.25 * (hi - lo), lo + 0.75 * (hi - lo)
        if (abs(f(x0 + q1 * d) - (0.75 * flo + 0.25 * fhi)) < 1e-13 * scale and
                abs(f(x0 + q3 * d) - (0.25 * flo + 0.75 * fhi)) < 1e-13 * scale):
            return out
    find_kinks(x0, d, lo, mid, flo, fmid, depth + 1, out)
    find_kinks(x0, d, mid, hi, fmid, fhi, depth + 1, out)
    return out


def gradient(x, h=1e-6):
    g = np.empty(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        g[j] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def merge_kinks(ts, tol=1e-6):
    ts = sorted(ts)
    groups = []
    for t in ts:
        if groups and t - groups[-1][-1] < tol:
            groups[-1].append(t)
        else:
            groups.append([t])
    return [np.mean(g) for g in groups]


def normalize(v):
    v = v / np.linalg.norm(v)
    # canonical sign: largest-magnitude entry positive
    return v * np.sign(v[np.argmax(np.abs(v))])


def steal(n_lines=30, T=50.0):
    rows = []      # list of normalized row estimates
    counts = []
    for _ in range(n_lines):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        ts = find_kinks(x0, d, -T, T, f(x0 - T * d), f(x0 + T * d))
        ts = merge_kinks(ts)
        for k, t in enumerate(ts):
            # offset to either side, staying clear of neighbouring kinks
            gap = 1e-3
            if k > 0:
                gap = min(gap, (t - ts[k - 1]) / 3)
            if k + 1 < len(ts):
                gap = min(gap, (ts[k + 1] - t) / 3)
            h = gap / 10
            gl = gradient(x0 + (t - gap) * d, h)
            gr = gradient(x0 + (t + gap) * d, h)
            diff = gr - gl
            if np.linalg.norm(diff) < 1e-9:
                continue
            v = normalize(diff)
            for i, r in enumerate(rows):
                if abs(np.dot(r, v)) > 1 - 1e-5:
                    rows[i] = (rows[i] * counts[i] + v * np.sign(np.dot(r, v))) / (counts[i] + 1)
                    counts[i] += 1
                    break
            else:
                rows.append(v)
                counts.append(1)
    # discard spurious one-off detections if they are a small minority
    A = np.array([normalize(r) for r, c in zip(rows, counts) if c >= 2 or max(counts) < 3])
    return A


if __name__ == "__main__":
    A1_hat = steal()
    np.save(OUT, A1_hat)
    print(f"Recovered {A1_hat.shape[0]} neurons; shape {A1_hat.shape}")
    print(A1_hat)
