"""Pipeline-parallel training (AFAB schedule) for HuggingFace LlamaForCausalLM."""

import torch
import torch.distributed as dist
import torch.nn.functional as F

try:
    from transformers.masking_utils import create_causal_mask
except Exception:  # pragma: no cover
    create_causal_mask = None


def _partition_layers(num_layers, world_size, rank):
    """Return [start, end) layer indices for `rank`, balanced (remainder to early ranks)."""
    base, rem = divmod(num_layers, world_size)
    start = rank * base + min(rank, rem)
    end = start + base + (1 if rank < rem else 0)
    return start, end


def _p2p(ops):
    if not ops:
        return
    reqs = dist.batch_isend_irecv(ops)
    for r in reqs:
        r.wait()


def _send(tensor, peer):
    _p2p([dist.P2POp(dist.isend, tensor.contiguous(), peer)])


def _recv(shape, peer, device, dtype):
    buf = torch.empty(shape, device=device, dtype=dtype)
    _p2p([dist.P2POp(dist.irecv, buf, peer)])
    return buf


def _stage_forward(model, hidden_or_ids, start, end, is_first, is_last):
    """Run this stage's portion of the model. Returns hidden states or logits."""
    base = model.model
    if is_first:
        hidden = base.embed_tokens(hidden_or_ids)
    else:
        hidden = hidden_or_ids

    seq_len = hidden.shape[1]
    position_ids = torch.arange(seq_len, device=hidden.device).unsqueeze(0)

    causal_mask = None
    if create_causal_mask is not None:
        causal_mask = create_causal_mask(
            config=base.config,
            inputs_embeds=hidden,
            attention_mask=None,
            past_key_values=None,
            position_ids=position_ids,
        )
    position_embeddings = base.rotary_emb(hidden, position_ids=position_ids)

    for layer in base.layers[start:end]:
        out = layer(
            hidden,
            attention_mask=causal_mask,
            position_embeddings=position_embeddings,
            position_ids=position_ids,
            past_key_values=None,
            use_cache=False,
        )
        hidden = out[0] if isinstance(out, (tuple, list)) else out

    if is_last:
        hidden = base.norm(hidden)
        return model.lm_head(hidden)
    return hidden


def train_step_pipeline_afab(model, inputs, targets, device, dtype):
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    is_first = rank == 0
    is_last = rank == world_size - 1
    prev_rank, next_rank = rank - 1, rank + 1

    config = model.config
    num_layers = config.num_hidden_layers
    hidden_size = config.hidden_size
    start, end = _partition_layers(num_layers, world_size, rank)

    num_mb = len(inputs)
    input_tensors = []
    output_tensors = []
    total_loss = torch.zeros((), device=device, dtype=torch.float32)

    # ---------------- All forward ----------------
    for i in range(num_mb):
        mb_shape = tuple(inputs[i].shape)  # [microbatch, seq_len]
        hidden_shape = mb_shape + (hidden_size,)

        if is_first:
            stage_in = inputs[i].to(device)
        else:
            stage_in = _recv(hidden_shape, prev_rank, device, dtype)
            stage_in.requires_grad_(True)

        out = _stage_forward(model, stage_in, start, end, is_first, is_last)

        if is_last:
            tgt = targets[i].to(device)
            loss = F.cross_entropy(
                out.reshape(-1, out.shape[-1]).float(), tgt.reshape(-1)
            ) / num_mb
            total_loss = total_loss + loss.detach()
            out = loss
        else:
            _send(out.detach().to(device=device, dtype=dtype), next_rank)

        input_tensors.append(stage_in)
        output_tensors.append(out)

    # ---------------- All backward ----------------
    for i in range(num_mb):
        stage_in = input_tensors[i]
        out = output_tensors[i]
        hidden_shape = tuple(inputs[i].shape) + (hidden_size,)

        if is_last:
            grad_out = None
        else:
            grad_out = _recv(hidden_shape, next_rank, device, dtype)
            grad_out = grad_out.to(dtype=out.dtype)

        torch.autograd.backward(out, grad_tensors=grad_out)

        if not is_first:
            grad_in = stage_in.grad
            if grad_in is None:
                grad_in = torch.zeros(hidden_shape, device=device, dtype=dtype)
            _send(grad_in.to(device=device, dtype=dtype), prev_rank)

        # free memory
        input_tensors[i] = None
        output_tensors[i] = None

    return total_loss if is_last else None
