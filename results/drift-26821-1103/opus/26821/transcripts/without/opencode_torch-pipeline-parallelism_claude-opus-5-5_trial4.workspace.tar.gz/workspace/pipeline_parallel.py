"""Pipeline-parallel training step (All-Forward-All-Backward) for LlamaForCausalLM."""

import torch
import torch.distributed as dist
import torch.nn.functional as F

try:
    from transformers.masking_utils import create_causal_mask
except Exception:  # pragma: no cover - older transformers
    create_causal_mask = None


def _partition_layers(num_layers, world_size, rank):
    """Return [start, end) layer indices for `rank`, balanced (remainder to first ranks)."""
    base, rem = divmod(num_layers, world_size)
    start = rank * base + min(rank, rem)
    end = start + base + (1 if rank < rem else 0)
    return start, end


def _p2p(op, tensor, peer):
    reqs = dist.batch_isend_irecv([dist.P2POp(op, tensor, peer)])
    for r in reqs:
        r.wait()


def _send(tensor, peer):
    _p2p(dist.isend, tensor.contiguous(), peer)


def _recv(shape, peer, device, dtype):
    buf = torch.empty(shape, device=device, dtype=dtype)
    _p2p(dist.irecv, buf, peer)
    return buf


def _run_stage(model, hidden_states, start, end):
    """Run decoder layers [start, end) of the model on hidden_states."""
    base = model.model
    seq_len = hidden_states.shape[1]
    position_ids = torch.arange(seq_len, device=hidden_states.device).unsqueeze(0)

    causal_mask = None
    if create_causal_mask is not None:
        causal_mask = create_causal_mask(
            config=base.config,
            inputs_embeds=hidden_states,
            attention_mask=None,
            past_key_values=None,
            position_ids=position_ids,
        )
    position_embeddings = base.rotary_emb(hidden_states, position_ids=position_ids)

    for layer in base.layers[start:end]:
        out = layer(
            hidden_states,
            attention_mask=causal_mask,
            position_ids=position_ids,
            position_embeddings=position_embeddings,
            past_key_values=None,
            use_cache=False,
        )
        hidden_states = out[0] if isinstance(out, (tuple, list)) else out
    return hidden_states


def train_step_pipeline_afab(model, inputs, targets, device, dtype):
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    is_first = rank == 0
    is_last = rank == world_size - 1

    config = model.config
    hidden_size = config.hidden_size
    num_layers = config.num_hidden_layers
    start, end = _partition_layers(num_layers, world_size, rank)

    num_micro = len(inputs)
    stage_inputs = []   # input tensors (requiring grad) for each microbatch on this stage
    stage_outputs = []  # outputs (hidden states, or loss on the last rank)
    total_loss = None

    # ---------------- All forward ----------------
    for i in range(num_micro):
        if is_first:
            input_ids = inputs[i].to(device)
            mb, seq_len = input_ids.shape
            hidden = model.model.embed_tokens(input_ids).to(dtype)
            stage_input = None
        else:
            mb, seq_len = inputs[i].shape[0], inputs[i].shape[1]
            hidden = _recv((mb, seq_len, hidden_size), rank - 1, device, dtype)
            hidden.requires_grad_(True)
            stage_input = hidden

        out = _run_stage(model, hidden, start, end).to(dtype)

        if is_last:
            logits = model.lm_head(model.model.norm(out))
            tgt = targets[i].to(device)
            loss = F.cross_entropy(
                logits.reshape(-1, logits.shape[-1]).float(), tgt.reshape(-1)
            ) / num_micro
            stage_outputs.append(loss)
            total_loss = loss.detach() if total_loss is None else total_loss + loss.detach()
        else:
            _send(out.detach().to(device=device, dtype=dtype), rank + 1)
            stage_outputs.append(out)
        stage_inputs.append(stage_input)

    # ---------------- All backward ----------------
    for i in range(num_micro):
        out = stage_outputs[i]
        if is_last:
            out.backward()
        else:
            grad = _recv(tuple(out.shape), rank + 1, device, dtype)
            torch.autograd.backward(out, grad_tensors=grad)

        if not is_first:
            inp_grad = stage_inputs[i].grad
            if inp_grad is None:
                inp_grad = torch.zeros_like(stage_inputs[i])
            _send(inp_grad.to(device=device, dtype=dtype), rank - 1)

        stage_outputs[i] = None
        stage_inputs[i] = None

    return total_loss
