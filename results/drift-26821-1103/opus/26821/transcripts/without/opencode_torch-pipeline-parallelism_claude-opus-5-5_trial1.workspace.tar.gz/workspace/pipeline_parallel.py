"""Pipeline-parallel training step (AFAB schedule) for HF LlamaForCausalLM."""

import torch
import torch.distributed as dist
import torch.nn.functional as F

try:
    from transformers.masking_utils import create_causal_mask
except Exception:  # pragma: no cover - older transformers
    create_causal_mask = None


def _partition_layers(num_layers, world_size, rank):
    """Return [start, end) of the layers owned by `rank` (balanced split)."""
    base, rem = divmod(num_layers, world_size)
    start = rank * base + min(rank, rem)
    end = start + base + (1 if rank < rem else 0)
    return start, end


def _p2p(op, tensor, peer):
    reqs = dist.batch_isend_irecv([dist.P2POp(op, tensor, peer)])
    for r in reqs:
        r.wait()


def _hidden_shape(inputs, targets, i, hidden_size):
    ref = inputs[i] if i < len(inputs) and torch.is_tensor(inputs[i]) else targets[i]
    return (ref.shape[0], ref.shape[1], hidden_size)


def _stage_forward(model, layers, hidden, is_first, is_last, device, dtype):
    """Run this stage's portion of the model; returns hidden states or logits."""
    inner = model.model
    if is_first:
        hidden = inner.embed_tokens(hidden)
    hidden = hidden.to(device=device, dtype=dtype)

    seq_len = hidden.shape[1]
    position_ids = torch.arange(seq_len, device=device).unsqueeze(0)
    if create_causal_mask is not None:
        causal_mask = create_causal_mask(
            config=inner.config,
            inputs_embeds=hidden,
            attention_mask=None,
            past_key_values=None,
            position_ids=position_ids,
        )
    else:
        causal_mask = None
    position_embeddings = inner.rotary_emb(hidden, position_ids=position_ids)

    for layer in layers:
        out = layer(
            hidden,
            attention_mask=causal_mask,
            position_ids=position_ids,
            position_embeddings=position_embeddings,
        )
        hidden = out[0] if isinstance(out, (tuple, list)) else out

    if is_last:
        hidden = inner.norm(hidden)
        hidden = model.lm_head(hidden)
    return hidden


def train_step_pipeline_afab(model, inputs, targets, device, dtype):
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    is_first = rank == 0
    is_last = rank == world_size - 1
    prev_rank, next_rank = rank - 1, rank + 1

    config = model.config
    hidden_size = config.hidden_size
    all_layers = model.model.layers
    start, end = _partition_layers(len(all_layers), world_size, rank)
    local_layers = [all_layers[i] for i in range(start, end)]

    num_mb = len(targets) if targets is not None else len(inputs)

    stage_inputs = []   # tensors received from previous stage (need grads)
    stage_outputs = []  # outputs (or losses on last stage) for backward
    total_loss = torch.zeros((), device=device, dtype=torch.float32)

    # ---------------- All forward ----------------
    for i in range(num_mb):
        if is_first:
            x = inputs[i].to(device=device)
        else:
            x = torch.empty(_hidden_shape(inputs, targets, i, hidden_size),
                            device=device, dtype=dtype)
            _p2p(dist.irecv, x, prev_rank)
            x.requires_grad_(True)
        stage_inputs.append(x)

        out = _stage_forward(model, local_layers, x, is_first, is_last, device, dtype)

        if is_last:
            tgt = targets[i].to(device=device)
            loss = F.cross_entropy(
                out.float().reshape(-1, out.shape[-1]), tgt.reshape(-1)
            ) / num_mb
            total_loss = total_loss + loss.detach()
            stage_outputs.append(loss)
        else:
            out = out.to(device=device, dtype=dtype)
            _p2p(dist.isend, out.detach().contiguous(), next_rank)
            stage_outputs.append(out)

    # ---------------- All backward ----------------
    for i in range(num_mb):
        out = stage_outputs[i]
        if is_last:
            torch.autograd.backward(out)
        else:
            grad = torch.empty(out.shape, device=device, dtype=dtype)
            _p2p(dist.irecv, grad, next_rank)
            torch.autograd.backward(out, grad_tensors=grad)

        if not is_first:
            g = stage_inputs[i].grad
            if g is None:
                g = torch.zeros_like(stage_inputs[i])
            g = g.to(device=device, dtype=dtype).contiguous()
            _p2p(dist.isend, g, prev_rank)

        stage_outputs[i] = None
        stage_inputs[i] = None

    return total_loss if is_last else None
