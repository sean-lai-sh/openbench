import torch
import torch.distributed as dist
import torch.nn as nn
import torch.nn.functional as F


def _world_size():
    if dist.is_available() and dist.is_initialized():
        return dist.get_world_size()
    return 1


def _rank():
    if dist.is_available() and dist.is_initialized():
        return dist.get_rank()
    return 0


def _divide(n, d):
    assert n % d == 0, f"{n} is not divisible by {d}"
    return n // d


# ---------------------------------------------------------------------------
# Autograd-aware communication primitives
# ---------------------------------------------------------------------------
class _CopyToParallelRegion(torch.autograd.Function):
    """Forward: identity. Backward: all-reduce gradient."""

    @staticmethod
    def forward(ctx, x):
        return x

    @staticmethod
    def backward(ctx, grad):
        if _world_size() == 1:
            return grad
        grad = grad.contiguous().clone()
        dist.all_reduce(grad, op=dist.ReduceOp.SUM)
        return grad


class _ReduceFromParallelRegion(torch.autograd.Function):
    """Forward: all-reduce. Backward: identity."""

    @staticmethod
    def forward(ctx, x):
        if _world_size() == 1:
            return x
        x = x.contiguous().clone()
        dist.all_reduce(x, op=dist.ReduceOp.SUM)
        return x

    @staticmethod
    def backward(ctx, grad):
        return grad


class _ScatterToParallelRegion(torch.autograd.Function):
    """Forward: take this rank's chunk of the last dim. Backward: all-gather."""

    @staticmethod
    def forward(ctx, x):
        ws = _world_size()
        if ws == 1:
            return x
        chunk = _divide(x.shape[-1], ws)
        r = _rank()
        return x[..., r * chunk:(r + 1) * chunk].contiguous()

    @staticmethod
    def backward(ctx, grad):
        return _all_gather_last_dim(grad)


class _GatherFromParallelRegion(torch.autograd.Function):
    """Forward: all-gather along last dim. Backward: take this rank's chunk."""

    @staticmethod
    def forward(ctx, x):
        return _all_gather_last_dim(x)

    @staticmethod
    def backward(ctx, grad):
        ws = _world_size()
        if ws == 1:
            return grad
        chunk = _divide(grad.shape[-1], ws)
        r = _rank()
        return grad[..., r * chunk:(r + 1) * chunk].contiguous()


def _all_gather_last_dim(x):
    ws = _world_size()
    if ws == 1:
        return x
    x = x.contiguous()
    parts = [torch.empty_like(x) for _ in range(ws)]
    dist.all_gather(parts, x)
    return torch.cat(parts, dim=-1).contiguous()


# ---------------------------------------------------------------------------
# Layers
# ---------------------------------------------------------------------------
class ColumnParallelLinear(nn.Module):
    """Y = X A^T + b, with A (out_features x in_features) split along the
    output dimension. Each rank computes a slice of the output columns; the
    full output is assembled via all_gather along the last dimension."""

    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.world_size = _world_size()
        self.rank = _rank()
        self.out_features_per_partition = _divide(out_features, self.world_size)

        start = self.rank * self.out_features_per_partition
        end = start + self.out_features_per_partition
        master_weight = master_weight.detach()
        assert tuple(master_weight.shape) == (out_features, in_features)
        self.weight = nn.Parameter(master_weight[start:end, :].clone().contiguous())

        if bias:
            self.bias = nn.Parameter(
                torch.zeros(self.out_features_per_partition,
                            dtype=master_weight.dtype, device=master_weight.device)
            )
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        x = _CopyToParallelRegion.apply(x)
        out = F.linear(x, self.weight, self.bias)
        return _GatherFromParallelRegion.apply(out)


class RowParallelLinear(nn.Module):
    """Y = X A^T + b, with A (out_features x in_features) split along the
    input dimension. Each rank computes a partial output from its slice of the
    input features; partial outputs are summed via all_reduce. The bias is
    kept full on each rank and added after the reduction."""

    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.world_size = _world_size()
        self.rank = _rank()
        self.in_features_per_partition = _divide(in_features, self.world_size)

        start = self.rank * self.in_features_per_partition
        end = start + self.in_features_per_partition
        master_weight = master_weight.detach()
        assert tuple(master_weight.shape) == (out_features, in_features)
        self.weight = nn.Parameter(master_weight[:, start:end].clone().contiguous())

        if bias:
            self.bias = nn.Parameter(
                torch.zeros(out_features,
                            dtype=master_weight.dtype, device=master_weight.device)
            )
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        # Accept either the full input (split here) or an already-partitioned input.
        if self.world_size > 1 and x.shape[-1] == self.in_features:
            x = _ScatterToParallelRegion.apply(x)
        partial = F.linear(x, self.weight)
        out = _ReduceFromParallelRegion.apply(partial)
        if self.bias is not None:
            out = out + self.bias
        return out
