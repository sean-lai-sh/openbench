/* /* */
#include <cstdio>
#include <cstdlib>
#include <vector>
int main(int argc, char** argv) {
    long n = argc > 1 ? atol(argv[1]) : 0;
    std::vector<unsigned> a{1}, b{1};
    for (long i = 1; i <= n; i++) {
        std::vector<unsigned> c;
        unsigned long long carry = 0;
        for (size_t j = 0; j < b.size() || carry; j++) {
            unsigned long long s = carry + (j < a.size() ? a[j] : 0) + (j < b.size() ? b[j] : 0);
            c.push_back(s % 1000000000ULL);
            carry = s / 1000000000ULL;
        }
        a = b; b = c;
    }
    printf("%u", a.back());
    for (size_t j = a.size() - 1; j-- > 0;) printf("%09u", a[j]);
    printf("\n");
    return 0;
}
#if 0
// */
fn main() {
    let n: u64 = std::env::args().nth(1).and_then(|s| s.trim().parse().ok()).unwrap_or(0);
    let mut a: Vec<u64> = vec![1];
    let mut b: Vec<u64> = vec![1];
    for _ in 0..n {
        let mut c: Vec<u64> = Vec::new();
        let mut carry: u64 = 0;
        let mut j = 0;
        while j < b.len() || carry > 0 {
            let s = carry + a.get(j).copied().unwrap_or(0) + b.get(j).copied().unwrap_or(0);
            c.push(s % 1000000000);
            carry = s / 1000000000;
            j += 1;
        }
        a = b;
        b = c;
    }
    let mut out = format!("{}", a[a.len() - 1]);
    for d in a.iter().rev().skip(1) {
        out.push_str(&format!("{:09}", d));
    }
    println!("{}", out);
}
/* /* */
#endif
// */
