// \
/*
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>
#include <algorithm>
static std::vector<int> add(const std::vector<int>& a, const std::vector<int>& b) {
    std::vector<int> r;
    int c = 0;
    for (size_t i = 0; i < std::max(a.size(), b.size()) || c; i++) {
        int s = c + (i < a.size() ? a[i] : 0) + (i < b.size() ? b[i] : 0);
        r.push_back(s % 10);
        c = s / 10;
    }
    return r;
}
int main(int argc, char** argv) {
    long n = argc > 1 ? atol(argv[1]) : 0;
    std::vector<int> a(1, 1), b(1, 1);
    for (long i = 0; i < n; i++) { std::vector<int> t = add(a, b); a = b; b = t; }
    std::string s;
    for (size_t i = a.size(); i-- > 0;) s.push_back((char)(48 + a[i]));
    printf("%s\n", s.c_str());
    return 0;
}
#if 0
// \
*/
fn add(a: &Vec<u8>, b: &Vec<u8>) -> Vec<u8> {
    let mut r = Vec::new();
    let mut c = 0u8;
    let mut i = 0;
    while i < a.len().max(b.len()) || c > 0 {
        let s = c + a.get(i).copied().unwrap_or(0) + b.get(i).copied().unwrap_or(0);
        r.push(s % 10);
        c = s / 10;
        i += 1;
    }
    r
}
fn main() {
    let n: u64 = std::env::args().nth(1).and_then(|s| s.trim().parse().ok()).unwrap_or(0);
    let mut a = vec![1u8];
    let mut b = vec![1u8];
    for _ in 0..n {
        let t = add(&a, &b);
        a = b;
        b = t;
    }
    let s: String = a.iter().rev().map(|d| (48 + d) as char).collect();
    println!("{}", s);
}
// \
/*
#endif
// \
*/
