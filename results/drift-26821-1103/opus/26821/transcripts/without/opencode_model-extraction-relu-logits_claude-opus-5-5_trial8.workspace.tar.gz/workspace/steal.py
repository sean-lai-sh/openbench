"""Extract A1 (up to row permutation and scaling) from a 1-hidden-layer ReLU net
using only black-box queries to forward(x).

Method: along random lines in input space, the network is piecewise linear;
each kink corresponds to one hidden neuron crossing zero. At a kink, the jump
in the gradient equals A2[i] * A1[i, :], i.e. the neuron's weight row up to
scale. We collect these rows from many lines and deduplicate.
"""
import os
import numpy as np
from forward import forward

DIM = 10
rng = np.random.default_rng(1234)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")

f = lambda x: float(forward(np.asarray(x, dtype=np.float64)))


def line_f(x0, d, t):
    return f(x0 + t * d)


def slope(x0, d, t, h=1e-6):
    return (line_f(x0, d, t + h) - line_f(x0, d, t - h)) / (2 * h)


def find_kinks(x0, d, a, b, fa, fb, sa, sb, depth=0, out=None):
    """Recursively locate kinks of g(t)=f(x0+t d) in [a,b]."""
    if out is None:
        out = []
    if depth > 60 or b - a < 1e-9:
        return out
    if abs(sa - sb) < 1e-9 * (1 + abs(sa) + abs(sb)):
        # same slope at both ends; check the midpoint is consistent with linearity
        m = 0.5 * (a + b)
        if abs(line_f(x0, d, m) - (fa + sa * (m - a))) < 1e-10:
            return out
    else:
        # Assume a single kink: intersect the two lines
        tc = (fb - fa + sa * a - sb * b) / (sa - sb)
        if a < tc < b:
            fc = line_f(x0, d, tc)
            pred = fa + sa * (tc - a)
            if abs(fc - pred) < 1e-9 * (1 + abs(fc)):
                # verify linear on both sides via quarter points
                q1 = 0.5 * (a + tc)
                q2 = 0.5 * (tc + b)
                ok1 = abs(line_f(x0, d, q1) - (fa + sa * (q1 - a))) < 1e-9 * (1 + abs(fa))
                ok2 = abs(line_f(x0, d, q2) - (fb + sb * (q2 - b))) < 1e-9 * (1 + abs(fb))
                if ok1 and ok2:
                    out.append(tc)
                    return out
    m = 0.5 * (a + b)
    fm = line_f(x0, d, m)
    sm = slope(x0, d, m)
    find_kinks(x0, d, a, m, fa, fm, sa, sm, depth + 1, out)
    find_kinks(x0, d, m, b, fm, fb, sm, sb, depth + 1, out)
    return out


def gradient(x, h=1e-5):
    g = np.zeros(DIM)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = h
        g[i] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def _row(x0, d, t, eps, h):
    r = gradient(x0 + (t + eps) * d, h) - gradient(x0 + (t - eps) * d, h)
    n = np.linalg.norm(r)
    return None if n < 1e-8 else r / n


def row_at_kink(x0, d, t, eps=1e-4):
    # Compute twice with different step sizes; reject if inconsistent
    # (e.g. a finite-difference step accidentally crossed another neuron's boundary).
    r1 = _row(x0, d, t, eps, 1e-6)
    r2 = _row(x0, d, t, eps / 2, 3e-7)
    if r1 is None or r2 is None or abs(np.dot(r1, r2)) < 1 - 1e-6:
        return None
    return r1


def canon(r):
    # fix sign so that the largest-magnitude entry is positive
    return r * np.sign(r[np.argmax(np.abs(r))])


def main():
    rows = []
    counts = []
    T = 50.0
    n_lines = 60
    for _ in range(n_lines):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        a, b = -T, T
        kinks = find_kinks(x0, d, a, b, line_f(x0, d, a), line_f(x0, d, b),
                           slope(x0, d, a), slope(x0, d, b))
        kinks = sorted(kinks)
        for j, t in enumerate(kinks):
            # pick eps smaller than distance to neighbouring kinks
            gaps = [abs(t - k) for k in kinks if k != t]
            eps = min([1e-4] + [g / 4 for g in gaps])
            r = row_at_kink(x0, d, t, eps)
            if r is None:
                continue
            r = canon(r)
            for k, existing in enumerate(rows):
                if abs(np.dot(existing, r)) > 1 - 1e-5:
                    counts[k] += 1
                    break
            else:
                rows.append(r)
                counts.append(1)
    # Keep rows observed more than once if possible (filter numeric junk)
    rows = np.array(rows)
    counts = np.array(counts)
    if (counts > 1).sum() > 0:
        rows = rows[counts > 1]
    print(f"Recovered {len(rows)} neurons")
    np.save(OUT, rows)
    print(rows)
    return rows


if __name__ == "__main__":
    main()
