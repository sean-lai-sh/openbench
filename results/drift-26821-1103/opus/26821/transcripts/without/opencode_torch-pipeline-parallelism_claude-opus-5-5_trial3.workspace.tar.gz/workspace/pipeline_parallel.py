"""Pipeline-parallel training for LlamaForCausalLM with AFAB scheduling.

All-forward-all-backward (AFAB): every stage first runs the forward pass for
all microbatches (receiving activations from the previous stage and sending
its outputs to the next one), then runs the backward pass for all
microbatches (receiving output gradients from the next stage and sending
input gradients to the previous one).
"""

import torch
import torch.distributed as dist
import torch.nn.functional as F

try:  # transformers >= 4.53
    from transformers.masking_utils import create_causal_mask
except Exception:  # pragma: no cover - older transformers
    create_causal_mask = None


# --------------------------------------------------------------------------- #
# Partitioning
# --------------------------------------------------------------------------- #
def partition_layers(num_layers, world_size, rank):
    """Return the [start, end) range of decoder layers owned by ``rank``.

    Layers are split as evenly as possible; the first ``num_layers % world_size``
    ranks get one extra layer.
    """
    base, rem = divmod(num_layers, world_size)
    start = rank * base + min(rank, rem)
    end = start + base + (1 if rank < rem else 0)
    return start, end


# --------------------------------------------------------------------------- #
# Communication helpers
# --------------------------------------------------------------------------- #
def _p2p(op, tensor, peer):
    reqs = dist.batch_isend_irecv([dist.P2POp(op, tensor, peer)])
    for r in reqs:
        r.wait()


def _send(tensor, dst):
    _p2p(dist.isend, tensor.contiguous(), dst)


def _recv(shape, src, device, dtype):
    buf = torch.empty(shape, device=device, dtype=dtype)
    _p2p(dist.irecv, buf, src)
    return buf


# --------------------------------------------------------------------------- #
# Stage forward
# --------------------------------------------------------------------------- #
def _build_mask(config, hidden_states, position_ids):
    if create_causal_mask is None:
        return None
    return create_causal_mask(
        config=config,
        inputs_embeds=hidden_states,
        attention_mask=None,
        past_key_values=None,
        position_ids=position_ids,
    )


def _stage_forward(model, hidden_states, layer_range):
    """Run the decoder layers in ``layer_range`` on ``hidden_states``."""
    inner = model.model
    seq_len = hidden_states.shape[1]
    position_ids = torch.arange(seq_len, device=hidden_states.device).unsqueeze(0)
    causal_mask = _build_mask(model.config, hidden_states, position_ids)
    position_embeddings = inner.rotary_emb(hidden_states, position_ids=position_ids)

    start, end = layer_range
    for layer in inner.layers[start:end]:
        out = layer(
            hidden_states,
            attention_mask=causal_mask,
            position_ids=position_ids,
            past_key_values=None,
            use_cache=False,
            position_embeddings=position_embeddings,
        )
        hidden_states = out[0] if isinstance(out, tuple) else out
    return hidden_states


# --------------------------------------------------------------------------- #
# Training step
# --------------------------------------------------------------------------- #
def train_step_pipeline_afab(model, inputs, targets, device, dtype):
    """One training step (forward + backward) with AFAB pipeline scheduling.

    Returns the total (microbatch-averaged) loss on the last rank and ``None``
    on the other ranks. Gradients are accumulated into the parameters owned by
    this rank's stage.
    """
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    is_first = rank == 0
    is_last = rank == world_size - 1
    prev_rank = rank - 1
    next_rank = rank + 1

    config = model.config
    hidden_size = config.hidden_size
    num_layers = config.num_hidden_layers
    num_microbatches = len(inputs)
    layer_range = partition_layers(num_layers, world_size, rank)

    model.train()

    stage_inputs = []   # per-microbatch tensors received from previous stage
    stage_outputs = []  # per-microbatch outputs (hidden states or loss)
    total_loss = torch.zeros((), device=device, dtype=torch.float32) if is_last else None

    # ---------------------------- all forward ---------------------------- #
    for mb in range(num_microbatches):
        mb_shape = tuple(inputs[mb].shape[:2]) if inputs is not None else tuple(targets[mb].shape[:2])
        hidden_shape = (*mb_shape, hidden_size)

        if is_first:
            input_ids = inputs[mb].to(device)
            hidden_states = model.model.embed_tokens(input_ids).to(dtype)
            stage_inputs.append(None)
        else:
            hidden_states = _recv(hidden_shape, prev_rank, device, dtype)
            hidden_states.requires_grad_(True)
            stage_inputs.append(hidden_states)

        hidden_states = _stage_forward(model, hidden_states, layer_range)

        if is_last:
            hidden_states = model.model.norm(hidden_states)
            logits = model.lm_head(hidden_states)
            tgt = targets[mb].to(device)
            loss = F.cross_entropy(
                logits.reshape(-1, logits.size(-1)).float(), tgt.reshape(-1)
            ) / num_microbatches
            total_loss += loss.detach()
            stage_outputs.append(loss)
        else:
            _send(hidden_states.detach().to(device=device, dtype=dtype), next_rank)
            stage_outputs.append(hidden_states)

    # ---------------------------- all backward --------------------------- #
    for mb in range(num_microbatches):
        output = stage_outputs[mb]
        if is_last:
            torch.autograd.backward(output)
        else:
            grad = _recv(output.shape, next_rank, device, dtype)
            torch.autograd.backward(output, grad_tensors=grad)

        if not is_first:
            inp = stage_inputs[mb]
            grad_in = inp.grad
            if grad_in is None:
                grad_in = torch.zeros_like(inp)
            _send(grad_in.detach().to(device=device, dtype=dtype), prev_rank)

        # free activations
        stage_outputs[mb] = None
        stage_inputs[mb] = None

    return total_loss
