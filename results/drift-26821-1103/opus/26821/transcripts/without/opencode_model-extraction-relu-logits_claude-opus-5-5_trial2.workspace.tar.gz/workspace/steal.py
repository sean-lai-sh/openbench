"""
Recover A1 (up to row permutation and scaling) of f(x) = A2 ReLU(A1 x + b1) + b2
using only black-box queries to forward(x).

Method (critical-point attack):
  1. Along random lines x(t) = x0 + t*d, f is piecewise linear in t; each kink
     is a point where some neuron's pre-activation crosses zero.
  2. Locate kinks precisely by recursively intersecting linear pieces.
  3. At each kink, the gradient jump across it equals c * A1[i] for the neuron i
     that switches, so it reveals that row up to scale.
  4. Deduplicate rows found from many kinks (by direction) -> stolen A1.
"""
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from forward import forward  # noqa: E402

DIM = 10
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi, eps=1e-7, tol=1e-9, depth=0):
    """Return list of t values in [lo, hi] where g(t)=f(x0+t d) has a kink."""
    g = lambda t: f(x0 + t * d)
    fa, fb = g(lo), g(hi)
    sa = (g(lo + eps) - fa) / eps          # slope just right of lo
    sb = (fb - g(hi - eps)) / eps          # slope just left of hi
    scale = max(1.0, abs(sa), abs(sb))
    if abs(sa - sb) < 1e-6 * scale:
        # Same slope at both ends; check a midpoint to be safe.
        m = 0.5 * (lo + hi)
        if abs(g(m) - (fa + sa * (m - lo))) < tol * max(1.0, abs(fa)) * 10:
            return []
    if hi - lo < 1e-6 or depth > 60:
        return [0.5 * (lo + hi)] if abs(sa - sb) > 1e-6 * scale else []
    if abs(sa - sb) > 1e-6 * scale:
        # Intersection of the two end lines -> candidate single kink.
        c = (fb - fa + sa * lo - sb * hi) / (sa - sb)
        if lo < c < hi:
            pred = fa + sa * (c - lo)
            if abs(g(c) - pred) < 1e-9 * max(1.0, abs(pred)):
                # Verify it really is a single kink: check slopes either side.
                h = min(1e-5, (c - lo) / 4, (hi - c) / 4)
                if h > 0:
                    sl = (g(c) - g(c - h)) / h
                    sr = (g(c + h) - g(c)) / h
                    if abs(sl - sa) < 1e-6 * scale and abs(sr - sb) < 1e-6 * scale:
                        return [c]
    m = 0.5 * (lo + hi)
    return (find_kinks(x0, d, lo, m, eps, tol, depth + 1)
            + find_kinks(x0, d, m, hi, eps, tol, depth + 1))


def gradient(x, h):
    gr = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        gr[j] = (f(x + e) - f(x - e)) / (2 * h)
    return gr


def normalize(v):
    v = v / np.linalg.norm(v)
    k = np.argmax(np.abs(v))
    return v * np.sign(v[k])


def steal(n_lines=60, T=20.0):
    rows = []
    for _ in range(n_lines):
        x0 = rng.normal(size=DIM) * 0.5
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        for t in find_kinks(x0, d, -T, T):
            xs = x0 + t * d
            delta = 1e-4
            gp = gradient(xs + delta * d, 1e-6)
            gm = gradient(xs - delta * d, 1e-6)
            diff = gp - gm
            if np.linalg.norm(diff) < 1e-8:
                continue
            rows.append(normalize(diff))

    # Cluster by direction.
    clusters = []
    for r in rows:
        for cl in clusters:
            if np.linalg.norm(cl[0] - r) < 1e-3:
                cl.append(r)
                break
        else:
            clusters.append([r])
    # Discard spurious singletons only if we have plenty of support elsewhere.
    clusters.sort(key=len, reverse=True)
    good = [c for c in clusters if len(c) >= 2] or clusters
    return np.array([np.median(np.array(c), axis=0) for c in good])


if __name__ == "__main__":
    A1_hat = steal()
    np.save(os.path.join(HERE, "stolen_A1.npy"), A1_hat)
    print(A1_hat.shape)
    print(A1_hat)
