#!/usr/bin/env python
"""Refine cell masks (rectangles and polylines) into polylines with MobileSAM.

For every annotation in the metadata csv, MobileSAM is prompted with the
annotation's bounding box (plus a positive point at its centre). The predicted
masks are post-processed so that:
  * every cell is represented by exactly one contiguous polygon (polyline),
  * no two cell polygons overlap,
  * no output mask is an axis aligned rectangle.

The refined annotations are written to a csv identical to the input except for
the xmin, ymin, xmax, ymax, coords_x and coords_y columns.

Usage:
    python convert_masks.py --weights_path mobile_sam.pt --output_path out/ \
        --rgb_path image.png --csv_path metadata.csv
"""

import argparse
import os

import cv2
import numpy as np
import pandas as pd
import torch
from tqdm import tqdm

from mobile_sam import SamPredictor, sam_model_registry

TILE_SIZE = 1024  # MobileSAM's native input resolution
TILE_CONTEXT = 64  # minimum context (px) around a box inside a tile
BOX_MARGIN_FRAC = 0.15  # how far SAM masks may extend beyond the given box
BOX_MARGIN_MIN = 3
MIN_AREA = 9


# --------------------------------------------------------------------------- #
# Argument parsing / IO
# --------------------------------------------------------------------------- #
def parse_args():
    p = argparse.ArgumentParser(description="Convert cell masks to polylines using MobileSAM.")
    # Accept both positional and --flag style arguments.
    for name, helptext in [
        ("weights_path", "Path to the MobileSAM weights (mobile_sam.pt)."),
        ("output_path", "Output folder (or .csv file path) for the refined masks."),
        ("rgb_path", "Path to the RGB image."),
        ("csv_path", "Path to the metadata csv."),
    ]:
        p.add_argument(name, nargs="?", default=None, help=helptext)
        p.add_argument("--" + name, dest=name + "_opt", default=None, help=helptext)
    p.add_argument("--device", default="cpu", help="torch device (default: cpu)")
    a = p.parse_args()
    args = argparse.Namespace(device=a.device)
    for name in ["weights_path", "output_path", "rgb_path", "csv_path"]:
        val = getattr(a, name + "_opt") or getattr(a, name)
        if val is None:
            p.error(f"missing required argument: {name}")
        setattr(args, name, val)
    return args


def parse_coords(value):
    if isinstance(value, (list, tuple, np.ndarray)):
        return [float(v) for v in value]
    s = str(value).strip().strip("[]()")
    return [float(v) for v in s.replace(";", ",").replace(" ", ",").split(",") if v.strip() != ""]


def resolve_output_file(output_path, csv_path):
    if output_path.lower().endswith(".csv"):
        parent = os.path.dirname(os.path.abspath(output_path))
        os.makedirs(parent, exist_ok=True)
        return output_path
    os.makedirs(output_path, exist_ok=True)
    return os.path.join(output_path, os.path.basename(csv_path))


def load_model(weights_path, device):
    sam = sam_model_registry["vit_t"](checkpoint=None)
    state = torch.load(weights_path, map_location="cpu")
    if isinstance(state, dict) and "model" in state and not any(k.startswith("image_encoder") for k in state):
        state = state["model"]
    sam.load_state_dict(state)
    sam.to(device)
    sam.eval()
    return SamPredictor(sam)


# --------------------------------------------------------------------------- #
# Geometry helpers
# --------------------------------------------------------------------------- #
def largest_component(mask):
    mask = mask.astype(np.uint8)
    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    if n <= 1:
        return np.zeros(mask.shape, bool)
    idx = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return labels == idx


def fill_holes(mask):
    m = mask.astype(np.uint8)
    contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    out = np.zeros_like(m)
    cv2.drawContours(out, contours, -1, 1, thickness=cv2.FILLED)
    return out.astype(bool)


def clean_mask(mask):
    """Smooth, fill holes and keep a single connected component."""
    if mask.sum() == 0:
        return mask.astype(bool)
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    m = mask.astype(np.uint8)
    opened = cv2.morphologyEx(m, cv2.MORPH_OPEN, k)
    if opened.sum() >= MIN_AREA:
        m = opened
    m = largest_component(m)
    m = fill_holes(m)
    return m


def ellipse_mask(shape, x0, y0, x1, y1):
    m = np.zeros(shape, np.uint8)
    cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    ax, ay = max(2, (x1 - x0) / 2.0), max(2, (y1 - y0) / 2.0)
    cv2.ellipse(m, (int(round(cx)), int(round(cy))), (int(round(ax)), int(round(ay))), 0, 0, 360, 1, -1)
    return m.astype(bool)


def polygon_mask(shape, xs, ys):
    m = np.zeros(shape, np.uint8)
    pts = np.stack([np.round(xs), np.round(ys)], 1).astype(np.int32)
    if len(pts) >= 3:
        cv2.fillPoly(m, [pts], 1)
    return m.astype(bool)


def iou(a, b):
    inter = np.logical_and(a, b).sum()
    union = np.logical_or(a, b).sum()
    return inter / union if union else 0.0


def mask_to_polygon(mask):
    """Return the outer contour (Nx2 int array) of a single-component mask."""
    contours, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    c = max(contours, key=cv2.contourArea).reshape(-1, 2)
    return c


def is_axis_aligned_rectangle(poly):
    if poly is None:
        return True
    xs, ys = poly[:, 0], poly[:, 1]
    on_edge = (xs == xs.min()) | (xs == xs.max()) | (ys == ys.min()) | (ys == ys.max())
    return len(np.unique(poly, axis=0)) <= 4 or bool(on_edge.all())


# --------------------------------------------------------------------------- #
# SAM inference (tiled so that large images keep full resolution)
# --------------------------------------------------------------------------- #
def make_tile(box, h, w):
    """Choose a tile (x0, y0, x1, y1) of at most TILE_SIZE containing the ROI."""
    bx0, by0, bx1, by1 = box
    tw, th = min(TILE_SIZE, w), min(TILE_SIZE, h)
    cx, cy = (bx0 + bx1) / 2.0, (by0 + by1) / 2.0
    # snap to a grid so that neighbouring boxes share a tile embedding
    stride = TILE_SIZE // 2
    def snap(c, size, full):
        start = int(np.floor((c - size / 2.0) / stride + 0.5)) * stride
        return int(np.clip(start, 0, full - size))
    x0, y0 = snap(cx, tw, w), snap(cy, th, h)
    # ensure the box (with context) is inside the tile
    if bx0 - TILE_CONTEXT < x0 or bx1 + TILE_CONTEXT > x0 + tw:
        x0 = int(np.clip(cx - tw / 2.0, 0, w - tw))
    if by0 - TILE_CONTEXT < y0 or by1 + TILE_CONTEXT > y0 + th:
        y0 = int(np.clip(cy - th / 2.0, 0, h - th))
    return x0, y0, x0 + tw, y0 + th


def crop_padded(arr, x0, y0, x1, y1, fill=-np.inf):
    """arr[y0:y1, x0:x1] where out-of-bounds areas are filled with `fill`."""
    out = np.full((y1 - y0, x1 - x0), fill, np.float32)
    h, w = arr.shape
    sx0, sy0, sx1, sy1 = max(0, x0), max(0, y0), min(w, x1), min(h, y1)
    if sx1 > sx0 and sy1 > sy0:
        out[sy0 - y0:sy1 - y0, sx0 - x0:sx1 - x0] = arr[sy0:sy1, sx0:sx1]
    return out


def run_sam(predictor, image, records):
    """Return per-record (best logit crop over the record's ROI, score) or None."""
    h, w = image.shape[:2]
    tiles = {}
    for i, r in enumerate(records):
        tiles.setdefault(make_tile(r["roi"], h, w), []).append(i)

    results = [None] * len(records)
    pbar = tqdm(total=len(records), desc="MobileSAM")
    for (tx0, ty0, tx1, ty1), idxs in tiles.items():
        predictor.set_image(np.ascontiguousarray(image[ty0:ty1, tx0:tx1]), image_format="RGB")
        for i in idxs:
            r = records[i]
            bx0, by0, bx1, by1 = r["box"]
            box = np.array([bx0 - tx0, by0 - ty0, bx1 - tx0, by1 - ty0], dtype=np.float32)
            pt = np.array([[r["center"][0] - tx0, r["center"][1] - ty0]], dtype=np.float32)
            candidates = []
            with torch.no_grad():
                # box only, and box + centre point prompts
                for kwargs in (
                    dict(box=box),
                    dict(box=box, point_coords=pt, point_labels=np.array([1])),
                ):
                    logits, scores, _ = predictor.predict(multimask_output=True, return_logits=True, **kwargs)
                    for lg, sc in zip(logits, scores):
                        candidates.append((lg, float(sc)))
            cx0, cy0, cx1, cy1 = r["roi"]
            ref = r["ref"]
            box_area = max(1.0, (bx1 - bx0) * (by1 - by0))

            best, best_q = None, -np.inf
            for lg, sc in candidates:
                crop = crop_padded(lg, cx0 - tx0, cy0 - ty0, cx1 - tx0, cy1 - ty0)
                m = crop > 0
                area = m.sum()
                if area < MIN_AREA:
                    continue
                full_area = (lg > 0).sum()
                inside = area / max(1, full_area)  # fraction of mask inside ROI
                fill = area / box_area
                q = sc + 1.0 * iou(m, ref) + 0.5 * inside
                if fill < 0.15 or fill > 1.3:
                    q -= 0.5
                if q > best_q:
                    best_q, best = q, (crop.astype(np.float32), sc)
            results[i] = best
            pbar.update(1)
    pbar.close()
    return results


# --------------------------------------------------------------------------- #
# Main conversion
# --------------------------------------------------------------------------- #
def convert(args):
    image = cv2.imread(args.rgb_path, cv2.IMREAD_COLOR)
    if image is None:
        raise FileNotFoundError(f"Could not read image: {args.rgb_path}")
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    h, w = image.shape[:2]

    df = pd.read_csv(args.csv_path)
    index_col = None
    if len(df.columns) and (str(df.columns[0]).startswith("Unnamed: 0") or str(df.columns[0]) == ""):
        index_col = df.columns[0]
        df = df.set_index(index_col)
        df.index.name = None

    # ---- build prompts -------------------------------------------------- #
    records = []
    for _, row in df.iterrows():
        try:
            xs = np.array(parse_coords(row["coords_x"]), float)
            ys = np.array(parse_coords(row["coords_y"]), float)
        except Exception:
            xs = ys = np.array([])
        if len(xs) >= 3 and len(xs) == len(ys):
            x0, x1, y0, y1 = xs.min(), xs.max(), ys.min(), ys.max()
        else:
            x0, x1, y0, y1 = float(row["xmin"]), float(row["xmax"]), float(row["ymin"]), float(row["ymax"])
            xs = np.array([x0, x1, x1, x0, x0])
            ys = np.array([y0, y0, y1, y1, y0])
        x0, x1 = (float(v) for v in np.clip([x0, x1], 0, w - 1))
        y0, y1 = (float(v) for v in np.clip([y0, y1], 0, h - 1))
        if x1 - x0 < 2:
            x0, x1 = max(0.0, x0 - 1), min(w - 1.0, x1 + 1)
        if y1 - y0 < 2:
            y0, y1 = max(0.0, y0 - 1), min(h - 1.0, y1 + 1)
        # region of interest = box + margin; all per-cell arrays live in this crop
        mx = max(BOX_MARGIN_MIN, BOX_MARGIN_FRAC * (x1 - x0))
        my = max(BOX_MARGIN_MIN, BOX_MARGIN_FRAC * (y1 - y0))
        rx0, ry0 = int(max(0, np.floor(x0 - mx))), int(max(0, np.floor(y0 - my)))
        rx1, ry1 = int(min(w, np.ceil(x1 + mx) + 1)), int(min(h, np.ceil(y1 + my) + 1))
        rshape = (ry1 - ry0, rx1 - rx0)
        is_rect = str(row.get("type", "")).lower().startswith("rect") or \
            len(np.unique(np.stack([xs, ys], 1), axis=0)) <= 4
        if is_rect:
            ref = ellipse_mask(rshape, x0 - rx0, y0 - ry0, x1 - rx0, y1 - ry0)
        else:
            ref = polygon_mask(rshape, xs - rx0, ys - ry0)
        if ref.sum() == 0:
            ref = ellipse_mask(rshape, x0 - rx0, y0 - ry0, x1 - rx0, y1 - ry0)
        ys_r, xs_r = np.nonzero(ref)
        if len(xs_r):
            # SAM's point prompt must lie inside the cell: ref pixel closest to centroid
            j = np.argmin((xs_r - xs_r.mean()) ** 2 + (ys_r - ys_r.mean()) ** 2)
            center = (float(xs_r[j] + rx0), float(ys_r[j] + ry0))
        else:
            center = ((x0 + x1) / 2, (y0 + y1) / 2)
        records.append(dict(box=(x0, y0, x1, y1), roi=(rx0, ry0, rx1, ry1), ref=ref,
                            center=center, is_rect=is_rect))

    # ---- MobileSAM ------------------------------------------------------ #
    predictor = load_model(args.weights_path, args.device)
    sam_results = run_sam(predictor, image, records)

    # ---- candidate masks per cell (ROI crops) --------------------------- #
    n = len(records)
    masks, logits = [], []
    for r, best in zip(records, sam_results):
        m, lg = None, None
        if best is not None:
            crop, _ = best
            cm = clean_mask(crop > 0)
            if cm.sum() >= MIN_AREA:
                m, lg = cm, np.where(cm, crop, -np.inf).astype(np.float32)
        if m is None:  # fallback: annotation-shaped (non rectangular) mask
            m = r["ref"].copy()
            lg = np.where(m, 0.0, -np.inf).astype(np.float32)
        masks.append(m)
        logits.append(lg)

    # ---- resolve overlaps: each pixel goes to the most confident cell -- #
    label = np.zeros((h, w), np.int32)  # 0 = background, k+1 = cell k
    best_logit = np.full((h, w), -np.inf, np.float32)
    order = sorted(range(n), key=lambda k: masks[k].sum())  # ties favour smaller cells
    for k in order:
        x0, y0, x1, y1 = records[k]["roi"]
        L, B = label[y0:y1, x0:x1], best_logit[y0:y1, x0:x1]
        upd = masks[k] & (logits[k] > B)
        L[upd] = k + 1
        B[upd] = logits[k][upd]
    del best_logit

    # keep one component per cell, then enforce a 1px gap between cells
    for k in range(n):
        x0, y0, x1, y1 = records[k]["roi"]
        L = label[y0:y1, x0:x1]
        own = L == k + 1
        keep = clean_component(own)
        L[own & ~keep] = 0
    final = separate_masks(label, records)

    # ---- polygons ------------------------------------------------------- #
    out = df.copy()
    for col in ["coords_x", "coords_y"]:
        out[col] = out[col].astype(object)
    for col in ["xmin", "xmax", "ymin", "ymax"]:
        out[col] = out[col].astype(object)
    occupied = label != 0
    for k, (idx, r) in enumerate(zip(df.index, records)):
        m = final[k]
        x0, y0 = r["roi"][:2]
        poly = mask_to_polygon(m) if m.sum() >= 3 else None
        if poly is not None:
            poly = poly + np.array([x0, y0])
        if poly is None or len(poly) < 3 or is_axis_aligned_rectangle(poly):
            poly = fallback_polygon(r, occupied, label == k + 1, (h, w))
            px0, py0 = poly.min(0)
            px1, py1 = poly.max(0) + 1
            pm = polygon_mask((py1 - py0, px1 - px0), poly[:, 0] - px0, poly[:, 1] - py0)
            occupied[py0:py1, px0:px1] |= pm
        xs = [int(v) for v in poly[:, 0]] + [int(poly[0, 0])]
        ys = [int(v) for v in poly[:, 1]] + [int(poly[0, 1])]
        out.at[idx, "coords_x"] = ",".join(map(str, xs))
        out.at[idx, "coords_y"] = ",".join(map(str, ys))
        out.at[idx, "xmin"] = int(min(xs))
        out.at[idx, "xmax"] = int(max(xs))
        out.at[idx, "ymin"] = int(min(ys))
        out.at[idx, "ymax"] = int(max(ys))

    out_file = resolve_output_file(args.output_path, args.csv_path)
    if index_col is not None:
        out.to_csv(out_file, index=True, index_label="" if index_col.startswith("Unnamed") else index_col)
    else:
        out.to_csv(out_file, index=False)
    print(f"Saved {len(out)} refined masks to {out_file}")
    return out_file


def clean_component(mask):
    if mask.sum() == 0:
        return mask
    m = largest_component(mask)
    m = fill_holes(m)
    return m


def separate_masks(label, records):
    """Make cells disjoint with a >=1px gap; single component, no holes.

    Operates in-place on the label map; returns per-cell boolean ROI crops.
    """
    h, w = label.shape
    k3 = np.ones((3, 3), np.uint8)
    out = []
    for k, r in enumerate(records):
        x0, y0, x1, y1 = r["roi"]
        px0, py0, px1, py1 = max(0, x0 - 1), max(0, y0 - 1), min(w, x1 + 1), min(h, y1 + 1)
        Lp = label[py0:py1, px0:px1]
        others = (Lp != 0) & (Lp != k + 1)
        near = cv2.dilate(others.astype(np.uint8), k3).astype(bool)
        near = near[y0 - py0:y0 - py0 + (y1 - y0), x0 - px0:x0 - px0 + (x1 - x0)]
        L = label[y0:y1, x0:x1]
        own = L == k + 1
        m = own & ~near
        m = clean_mask(m) if m.sum() >= MIN_AREA else largest_component(m)
        m = largest_component(m & ~near & (own | (L == 0)))
        L[own & ~m] = 0  # release pixels removed from this cell
        out.append(m)
    return out


def fallback_polygon(r, occupied, own, shape):
    """Small non-rectangular polygon (octagon) at the cell centre in free space."""
    h, w = shape
    cx, cy = r["center"]
    x0, y0, x1, y1 = r["box"]
    rmax = max(2.0, min(x1 - x0, y1 - y0) / 2.0)
    wx0, wy0 = int(max(0, np.floor(cx - rmax - 3))), int(max(0, np.floor(cy - rmax - 3)))
    wx1, wy1 = int(min(w, np.ceil(cx + rmax + 4))), int(min(h, np.ceil(cy + rmax + 4)))
    win_occ = occupied[wy0:wy1, wx0:wx1] & ~own[wy0:wy1, wx0:wx1]
    free = ~cv2.dilate(win_occ.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool)
    ang = np.linspace(0, 2 * np.pi, 8, endpoint=False) + np.pi / 8
    for rad in [rmax * s for s in (1.0, 0.7, 0.5, 0.35, 0.25)] + [2.0, 1.5]:
        px = np.clip(np.round(cx + rad * np.cos(ang)), 0, w - 1).astype(int)
        py = np.clip(np.round(cy + rad * np.sin(ang)), 0, h - 1).astype(int)
        poly = np.stack([px, py], 1)
        if len(np.unique(poly, axis=0)) < 3 or is_axis_aligned_rectangle(poly):
            continue
        pm = polygon_mask(free.shape, px - wx0, py - wy0)
        if pm.sum() and not (pm & ~free).any():
            return poly
    # last resort: a tiny triangle at the centre
    cxi, cyi = int(np.clip(round(cx), 0, w - 2)), int(np.clip(round(cy), 1, h - 1))
    return np.array([[cxi, cyi], [cxi + 1, cyi], [cxi, cyi - 1]])


if __name__ == "__main__":
    convert(parse_args())
