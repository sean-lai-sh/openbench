"""Pipeline-parallel training step (AFAB schedule) for HF LlamaForCausalLM."""

import torch
import torch.distributed as dist
import torch.nn.functional as F

try:
    from transformers.masking_utils import create_causal_mask
except ImportError:  # pragma: no cover
    create_causal_mask = None


def _partition_layers(num_layers, world_size, rank):
    """Return [start, end) of decoder layers owned by `rank` (balanced split)."""
    base, rem = divmod(num_layers, world_size)
    start = rank * base + min(rank, rem)
    end = start + base + (1 if rank < rem else 0)
    return start, end


def _p2p(ops):
    if not ops:
        return
    reqs = dist.batch_isend_irecv(ops)
    for r in reqs:
        r.wait()


def _send(tensor, peer):
    _p2p([dist.P2POp(dist.isend, tensor.contiguous(), peer)])


def _recv(shape, peer, device, dtype):
    buf = torch.empty(shape, device=device, dtype=dtype)
    _p2p([dist.P2POp(dist.irecv, buf, peer)])
    return buf


def _stage_forward(model, hidden, start, end, is_last):
    """Run decoder layers [start, end) (plus final norm/lm_head if last stage)."""
    base = model.model
    seq_len = hidden.shape[1]
    position_ids = torch.arange(seq_len, device=hidden.device).unsqueeze(0)

    causal_mask = None
    if create_causal_mask is not None:
        causal_mask = create_causal_mask(
            config=base.config,
            inputs_embeds=hidden,
            attention_mask=None,
            past_key_values=None,
            position_ids=position_ids,
        )
    position_embeddings = base.rotary_emb(hidden, position_ids=position_ids)

    for layer in base.layers[start:end]:
        out = layer(
            hidden,
            attention_mask=causal_mask,
            position_ids=position_ids,
            position_embeddings=position_embeddings,
            past_key_values=None,
            use_cache=False,
        )
        hidden = out[0] if isinstance(out, tuple) else out

    if is_last:
        hidden = base.norm(hidden)
        hidden = model.lm_head(hidden)
    return hidden


def train_step_pipeline_afab(model, inputs, targets, device, dtype):
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    is_first = rank == 0
    is_last = rank == world_size - 1
    prev_rank, next_rank = rank - 1, rank + 1

    num_layers = len(model.model.layers)
    start, end = _partition_layers(num_layers, world_size, rank)
    hidden_size = model.config.hidden_size
    n_micro = len(inputs)

    stage_inputs, stage_outputs, losses = [], [], []

    # ---------------- all forward ----------------
    for i in range(n_micro):
        mb, seq_len = inputs[i].shape[0], inputs[i].shape[1]
        if is_first:
            ids = inputs[i].to(device)
            hidden_in = model.model.embed_tokens(ids).to(device=device, dtype=dtype)
        else:
            hidden_in = _recv((mb, seq_len, hidden_size), prev_rank, device, dtype)
            hidden_in.requires_grad_(True)

        out = _stage_forward(model, hidden_in, start, end, is_last)

        if is_last:
            tgt = targets[i].to(device)
            loss = F.cross_entropy(
                out.reshape(-1, out.shape[-1]).float(), tgt.reshape(-1)
            ) / n_micro
            losses.append(loss)
            stage_outputs.append(loss)
        else:
            out = out.to(device=device, dtype=dtype)
            _send(out.detach(), next_rank)
            stage_outputs.append(out)
        stage_inputs.append(hidden_in)

    # ---------------- all backward ----------------
    for i in range(n_micro):
        hidden_in, out = stage_inputs[i], stage_outputs[i]
        if is_last:
            out.backward()
        else:
            grad = _recv(out.shape, next_rank, device, dtype)
            torch.autograd.backward(out, grad_tensors=grad)

        if not is_first:
            g = hidden_in.grad
            if g is None:
                g = torch.zeros_like(hidden_in)
            _send(g.to(device=device, dtype=dtype), prev_rank)

    if is_last:
        return torch.stack([l.detach() for l in losses]).sum()
    return None
