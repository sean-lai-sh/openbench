"""Recover A1 (up to neuron permutation and row scaling) of a 1-hidden-layer
ReLU network using only black-box queries to forward(x).

Method: along random lines x(t) = x0 + t*d, the output is piecewise linear in t.
Each kink corresponds to a hidden neuron's hyperplane a_i.x + b_i = 0. At a kink,
the jump in the full input gradient equals A2_i * a_i (up to sign), so it gives
the row a_i up to scale. Rows from many kinks are normalized and deduplicated.
"""
import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def grad(x, h=1e-6):
    g = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        g[j] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def find_kinks(x0, d, lo, hi, flo, fhi, depth=0, out=None):
    """Recursively find t values where f(x0 + t d) is non-linear."""
    if out is None:
        out = []
    mid = 0.5 * (lo + hi)
    fmid = f(x0 + mid * d)
    q1, q3 = lo + 0.25 * (hi - lo), lo + 0.75 * (hi - lo)
    fq1, fq3 = f(x0 + q1 * d), f(x0 + q3 * d)
    lin = lambda t: flo + (fhi - flo) * (t - lo) / (hi - lo)
    tol = 1e-12 * (1 + abs(flo) + abs(fhi))
    if (abs(fmid - lin(mid)) < tol and abs(fq1 - lin(q1)) < tol
            and abs(fq3 - lin(q3)) < tol):
        return out  # linear on this segment
    if hi - lo < 1e-3 or depth > 40:
        # Try to locate a single kink by intersecting the end-piece lines.
        e = 1e-7 * (hi - lo) + 1e-9
        sl = (f(x0 + (lo + e) * d) - flo) / e
        sr = (fhi - f(x0 + (hi - e) * d)) / e
        if abs(sl - sr) > 1e-9:
            t = (fhi - flo + sl * lo - sr * hi) / (sl - sr)
            if lo <= t <= hi:
                out.append(t)
        return out
    find_kinks(x0, d, lo, mid, flo, fmid, depth + 1, out)
    find_kinks(x0, d, mid, hi, fmid, fhi, depth + 1, out)
    return out


def normalize(v):
    v = v / np.linalg.norm(v)
    # canonical sign: largest-magnitude entry positive
    return v * np.sign(v[np.argmax(np.abs(v))])


def main():
    rows = []      # list of (unit vector, count)
    stale = 0
    n_lines = 0
    while stale < 60 and n_lines < 2000:
        n_lines += 1
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        T = 20.0
        kinks = find_kinks(x0, d, -T, T, f(x0 - T * d), f(x0 + T * d))
        new_found = False
        for t in kinks:
            xs = x0 + t * d
            eps = 1e-4
            diff = grad(xs + eps * d) - grad(xs - eps * d)
            n = np.linalg.norm(diff)
            if n < 1e-7:
                continue
            v = normalize(diff)
            # verify: a second, closer pair should give the same direction
            diff2 = grad(xs + eps / 10 * d) - grad(xs - eps / 10 * d)
            if np.linalg.norm(diff2) < 1e-7 or abs(np.dot(normalize(diff2), v)) < 1 - 1e-6:
                continue
            for r in rows:
                if abs(np.dot(r[0], v)) > 1 - 1e-5:
                    r[1] += 1
                    break
            else:
                rows.append([v, 1])
                new_found = True
        stale = 0 if new_found else stale + 1

    A = np.array([r[0] for r in rows])
    print(f"Recovered {len(A)} neurons using {n_lines} lines")
    np.save(OUT, A)
    np.set_printoptions(precision=6, suppress=True, linewidth=150)
    print(A)
    return A


if __name__ == "__main__":
    main()
