import torch
import torch.distributed as dist
import torch.nn.functional as F


def _world_size():
    if dist.is_available() and dist.is_initialized():
        return dist.get_world_size()
    return 1


def _rank():
    if dist.is_available() and dist.is_initialized():
        return dist.get_rank()
    return 0


# ---------------------------------------------------------------------------
# Autograd-aware communication primitives
# ---------------------------------------------------------------------------

class _CopyToParallelRegion(torch.autograd.Function):
    """Forward: identity. Backward: all-reduce the gradient."""

    @staticmethod
    def forward(ctx, x):
        return x

    @staticmethod
    def backward(ctx, grad):
        if _world_size() == 1:
            return grad
        grad = grad.contiguous().clone()
        dist.all_reduce(grad, op=dist.ReduceOp.SUM)
        return grad


class _ReduceFromParallelRegion(torch.autograd.Function):
    """Forward: all-reduce. Backward: identity."""

    @staticmethod
    def forward(ctx, x):
        if _world_size() == 1:
            return x
        x = x.contiguous().clone()
        dist.all_reduce(x, op=dist.ReduceOp.SUM)
        return x

    @staticmethod
    def backward(ctx, grad):
        return grad


class _GatherFromParallelRegion(torch.autograd.Function):
    """Forward: all-gather along last dim. Backward: take local slice."""

    @staticmethod
    def forward(ctx, x):
        ws = _world_size()
        if ws == 1:
            return x
        x = x.contiguous()
        parts = [torch.empty_like(x) for _ in range(ws)]
        dist.all_gather(parts, x)
        return torch.cat(parts, dim=-1).contiguous()

    @staticmethod
    def backward(ctx, grad):
        ws = _world_size()
        if ws == 1:
            return grad
        chunk = grad.size(-1) // ws
        r = _rank()
        return grad[..., r * chunk:(r + 1) * chunk].contiguous()


class _ScatterToParallelRegion(torch.autograd.Function):
    """Forward: take local slice along last dim. Backward: all-gather."""

    @staticmethod
    def forward(ctx, x):
        ws = _world_size()
        if ws == 1:
            return x
        chunk = x.size(-1) // ws
        r = _rank()
        return x[..., r * chunk:(r + 1) * chunk].contiguous()

    @staticmethod
    def backward(ctx, grad):
        ws = _world_size()
        if ws == 1:
            return grad
        grad = grad.contiguous()
        parts = [torch.empty_like(grad) for _ in range(ws)]
        dist.all_gather(parts, grad)
        return torch.cat(parts, dim=-1).contiguous()


# ---------------------------------------------------------------------------
# Parallel linear layers
# ---------------------------------------------------------------------------

class ColumnParallelLinear(torch.nn.Module):
    """Y = X A^T + b, with A (out_features x in_features) split along the
    output dimension. Each rank computes a slice of the output, which is
    then all-gathered along the last dimension."""

    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.world_size = _world_size()
        self.rank = _rank()
        assert out_features % self.world_size == 0, \
            "out_features must be divisible by world_size"
        self.output_size_per_partition = out_features // self.world_size

        master_weight = torch.as_tensor(master_weight)
        assert tuple(master_weight.shape) == (out_features, in_features), \
            f"master_weight must have shape ({out_features}, {in_features})"
        start = self.rank * self.output_size_per_partition
        end = start + self.output_size_per_partition
        self.weight = torch.nn.Parameter(
            master_weight[start:end, :].detach().clone().contiguous()
        )

        if bias:
            self.bias = torch.nn.Parameter(
                torch.zeros(self.output_size_per_partition,
                            dtype=self.weight.dtype,
                            device=self.weight.device)
            )
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        x = _CopyToParallelRegion.apply(x)
        local_out = F.linear(x, self.weight, self.bias)
        return _GatherFromParallelRegion.apply(local_out)


class RowParallelLinear(torch.nn.Module):
    """Y = X A^T + b, with A (out_features x in_features) split along the
    input dimension. Each rank computes a partial output from its slice of
    the input; partial outputs are summed (all-reduce) and the full bias is
    added afterwards."""

    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.world_size = _world_size()
        self.rank = _rank()
        assert in_features % self.world_size == 0, \
            "in_features must be divisible by world_size"
        self.input_size_per_partition = in_features // self.world_size

        master_weight = torch.as_tensor(master_weight)
        assert tuple(master_weight.shape) == (out_features, in_features), \
            f"master_weight must have shape ({out_features}, {in_features})"
        start = self.rank * self.input_size_per_partition
        end = start + self.input_size_per_partition
        self.weight = torch.nn.Parameter(
            master_weight[:, start:end].detach().clone().contiguous()
        )

        if bias:
            self.bias = torch.nn.Parameter(
                torch.zeros(out_features,
                            dtype=self.weight.dtype,
                            device=self.weight.device)
            )
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        # Accept either the full input (split it here) or an already
        # partitioned input.
        if self.world_size > 1 and x.size(-1) == self.in_features:
            x = _ScatterToParallelRegion.apply(x)
        elif x.size(-1) != self.input_size_per_partition:
            raise ValueError(
                f"Expected input last dim {self.in_features} or "
                f"{self.input_size_per_partition}, got {x.size(-1)}"
            )
        partial = F.linear(x, self.weight)
        out = _ReduceFromParallelRegion.apply(partial)
        if self.bias is not None:
            out = out + self.bias
        return out
