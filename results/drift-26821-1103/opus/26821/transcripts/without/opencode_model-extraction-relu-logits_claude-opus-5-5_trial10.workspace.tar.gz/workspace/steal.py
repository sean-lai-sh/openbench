"""
Extract A1 (up to neuron permutation and scaling) of a one-hidden-layer ReLU
network f(x) = A2 ReLU(A1 x + b1) + b2 using only black-box queries to forward().

Method:
  1. Walk along many random lines in input space and locate the "kinks"
     (critical points) where some hidden neuron switches on/off, by recursive
     bisection on the piecewise-linear 1-D restriction of f.
  2. At each critical point, compute the gradient of f on both sides of the
     kink.  The difference of gradients is proportional to the row of A1 for
     the neuron that switched.  The point itself gives the bias (w.x + b = 0).
  3. Cluster the recovered (normalised) rows to deduplicate neurons.
  4. Resolve the sign of each row globally: fit output weights by least
     squares and choose the sign pattern which leaves no residual linear term.
"""
import os
import itertools
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi, tol=1e-13, min_len=1e-9):
    """Return t values of kinks of g(t)=f(x0+t d) in [lo, hi]."""
    g = lambda t: f(x0 + t * d)
    kinks = []

    def rec(a, fa, b, fb, depth):
        m = 0.5 * (a + b)
        fm = g(m)
        q1, q3 = 0.75 * a + 0.25 * b, 0.25 * a + 0.75 * b
        fq1, fq3 = g(q1), g(q3)
        scale = tol * (1 + abs(fa) + abs(fb))
        lin = lambda t: fa + (fb - fa) * (t - a) / (b - a)
        if (abs(fm - lin(m)) < scale and abs(fq1 - lin(q1)) < scale
                and abs(fq3 - lin(q3)) < scale):
            return
        if b - a < min_len:
            kinks.append(m)
            return
        # try to resolve a single kink by intersecting the end lines
        h = min(1e-7, (b - a) * 1e-3)
        sa = (g(a + h) - fa) / h
        sb = (fb - g(b - h)) / h
        if abs(sa - sb) > 1e-12:
            ts = (fb - fa + sa * a - sb * b) / (sa - sb)
            if a + 2 * h < ts < b - 2 * h:
                fts = g(ts)
                ok = abs(fts - (fa + sa * (ts - a))) < 10 * scale
                # check linearity on each side (single kink only)
                for t in (0.5 * (a + ts), 0.5 * (ts + b)):
                    pred = fa + sa * (t - a) if t < ts else fb + sb * (t - b)
                    ok = ok and abs(g(t) - pred) < 10 * scale
                if ok:
                    kinks.append(ts)
                    return
        rec(a, fa, m, fm, depth + 1)
        rec(m, fm, b, fb, depth + 1)

    # split initial range into chunks to reduce chance of cancelling kinks
    edges = np.linspace(lo, hi, 65)
    fe = [g(t) for t in edges]
    for i in range(len(edges) - 1):
        rec(edges[i], fe[i], edges[i + 1], fe[i + 1], 0)
    # merge near-duplicates
    kinks.sort()
    merged = []
    for k in kinks:
        if not merged or k - merged[-1] > 1e-5:
            merged.append(k)
    return merged


def grad(x, h=1e-6):
    f0 = f(x)
    gr = np.empty(DIM)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = h
        gr[i] = (f(x + e) - f0) / h
    return gr


def main():
    candidates = []  # (unit normal, bias)
    n_lines = 120
    for _ in range(n_lines):
        x0 = rng.normal(size=DIM) * rng.uniform(0.1, 2.0)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        for t in find_kinks(x0, d, -15.0, 15.0):
            xs = x0 + t * d
            diff = grad(xs + 1e-4 * d) - grad(xs - 1e-4 * d)
            diff2 = grad(xs + 1e-5 * d) - grad(xs - 1e-5 * d)
            nrm = np.linalg.norm(diff)
            if nrm < 1e-8:
                continue
            # reject points where another kink is nearby (inconsistent)
            if np.linalg.norm(diff - diff2) > 1e-3 * nrm:
                continue
            w = diff / nrm
            # make representation canonical (sign of largest component +)
            if w[np.argmax(np.abs(w))] < 0:
                w = -w
            b = -w @ xs
            candidates.append((w, b))

    # cluster
    clusters = []  # list of [sum_w, sum_b, count]
    for w, b in candidates:
        for c in clusters:
            cw = c[0] / c[2]
            cw /= np.linalg.norm(cw)
            if abs(cw @ w) > 1 - 1e-4:
                c[0] += w
                c[1] += b
                c[2] += 1
                break
        else:
            clusters.append([w.copy(), b, 1])
    # keep clusters seen more than once (robust against spurious points),
    # unless very few candidates
    good = [c for c in clusters if c[2] >= 2] or clusters
    W = np.array([c[0] / np.linalg.norm(c[0]) for c in good])
    B = np.array([c[1] / c[2] for c in good])
    print(f"found {len(W)} neurons from {len(candidates)} critical points")

    # --- global sign resolution ---
    # f(x) = sum_i c_i relu(W_i x + B_i) + v.x + b0, where v != 0 indicates
    # some rows have the wrong sign: relu(-z) = relu(z) - z.
    X = rng.normal(size=(4000, DIM)) * 3.0
    y = np.array([f(x) for x in X])
    H = np.maximum(0, X @ W.T + B)
    M = np.hstack([H, X, np.ones((len(X), 1))])
    coef, *_ = np.linalg.lstsq(M, y, rcond=None)
    c = coef[:len(W)]
    v = coef[len(W):len(W) + DIM]
    # find subset S with sum_{i in S} c_i W_i = -v  (flipping those rows)
    n = len(W)
    CW = c[:, None] * W
    best, best_err = None, np.inf
    if n <= 22:
        half = n // 2
        idxA, idxB = list(range(half)), list(range(half, n))
        def all_sums(idx):
            masks = np.array(list(itertools.product([0, 1], repeat=len(idx))),
                             dtype=float).reshape(-1, len(idx))
            return masks, masks @ CW[idx] if len(idx) else np.zeros((1, DIM))
        mA, sA = all_sums(idxA)
        mB, sB = all_sums(idxB)
        target = -v
        for j in range(len(sB)):
            err = np.linalg.norm(sA + sB[j] - target, axis=1)
            k = np.argmin(err)
            if err[k] < best_err:
                best_err = err[k]
                best = np.concatenate([mA[k], mB[j]])
    else:
        # greedy fallback
        best = np.zeros(n)
    flip = np.where(best > 0.5, -1.0, 1.0)
    W = W * flip[:, None]
    print("sign-resolution residual:", best_err, "| |v| =", np.linalg.norm(v))

    np.save(OUT, W)
    print(W)
    return W


if __name__ == "__main__":
    main()
