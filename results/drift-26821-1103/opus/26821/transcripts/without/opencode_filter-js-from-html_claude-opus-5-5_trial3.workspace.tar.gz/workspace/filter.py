#!/usr/bin/env python3
"""Remove JavaScript from an HTML file (in place) while leaving everything
else byte-for-byte untouched.

Usage: python filter.py file.html

The file is scanned with a small tokenizer that follows the HTML5
tokenization rules closely.  Only constructs that can execute script are
changed:

  * <script> elements (with their content) are removed.
  * Event-handler attributes (on*) are removed.
  * Attributes whose value carries a javascript:/vbscript:/data: payload
    (href, src, action, formaction, xlink:href, SVG animation values, meta
    refresh content, ...) are removed.
  * Dangerous inline CSS (expression(), javascript: urls, behaviors, ...)
    is removed.
  * Comments / CDATA / raw-text content that would contain active markup if
    interpreted differently by a browser are neutralised.

Tags that need no change are emitted verbatim, so formatting is preserved.
"""

import html
import re
import sys

WS = "\t\n\f\r "

# Elements removed together with their content.
DROP_ELEMENTS = {"script"}

# Elements whose content is raw text in (some contexts of) HTML parsing.
RAWTEXT_ELEMENTS = {
    "style", "xmp", "iframe", "noembed", "noframes", "noscript",
    "textarea", "title", "plaintext",
}

# Attributes in which a "data:" URL is considered harmless text.
TEXT_ATTRS = {"title", "alt", "value", "placeholder", "label", "class", "id",
              "name", "lang", "dir", "summary", "abbr"}

SCRIPT_SCHEME_RE = re.compile(r"(?:java|vb|live|ecma|j|mocha)script\s*:", re.I)
DATA_RE = re.compile(r"(?<![a-z0-9_\-])data\s*:", re.I)
SAFE_DATA_RE = re.compile(
    r"(?<![a-z0-9_\-])data\s*:\s*image/(?:png|jpe?g|gif|webp|bmp|x-icon|avif)[;,]",
    re.I)
CSS_DANGER_RE = re.compile(
    r"expression\(|javascript:|vbscript:|behavior:|-moz-binding|"
    r"@import|url\(\s*['\"]?\s*(?:data|javascript|vbscript):",
    re.I)
CONTROL_RE = re.compile(r"[\x00-\x20\x7f]")


# ---------------------------------------------------------------------------
# Attribute checks
# ---------------------------------------------------------------------------

def _decode(value):
    try:
        return html.unescape(value)
    except Exception:  # pragma: no cover - defensive
        return value


def _has_script_url(value):
    compact = CONTROL_RE.sub("", value)
    return bool(SCRIPT_SCHEME_RE.search(compact))


def _has_bad_data_url(value):
    compact = CONTROL_RE.sub("", value)
    for m in DATA_RE.finditer(compact):
        if not SAFE_DATA_RE.match(compact, m.start()):
            return True
    return False


def _css_dangerous(value):
    v = re.sub(r"/\*.*?\*/", "", value, flags=re.S)
    v = v.replace("\\", "")
    v = CONTROL_RE.sub("", v)
    return bool(CSS_DANGER_RE.search(v))


def attr_is_dangerous(tag, name, raw_value):
    lname = name.lower()
    if lname.startswith("on"):
        return True
    if raw_value is None:
        return False
    value = _decode(raw_value)
    if _has_script_url(value):
        return True
    if lname not in TEXT_ATTRS and not lname.startswith(("aria-", "data-")):
        if _has_bad_data_url(value):
            return True
    if lname == "style" and _css_dangerous(value):
        return True
    if lname == "srcdoc":
        if sanitize(value, nested=True) != value:
            return True
    if lname == "attributename" and value.strip().lower().startswith(
            ("on", "href", "xlink:href", "src", "action", "formaction")):
        return True
    if lname == "http-equiv" and value.strip().lower() == "refresh":
        # Only dangerous if content carries a script/data URL; handled by
        # checking content itself.
        return False
    if "<" in value and sanitize(value, nested=True) != value:
        return True
    return False


# ---------------------------------------------------------------------------
# Tokenizer helpers
# ---------------------------------------------------------------------------

def parse_tag(s, i):
    """Parse a start/end tag starting at s[i] == '<'.

    Returns (end_index, tag_name, attrs, complete) where attrs is a list of
    (span_start, span_end, name, raw_value_or_None, sep) and sep is the raw
    whitespace/slash text preceding the attribute.  end_index points just
    past the closing '>' (or len(s) if incomplete).
    """
    n = len(s)
    j = i + 1
    if j < n and s[j] == "/":
        j += 1
    start_name = j
    while j < n and s[j] not in WS and s[j] not in "/>":
        j += 1
    tag_name = s[start_name:j]
    name_end = j
    attrs = []
    while True:
        sep_start = j
        # before attribute name: skip whitespace and stray slashes
        while j < n:
            c = s[j]
            if c in WS:
                j += 1
            elif c == "/":
                if j + 1 < n and s[j + 1] == ">":
                    break
                j += 1
            else:
                break
        if j >= n:
            return n, tag_name, attrs, False, name_end
        if s[j] == ">":
            return j + 1, tag_name, attrs, True, name_end
        if s[j] == "/" and j + 1 < n and s[j + 1] == ">":
            return j + 2, tag_name, attrs, True, name_end
        sep = s[sep_start:j]
        attr_start = j
        # attribute name (first char may be '=')
        k = j + 1
        while k < n and s[k] not in WS and s[k] not in "/>=":
            k += 1
        name = s[j:k]
        j = k
        # after attribute name
        m = j
        while m < n and s[m] in WS:
            m += 1
        value = None
        if m < n and s[m] == "=":
            m += 1
            while m < n and s[m] in WS:
                m += 1
            if m >= n:
                return n, tag_name, attrs, False, name_end
            q = s[m]
            if q in "\"'":
                close = s.find(q, m + 1)
                if close == -1:
                    attrs.append((sep_start, n, name, s[m + 1:], sep))
                    return n, tag_name, attrs, False, name_end
                value = s[m + 1:close]
                j = close + 1
            elif q == ">":
                value = ""
                j = m
            else:
                k = m
                while k < n and s[k] not in WS and s[k] != ">":
                    k += 1
                value = s[m:k]
                j = k
        attrs.append((sep_start, j, name, value, sep))
        del attr_start


def find_rawtext_end(s, i, name):
    """Return index of '</name' closing tag (case-insensitive) or -1."""
    pat = re.compile(r"</" + re.escape(name) + r"(?=[\t\n\f\r />])", re.I)
    m = pat.search(s, i)
    return m.start() if m else -1


def rebuild_tag(s, i, end, name_end, attrs, keep):
    out = [s[i:name_end]]
    pos = name_end
    for (a_start, a_end, _name, _value, _sep), k in zip(attrs, keep):
        if k:
            piece = s[a_start:a_end]
            if not piece[:1] or (piece[0] not in WS and piece[0] != "/"):
                piece = " " + piece
            out.append(piece)
        pos = a_end
    out.append(s[pos:end])
    return "".join(out)


# ---------------------------------------------------------------------------
# Main sanitizer
# ---------------------------------------------------------------------------

def _region_dangerous(text):
    if SCRIPT_SCHEME_RE.search(CONTROL_RE.sub("", _decode(text))):
        return True
    return sanitize(text, nested=True) != text


def sanitize_once(s, nested=False):
    out = []
    n = len(s)
    i = 0
    while i < n:
        lt = s.find("<", i)
        if lt == -1:
            out.append(s[i:])
            break
        out.append(s[i:lt])
        i = lt
        nxt = s[i + 1] if i + 1 < n else ""

        # ---- comments / doctype / CDATA / processing instructions -------
        if s.startswith("<!--", i):
            body_start = i + 4
            if s.startswith(">", body_start):
                end = body_start + 1
                body = ""
            elif s.startswith("->", body_start):
                end = body_start + 2
                body = ""
            else:
                cands = [x for x in (s.find("-->", body_start),
                                     s.find("--!>", body_start)) if x != -1]
                if cands:
                    c = min(cands)
                    body = s[body_start:c]
                    end = c + (3 if s.startswith("-->", c) else 4)
                else:
                    body = s[body_start:]
                    end = n
            if not _region_dangerous(body):
                out.append(s[i:end])
            i = end
            continue
        if s.startswith("<![CDATA[", i):
            gt = s.find(">", i)
            cd = s.find("]]>", i)
            ends = [x for x in ((gt + 1) if gt != -1 else -1,
                                (cd + 3) if cd != -1 else -1) if x != -1]
            end = max(ends) if ends else n
            body = s[i + 9:end]
            if not _region_dangerous(body):
                out.append(s[i:end])
            i = end
            continue
        if nxt in ("!", "?") or (nxt == "/" and i + 2 < n
                                 and not s[i + 2].isalpha()
                                 and s[i + 2] != ">"):
            gt = s.find(">", i)
            end = gt + 1 if gt != -1 else n
            body = s[i + 2:end]
            if not _region_dangerous(body):
                out.append(s[i:end])
            i = end
            continue
        if nxt == "/" and i + 2 < n and s[i + 2] == ">":
            out.append("</>")
            i += 3
            continue

        # ---- tags ---------------------------------------------------------
        is_end = nxt == "/"
        if not ((nxt.isascii() and nxt.isalpha()) or
                (is_end and i + 2 < n and s[i + 2].isascii()
                 and s[i + 2].isalpha())):
            out.append("<")
            i += 1
            continue

        end, tag_name, attrs, complete, name_end = parse_tag(s, i)
        lname = tag_name.lower()

        if is_end:
            if lname in DROP_ELEMENTS:
                i = end
                continue
            out.append(s[i:end])
            i = end
            continue

        if lname in DROP_ELEMENTS:
            if not complete:
                i = n
                break
            close = find_rawtext_end(s, end, lname)
            if close == -1:
                i = n
                break
            gt = s.find(">", close)
            i = gt + 1 if gt != -1 else n
            continue

        keep = [not attr_is_dangerous(lname, a[2], a[3]) for a in attrs]
        if not complete:
            if all(keep) and not _incomplete_dangerous(s[i:end]):
                out.append(s[i:end])
            i = n
            break
        if all(keep):
            out.append(s[i:end])
        else:
            out.append(rebuild_tag(s, i, end, name_end, attrs, keep))
        i = end

        if lname in RAWTEXT_ELEMENTS:
            if lname == "plaintext":
                close = -1
            else:
                close = find_rawtext_end(s, i, lname)
            content_end = close if close != -1 else n
            content = s[i:content_end]
            if lname == "style" and _css_dangerous(content):
                content = ""
            else:
                cleaned = sanitize(content, nested=True)
                if cleaned != content:
                    content = cleaned
            out.append(content)
            i = content_end
    return "".join(out)


def _incomplete_dangerous(text):
    return bool(SCRIPT_SCHEME_RE.search(CONTROL_RE.sub("", _decode(text))) or
                re.search(r"[\s/\"']on[a-z]+\s*=", text, re.I))


def sanitize(s, nested=False, max_rounds=10):
    for _ in range(max_rounds):
        new = sanitize_once(s, nested=nested)
        if new == s:
            return s
        s = new
    return s


def main():
    if len(sys.argv) < 2:
        sys.stderr.write("usage: %s file.html\n" % sys.argv[0])
        return 1
    path = sys.argv[1]
    with open(path, "rb") as f:
        data = f.read()
    text = data.decode("utf-8", errors="surrogateescape")
    result = sanitize(text)
    if result != text:
        with open(path, "wb") as f:
            f.write(result.encode("utf-8", errors="surrogateescape"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
