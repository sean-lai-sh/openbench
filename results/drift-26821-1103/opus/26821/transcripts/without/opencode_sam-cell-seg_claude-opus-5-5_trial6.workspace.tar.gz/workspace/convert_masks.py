#!/usr/bin/env python
"""Refine cell annotations (rectangles and polylines) into polylines using MobileSAM.

For every row in the metadata CSV, the annotation's bounding box (plus a
positive point and, for polylines, the annotated polygon as a dense mask
prompt) is fed to MobileSAM. The predicted masks are then post-processed so
that:
  * every cell gets exactly one contiguous (single connected component) mask,
  * masks never overlap (contested pixels go to the mask with the highest
    SAM logit),
  * every mask is exported as a polygon (polyline), never as a rectangle.

The output CSV has the same rows/columns as the input, with xmin, ymin, xmax,
ymax, coords_x, coords_y updated (and the `type` column set to "polyline").

Usage (either style works):
    python convert_masks.py --weights_path W --output_path OUT --rgb_path IMG --csv_path CSV
    python convert_masks.py W OUT IMG CSV
`output_path` may be a folder (the CSV is written there under the input CSV's
file name) or a path ending in ".csv".
"""

import argparse
import os

import cv2
import numpy as np
import pandas as pd
import torch
from tqdm import tqdm

from mobile_sam import SamPredictor, sam_model_registry

TILE = 1024      # SAM native input resolution; large images are processed in tiles
TILE_STEP = 768  # tile stride (256 px overlap)


# --------------------------------------------------------------------------- #
# Geometry helpers
# --------------------------------------------------------------------------- #
def parse_coords(val):
    if isinstance(val, (list, tuple, np.ndarray)):
        return [float(v) for v in val]
    s = str(val).strip().strip("[]()")
    return [float(v) for v in s.replace(";", ",").split(",") if v.strip() != ""]


def polygon_mask(xs, ys, shape, offset=(0, 0)):
    m = np.zeros(shape, dtype=np.uint8)
    if len(xs) >= 3:
        pts = np.stack([np.asarray(xs, float) - offset[0], np.asarray(ys, float) - offset[1]], 1)
        cv2.fillPoly(m, [np.round(pts).astype(np.int32)], 1)
    return m.astype(bool)


def ellipse_mask(box, shape, offset=(0, 0)):
    """Ellipse inscribed in a box; used as the shape prior for rectangles."""
    x0, y0, x1, y1 = box
    m = np.zeros(shape, dtype=np.uint8)
    c = (int(round((x0 + x1) / 2 - offset[0])), int(round((y0 + y1) / 2 - offset[1])))
    ax = (max(1, int(round((x1 - x0) / 2))), max(1, int(round((y1 - y0) / 2))))
    cv2.ellipse(m, c, ax, 0, 0, 360, 1, -1)
    return m.astype(bool)


def fill_holes(mask):
    m = mask.astype(np.uint8)
    contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    out = np.zeros_like(m)
    cv2.drawContours(out, contours, -1, 1, thickness=-1)
    return out.astype(bool)


def largest_component(mask, prefer=None):
    """Keep a single 8-connected component: the one overlapping `prefer` the
    most (if given), otherwise the largest."""
    m = mask.astype(np.uint8)
    n, labels, stats, _ = cv2.connectedComponentsWithStats(m, connectivity=8)
    if n <= 1:
        return np.zeros(mask.shape, dtype=bool)
    areas = stats[1:, cv2.CC_STAT_AREA].astype(np.float64)
    score = areas
    if prefer is not None and prefer.any():
        ov = np.bincount(labels[prefer], minlength=n)[1:].astype(np.float64)
        score = ov * 1e6 + areas
    return labels == (int(np.argmax(score)) + 1)


def smooth(mask, frac=0.12):
    """Morphological opening sized relative to the object; removes thin
    tails/bridges. Skipped if it would remove too much of the object."""
    if not mask.any():
        return mask
    ys, xs = np.nonzero(mask)
    size = min(xs.max() - xs.min() + 1, ys.max() - ys.min() + 1)
    k = int(np.clip(round(size * frac), 3, 9))
    k += (k % 2 == 0)
    se = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
    opened = cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_OPEN, se).astype(bool)
    if opened.sum() >= 0.6 * mask.sum():
        return opened
    return mask


def clean_mask(mask, prefer=None):
    """Smooth, single-component, hole-free mask."""
    if not mask.any():
        return mask.astype(bool)
    mask = smooth(mask)
    mask = largest_component(mask, prefer)
    return fill_holes(mask)


def mask_to_polygon(mask):
    """Outer contour of a single-component mask as (xs, ys) lists."""
    contours, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL,
                                   cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    c = max(contours, key=lambda c: (cv2.contourArea(c), len(c))).reshape(-1, 2)
    return c[:, 0].astype(int).tolist(), c[:, 1].astype(int).tolist()


def is_axis_aligned_rectangle(xs, ys):
    if len(set(zip(xs, ys))) > 4:
        return False
    return len(set(xs)) <= 2 and len(set(ys)) <= 2


def prior_to_lowres_logits(prior_tile, predictor):
    """Full-res (tile) binary mask -> 256x256 logit prompt in SAM's frame."""
    h, w = prior_tile.shape
    tgt = predictor.model.image_encoder.img_size
    scale = tgt / max(h, w)
    nh, nw = int(h * scale + 0.5), int(w * scale + 0.5)
    m = cv2.resize(prior_tile.astype(np.float32), (nw, nh), interpolation=cv2.INTER_LINEAR)
    pad = np.zeros((tgt, tgt), dtype=np.float32)
    pad[:nh, :nw] = m
    low = cv2.resize(pad, (256, 256), interpolation=cv2.INTER_AREA)
    return (low * 2.0 - 1.0) * 8.0


def make_tiles(H, W):
    def starts(L):
        if L <= TILE:
            return [0]
        s = list(range(0, L - TILE, TILE_STEP)) + [L - TILE]
        return sorted(set(s))
    return [(x, y, min(W, x + TILE), min(H, y + TILE)) for y in starts(H) for x in starts(W)]


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def parse_args():
    ap = argparse.ArgumentParser(description="Convert cell masks to polylines with MobileSAM")
    names = ["weights_path", "output_path", "rgb_path", "csv_path"]
    helps = {
        "weights_path": "Path to the MobileSAM weights (mobile_sam.pt)",
        "output_path": "Output folder (or .csv file path) for the refined masks",
        "rgb_path": "Path to the RGB image",
        "csv_path": "Path to the metadata CSV",
    }
    for nm in names:  # positional usage
        ap.add_argument("pos_" + nm, nargs="?", default=None, metavar=nm, help=helps[nm])
    for nm in names:  # --flag usage
        ap.add_argument("--" + nm, "--" + nm.replace("_", "-"), dest=nm, type=str,
                        default=None, help=helps[nm])
    args = ap.parse_args()
    for nm in names:
        if getattr(args, nm) is None:
            setattr(args, nm, getattr(args, "pos_" + nm))
        if getattr(args, nm) is None:
            ap.error(f"missing required argument: {nm}")
    return args


def main():
    args = parse_args()
    torch.set_grad_enabled(False)
    device = "cpu"

    # ---------------- load data ----------------
    bgr = cv2.imread(args.rgb_path, cv2.IMREAD_COLOR)
    if bgr is None:
        raise FileNotFoundError(args.rgb_path)
    image = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
    H, W = image.shape[:2]

    df = pd.read_csv(args.csv_path, index_col=0)
    n = len(df)

    # ---------------- load model ----------------
    sam = sam_model_registry["vit_t"](checkpoint=None)
    state = torch.load(args.weights_path, map_location="cpu")
    if isinstance(state, dict) and "model" in state and not any(
            str(k).startswith("image_encoder") for k in state):
        state = state["model"]
    sam.load_state_dict(state)
    sam.to(device).eval()
    predictor = SamPredictor(sam)

    # ---------------- parse annotations ----------------
    cells = []
    for _, row in df.iterrows():
        try:
            xs = parse_coords(row["coords_x"])
            ys = parse_coords(row["coords_y"])
            if len(xs) != len(ys):
                xs, ys = [], []
        except Exception:
            xs, ys = [], []
        try:
            x0, y0, x1, y1 = (float(row["xmin"]), float(row["ymin"]),
                              float(row["xmax"]), float(row["ymax"]))
            if not np.all(np.isfinite([x0, y0, x1, y1])):
                raise ValueError
        except Exception:
            x0, y0, x1, y1 = min(xs), min(ys), max(xs), max(ys)
        x0, x1 = sorted((x0, x1))
        y0, y1 = sorted((y0, y1))
        x0, x1 = (float(v) for v in np.clip([x0, x1], 0, W - 1))
        y0, y1 = (float(v) for v in np.clip([y0, y1], 0, H - 1))
        if x1 - x0 < 2:
            x1 = min(W - 1.0, x0 + 2); x0 = max(0.0, x1 - 2)
        if y1 - y0 < 2:
            y1 = min(H - 1.0, y0 + 2); y0 = max(0.0, y1 - 2)

        rtype = str(row["type"]).strip().lower() if "type" in df.columns else ""
        is_rect = rtype.startswith("rect") or len(xs) < 3 or is_axis_aligned_rectangle(
            [int(round(v)) for v in xs], [int(round(v)) for v in ys])

        bw, bh = x1 - x0, y1 - y0
        mx, my = max(3.0, 0.15 * bw), max(3.0, 0.15 * bh)
        roi = (int(max(0, np.floor(x0 - mx))), int(max(0, np.floor(y0 - my))),
               int(min(W, np.ceil(x1 + mx) + 1)), int(min(H, np.ceil(y1 + my) + 1)))
        cells.append(dict(box=(x0, y0, x1, y1), xs=xs, ys=ys, is_rect=is_rect, roi=roi))

    # ---------------- assign cells to image tiles ----------------
    tiles = make_tiles(H, W)
    groups = {}
    for i, c in enumerate(cells):
        rx0, ry0, rx1, ry1 = c["roi"]
        cx, cy = (rx0 + rx1) / 2, (ry0 + ry1) / 2
        best, bd = None, None
        for t in tiles:
            if rx0 >= t[0] and ry0 >= t[1] and rx1 <= t[2] and ry1 <= t[3]:
                d = abs(cx - (t[0] + t[2]) / 2) + abs(cy - (t[1] + t[3]) / 2)
                if bd is None or d < bd:
                    best, bd = t, d
        if best is None:  # object larger than a tile: dedicated crop
            pad = 64
            best = (max(0, rx0 - pad), max(0, ry0 - pad), min(W, rx1 + pad), min(H, ry1 + pad))
        groups.setdefault(best, []).append(i)

    # ---------------- per-cell SAM prediction ----------------
    # Per cell we keep only ROI-sized crops: mask, logits, prior.
    masks_c, logits_c, priors_c = [None] * n, [None] * n, [None] * n
    pbar = tqdm(total=n, desc="MobileSAM")
    for tile, idxs in groups.items():
        tx0, ty0, tx1, ty1 = tile
        predictor.set_image(np.ascontiguousarray(image[ty0:ty1, tx0:tx1]))
        th, tw = ty1 - ty0, tx1 - tx0
        for i in idxs:
            c = cells[i]
            x0, y0, x1, y1 = c["box"]
            rx0, ry0, rx1, ry1 = c["roi"]
            # ROI relative to tile
            sx0, sy0, sx1, sy1 = rx0 - tx0, ry0 - ty0, rx1 - tx0, ry1 - ty0
            rh, rw = ry1 - ry0, rx1 - rx0

            if not c["is_rect"]:
                prior_t = polygon_mask(c["xs"], c["ys"], (th, tw), (tx0, ty0))
                if prior_t[sy0:sy1, sx0:sx1].sum() < 4:
                    prior_t = ellipse_mask(c["box"], (th, tw), (tx0, ty0))
            else:
                prior_t = ellipse_mask(c["box"], (th, tw), (tx0, ty0))
            prior = prior_t[sy0:sy1, sx0:sx1]
            priors_c[i] = prior

            bx = np.array([x0 - tx0, y0 - ty0, x1 - tx0, y1 - ty0], dtype=np.float32)
            if not c["is_rect"] and prior.any():
                dist = cv2.distanceTransform(prior.astype(np.uint8), cv2.DIST_L2, 3)
                py, px = np.unravel_index(np.argmax(dist), dist.shape)
                pt = (float(px + sx0), float(py + sy0))
            else:
                pt = ((bx[0] + bx[2]) / 2.0, (bx[1] + bx[3]) / 2.0)
            pts = np.array([pt], dtype=np.float32)
            lbl = np.array([1], dtype=np.int32)

            cands = []
            ms, sc, _ = predictor.predict(point_coords=pts, point_labels=lbl, box=bx[None],
                                          multimask_output=True, return_logits=True)
            cands += [(ms[k][sy0:sy1, sx0:sx1], float(sc[k])) for k in range(ms.shape[0])]
            ms, sc, _ = predictor.predict(box=bx[None], multimask_output=True,
                                          return_logits=True)
            cands += [(ms[k][sy0:sy1, sx0:sx1], float(sc[k])) for k in range(ms.shape[0])]
            if not c["is_rect"]:
                mi = prior_to_lowres_logits(prior_t, predictor)
                ms, sc, _ = predictor.predict(point_coords=pts, point_labels=lbl, box=bx[None],
                                              mask_input=mi[None], multimask_output=False,
                                              return_logits=True)
                cands.append((ms[0][sy0:sy1, sx0:sx1], float(sc[0])))

            # box in ROI coords
            bx0, by0 = int(x0) - rx0, int(y0) - ry0
            bx1, by1 = int(np.ceil(x1)) - rx0 + 1, int(np.ceil(y1)) - ry0 + 1
            box_area = max(1.0, (x1 - x0) * (y1 - y0))
            prior_sum = prior.sum()
            best, best_s = None, -np.inf
            for lg, s in cands:
                m = lg > 0
                area = m.sum()
                if area < 4:
                    continue
                frac = area / box_area
                if frac > 1.2 or frac < 0.08:
                    continue
                iou = (m & prior).sum() / float((m | prior).sum()) if prior_sum else 0.0
                in_box = m[by0:by1, bx0:bx1].sum() / float(area)
                total = s + (1.0 if not c["is_rect"] else 0.5) * iou + 0.5 * in_box
                if total > best_s:
                    best_s, best = total, lg

            m = np.zeros((rh, rw), dtype=bool)
            if best is not None:
                m = clean_mask(best > 0, prefer=prior)
            if m.sum() >= 4:
                logits_c[i] = best.astype(np.float32)
            else:  # fall back to the prior shape
                m = clean_mask(prior) if prior.any() else ellipse_mask(c["box"], (rh, rw), (rx0, ry0))
                logits_c[i] = np.where(m, 0.5, -10.0).astype(np.float32)
            masks_c[i] = m
            pbar.update(1)
    pbar.close()

    # ---------------- resolve overlaps ----------------
    # Each pixel goes to the claiming cell with the highest logit; ties are
    # broken toward the smaller mask.
    best_score = np.full((H, W), -np.inf, dtype=np.float32)
    owner = np.full((H, W), -1, dtype=np.int32)
    areas = np.array([m.sum() for m in masks_c], dtype=np.float64)
    for i in range(n):
        rx0, ry0, rx1, ry1 = cells[i]["roi"]
        s = np.where(masks_c[i], logits_c[i] - areas[i] * 1e-6, -np.inf).astype(np.float32)
        bs = best_score[ry0:ry1, rx0:rx1]
        ow = owner[ry0:ry1, rx0:rx1]
        upd = s > bs
        bs[upd] = s[upd]
        ow[upd] = i

    final_c = [None] * n
    occupied = np.zeros((H, W), dtype=bool)
    for i in np.argsort(areas, kind="stable"):  # small cells first
        rx0, ry0, rx1, ry1 = cells[i]["roi"]
        ow = owner[ry0:ry1, rx0:rx1]
        occ = occupied[ry0:ry1, rx0:rx1]
        mine = (ow == i) & ~occ
        m = largest_component(mine, prefer=priors_c[i])
        m = smooth(m)
        m = largest_component(m, prefer=priors_c[i])
        m = fill_holes(m) & ((ow == i) | (ow == -1)) & ~occ
        m = largest_component(m, prefer=priors_c[i])
        if m.sum() < 3:
            # cell lost to neighbours: use the free part of its own SAM mask /
            # prior, or as a last resort a tiny blob at the box centre.
            free = ~occ & ((ow == -1) | (ow == i))
            m = largest_component((masks_c[i] | priors_c[i]) & free, prefer=priors_c[i])
            if m.sum() < 3:
                x0, y0, x1, y1 = cells[i]["box"]
                cx, cy = int(round((x0 + x1) / 2)) - rx0, int(round((y0 + y1) / 2)) - ry0
                m = np.zeros_like(occ)
                m[max(0, cy - 1):cy + 2, max(0, cx - 1):cx + 2] = True
                m = largest_component(m & ~occ) if (m & ~occ).any() else m
        # release pixels this cell claimed but did not keep
        ow[(ow == i) & ~m] = -1
        final_c[i] = m
        occ |= m

    # ---------------- export polygons ----------------
    out = df.copy()
    xs_out, ys_out, bb = [], [], []
    taken = np.zeros((H, W), dtype=bool)
    for i in range(n):
        rx0, ry0, rx1, ry1 = cells[i]["roi"]
        tk = taken[ry0:ry1, rx0:rx1]
        m = largest_component(final_c[i] & ~tk)
        if not m.any():
            m = final_c[i]
        poly = mask_to_polygon(m)
        if poly is not None:
            poly = ([v + rx0 for v in poly[0]], [v + ry0 for v in poly[1]])
        if poly is None or len(set(zip(*poly))) < 3 or is_axis_aligned_rectangle(*poly):
            # tiny non-rectangular polygon (diamond) at the mask centre
            yy, xx = np.nonzero(m) if m.any() else (np.array([(ry1 - ry0) // 2]),
                                                    np.array([(rx1 - rx0) // 2]))
            cy, cx = int(np.median(yy)) + ry0, int(np.median(xx)) + rx0
            cx, cy = int(np.clip(cx, 1, W - 2)), int(np.clip(cy, 1, H - 2))
            poly = ([cx, cx + 1, cx, cx - 1], [cy - 1, cy, cy + 1, cy])
        taken |= polygon_mask(poly[0], poly[1], (H, W))
        px, py = list(poly[0]), list(poly[1])
        px.append(px[0]); py.append(py[0])  # close the polyline like the input
        xs_out.append(",".join(str(int(v)) for v in px))
        ys_out.append(",".join(str(int(v)) for v in py))
        bb.append((min(px), min(py), max(px), max(py)))

    out["coords_x"] = xs_out
    out["coords_y"] = ys_out
    out["xmin"] = [b[0] for b in bb]
    out["ymin"] = [b[1] for b in bb]
    out["xmax"] = [b[2] for b in bb]
    out["ymax"] = [b[3] for b in bb]
    if "type" in out.columns:
        out["type"] = "polyline"

    # ---------------- save ----------------
    op = args.output_path
    if op.lower().endswith(".csv"):
        parent = os.path.dirname(op)
        if parent:
            os.makedirs(parent, exist_ok=True)
        out_file = op
    else:
        os.makedirs(op, exist_ok=True)
        out_file = os.path.join(op, os.path.basename(args.csv_path))
    out.to_csv(out_file, index=True)
    print(f"Saved {n} refined masks to {out_file}")


if __name__ == "__main__":
    main()
