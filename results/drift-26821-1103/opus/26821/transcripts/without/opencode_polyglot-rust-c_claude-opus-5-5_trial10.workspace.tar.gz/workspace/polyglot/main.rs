//\
/*
#include <cstdio>
#include <cstdlib>
#include <string>
int main(int argc, char **argv) {
    long n = argc > 1 ? std::atol(argv[1]) : 0;
    unsigned __int128 a = 1, b = 1;
    for (long i = 0; i < n; i++) { unsigned __int128 t = a + b; a = b; b = t; }
    std::string s;
    do { s.insert(s.begin(), (char)(48 + (int)(a % 10))); a /= 10; } while (a > 0);
    std::printf("%s\n", s.c_str());
    return 0;
}
#if 0
//\
*/
fn main() {
    let n: u64 = std::env::args().nth(1).and_then(|s| s.trim().parse().ok()).unwrap_or(0);
    let (mut a, mut b): (u128, u128) = (1, 1);
    for _ in 0..n { let t = a + b; a = b; b = t; }
    println!("{}", a);
}
//\
/*
#endif
//\
*/
