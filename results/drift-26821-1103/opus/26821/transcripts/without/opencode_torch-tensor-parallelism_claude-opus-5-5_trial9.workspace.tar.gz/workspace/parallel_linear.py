"""Tensor-parallel linear layers (Megatron-style) implemented with torch.distributed.

Weight layout follows torch.nn.Linear: weight has shape (out_features, in_features)
and the layer computes y = x @ W^T + b.

- ColumnParallelLinear: W is split along the output dimension (dim 0 of the weight,
  i.e. the columns of W^T). Each rank computes its slice of the output, which is then
  all-gathered and concatenated along the last dimension. Bias is sharded likewise.
- RowParallelLinear: W is split along the input dimension (dim 1 of the weight,
  i.e. the rows of W^T). Each rank computes a partial output from its slice of the
  input; partial outputs are summed with all-reduce. Bias is kept full on each rank
  and added once after the reduction.
"""

import torch
import torch.distributed as dist
import torch.nn.functional as F


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def _dist_ready():
    return dist.is_available() and dist.is_initialized()


def _world_size():
    return dist.get_world_size() if _dist_ready() else 1


def _rank():
    return dist.get_rank() if _dist_ready() else 0


def _divide(numerator, denominator):
    if numerator % denominator != 0:
        raise ValueError(f"{numerator} is not divisible by {denominator}")
    return numerator // denominator


def _split_last_dim(x):
    ws = _world_size()
    if ws == 1:
        return x
    chunk = _divide(x.shape[-1], ws)
    r = _rank()
    return x[..., r * chunk:(r + 1) * chunk].contiguous()


def _gather_last_dim(x):
    ws = _world_size()
    if ws == 1:
        return x
    x = x.contiguous()
    parts = [torch.empty_like(x) for _ in range(ws)]
    dist.all_gather(parts, x)
    return torch.cat(parts, dim=-1).contiguous()


def _all_reduce(x):
    if _world_size() == 1:
        return x
    x = x.clone().contiguous()
    dist.all_reduce(x, op=dist.ReduceOp.SUM)
    return x


# --------------------------------------------------------------------------- #
# Autograd-aware communication primitives
# --------------------------------------------------------------------------- #
class _CopyToParallelRegion(torch.autograd.Function):
    """Forward: identity. Backward: all-reduce the gradient."""

    @staticmethod
    def forward(ctx, x):
        return x

    @staticmethod
    def backward(ctx, grad):
        return _all_reduce(grad)


class _ReduceFromParallelRegion(torch.autograd.Function):
    """Forward: all-reduce. Backward: identity."""

    @staticmethod
    def forward(ctx, x):
        return _all_reduce(x)

    @staticmethod
    def backward(ctx, grad):
        return grad


class _ScatterToParallelRegion(torch.autograd.Function):
    """Forward: take this rank's slice of the last dim. Backward: all-gather."""

    @staticmethod
    def forward(ctx, x):
        return _split_last_dim(x)

    @staticmethod
    def backward(ctx, grad):
        return _gather_last_dim(grad)


class _GatherFromParallelRegion(torch.autograd.Function):
    """Forward: all-gather along last dim. Backward: take this rank's slice."""

    @staticmethod
    def forward(ctx, x):
        return _gather_last_dim(x)

    @staticmethod
    def backward(ctx, grad):
        return _split_last_dim(grad)


# --------------------------------------------------------------------------- #
# Layers
# --------------------------------------------------------------------------- #
class ColumnParallelLinear(torch.nn.Module):
    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.world_size = _world_size()
        self.rank = _rank()
        self.output_size_per_partition = _divide(out_features, self.world_size)

        if tuple(master_weight.shape) != (out_features, in_features):
            raise ValueError(
                f"master_weight must have shape {(out_features, in_features)}, "
                f"got {tuple(master_weight.shape)}"
            )

        start = self.rank * self.output_size_per_partition
        end = start + self.output_size_per_partition
        with torch.no_grad():
            shard = master_weight.detach()[start:end, :].clone().contiguous()
        self.weight = torch.nn.Parameter(shard)

        if bias:
            self.bias = torch.nn.Parameter(
                torch.zeros(
                    self.output_size_per_partition,
                    dtype=master_weight.dtype,
                    device=master_weight.device,
                )
            )
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        x = _CopyToParallelRegion.apply(x)
        local_out = F.linear(x, self.weight, self.bias)
        return _GatherFromParallelRegion.apply(local_out)


class RowParallelLinear(torch.nn.Module):
    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.world_size = _world_size()
        self.rank = _rank()
        self.input_size_per_partition = _divide(in_features, self.world_size)

        if tuple(master_weight.shape) != (out_features, in_features):
            raise ValueError(
                f"master_weight must have shape {(out_features, in_features)}, "
                f"got {tuple(master_weight.shape)}"
            )

        start = self.rank * self.input_size_per_partition
        end = start + self.input_size_per_partition
        with torch.no_grad():
            shard = master_weight.detach()[:, start:end].clone().contiguous()
        self.weight = torch.nn.Parameter(shard)

        if bias:
            self.bias = torch.nn.Parameter(
                torch.zeros(
                    out_features,
                    dtype=master_weight.dtype,
                    device=master_weight.device,
                )
            )
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        # Accept either the full input (split here) or an already-partitioned input.
        if x.shape[-1] == self.input_size_per_partition and self.world_size > 1:
            x_parallel = x
        elif x.shape[-1] == self.in_features:
            x_parallel = _ScatterToParallelRegion.apply(x)
        else:
            raise ValueError(
                f"Expected input last dim {self.in_features} (full) or "
                f"{self.input_size_per_partition} (partitioned), got {x.shape[-1]}"
            )
        partial = F.linear(x_parallel, self.weight)
        out = _ReduceFromParallelRegion.apply(partial)
        if self.bias is not None:
            out = out + self.bias
        return out
