import json
import itertools

# Internal line format: <marker><64 board chars><4 castle chars><1 ep char>
# board: row 0 = rank 8, '.' = empty; castle: K Q k q or '_'; ep: file letter or '-'
FILES = "abcdefgh"
CK, CQ, Ck, Cq, EP = 64, 65, 66, 67, 68
NPOS = 69

rules = []


def sq(r, c):
    return r * 8 + c


def onb(r, c):
    return 0 <= r < 8 and 0 <= c < 8


def move_rule(cond, changes, marker="N"):
    cons = dict(cond)
    for p in changes:
        cons.setdefault(p, ".")
    pat = "(?m)^S"
    gidx = {}
    parts = []  # list of ('free', g) or ('sq', p, g)
    g = 0
    free = 0
    for p in range(NPOS):
        if p in cons:
            if free:
                g += 1
                pat += "(.{%d})" % free
                parts.append(("free", g))
                free = 0
            g += 1
            pat += "(" + cons[p] + ")"
            gidx[p] = g
            parts.append(("sq", p, g))
        else:
            free += 1
    if free:
        g += 1
        pat += "(.{%d})" % free
        parts.append(("free", g))
    repl = "\\g<0>\n" + marker
    for part in parts:
        if part[0] == "free":
            repl += "\\g<%d>" % part[1]
        else:
            p, gg = part[1], part[2]
            if p in changes:
                v = changes[p]
                if isinstance(v, tuple):
                    repl += "\\g<%d>" % gidx[v[1]]
                else:
                    repl += v
            else:
                repl += "\\g<%d>" % gg
    rules.append([pat, repl])


def castle_updates(frm, to):
    ch = {}
    if frm == sq(7, 4):
        ch[CK] = "_"
        ch[CQ] = "_"
    if frm == sq(7, 7):
        ch[CK] = "_"
    if frm == sq(7, 0):
        ch[CQ] = "_"
    if to == sq(0, 7):
        ch[Ck] = "_"
    if to == sq(0, 0):
        ch[Cq] = "_"
    return ch


TARGET = "[.a-z]"


def simple_move(frm, to, piececls, extra_cond=None, newpiece=None, ep="-"):
    cond = {frm: piececls, to: TARGET}
    if extra_cond:
        cond.update(extra_cond)
    changes = {frm: ".", to: newpiece if newpiece else ("copy", frm), EP: ep}
    changes.update(castle_updates(frm, to))
    move_rule(cond, changes)


# ---------------- Input parsing ----------------
rules.append([r"^(\S+) w (\S+) (\S+).*$", r"\1 \2 \3"])
rules.append([r" ([a-h])[36]$", r" \1"])
for n in range(16):
    s = "".join(ch for i, ch in enumerate("KQkq") if n >> i & 1)
    canon = "".join(ch if n >> i & 1 else "_" for i, ch in enumerate("KQkq"))
    if not s:
        s = "-"
    rules.append([" " + s + r" (\S)$", canon + r"\1"])
for d in range(1, 9):
    rules.append([str(d), "." * d])
rules.append(["/", ""])
rules.append(["^", "S"])

# ---------------- Move generation ----------------
KN = [(1, 2), (2, 1), (-1, 2), (-2, 1), (1, -2), (2, -1), (-1, -2), (-2, -1)]
KG = [(dr, dc) for dr in (-1, 0, 1) for dc in (-1, 0, 1) if (dr, dc) != (0, 0)]
ORTH = [(1, 0), (-1, 0), (0, 1), (0, -1)]
DIAG = [(1, 1), (1, -1), (-1, 1), (-1, -1)]

for r in range(8):
    for c in range(8):
        f = sq(r, c)
        # knights
        for dr, dc in KN:
            if onb(r + dr, c + dc):
                simple_move(f, sq(r + dr, c + dc), "N")
        # king
        for dr, dc in KG:
            if onb(r + dr, c + dc):
                simple_move(f, sq(r + dr, c + dc), "K")
        # sliders
        for dirs, cls in ((ORTH, "[RQ]"), (DIAG, "[BQ]")):
            for dr, dc in dirs:
                path = []
                rr, cc = r + dr, c + dc
                while onb(rr, cc):
                    extra = {p: r"\." for p in path}
                    simple_move(f, sq(rr, cc), cls, extra)
                    path.append(sq(rr, cc))
                    rr += dr
                    cc += dc
        # pawns
        if 1 <= r <= 6:
            promo = "Q" if r == 1 else None
            t = sq(r - 1, c)
            move_rule({f: "P", t: r"\."},
                      {f: ".", t: promo or "P", EP: "-", **castle_updates(f, t)})
            if r == 6:
                t2 = sq(r - 2, c)
                move_rule({f: "P", t: r"\.", t2: r"\."},
                          {f: ".", t2: "P", EP: FILES[c]})
            for dc in (-1, 1):
                if onb(r - 1, c + dc):
                    t = sq(r - 1, c + dc)
                    move_rule({f: "P", t: "[a-z]"},
                              {f: ".", t: promo or "P", EP: "-", **castle_updates(f, t)})
            if r == 3:
                for dc in (-1, 1):
                    if onb(r, c + dc):
                        t = sq(r - 1, c + dc)
                        cap = sq(r, c + dc)
                        move_rule({f: "P", t: r"\.", cap: "p", EP: FILES[c + dc]},
                                  {f: ".", t: "P", cap: ".", EP: "-"})

# castling
move_rule({sq(7, 4): "K", sq(7, 5): r"\.", sq(7, 6): r"\.", sq(7, 7): "R", CK: "K"},
          {sq(7, 5): "K", sq(7, 6): "K", CK: "_", CQ: "_", EP: "-"}, marker="C")
move_rule({sq(7, 4): "K", sq(7, 3): r"\.", sq(7, 2): r"\.", sq(7, 1): r"\.", sq(7, 0): "R", CQ: "Q"},
          {sq(7, 3): "K", sq(7, 2): "K", CK: "_", CQ: "_", EP: "-"}, marker="D")


# ---------------- Legality check ----------------
def seg(cons):
    out = ""
    prev = 0
    for p in sorted(cons):
        gap = p - prev
        if gap:
            out += ".{%d}" % gap
        out += cons[p]
        prev = p + 1
    return out


for r in range(8):
    for c in range(8):
        k = sq(r, c)
        alts = []
        for dr, dc in KN:
            if onb(r + dr, c + dc):
                alts.append(seg({sq(r + dr, c + dc): "n"}))
        for dr, dc in KG:
            if onb(r + dr, c + dc):
                alts.append(seg({sq(r + dr, c + dc): "k"}))
        for dc in (-1, 1):
            if onb(r - 1, c + dc):
                alts.append(seg({sq(r - 1, c + dc): "p"}))
        for dirs, cls in ((ORTH, "[rq]"), (DIAG, "[bq]")):
            for dr, dc in dirs:
                path = []
                rr, cc = r + dr, c + dc
                while onb(rr, cc):
                    cons = {p: r"\." for p in path}
                    cons[sq(rr, cc)] = cls
                    alts.append(seg(cons))
                    path.append(sq(rr, cc))
                    rr += dr
                    cc += dc
        rules.append(["(?m)^[NCD](?=%s)(?=%s)" % (seg({k: "K"}), "|".join(alts)), "X"])

rules.append([r"(?m)^[XS].*\n?", ""])
rules.append([r"\n+\Z", ""])

# fix up castling lines
rules.append([r"(?m)^C(.{60})KKKR", r"N\1.RK."])
rules.append([r"(?m)^D(.{56})R.KKK", r"N\1..KR."])

# ---------------- Output formatting ----------------
rules.append([r"(?m)^N" + "(.{8})" * 8 + r"(.{4})(.)$",
              "/".join("\\g<%d>" % i for i in range(1, 9)) + r" b \g<9> \g<10> 0 0"])
for d in range(8, 0, -1):
    rules.append([r"\." * d, str(d)])
rules.append(["_", ""])
rules.append([" b  ", " b - "])
rules.append([r"(?m) ([a-h]) 0 0$", r" \g<1>3 0 0"])

json.dump(rules, open("re.json", "w"))
print(len(rules), "rules")
