import json, re, random, chess, sys
rules = json.load(open("re.json"))
def run(fen):
    for p, r in rules: fen = re.sub(p, r, fen)
    return [" ".join(x.split(" ")[:-2]) for x in fen.split("\n")]
def ref(fen):
    b = chess.Board(fen); s=set()
    for m in b.legal_moves:
        if m.promotion and m.promotion != chess.QUEEN: continue
        c=b.copy(); c.push(m); s.add(" ".join(c.fen().split(" ")[:-2]))
    return s
def check(fen):
    ours = run(fen); r = ref(fen)
    ok = all(x in r or x.rpartition(" ")[0]+" -" in r for x in ours) and len(ours)==len(r)
    if not ok and r:
        print("FAIL", fen); print(sorted(ours)); print(sorted(r)); sys.exit(1)
ex = run("rnb1k1nr/p2p1ppp/3B4/1p1NPN1P/6P1/3P1Q2/P1P5/q4Kb1 w kq - 0 1"); print(ex)
random.seed(int(sys.argv[1]) if len(sys.argv)>1 else 0)
n=0
for g in range(int(sys.argv[2]) if len(sys.argv)>2 else 100):
    b = chess.Board()
    while not b.is_game_over():
        if b.turn == chess.WHITE: check(b.fen()); n+=1
        moves=list(b.legal_moves)
        sp=[m for m in moves if b.is_castling(m) or b.is_en_passant(m) or m.promotion]
        b.push(random.choice(sp) if sp and random.random()<0.7 else random.choice(moves))
print("ok", n)
