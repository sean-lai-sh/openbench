#!/usr/bin/env python
"""Refine cell annotations (rectangles + polylines) into polyline masks with MobileSAM.

Every annotation in the metadata CSV is used as a box prompt for MobileSAM.  The
predicted masks are then post-processed so that:
  * every cell is represented by exactly one contiguous polygon (polyline),
  * no two cells overlap,
  * no output mask is a plain rectangle.

The output CSV mirrors the input CSV; only xmin, ymin, xmax, ymax, coords_x and
coords_y are updated.

Usage:
    python convert_masks.py --weights_path mobile_sam.pt --output_path out/ \
        --rgb_path image.png --csv_path metadata.csv
(positional arguments in the same order are also accepted.)
"""

import argparse
import os

import cv2
import numpy as np
import pandas as pd
import torch
from tqdm import tqdm

from mobile_sam import SamPredictor, sam_model_registry

# Images larger than this (in either dimension) are processed in tiles so that
# small cells are seen by SAM at a higher effective resolution.
TILE_SIZE = 512
TILE_OVERLAP = 128
# Extra context (px) around a prompt box in which the SAM mask may extend.
BOX_MARGIN_FRAC = 0.15
BOX_MARGIN_MIN = 4


# --------------------------------------------------------------------------- #
# Argument parsing / IO
# --------------------------------------------------------------------------- #
def parse_args():
    p = argparse.ArgumentParser(description="Refine cell masks into polylines with MobileSAM.")
    names = ["weights_path", "output_path", "rgb_path", "csv_path"]
    helps = [
        "Path to the MobileSAM weights (mobile_sam.pt).",
        "Output folder (or .csv file path) where the refined masks are saved.",
        "Path to the RGB image.",
        "Path to the metadata CSV.",
    ]
    for n, h in zip(names, helps):
        p.add_argument(n, nargs="?", default=None, help=h)
        p.add_argument("--" + n, dest=n + "_opt", default=None, help=h)
    p.add_argument("--device", default=None, help="torch device (default: cuda if available, else cpu)")
    a = p.parse_args()
    for n in names:
        val = getattr(a, n + "_opt") or getattr(a, n)
        if val is None:
            p.error("argument %s is required" % n)
        setattr(a, n, val)
    return a


def parse_coords(v):
    if isinstance(v, (list, tuple, np.ndarray)):
        return [float(x) for x in v]
    s = str(v).strip().strip("[]()")
    return [float(x) for x in s.replace(";", ",").replace(" ", ",").split(",") if x.strip() != ""]


def resolve_output_file(output_path, csv_path):
    if output_path.lower().endswith(".csv"):
        d = os.path.dirname(output_path)
        if d:
            os.makedirs(d, exist_ok=True)
        return output_path
    os.makedirs(output_path, exist_ok=True)
    return os.path.join(output_path, os.path.basename(csv_path))


# --------------------------------------------------------------------------- #
# Geometry helpers
# --------------------------------------------------------------------------- #
def largest_component(mask):
    """Largest 4-connected component of a boolean mask."""
    if not mask.any():
        return mask
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask.astype(np.uint8), connectivity=4)
    if n <= 2:
        return lab == 1
    k = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return lab == k


def fill_holes(mask):
    """Fill background regions not connected to the image border."""
    m = mask.astype(np.uint8)
    h, w = m.shape
    pad = np.zeros((h + 2, w + 2), np.uint8)
    pad[1:-1, 1:-1] = m
    ff = pad.copy()
    cv2.floodFill(ff, np.zeros((h + 4, w + 4), np.uint8), (0, 0), 1)
    holes = ff[1:-1, 1:-1] == 0
    return mask | holes


def clean_mask(mask):
    """Light smoothing (opening) followed by largest-component selection."""
    if not mask.any():
        return mask
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    opened = cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_OPEN, k).astype(bool)
    if opened.sum() >= 0.5 * mask.sum():
        mask = opened
    return largest_component(mask)


def mask_to_polygon(mask):
    """Single external contour of a mask as an (N,2) int array (x, y)."""
    cnts, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cnts:
        return None
    c = max(cnts, key=cv2.contourArea)
    return c.reshape(-1, 2)


def remove_pinches(mask, max_iter=20):
    """Remove 1-px necks / diagonal pinches so the outer contour is a simple polygon."""
    for _ in range(max_iter):
        if not mask.any():
            return mask
        cnts, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        c = max(cnts, key=cv2.contourArea).reshape(-1, 2)
        _, inv, cnt = np.unique(c, axis=0, return_inverse=True, return_counts=True)
        dup = c[cnt[inv.ravel()] > 1]
        if len(dup) == 0 and len(cnts) == 1:
            return mask
        mask = mask.copy()
        mask[dup[:, 1], dup[:, 0]] = False
        mask = largest_component(mask)
    return mask


def polygon_to_mask(poly, shape):
    m = np.zeros(shape, np.uint8)
    cv2.fillPoly(m, [np.round(np.asarray(poly)).astype(np.int32).reshape(-1, 1, 2)], 1)
    return m.astype(bool)


def ellipse_mask(x0, y0, x1, y1, shape, scale=1.0):
    m = np.zeros(shape, np.uint8)
    cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    ax = max(1, int(round((x1 - x0) / 2.0 * scale)))
    ay = max(1, int(round((y1 - y0) / 2.0 * scale)))
    cv2.ellipse(m, (int(round(cx)), int(round(cy))), (ax, ay), 0, 0, 360, 1, -1)
    return m.astype(bool)


def is_rectangular(mask, poly):
    """True if the mask is (close to) an axis-aligned rectangle."""
    if poly is None:
        return True
    ys, xs = np.nonzero(mask)
    if len(xs) == 0:
        return True
    bbox_area = (xs.max() - xs.min() + 1) * (ys.max() - ys.min() + 1)
    return len(poly) <= 4 or mask.sum() / float(bbox_area) > 0.97


# --------------------------------------------------------------------------- #
# SAM inference
# --------------------------------------------------------------------------- #
def make_tiles(h, w):
    if h <= TILE_SIZE and w <= TILE_SIZE:
        return [(0, 0, w, h)]
    step = TILE_SIZE - TILE_OVERLAP

    def starts(n):
        if n <= TILE_SIZE:
            return [0]
        s = list(range(0, n - TILE_SIZE + 1, step))
        if s[-1] != n - TILE_SIZE:
            s.append(n - TILE_SIZE)
        return s

    return [(x, y, min(x + TILE_SIZE, w), min(y + TILE_SIZE, h)) for y in starts(h) for x in starts(w)]


def assign_tile(box, tiles):
    """Pick tile that contains the box with the largest margin (or best overlap)."""
    x0, y0, x1, y1 = box
    best, best_score = 0, -np.inf
    for i, (tx0, ty0, tx1, ty1) in enumerate(tiles):
        margin = min(x0 - tx0, y0 - ty0, tx1 - x1, ty1 - y1)
        if margin >= 0:
            score = 1e6 + margin
        else:
            ix = max(0, min(x1, tx1) - max(x0, tx0))
            iy = max(0, min(y1, ty1) - max(y0, ty0))
            score = ix * iy + margin * 1e-3
        if score > best_score:
            best, best_score = i, score
    return best


def run_sam(predictor, image, boxes, wins, orig_masks, is_rect):
    """Return per-cell SAM logits cropped to each cell's window."""
    h, w = image.shape[:2]
    thr = predictor.model.mask_threshold
    tiles = make_tiles(h, w)
    tile_of = [assign_tile(b, tiles) for b in boxes]
    logits = [None] * len(boxes)

    for t, (tx0, ty0, tx1, ty1) in enumerate(tqdm(tiles, desc="SAM tiles", disable=len(tiles) == 1)):
        idx = [i for i, ti in enumerate(tile_of) if ti == t]
        if not idx:
            continue
        predictor.set_image(np.ascontiguousarray(image[ty0:ty1, tx0:tx1]))
        th, tw = ty1 - ty0, tx1 - tx0
        for i in tqdm(idx, desc="Refining masks", leave=False):
            x0, y0, x1, y1 = boxes[i]
            box_local = np.array([x0 - tx0, y0 - ty0, x1 - tx0, y1 - ty0], dtype=np.float32)
            box_local[[0, 2]] = np.clip(box_local[[0, 2]], 0, tw - 1)
            box_local[[1, 3]] = np.clip(box_local[[1, 3]], 0, th - 1)
            with torch.no_grad():
                m, scores, _ = predictor.predict(box=box_local, multimask_output=True, return_logits=True)

            # Crop the (3, th, tw) logits to the cell window (window ∩ tile).
            wx0, wy0, wx1, wy1 = wins[i]
            cand = np.full((m.shape[0], wy1 - wy0, wx1 - wx0), -1e4, np.float32)
            ix0, iy0 = max(wx0, tx0), max(wy0, ty0)
            ix1, iy1 = min(wx1, tx1), min(wy1, ty1)
            if ix1 > ix0 and iy1 > iy0:
                cand[:, iy0 - wy0:iy1 - wy0, ix0 - wx0:ix1 - wx0] = m[:, iy0 - ty0:iy1 - ty0, ix0 - tx0:ix1 - tx0]

            box_area = max(1.0, float((x1 - x0) * (y1 - y0)))
            best_j, best_val = 0, -np.inf
            for j in range(cand.shape[0]):
                mj = cand[j] > thr
                area = mj.sum()
                if area == 0:
                    continue
                frac = area / box_area
                val = float(scores[j])
                if frac < 0.1 or frac > 1.3:  # implausibly tiny / leaking
                    val -= 1.0
                if not is_rect[i]:
                    inter = (mj & orig_masks[i]).sum()
                    union = (mj | orig_masks[i]).sum()
                    val += inter / max(1, union)
                else:
                    val -= 0.5 * max(0.0, frac - 0.95)  # avoid "box-filling" masks
                if val > best_val:
                    best_j, best_val = j, val
            logits[i] = cand[best_j]
    return logits


# --------------------------------------------------------------------------- #
# Post-processing: one contiguous, non-overlapping, non-rectangular polygon each
# --------------------------------------------------------------------------- #
def win_slice(win):
    x0, y0, x1, y1 = win
    return slice(y0, y1), slice(x0, x1)


def resolve(logits, thr, boxes, wins, orig_masks, shape):
    n = len(logits)
    h, w = shape

    # 1) Clean individual masks; fall back to the original annotation if SAM failed.
    masks = []
    for i in range(n):
        m = fill_holes(clean_mask(logits[i] > thr))
        x0, y0, x1, y1 = boxes[i]
        box_area = max(1, (x1 - x0) * (y1 - y0))
        if m.sum() < max(6, 0.05 * box_area):
            m = orig_masks[i].copy()
            logits[i] = np.where(m, np.maximum(logits[i], 0.5), logits[i])
        masks.append(m)
    areas = np.array([m.sum() for m in masks], np.float64)

    # 2) Pixel ownership: contested pixels go to the mask with highest logit
    #    (ties broken in favour of smaller masks).
    best = np.full((h, w), -np.inf, np.float32)
    owner = np.full((h, w), -1, np.int32)
    for i in range(n):
        sl = win_slice(wins[i])
        sc = np.where(masks[i], logits[i] - 1e-6 * areas[i], -np.inf).astype(np.float32)
        upd = sc > best[sl]
        best[sl][upd] = sc[upd]
        owner[sl][upd] = i
    del best

    # 3) Label map; each cell keeps only its largest contiguous owned region.
    label = np.full((h, w), -1, np.int32)
    order = np.argsort(areas, kind="stable")
    for i in order:
        sl = win_slice(wins[i])
        own = clean_mask((owner[sl] == i) & masks[i])
        label[sl][own] = i
    del owner

    # 4) Guarantee every cell has a mask.
    protected = np.zeros((h, w), np.uint8)
    for i in range(n):
        sl = win_slice(wins[i])
        if (label[sl] == i).sum() >= 9:
            continue
        label[sl][label[sl] == i] = -1
        wx0, wy0 = wins[i][0], wins[i][1]
        x0, y0, x1, y1 = boxes[i]
        lshape = label[sl].shape
        cand = np.zeros(lshape, bool)
        for scale in (0.6, 0.4, 0.25, 1.0):
            cand = ellipse_mask(x0 - wx0, y0 - wy0, x1 - wx0, y1 - wy0, lshape, scale) & (label[sl] == -1)
            cand = remove_pinches(clean_mask(cand))
            if cand.sum() >= 9:
                break
        if cand.sum() < 9:  # take a small disk inside the box from neighbours
            r = max(2, int(round(0.15 * min(x1 - x0, y1 - y0))))
            # place it as far as possible from other fallback disks / box edges
            free = np.zeros(lshape, np.uint8)
            free[y0 - wy0 + 1:y1 - wy0, x0 - wx0 + 1:x1 - wx0] = 1
            free &= ~protected[sl]
            if free.any():
                dist = cv2.distanceTransform(free, cv2.DIST_L2, 3)
                cy, cx = np.unravel_index(int(np.argmax(dist)), lshape)
                r = int(max(1, min(r, dist[cy, cx] - 1)))
            else:
                cx, cy = (x0 + x1) // 2 - wx0, (y0 + y1) // 2 - wy0
            cand = ellipse_mask(cx - r, cy - r, cx + r, cy + r, lshape, 1.0)
            protected[sl] |= cand.astype(np.uint8)
            stolen = np.unique(label[sl][cand])
            label[sl][cand] = i
            for j in stolen[stolen >= 0]:  # keep neighbours contiguous
                slj = win_slice(wins[j])
                mj = label[slj] == j
                label[slj][mj & ~largest_component(mj)] = -1
            continue
        label[sl][cand] = i

    # 5) Polygon extraction: single external contour, no enclosed neighbours,
    #    no rectangles.
    polys = [None] * n
    for i in range(n):
        sl = win_slice(wins[i])
        lab = label[sl]  # view
        m = lab == i
        m2 = largest_component(m)
        lab[m & ~m2] = -1
        m = m2
        for _ in range(10):
            holes = fill_holes(m) & ~m
            if not holes.any():
                break
            others = holes & (lab >= 0)
            hn, hlab = cv2.connectedComponents(holes.astype(np.uint8), connectivity=4)
            for k in range(1, hn):
                comp = hlab == k
                if not (comp & others).any():
                    m = m | comp  # empty hole: fill it
                    lab[comp] = i
                else:  # hole contains another cell: cut a 1px slit to the outside
                    ys, xs = np.nonzero(comp)
                    t = int(np.argmin(ys))
                    r, c = ys[t], xs[t]
                    cut = np.zeros_like(m)
                    cut[:r, c] = True
                    lab[m & cut] = -1
                    m = m & ~cut
            m2 = largest_component(m)
            lab[m & ~m2] = -1
            m = m2

        m2 = remove_pinches(m)
        if m2.sum() >= 3:
            lab[m & ~m2] = -1
            m = m2
        poly = mask_to_polygon(m) if m.any() else None
        if poly is not None and is_rectangular(m, poly):
            ys, xs = np.nonzero(m)
            ell = ellipse_mask(xs.min(), ys.min(), xs.max(), ys.max(), m.shape, 1.0) & m
            ell = remove_pinches(largest_component(ell))
            if ell.sum() >= 3:
                lab[m & ~ell] = -1
                m = ell
                poly = mask_to_polygon(m)
        if poly is None or len(poly) < 3:
            # Degenerate last resort: tiny triangle at box centre.
            x0, y0, x1, y1 = boxes[i]
            cx, cy = (x0 + x1) // 2, (y0 + y1) // 2
            poly = np.array([[cx, cy], [cx + 1, cy], [cx, cy + 1]]) - np.array([wins[i][0], wins[i][1]])
        polys[i] = poly + np.array([wins[i][0], wins[i][1]])
    return polys


def verify(polys, shape):
    occ = np.zeros(shape, np.uint8)
    for p in polys:
        x0, y0 = p.min(0)
        x1, y1 = p.max(0) + 1
        occ[y0:y1, x0:x1] += polygon_to_mask(p - [x0, y0], (y1 - y0, x1 - x0)).astype(np.uint8)
    return int((occ > 1).sum())


# --------------------------------------------------------------------------- #
def main():
    args = parse_args()
    device = args.device or ("cuda" if torch.cuda.is_available() else "cpu")

    image = cv2.imread(args.rgb_path, cv2.IMREAD_COLOR)
    if image is None:
        raise FileNotFoundError(args.rgb_path)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    h, w = image.shape[:2]

    df = pd.read_csv(args.csv_path, index_col=0)
    n = len(df)
    out_file = resolve_output_file(args.output_path, args.csv_path)
    if n == 0:
        df.to_csv(out_file)
        return

    # Prompt boxes, per-cell windows and original annotation masks (window-local).
    boxes, wins, orig_masks, is_rect = [], [], [], []
    for _, row in df.iterrows():
        try:
            xs, ys = parse_coords(row["coords_x"]), parse_coords(row["coords_y"])
        except (ValueError, KeyError):
            xs, ys = [], []
        if len(xs) >= 3 and len(xs) == len(ys):
            pts = np.stack([xs, ys], 1)
        else:
            x0, y0, x1, y1 = float(row["xmin"]), float(row["ymin"]), float(row["xmax"]), float(row["ymax"])
            pts = np.array([[x0, y0], [x1, y0], [x1, y1], [x0, y1]])
        pts[:, 0] = np.clip(pts[:, 0], 0, w - 1)
        pts[:, 1] = np.clip(pts[:, 1], 0, h - 1)
        x0, y0 = int(np.floor(pts[:, 0].min())), int(np.floor(pts[:, 1].min()))
        x1, y1 = int(np.ceil(pts[:, 0].max())), int(np.ceil(pts[:, 1].max()))
        x1, y1 = min(max(x1, x0 + 1), w - 1), min(max(y1, y0 + 1), h - 1)
        x0, y0 = min(x0, x1), min(y0, y1)
        boxes.append((x0, y0, x1, y1))

        mg = max(BOX_MARGIN_MIN, int(round(BOX_MARGIN_FRAC * max(x1 - x0, y1 - y0))))
        win = (max(0, x0 - mg), max(0, y0 - mg), min(w, x1 + mg + 1), min(h, y1 + mg + 1))
        wins.append(win)
        wshape = (win[3] - win[1], win[2] - win[0])

        typ = str(row["type"]).lower() if "type" in df.columns else ""
        uniq = np.unique(np.round(pts), axis=0)
        rect = "rect" in typ or (len(uniq) <= 4 and len(np.unique(uniq[:, 0])) <= 2
                                 and len(np.unique(uniq[:, 1])) <= 2)
        is_rect.append(rect)
        if rect:  # a rectangle carries no shape info: use an inscribed ellipse
            om = ellipse_mask(x0 - win[0], y0 - win[1], x1 - win[0], y1 - win[1], wshape, 1.0)
        else:
            om = polygon_to_mask(pts - [win[0], win[1]], wshape)
        orig_masks.append(om)

    sam = sam_model_registry["vit_t"](checkpoint=args.weights_path)
    sam.to(device=device)
    sam.eval()
    predictor = SamPredictor(sam)

    logits = run_sam(predictor, image, boxes, wins, orig_masks, is_rect)
    polys = resolve(logits, sam.mask_threshold, boxes, wins, orig_masks, (h, w))

    overlap = verify(polys, (h, w))
    if overlap:
        print("Warning: %d overlapping pixels after rasterisation" % overlap)

    out = df.copy()
    for col in ["xmin", "ymin", "xmax", "ymax"]:
        out[col] = 0
    out["coords_x"] = out["coords_x"].astype(object)
    out["coords_y"] = out["coords_y"].astype(object)
    for k, idx in enumerate(df.index):
        p = polys[k].astype(int)
        closed = np.vstack([p, p[:1]])  # close the polyline like the input format
        out.at[idx, "xmin"] = int(p[:, 0].min())
        out.at[idx, "xmax"] = int(p[:, 0].max())
        out.at[idx, "ymin"] = int(p[:, 1].min())
        out.at[idx, "ymax"] = int(p[:, 1].max())
        out.at[idx, "coords_x"] = ",".join(str(int(v)) for v in closed[:, 0])
        out.at[idx, "coords_y"] = ",".join(str(int(v)) for v in closed[:, 1])
    out.to_csv(out_file)
    print("Saved %d refined masks to %s" % (n, out_file))


if __name__ == "__main__":
    main()
