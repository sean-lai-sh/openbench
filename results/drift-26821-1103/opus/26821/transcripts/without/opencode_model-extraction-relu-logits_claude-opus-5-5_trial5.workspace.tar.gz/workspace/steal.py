"""Extract A1 (up to row permutation and scaling) from a 1-hidden-layer ReLU net
using only black-box queries to forward(x).

Method: along random lines x0 + t*d, locate the points where the piecewise-linear
function f bends (a hidden neuron crosses zero). At each such critical point the
jump in the gradient of f equals a2_i * A1[i, :], i.e. a scaled row of A1.
"""
import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def grad(x, h=1e-6):
    g = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        g[j] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def find_kinks(x0, d, lo, hi, n_init=200):
    """Return t values of kinks of t -> f(x0 + t d) in [lo, hi]."""
    g = lambda t: f(x0 + t * d)
    kinks = []

    def is_linear(a, b, fa, fb):
        for frac in (0.25, 0.5, 0.75):
            t = a + frac * (b - a)
            pred = fa + frac * (fb - fa)
            if abs(g(t) - pred) > 1e-11 * (1 + abs(pred)):
                return False
        return True

    def rec(a, b, fa, fb, depth=0):
        if is_linear(a, b, fa, fb):
            return
        if b - a < 1e-2:
            # assume a single kink: intersect the two boundary linear pieces
            dl = (b - a) * 1e-4
            sl = (g(a + dl) - fa) / dl
            sr = (fb - g(b - dl)) / dl
            if abs(sl - sr) > 1e-12:
                ts_ = (fb - fa + sl * a - sr * b) / (sl - sr)
                if a < ts_ < b:
                    pred = fa + sl * (ts_ - a)
                    if abs(g(ts_) - pred) < 1e-12 * (1 + abs(pred)) + 1e-14:
                        kinks.append(ts_)
                        return
        if b - a < 1e-9 or depth > 60:
            kinks.append(0.5 * (a + b))
            return
        m = 0.5 * (a + b)
        fm = g(m)
        rec(a, m, fa, fm, depth + 1)
        rec(m, b, fm, fb, depth + 1)

    ts = np.linspace(lo, hi, n_init + 1)
    fs = [g(t) for t in ts]
    for i in range(n_init):
        rec(ts[i], ts[i + 1], fs[i], fs[i + 1])
    # merge near-duplicates
    kinks.sort()
    merged = []
    for t in kinks:
        if not merged or t - merged[-1] > 1e-6:
            merged.append(t)
    return merged


def normalize(v):
    v = v / np.linalg.norm(v)
    if v[np.argmax(np.abs(v))] < 0:
        v = -v
    return v


rows = []      # normalized row directions
counts = []
stable_lines = 0
for line in range(200):
    x0 = rng.normal(size=DIM) * rng.uniform(0.1, 3.0)
    d = rng.normal(size=DIM)
    d /= np.linalg.norm(d)
    n_before = len(rows)
    for t in find_kinks(x0, d, -30.0, 30.0):
        off = 1e-4
        gl = grad(x0 + (t - off) * d)
        gr = grad(x0 + (t + off) * d)
        diff = gr - gl
        if np.linalg.norm(diff) < 1e-7:
            continue
        v = normalize(diff)
        for k, r in enumerate(rows):
            if abs(np.dot(r, v)) > 1 - 1e-6:
                # running average for precision
                rows[k] = normalize(r * counts[k] + v * np.sign(np.dot(r, v)))
                counts[k] += 1
                break
        else:
            rows.append(v)
            counts.append(1)
    stable_lines = stable_lines + 1 if len(rows) == n_before else 0
    if line >= 10 and stable_lines >= 15:
        break

# drop spurious directions seen only once (e.g. two kinks merged together)
keep = [r for r, c in zip(rows, counts) if c >= 2] if max(counts) > 2 else rows
A1_stolen = np.array(keep)
np.save(OUT, A1_stolen)
print(f"Recovered {A1_stolen.shape[0]} neurons")
print(A1_stolen)
