#!/usr/bin/env python3
"""Hurdle jump analyzer.

Detects the takeoff and landing frames of a single hurdle jump in an MP4 video
recorded from a (nearly) stationary camera, and writes them to a TOML file.

Approach
--------
1. Read all frames and register each frame to the first frame (phase
   correlation) to compensate for small camera drift / shake.
2. Build a clean background as the per-pixel median of the aligned frames
   (the athlete only covers any given pixel for a few frames).
3. Foreground = pixels that differ strongly from the background. The lowest
   foreground point in each frame is the athlete's lowest foot.
4. The ground level is estimated from the lowest-foot positions while the
   athlete is running. Frames where the lowest foot is clearly above the ground
   are "airborne". The jump is the longest airborne segment (preferring the one
   in which the athlete crosses the hurdle).
5. Takeoff = last ground-contact frame before the flight,
   landing = first ground-contact frame after the flight.

Usage:
    python jump_analyzer.py <video.mp4> [output.toml]
"""

import os
import sys

import cv2
import numpy as np
import toml

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_VIDEO = os.path.join(SCRIPT_DIR, "example_video.mp4")
DEFAULT_OUTPUT = os.path.join(SCRIPT_DIR, "output.toml")

# Approximate horizontal location of the hurdle in the (fixed) scene, in
# pixels for a 960 px wide frame. Scaled when the frame width differs.
HURDLE_X_RANGE = (490.0, 625.0)
REF_WIDTH = 960.0

DIFF_THRESHOLD = 35      # max-channel abs difference to count as foreground
MIN_BLOB_AREA = 60       # ignore tiny noise blobs
MIN_PERSON_AREA = 1500   # minimum foreground pixels to consider runner present


def read_frames(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open video: {path}")
    frames = []
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frames.append(frame)
    cap.release()
    if not frames:
        raise RuntimeError(f"No frames read from: {path}")
    return frames


def align_frames(frames):
    """Register every frame to the first frame using phase correlation."""
    h, w = frames[0].shape[:2]
    ref = cv2.cvtColor(frames[0], cv2.COLOR_BGR2GRAY).astype(np.float32)
    win = cv2.createHanningWindow((w, h), cv2.CV_32F)
    aligned = []
    for f in frames:
        g = cv2.cvtColor(f, cv2.COLOR_BGR2GRAY).astype(np.float32)
        (dx, dy), _ = cv2.phaseCorrelate(ref, g, win)
        if abs(dx) > 40 or abs(dy) > 40:  # implausible, ignore
            dx = dy = 0.0
        m = np.float32([[1, 0, -dx], [0, 1, -dy]])
        aligned.append(cv2.warpAffine(f, m, (w, h),
                                      flags=cv2.INTER_LINEAR,
                                      borderMode=cv2.BORDER_REPLICATE))
    return aligned


def build_background(aligned):
    n = len(aligned)
    step = max(1, n // 90)  # cap memory / time for long videos
    sample = np.stack(aligned[::step]).astype(np.uint8)
    return np.median(sample, axis=0).astype(np.int16)


def foreground_mask(frame, bg):
    d = np.abs(frame.astype(np.int16) - bg).max(axis=2)
    m = (d > DIFF_THRESHOLD).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    n, lab, stats, _ = cv2.connectedComponentsWithStats(m)
    keep = np.zeros_like(m)
    for k in range(1, n):
        if stats[k, cv2.CC_STAT_AREA] > MIN_BLOB_AREA:
            keep[lab == k] = 1
    return keep


def measure(aligned, bg):
    """Per frame: (present, bottom_y, centroid_x, top_y)."""
    h, w = aligned[0].shape[:2]
    out = []
    for f in aligned:
        m = foreground_mask(f, bg)
        cnt = int(m.sum())
        if cnt < MIN_PERSON_AREA:
            out.append((False, None, None, None))
            continue
        ys, xs = np.nonzero(m)
        out.append((True, int(ys.max()), float(xs.mean()), int(ys.min())))
    return out


def find_segments(flags):
    segs, start = [], None
    for i, f in enumerate(flags):
        if f and start is None:
            start = i
        elif not f and start is not None:
            segs.append((start, i - 1))
            start = None
    if start is not None:
        segs.append((start, len(flags) - 1))
    return segs


def detect_jump(meas, width):
    n = len(meas)
    present = [m[0] for m in meas]
    idx = [i for i in range(n) if present[i]]
    if not idx:
        return 0, max(0, n - 1)

    bottoms = np.array([meas[i][1] for i in idx], dtype=np.float32)
    tops = np.array([meas[i][3] for i in idx], dtype=np.float32)
    # Ground level: the lowest foot position while in contact with the track.
    ground = float(np.percentile(bottoms, 80))
    body_h = float(np.median(bottoms - tops)) if len(idx) else 300.0
    thr = max(8.0, 0.04 * body_h)

    airborne = [bool(present[i] and meas[i][1] < ground - thr) for i in range(n)]
    segs = find_segments(airborne)
    if not segs:
        # Fallback: frame with highest foot is the apex
        apex = idx[int(np.argmin(bottoms))]
        return max(0, apex - 4), min(n - 1, apex + 4)

    sx = width / REF_WIDTH
    hx0, hx1 = HURDLE_X_RANGE[0] * sx, HURDLE_X_RANGE[1] * sx
    hc = 0.5 * (hx0 + hx1)

    def score(seg):
        a, b = seg
        length = b - a + 1
        xs = [meas[i][2] for i in range(a, b + 1) if meas[i][0]]
        crosses = 0.0
        if xs:
            lo, hi = min(xs), max(xs)
            if lo <= hc <= hi:
                crosses = 1.0
            else:
                dist = min(abs(lo - hc), abs(hi - hc))
                crosses = max(0.0, 1.0 - dist / (200.0 * sx))
        # height of flight (how far the feet are lifted)
        lift = max(ground - meas[i][1] for i in range(a, b + 1))
        return length + 4.0 * crosses + lift / max(body_h, 1.0) * 5.0

    best = max(segs, key=score)
    takeoff = max(0, best[0] - 1)
    land = min(n - 1, best[1] + 1)
    return takeoff, land


def analyze(video_path):
    frames = read_frames(video_path)
    width = frames[0].shape[1]
    aligned = align_frames(frames)
    bg = build_background(aligned)
    meas = measure(aligned, bg)
    return detect_jump(meas, width)


def main():
    video = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_VIDEO
    output = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_OUTPUT
    takeoff, land = analyze(video)
    result = {
        "jump_takeoff_frame_number": int(takeoff),
        "jump_land_frame_number": int(land),
    }
    with open(output, "w") as fh:
        toml.dump(result, fh)
    print(toml.dumps(result), end="")


if __name__ == "__main__":
    main()
