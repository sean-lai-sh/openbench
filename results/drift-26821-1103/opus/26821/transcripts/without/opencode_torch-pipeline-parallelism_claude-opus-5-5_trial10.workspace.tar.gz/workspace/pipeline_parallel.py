"""Pipeline-parallel training step for LlamaForCausalLM with AFAB scheduling.

All-Forward-All-Backward (AFAB / GPipe-style) schedule:
  1. Every stage runs the forward pass for all microbatches, receiving hidden
     states from the previous stage and sending its outputs to the next stage.
  2. Every stage then runs the backward pass for all microbatches, receiving
     output gradients from the next stage and sending input gradients to the
     previous stage.
"""

import torch
import torch.distributed as dist
import torch.nn.functional as F


# --------------------------------------------------------------------------- #
# Partitioning
# --------------------------------------------------------------------------- #
def _partition_layers(num_layers, world_size, rank):
    """Return [start, end) of decoder layers owned by ``rank`` (balanced split)."""
    base, rem = divmod(num_layers, world_size)
    start = rank * base + min(rank, rem)
    end = start + base + (1 if rank < rem else 0)
    return start, end


# --------------------------------------------------------------------------- #
# Communication helpers
# --------------------------------------------------------------------------- #
def _send(tensor, dst):
    ops = [dist.P2POp(dist.isend, tensor.contiguous(), dst)]
    for req in dist.batch_isend_irecv(ops):
        req.wait()


def _recv(shape, src, device, dtype):
    buf = torch.empty(shape, device=device, dtype=dtype)
    ops = [dist.P2POp(dist.irecv, buf, src)]
    for req in dist.batch_isend_irecv(ops):
        req.wait()
    return buf


# --------------------------------------------------------------------------- #
# Model helpers
# --------------------------------------------------------------------------- #
def _build_causal_mask(model, hidden_states, position_ids):
    """Build the attention mask the decoder layers expect (mirrors LlamaModel)."""
    config = model.config
    try:
        from transformers.masking_utils import create_causal_mask

        try:
            return create_causal_mask(
                config=config,
                inputs_embeds=hidden_states,
                attention_mask=None,
                past_key_values=None,
                position_ids=position_ids,
            )
        except TypeError:
            cache_position = torch.arange(hidden_states.shape[1], device=hidden_states.device)
            return create_causal_mask(
                config=config,
                input_embeds=hidden_states,
                attention_mask=None,
                cache_position=cache_position,
                past_key_values=None,
                position_ids=position_ids,
            )
    except Exception:
        pass

    # Fallback: explicit additive 4D causal mask (works for eager and sdpa).
    seq_len = hidden_states.shape[1]
    min_val = torch.finfo(hidden_states.dtype).min
    mask = torch.full((seq_len, seq_len), min_val, device=hidden_states.device, dtype=hidden_states.dtype)
    mask = torch.triu(mask, diagonal=1)
    return mask[None, None, :, :].expand(hidden_states.shape[0], 1, seq_len, seq_len)


def _run_layers(model, layers, hidden_states):
    """Run a contiguous slice of decoder layers on ``hidden_states``."""
    if len(layers) == 0:
        return hidden_states
    base = model.model
    seq_len = hidden_states.shape[1]
    position_ids = torch.arange(seq_len, device=hidden_states.device).unsqueeze(0)
    causal_mask = _build_causal_mask(model, hidden_states, position_ids)

    kwargs = dict(attention_mask=causal_mask, position_ids=position_ids)
    if getattr(base, "rotary_emb", None) is not None:
        kwargs["position_embeddings"] = base.rotary_emb(hidden_states, position_ids)

    for layer in layers:
        out = layer(hidden_states, **kwargs)
        hidden_states = out[0] if isinstance(out, (tuple, list)) else out
    return hidden_states


# --------------------------------------------------------------------------- #
# Training step
# --------------------------------------------------------------------------- #
def train_step_pipeline_afab(model, inputs, targets, device, dtype):
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    is_first = rank == 0
    is_last = rank == world_size - 1
    prev_rank = rank - 1
    next_rank = rank + 1

    base = model.model
    hidden_size = model.config.hidden_size
    num_layers = len(base.layers)
    start, end = _partition_layers(num_layers, world_size, rank)
    my_layers = [base.layers[i] for i in range(start, end)]

    num_microbatches = len(inputs)

    stage_inputs = []   # tensors received from the previous stage (leaf, requires grad)
    stage_outputs = []  # tensors produced by this stage (hidden states or loss)
    total_loss = 0.0

    # ----------------------------- all forward ----------------------------- #
    for i in range(num_microbatches):
        mb_shape = tuple(inputs[i].shape)
        hidden_shape = (mb_shape[0], mb_shape[1], hidden_size)

        if is_first:
            input_ids = inputs[i].to(device)
            hidden = base.embed_tokens(input_ids).to(dtype)
            stage_inputs.append(None)
        else:
            hidden = _recv(hidden_shape, prev_rank, device, dtype)
            hidden.requires_grad_(True)
            stage_inputs.append(hidden)

        hidden = _run_layers(model, my_layers, hidden)

        if is_last:
            hidden = base.norm(hidden)
            logits = model.lm_head(hidden)
            tgt = targets[i].to(device)
            loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), tgt.reshape(-1))
            loss = loss / num_microbatches
            total_loss += loss.detach().item()
            stage_outputs.append(loss)
        else:
            hidden = hidden.to(device=device, dtype=dtype)
            _send(hidden.detach(), next_rank)
            stage_outputs.append(hidden)

    # ----------------------------- all backward ---------------------------- #
    for i in range(num_microbatches):
        mb_shape = tuple(inputs[i].shape)
        hidden_shape = (mb_shape[0], mb_shape[1], hidden_size)
        output = stage_outputs[i]

        if is_last:
            output.backward()
        else:
            grad = _recv(hidden_shape, next_rank, device, dtype)
            torch.autograd.backward(output, grad_tensors=grad)

        if not is_first:
            inp = stage_inputs[i]
            grad_in = inp.grad
            if grad_in is None:
                grad_in = torch.zeros_like(inp)
            _send(grad_in.to(device=device, dtype=dtype), prev_rank)

        # free activations
        stage_outputs[i] = None
        stage_inputs[i] = None

    return total_loss if is_last else None
