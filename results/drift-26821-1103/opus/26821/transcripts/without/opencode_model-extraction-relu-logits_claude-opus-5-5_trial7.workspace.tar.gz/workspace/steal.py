"""Extract A1 (up to neuron permutation and row scaling) from a one-hidden-layer
ReLU network f(x) = A2 ReLU(A1 x + b1) + b2 using only black-box queries.

Method: walk along random lines, locate the kinks (points where a single hidden
neuron switches on/off), and compute the gradient of f just before and just
after each kink. The gradient jump equals A2_i * A1_i for the neuron i that
flipped, i.e. a scaled copy of row i of A1. Collect, normalise and deduplicate.
"""
import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, a, b, fa, fb, sa, sb, depth=0, out=None):
    """Find kink locations t in [a,b] of g(t)=f(x0+t d).
    sa / sb are slopes of g just right of a / just left of b."""
    if out is None:
        out = []
    scale = max(1.0, abs(fa), abs(fb))
    if abs(sa - sb) < 1e-9 * max(1.0, abs(sa), abs(sb)):
        # same slope at both ends: check consistency with a single line
        if abs(fa + sa * (b - a) - fb) < 1e-9 * scale:
            return out
    else:
        # assume a single kink: intersect the two lines
        tk = (fb - fa + sa * a - sb * b) / (sa - sb)
        if a < tk < b:
            fk = f(x0 + tk * d)
            pred = fa + sa * (tk - a)
            if abs(fk - pred) < 1e-9 * scale:
                # verify the line on each side really is straight
                m1 = 0.5 * (a + tk)
                m2 = 0.5 * (tk + b)
                ok1 = abs(f(x0 + m1 * d) - (fa + sa * (m1 - a))) < 1e-9 * scale
                ok2 = abs(f(x0 + m2 * d) - (fb + sb * (m2 - b))) < 1e-9 * scale
                if ok1 and ok2:
                    out.append(tk)
                    return out
    if depth > 60 or b - a < 1e-10:
        return out
    m = 0.5 * (a + b)
    fm = f(x0 + m * d)
    h = min(1e-6, (b - a) * 1e-3)
    sml = (fm - f(x0 + (m - h) * d)) / h
    smr = (f(x0 + (m + h) * d) - fm) / h
    find_kinks(x0, d, a, m, fa, fm, sa, sml, depth + 1, out)
    find_kinks(x0, d, m, b, fm, fb, smr, sb, depth + 1, out)
    return out


def gradient(x, h=1e-6):
    fx = f(x)
    g = np.empty(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        g[j] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def main():
    rows = []
    n_lines = 60
    T = 50.0
    for _ in range(n_lines):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        h = 1e-6
        fa, fb = f(x0 - T * d), f(x0 + T * d)
        sa = (f(x0 + (-T + h) * d) - fa) / h
        sb = (fb - f(x0 + (T - h) * d)) / h
        kinks = sorted(find_kinks(x0, d, -T, T, fa, fb, sa, sb))
        for i, tk in enumerate(kinks):
            # stay well away from neighbouring kinks
            gaps = [abs(tk - k) for j, k in enumerate(kinks) if j != i]
            delta = min([1e-3] + [0.25 * g for g in gaps])
            if delta < 1e-6:
                continue
            xc = x0 + tk * d
            gstep = min(1e-7, delta * 1e-2)
            g1 = gradient(xc - delta * d, gstep)
            g2 = gradient(xc + delta * d, gstep)
            diff = g2 - g1
            n = np.linalg.norm(diff)
            if n < 1e-8:
                continue
            v = diff / n
            v *= np.sign(v[np.argmax(np.abs(v))])
            rows.append(v)

    # cluster unit vectors (identical up to sign)
    clusters = []
    for v in rows:
        for c in clusters:
            if abs(np.dot(c[0], v)) > 0.9999:
                c.append(v * np.sign(np.dot(c[0], v)))
                break
        else:
            clusters.append([v])
    # keep clusters seen at least twice (robustness to spurious detections)
    good = [np.median(np.array(c), axis=0) for c in clusters if len(c) >= 2]
    A = np.array([g / np.linalg.norm(g) for g in good])
    print(f"Recovered {A.shape[0]} neurons")
    np.set_printoptions(precision=6, suppress=True, linewidth=150)
    print(A)
    np.save(OUT, A)


if __name__ == "__main__":
    main()
