#!/usr/bin/env python3
"""Detect hurdle jump takeoff and landing frames in an MP4 video.

Usage: python jump_analyzer.py <video.mp4> [output.toml]

Approach:
  * The first frame is an empty background (no runner).
  * Each frame is compared to the background (with brightness compensation)
    to obtain a foreground mask of the athlete.
  * The lowest foreground pixel (largest y) of the athlete approximates the
    foot position. While the athlete is on the ground, it sits at the track
    level; during the hurdle flight it rises well above it.
  * The airborne segment around the hurdle crossing that is the longest/
    highest is taken as the jump. Takeoff = last ground-contact frame before
    the flight, landing = first ground-contact frame after it.
"""
import os
import sys

import cv2
import numpy as np
import toml

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_OUTPUT = os.path.join(SCRIPT_DIR, "output.toml")

# Region of interest containing the runner (rows of the track in the image).
ROI_Y0, ROI_Y1 = 120, 440
DIFF_THRESH = 35
MIN_AREA = 400
DEBUG = os.environ.get("JUMP_DEBUG") == "1"


def preprocess(frame):
    roi = frame[ROI_Y0:ROI_Y1]
    blur = cv2.GaussianBlur(roi, (5, 5), 0)
    return blur.astype(np.float32)


def foreground_mask(cur, bg, bg_lo, bg_hi):
    # Compensate global brightness changes (clouds / auto exposure).
    cm = cur.reshape(-1, 3).mean(0)
    bm = bg.reshape(-1, 3).mean(0)
    adj = cur * (bm / np.maximum(cm, 1e-3))
    # Distance to the local background range (tolerant to ~1px jitter).
    diff = np.maximum(bg_lo - adj, adj - bg_hi).max(axis=2)
    mask = (diff > DIFF_THRESH).astype(np.uint8) * 255
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    return mask


def athlete_blob(mask, prev_center=None):
    """Return (bottom_y, cx, area) of the athlete blob, or None."""
    n, labels, stats, cents = cv2.connectedComponentsWithStats(mask, 8)
    if n <= 1:
        return None
    # Group components: take the largest one, then merge components that are
    # close to it horizontally (legs/feet can be disconnected from the torso).
    order = np.argsort(-stats[1:, cv2.CC_STAT_AREA]) + 1
    main = order[0]
    if stats[main, cv2.CC_STAT_AREA] < MIN_AREA:
        return None
    x0 = stats[main, cv2.CC_STAT_LEFT]
    x1 = x0 + stats[main, cv2.CC_STAT_WIDTH]
    y0 = stats[main, cv2.CC_STAT_TOP]
    y1 = y0 + stats[main, cv2.CC_STAT_HEIGHT]
    keep = [main]
    for k in order[1:]:
        a = stats[k, cv2.CC_STAT_AREA]
        if a < 30:
            continue
        kx0 = stats[k, cv2.CC_STAT_LEFT]
        kx1 = kx0 + stats[k, cv2.CC_STAT_WIDTH]
        ky0 = stats[k, cv2.CC_STAT_TOP]
        ky1 = ky0 + stats[k, cv2.CC_STAT_HEIGHT]
        if kx1 >= x0 - 60 and kx0 <= x1 + 60 and ky0 <= y1 + 60 and ky1 >= y0 - 20:
            keep.append(k)
    sel = np.isin(labels, keep)
    ys, xs = np.nonzero(sel)
    # Robust bottom: a few pixels from the very bottom to suppress noise.
    bottom = np.percentile(ys, 99.7) + ROI_Y0
    area = len(xs)
    return float(bottom), float(xs.mean()), int(area), int(xs.min()), int(xs.max())


def analyze(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise RuntimeError("Cannot open video: %s" % path)
    frames = []
    while True:
        ok, f = cap.read()
        if not ok:
            break
        frames.append(f)
    cap.release()
    if len(frames) < 3:
        raise RuntimeError("Video too short")

    h, w = frames[0].shape[:2]
    bg_full = frames[0]
    bg = preprocess(bg_full)
    k = np.ones((3, 3), np.uint8)
    bg_lo = cv2.erode(bg, k)
    bg_hi = cv2.dilate(bg, k)
    bg_gray = cv2.cvtColor(bg_full, cv2.COLOR_BGR2GRAY).astype(np.float32)
    win = cv2.createHanningWindow((w, h), cv2.CV_32F)

    data = []
    for i, f in enumerate(frames):
        # Compensate small camera shake by global translation alignment.
        g = cv2.cvtColor(f, cv2.COLOR_BGR2GRAY).astype(np.float32)
        (dx, dy), _ = cv2.phaseCorrelate(bg_gray, g, win)
        if abs(dx) < 15 and abs(dy) < 15 and (abs(dx) > 0.25 or abs(dy) > 0.25):
            M = np.float32([[1, 0, -dx], [0, 1, -dy]])
            f = cv2.warpAffine(f, M, (w, h), borderMode=cv2.BORDER_REPLICATE)
        m = foreground_mask(preprocess(f), bg, bg_lo, bg_hi)
        data.append(athlete_blob(m))
        if DEBUG:
            print(i, data[-1])

    present = [i for i, d in enumerate(data) if d is not None and d[2] >= 1500]
    if not present:
        return 0, 0

    # Hurdle location: fixed in all videos (vertical post around x~495,
    # base spans to ~620). Use its center.
    hurdle_x = 555.0 * w / 960.0

    bottoms = np.full(len(frames), np.nan)
    cxs = np.full(len(frames), np.nan)
    for i in present:
        bottoms[i] = data[i][0]
        cxs[i] = data[i][1]

    # Ground level: the typical lowest point of the athlete when on the ground.
    valid = bottoms[~np.isnan(bottoms)]
    ground = np.percentile(valid, 85)
    air_thresh = ground - 12.0 * h / 540.0

    # Frame where the athlete crosses the hurdle (center closest to hurdle x).
    dist = np.abs(cxs - hurdle_x)
    dist[np.isnan(dist)] = np.inf
    cross = int(np.argmin(dist))

    airborne = np.zeros(len(frames), bool)
    for i in present:
        airborne[i] = bottoms[i] < air_thresh

    # Find airborne segments (allow single-frame gaps in detection).
    segs = []
    i = 0
    n = len(frames)
    while i < n:
        if airborne[i]:
            j = i
            while j + 1 < n and (airborne[j + 1] or
                                 (np.isnan(bottoms[j + 1]) and j + 2 < n and airborne[j + 2])):
                j += 1
            segs.append((i, j))
            i = j + 1
        else:
            i += 1

    best = None
    best_score = -1
    for s, e in segs:
        seg_b = bottoms[s:e + 1]
        height = ground - np.nanmin(seg_b)
        dur = e - s + 1
        # Prefer the segment containing / nearest to the hurdle crossing.
        if s <= cross <= e:
            dpen = 0
        else:
            dpen = min(abs(cross - s), abs(cross - e))
        score = dur * height / (1.0 + dpen)
        if score > best_score:
            best_score = score
            best = (s, e)

    if best is None:
        return max(cross - 4, 0), min(cross + 4, n - 1)

    s, e = best
    takeoff = s - 1
    land = e + 1
    # Step back over undetected frames.
    while takeoff > 0 and np.isnan(bottoms[takeoff]):
        takeoff -= 1
    while land < n - 1 and np.isnan(bottoms[land]):
        land += 1
    takeoff = max(takeoff, 0)
    land = min(land, n - 1)
    if DEBUG:
        print("ground", ground, "thresh", air_thresh, "cross", cross, "segs", segs)
    return int(takeoff), int(land)


def main():
    if len(sys.argv) < 2:
        video = os.path.join(SCRIPT_DIR, "example_video.mp4")
    else:
        video = sys.argv[1]
    out = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_OUTPUT
    takeoff, land = analyze(video)
    result = {
        "jump_takeoff_frame_number": int(takeoff),
        "jump_land_frame_number": int(land),
    }
    with open(out, "w") as fh:
        toml.dump(result, fh)
    print(toml.dumps(result), end="")


if __name__ == "__main__":
    main()
