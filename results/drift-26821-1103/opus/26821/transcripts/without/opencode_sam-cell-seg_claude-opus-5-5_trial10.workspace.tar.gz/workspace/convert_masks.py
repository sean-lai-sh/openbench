#!/usr/bin/env python
"""Refine histopathology cell annotations (rectangles + polylines) with MobileSAM.

Every annotation in the metadata csv is used as a prompt for MobileSAM.  The
resulting masks are made mutually exclusive (no overlap), reduced to a single
connected component per cell and converted to polylines.  The output csv has
the same structure as the input csv, with updated ``xmin``, ``ymin``,
``xmax``, ``ymax``, ``coords_x`` and ``coords_y`` columns.

Example:
    python convert_masks.py \
        --weights_path weights/mobile_sam.pt \
        --output_path out/ \
        --rgb_path demo_rgb.png \
        --csv_path demo_metadata.csv
"""

import argparse
import os

import cv2
import numpy as np
import pandas as pd
import torch
from PIL import Image
from tqdm import tqdm

from mobile_sam import SamPredictor, sam_model_registry


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def parse_coords(value):
    """Parse a 'x1,x2,...' string (or a list-like) into an int numpy array."""
    if isinstance(value, (list, tuple, np.ndarray)):
        vals = list(value)
    else:
        s = str(value).strip().strip("[]()")
        vals = [v for v in s.replace(";", ",").replace(" ", ",").split(",") if v != ""]
    return np.round(np.asarray([float(v) for v in vals], dtype=np.float64)).astype(np.int64)


def is_rectangle(xs, ys):
    """True if the polygon is an axis aligned rectangle."""
    pts = set(zip(xs.tolist(), ys.tolist()))
    return len(set(xs.tolist())) <= 2 and len(set(ys.tolist())) <= 2 and len(pts) <= 4


def polygon_mask(xs, ys, shape):
    mask = np.zeros(shape, dtype=np.uint8)
    pts = np.stack([xs, ys], axis=1).astype(np.int32).reshape(-1, 1, 2)
    if len(pts) >= 3:
        cv2.fillPoly(mask, [pts], 1)
    return mask.astype(bool)


def ellipse_mask(box, shape):
    """Ellipse inscribed in a box - fallback for rectangles SAM fails on."""
    x0, y0, x1, y1 = box
    mask = np.zeros(shape, dtype=np.uint8)
    center = (int(round((x0 + x1) / 2)), int(round((y0 + y1) / 2)))
    axes = (max(1, int(round((x1 - x0) / 2))), max(1, int(round((y1 - y0) / 2))))
    cv2.ellipse(mask, center, axes, 0, 0, 360, 1, -1)
    return mask.astype(bool)


def largest_component(mask):
    mask = mask.astype(np.uint8)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=4)
    if n <= 1:
        return np.zeros(mask.shape, dtype=bool)
    best = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return lab == best


def fill_holes(mask):
    mask = mask.astype(np.uint8)
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    filled = np.zeros_like(mask)
    if contours:
        cv2.drawContours(filled, contours, -1, 1, thickness=-1)
    return filled.astype(bool)


def mask_to_polygon(mask):
    """Return the outer contour (Nx2 int array) of the largest blob in mask."""
    contours, _ = cv2.findContours(
        mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )
    if not contours:
        return None
    cnt = max(contours, key=cv2.contourArea)
    return cnt.reshape(-1, 2)


def rasterize(poly, shape):
    m = np.zeros(shape, dtype=np.uint8)
    cv2.fillPoly(m, [poly.reshape(-1, 1, 2).astype(np.int32)], 1)
    return m.astype(bool)


def valid_polygon(poly):
    """A usable polyline: >=3 distinct points and a non-zero area."""
    return (
        poly is not None
        and len(np.unique(poly, axis=0)) >= 3
        and abs(cv2.contourArea(poly.reshape(-1, 1, 2).astype(np.int32))) > 0
    )


def iou(a, b):
    inter = np.logical_and(a, b).sum()
    union = np.logical_or(a, b).sum()
    return inter / union if union else 0.0


# --------------------------------------------------------------------------- #
# Main pipeline
# --------------------------------------------------------------------------- #
def load_predictor(weights_path, device):
    model = sam_model_registry["vit_t"](checkpoint=None)
    state = torch.load(weights_path, map_location=device)
    if isinstance(state, dict) and "model" in state and isinstance(state["model"], dict):
        state = state["model"]
    model.load_state_dict(state)
    model.to(device=device)
    model.eval()
    return SamPredictor(model)


def sam_logits_for_cell(predictor, box, prior, prior_is_poly, shape):
    """Run MobileSAM with a box prompt; return full-res logits of the best mask."""
    H, W = shape
    masks, scores, _ = predictor.predict(
        box=np.asarray(box, dtype=np.float32),
        multimask_output=True,
        return_logits=True,
    )
    bw = box[2] - box[0] + 1
    bh = box[3] - box[1] + 1
    box_area = float(bw * bh)

    best, best_val = None, -np.inf
    for k in range(masks.shape[0]):
        m = masks[k] > predictor.model.mask_threshold
        area = m.sum()
        if area == 0:
            continue
        # Fraction of the mask that lies inside the (slightly expanded) prompt box.
        inside = np.logical_and(m, prior["box_region"]).sum() / area
        if prior_is_poly:
            # Stay faithful to the existing hand drawn outline.
            val = iou(m, prior["mask"]) + 0.25 * float(scores[k])
        else:
            # Rectangles: SAM confidence, penalise masks that are tiny w.r.t.
            # the box (likely a sub-part) or that leak outside the box.
            frac = area / box_area
            val = float(scores[k]) - (0.5 if frac < 0.15 else 0.0) - (1.0 - inside)
        if val > best_val:
            best, best_val = k, val
    if best is None:
        return None
    return masks[best].astype(np.float32)


def convert(weights_path, output_path, rgb_path, csv_path):
    device = "cpu"
    torch.set_grad_enabled(False)

    # ---- inputs ----------------------------------------------------------- #
    df = pd.read_csv(csv_path)
    has_index = len(df.columns) > 0 and str(df.columns[0]).startswith("Unnamed")
    if has_index:
        df = pd.read_csv(csv_path, index_col=0)
        df.index.name = None

    image = np.array(Image.open(rgb_path).convert("RGB"))
    H, W = image.shape[:2]
    shape = (H, W)

    predictor = load_predictor(weights_path, device)
    predictor.set_image(image)

    n = len(df)
    boxes, priors, prior_masks = [], [], []
    for i in range(n):
        row = df.iloc[i]
        xs = parse_coords(row["coords_x"]) if "coords_x" in df.columns else np.array([])
        ys = parse_coords(row["coords_y"]) if "coords_y" in df.columns else np.array([])
        if len(xs) and len(xs) == len(ys):
            x0, x1 = int(xs.min()), int(xs.max())
            y0, y1 = int(ys.min()), int(ys.max())
        else:
            x0, x1 = int(row["xmin"]), int(row["xmax"])
            y0, y1 = int(row["ymin"]), int(row["ymax"])
        x0, x1 = sorted((int(np.clip(x0, 0, W - 1)), int(np.clip(x1, 0, W - 1))))
        y0, y1 = sorted((int(np.clip(y0, 0, H - 1)), int(np.clip(y1, 0, H - 1))))
        box = (x0, y0, x1, y1)

        rect = (len(xs) < 3 or len(xs) != len(ys) or is_rectangle(xs, ys))
        if rect:
            pmask = ellipse_mask(box, shape)
        else:
            pmask = polygon_mask(xs, ys, shape)
            if pmask.sum() == 0:
                pmask = ellipse_mask(box, shape)
                rect = True

        # Region a refined mask is allowed to occupy: the box plus a margin.
        mx = max(3, int(round(0.15 * (x1 - x0 + 1))))
        my = max(3, int(round(0.15 * (y1 - y0 + 1))))
        region = np.zeros(shape, dtype=bool)
        region[max(0, y0 - my):min(H, y1 + my + 1), max(0, x0 - mx):min(W, x1 + mx + 1)] = True

        boxes.append(box)
        priors.append({"mask": pmask, "box_region": region, "is_poly": not rect})
        prior_masks.append(pmask)

    # ---- SAM refinement + pixel assignment by highest logit --------------- #
    # label map: 0 = background, i+1 = cell i
    label = np.zeros(shape, dtype=np.int32)
    best_logit = np.full(shape, -np.inf, dtype=np.float32)
    thr = predictor.model.mask_threshold

    for i in tqdm(range(n), desc="MobileSAM"):
        p = priors[i]
        logits = sam_logits_for_cell(predictor, boxes[i], p, p["is_poly"], shape)
        if logits is None or not np.any((logits > thr) & p["box_region"]):
            # SAM produced nothing usable: fall back to the prior shape,
            # with a weak constant logit so real SAM masks win contested pixels.
            logits = np.where(p["mask"], 0.01, -1.0).astype(np.float32)
        logits = np.where(p["box_region"], logits, -np.inf)
        cand = logits > thr
        m = largest_component(cand)
        if m.sum() == 0:
            m = p["mask"]
            logits = np.where(m, 0.01, -np.inf).astype(np.float32)
        win = m & (logits > best_logit)
        label[win] = i + 1
        best_logit[win] = logits[win]

    # ---- per cell cleanup and polygon extraction (no overlaps) ------------ #
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    occupied = np.zeros(shape, dtype=bool)
    results = [None] * n

    # Process small cells first so they are not swallowed by large ones.
    areas = [(label == i + 1).sum() for i in range(n)]
    order = sorted(range(n), key=lambda i: areas[i])

    def finalize(m):
        """Clean mask m against occupied pixels; return polygon + raster."""
        m = m & ~occupied
        m = largest_component(m)
        if m.sum() == 0:
            return None, None
        # Fill holes, but never into pixels that belong to someone else.
        m = fill_holes(m) & ~occupied
        opened = cv2.morphologyEx(m.astype(np.uint8), cv2.MORPH_OPEN, kernel).astype(bool)
        if opened.sum() >= 0.5 * m.sum():
            m = opened
        m = largest_component(m)
        for _ in range(5):
            poly = mask_to_polygon(m)
            if not valid_polygon(poly):
                return None, None
            r = rasterize(poly, shape)
            clash = r & occupied
            if not clash.any():
                return poly, r
            # Polygon covered someone else's pixels (e.g. through a hole):
            # shrink away from them and try again.
            grown = cv2.dilate(clash.astype(np.uint8), kernel).astype(bool)
            m = largest_component(m & ~grown)
            if m.sum() == 0:
                return None, None
        return None, None

    for i in order:
        own = label == i + 1
        poly, r = finalize(own)
        if poly is None:
            # Fallbacks: prior shape (polyline / inscribed ellipse) on free pixels,
            # then the full box on free pixels.
            poly, r = finalize(prior_masks[i])
        if poly is None:
            x0, y0, x1, y1 = boxes[i]
            bm = np.zeros(shape, dtype=bool)
            bm[y0:y1 + 1, x0:x1 + 1] = True
            poly, r = finalize(bm)
        if poly is None:
            # Last resort: a tiny triangle at the closest free pixel to the box center.
            x0, y0, x1, y1 = boxes[i]
            cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
            free = ~cv2.dilate(occupied.astype(np.uint8), kernel).astype(bool)
            free[-1, :] = False
            free[:, -1] = False
            ys_f, xs_f = np.nonzero(free)
            if len(xs_f):
                k = int(np.argmin((xs_f - cx) ** 2 + (ys_f - cy) ** 2))
                fx, fy = int(xs_f[k]), int(ys_f[k])
                poly = np.array([[fx, fy], [fx + 1, fy], [fx, fy + 1]])
                r = rasterize(poly, shape) & ~occupied
            else:
                poly = np.array([[x0, y0], [min(x0 + 1, W - 1), y0], [x0, min(y0 + 1, H - 1)]])
                r = np.zeros(shape, dtype=bool)
        occupied |= r
        results[i] = poly

    # ---- write output ----------------------------------------------------- #
    out = df.copy()
    xmins, ymins, xmaxs, ymaxs, cxs, cys = [], [], [], [], [], []
    for i in range(n):
        poly = results[i]
        xs = poly[:, 0].astype(int)
        ys = poly[:, 1].astype(int)
        # Close the polyline (first point repeated), as in the input format.
        xs = np.append(xs, xs[0])
        ys = np.append(ys, ys[0])
        xmins.append(int(xs.min()))
        xmaxs.append(int(xs.max()))
        ymins.append(int(ys.min()))
        ymaxs.append(int(ys.max()))
        cxs.append(",".join(str(v) for v in xs.tolist()))
        cys.append(",".join(str(v) for v in ys.tolist()))
    out["xmin"] = xmins
    out["ymin"] = ymins
    out["xmax"] = xmaxs
    out["ymax"] = ymaxs
    out["coords_x"] = cxs
    out["coords_y"] = cys

    if output_path.lower().endswith(".csv"):
        out_file = output_path
        parent = os.path.dirname(os.path.abspath(out_file))
        os.makedirs(parent, exist_ok=True)
    else:
        os.makedirs(output_path, exist_ok=True)
        out_file = os.path.join(output_path, os.path.basename(csv_path))
    out.to_csv(out_file, index=has_index)
    print(f"Saved {n} refined masks to {out_file}")
    return out_file


def main():
    parser = argparse.ArgumentParser(description="Refine cell masks with MobileSAM.")
    names = {
        "weights_path": "Path to the MobileSAM weights (mobile_sam.pt).",
        "output_path": "Output folder (or .csv file path) for the refined masks.",
        "rgb_path": "Path to the RGB image.",
        "csv_path": "Path to the metadata csv.",
    }
    # Accept both positional (weights output rgb csv) and --flag style arguments.
    for name, help_text in names.items():
        parser.add_argument(f"pos_{name}", nargs="?", default=None, metavar=name,
                            help=help_text)
    for name, help_text in names.items():
        parser.add_argument(f"--{name}", type=str, default=None, help=help_text)
    args = parser.parse_args()
    vals = {}
    for name in names:
        v = getattr(args, name) or getattr(args, f"pos_{name}")
        if v is None:
            parser.error(f"missing required argument: {name}")
        vals[name] = v
    convert(vals["weights_path"], vals["output_path"], vals["rgb_path"], vals["csv_path"])


if __name__ == "__main__":
    main()
