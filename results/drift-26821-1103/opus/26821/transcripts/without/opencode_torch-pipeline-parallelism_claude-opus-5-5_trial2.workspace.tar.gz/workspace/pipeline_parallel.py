"""Pipeline-parallel training step (AFAB schedule) for LlamaForCausalLM."""

import torch
import torch.distributed as dist
import torch.nn.functional as F

try:
    from transformers.masking_utils import create_causal_mask
except Exception:  # pragma: no cover - older transformers
    create_causal_mask = None


def _partition_layers(num_layers, world_size, rank):
    """Return [start, end) layer indices for `rank`, balanced as evenly as possible."""
    base, rem = divmod(num_layers, world_size)
    start = rank * base + min(rank, rem)
    end = start + base + (1 if rank < rem else 0)
    return start, end


def _p2p(ops):
    if not ops:
        return
    reqs = dist.batch_isend_irecv(ops)
    for req in reqs:
        req.wait()


def _send(tensor, peer):
    _p2p([dist.P2POp(dist.isend, tensor.contiguous(), peer)])


def _recv(shape, peer, device, dtype):
    buf = torch.empty(shape, device=device, dtype=dtype)
    _p2p([dist.P2POp(dist.irecv, buf, peer)])
    return buf


def _stage_forward(model, hidden_states, start, end):
    """Run decoder layers [start, end) of the LLaMA base model."""
    base = model.model
    seq_len = hidden_states.shape[1]
    position_ids = torch.arange(seq_len, device=hidden_states.device).unsqueeze(0)

    causal_mask = None
    if create_causal_mask is not None:
        causal_mask = create_causal_mask(
            config=base.config,
            inputs_embeds=hidden_states,
            attention_mask=None,
            past_key_values=None,
            position_ids=position_ids,
        )

    position_embeddings = base.rotary_emb(hidden_states, position_ids=position_ids)

    for layer in base.layers[start:end]:
        out = layer(
            hidden_states,
            attention_mask=causal_mask,
            position_embeddings=position_embeddings,
            position_ids=position_ids,
            past_key_values=None,
            use_cache=False,
        )
        hidden_states = out[0] if isinstance(out, (tuple, list)) else out
    return hidden_states


def train_step_pipeline_afab(model, inputs, targets, device, dtype):
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    is_first = rank == 0
    is_last = rank == world_size - 1
    prev_rank = rank - 1
    next_rank = rank + 1

    num_layers = len(model.model.layers)
    start, end = _partition_layers(num_layers, world_size, rank)
    hidden_size = model.config.hidden_size
    num_microbatches = len(inputs)

    model.train()

    stage_inputs = []   # tensors received from previous stage (need grads)
    stage_outputs = []  # outputs to backprop from (loss on last stage)
    total_loss = torch.zeros((), device=device, dtype=torch.float32)

    # ---------------- All forward ----------------
    for i in range(num_microbatches):
        mb_shape = tuple(inputs[i].shape)  # [microbatch, seq_len]
        hidden_shape = (mb_shape[0], mb_shape[1], hidden_size)

        if is_first:
            input_ids = inputs[i].to(device)
            hidden = model.model.embed_tokens(input_ids).to(device=device, dtype=dtype)
            stage_in = None
        else:
            stage_in = _recv(hidden_shape, prev_rank, device, dtype)
            stage_in.requires_grad_(True)
            hidden = stage_in

        hidden = _stage_forward(model, hidden, start, end)

        if is_last:
            hidden = model.model.norm(hidden)
            logits = model.lm_head(hidden)
            tgt = targets[i].to(device)
            loss = F.cross_entropy(
                logits.reshape(-1, logits.size(-1)).float(), tgt.reshape(-1)
            ) / num_microbatches
            total_loss = total_loss + loss.detach().float()
            stage_outputs.append(loss)
        else:
            hidden = hidden.to(device=device, dtype=dtype)
            _send(hidden.detach(), next_rank)
            stage_outputs.append(hidden)

        stage_inputs.append(stage_in)

    # ---------------- All backward ----------------
    for i in range(num_microbatches):
        mb_shape = tuple(inputs[i].shape)
        hidden_shape = (mb_shape[0], mb_shape[1], hidden_size)
        out = stage_outputs[i]

        if is_last:
            out.backward()
        else:
            grad = _recv(hidden_shape, next_rank, device, dtype)
            torch.autograd.backward(out, grad_tensors=grad)

        if not is_first:
            stage_in = stage_inputs[i]
            grad_in = stage_in.grad
            if grad_in is None:
                grad_in = torch.zeros(hidden_shape, device=device, dtype=dtype)
            _send(grad_in.to(device=device, dtype=dtype), prev_rank)

        stage_outputs[i] = None
        stage_inputs[i] = None

    if is_last:
        return total_loss
    return None
