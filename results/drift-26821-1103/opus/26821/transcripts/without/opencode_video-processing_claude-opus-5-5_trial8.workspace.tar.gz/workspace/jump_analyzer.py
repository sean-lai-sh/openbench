#!/usr/bin/env python3
"""Hurdle jump analyzer.

Detects the takeoff and landing frames of a single hurdle jump in a video
recorded from a static camera, and writes them to a TOML file.

Approach
--------
1. Build a static background model as the per-pixel median of (sampled)
   frames. The runner only occupies any pixel for a short time, so the median
   is the empty scene (the first frame is also guaranteed empty).
2. For each frame, segment the athlete by background differencing, keep the
   dominant blob (plus nearby fragments), and measure the lowest foreground
   point (the feet) and the horizontal centre of the body.
3. The ground contact level is estimated from the frames where the athlete
   is fully visible. A frame is "airborne" when the lowest point of the body
   is clearly above the ground level.
4. The hurdle clearance is the airborne run of frames during which the
   athlete crosses the hurdle (the longest flight phase otherwise).
   takeoff = last ground-contact frame before that flight,
   landing = first ground-contact frame after that flight.

Usage:
    python jump_analyzer.py input.mp4 [output.toml]
"""

import os
import sys

import cv2
import numpy as np
import toml

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_OUTPUT = os.path.join(SCRIPT_DIR, "output.toml")
DEFAULT_INPUT = os.path.join(SCRIPT_DIR, "example_video.mp4")

DIFF_THRESHOLD = 35        # per-channel abs difference to call a pixel foreground
MIN_BLOB_AREA = 1500       # minimum athlete area (pixels) for a valid measurement
AIR_MARGIN_FRAC = 0.028    # airborne if feet are this fraction of height above ground


def read_frames(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise IOError("Cannot open video: %s" % path)
    frames = []
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frames.append(frame)
    cap.release()
    if not frames:
        raise IOError("No frames read from video: %s" % path)
    return frames


def stabilize(frames):
    """Compensate small camera jitter/drift by aligning every frame to the
    first (empty) frame with sub-pixel phase correlation (translation)."""
    ref = cv2.cvtColor(frames[0], cv2.COLOR_BGR2GRAY).astype(np.float32)
    h, w = ref.shape
    win = cv2.createHanningWindow((w, h), cv2.CV_32F)
    out = [frames[0]]
    prev_shift = (0.0, 0.0)
    for frame in frames[1:]:
        g = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY).astype(np.float32)
        (dx, dy), resp = cv2.phaseCorrelate(ref, g, win)
        if abs(dx) > 20 or abs(dy) > 20:
            dx, dy = prev_shift
        prev_shift = (dx, dy)
        M = np.float32([[1, 0, -dx], [0, 1, -dy]])
        out.append(cv2.warpAffine(frame, M, (w, h), flags=cv2.INTER_LINEAR,
                                  borderMode=cv2.BORDER_REPLICATE))
    return out


def build_background(frames):
    n = len(frames)
    step = max(1, n // 150)
    sample = np.stack(frames[::step]).astype(np.uint8)
    bg = np.median(sample, axis=0).astype(np.float32)
    k = np.ones((3, 3), np.uint8)
    # Per-pixel tolerance band to absorb residual sub-pixel misalignment.
    return bg, cv2.dilate(bg, k), cv2.erode(bg, k)


def athlete_mask(frame, bgm):
    bg, bg_hi, bg_lo = bgm
    f = frame.astype(np.float32)
    # Compensate small global exposure changes.
    gain = float(np.median(bg)) / max(float(np.median(f)), 1.0)
    f = f * gain
    diff = np.maximum(np.maximum(f - bg_hi, bg_lo - f), 0).max(axis=2)
    m = (diff > DIFF_THRESHOLD).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))

    # Group body fragments with a strong dilation, pick the dominant group.
    grouped = cv2.dilate(m, np.ones((25, 25), np.uint8))
    n, labels, stats, _ = cv2.connectedComponentsWithStats(grouped)
    if n <= 1:
        return None
    # Score each group by the number of real foreground pixels it contains.
    counts = np.bincount(labels[m > 0].ravel(), minlength=n)
    counts[0] = 0
    best = int(np.argmax(counts))
    if counts[best] < MIN_BLOB_AREA:
        return None
    return (m > 0) & (labels == best)


def measure(frames, bg):
    h, w = frames[0].shape[:2]
    data = []
    for frame in frames:
        mask = athlete_mask(frame, bg)
        if mask is None:
            data.append(None)
            continue
        rows = np.nonzero(mask.sum(axis=1) >= 2)[0]
        if len(rows) == 0:
            data.append(None)
            continue
        ys, xs = np.nonzero(mask)
        bottom = int(rows.max())
        top = int(rows.min())
        left, right = int(xs.min()), int(xs.max())
        data.append({
            "bottom": bottom,
            "top": top,
            "left": left,
            "right": right,
            "cx": float(xs.mean()),
            "area": int(len(xs)),
            "touches_edge": left <= 2 or right >= w - 3,
        })
    return data


def find_hurdle_x(bgm):
    """Locate the hurdle as the strongest vertical-edge column in the lower
    part of the background (hurdle posts are thin vertical structures)."""
    bg = bgm[0]
    h, w = bg.shape[:2]
    gray = cv2.cvtColor(bg.astype(np.uint8), cv2.COLOR_BGR2GRAY)
    band = gray[int(h * 0.25):int(h * 0.40)].astype(np.float32)
    gx = np.abs(cv2.Sobel(band, cv2.CV_32F, 1, 0, ksize=3)).sum(axis=0)
    gx = np.convolve(gx, np.ones(5) / 5, mode="same")
    margin = int(w * 0.05)
    gx[:margin] = 0
    gx[-margin:] = 0
    return int(np.argmax(gx))


def analyze(path):
    frames = stabilize(read_frames(path))
    h, w = frames[0].shape[:2]
    bg = build_background(frames)
    data = measure(frames, bg)
    n = len(frames)

    valid = [i for i, d in enumerate(data) if d is not None]
    if len(valid) < 3:
        raise RuntimeError("Athlete not detected in video")

    # Ground level: robust high percentile of foot heights in frames where
    # the athlete is fully visible.
    full = [data[i]["bottom"] for i in valid if not data[i]["touches_edge"]]
    if len(full) < 3:
        full = [data[i]["bottom"] for i in valid]
    ground = float(np.percentile(full, 85))
    margin = AIR_MARGIN_FRAC * h

    airborne = np.zeros(n, dtype=bool)
    for i in valid:
        airborne[i] = data[i]["bottom"] < ground - margin

    # Collect airborne runs (only between valid frames).
    runs = []
    i = 0
    while i < n:
        if airborne[i]:
            j = i
            while j + 1 < n and airborne[j + 1]:
                j += 1
            runs.append((i, j))
            i = j + 1
        else:
            i += 1
    if not runs:
        raise RuntimeError("No flight phase detected")

    hurdle_x = find_hurdle_x(bg)

    def run_score(run):
        s, e = run
        length = e - s + 1
        xs = [data[k]["cx"] for k in range(s, e + 1) if data[k] is not None]
        lefts = [data[k]["left"] for k in range(s, e + 1) if data[k] is not None]
        rights = [data[k]["right"] for k in range(s, e + 1) if data[k] is not None]
        crosses = (min(lefts) <= hurdle_x <= max(rights)) if xs else False
        # Distance of body centre to hurdle during flight.
        dist = min(abs(x - hurdle_x) for x in xs) if xs else w
        return (1 if crosses else 0, length, -dist)

    s, e = max(runs, key=run_score)

    # Takeoff: last ground-contact frame before flight; landing: first after.
    takeoff = s - 1
    while takeoff > 0 and data[takeoff] is None:
        takeoff -= 1
    landing = e + 1
    while landing < n - 1 and data[landing] is None:
        landing += 1
    takeoff = max(0, takeoff)
    landing = min(n - 1, landing)
    return int(takeoff), int(landing)


def main():
    in_path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_INPUT
    out_path = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_OUTPUT
    takeoff, landing = analyze(in_path)
    result = {
        "jump_takeoff_frame_number": takeoff,
        "jump_land_frame_number": landing,
    }
    with open(out_path, "w") as fh:
        toml.dump(result, fh)
    print(toml.dumps(result), end="")


if __name__ == "__main__":
    main()
