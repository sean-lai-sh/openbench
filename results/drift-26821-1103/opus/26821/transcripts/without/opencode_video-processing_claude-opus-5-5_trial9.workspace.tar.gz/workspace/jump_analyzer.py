#!/usr/bin/env python3
"""Hurdle jump analyzer.

Detects the takeoff and landing frames of a single hurdle jump in an MP4
filmed from a static camera, and writes them to a TOML file.

Method:
  1. The first frame (no runner) is used as the background model.
  2. For every frame the runner silhouette is segmented by colour difference
     to the background, and the lowest silhouette pixel (the feet) is found.
  3. The ground level is estimated from frames where the feet are lowest.
  4. Frames where the lowest point is clearly above the ground are "airborne".
     The longest airborne run (preferring one near the hurdle) is the jump.
  5. Takeoff = last ground-contact frame before the flight,
     landing  = first ground-contact frame after the flight.

Usage:
  python jump_analyzer.py [input.mp4] [output.toml]
"""
import os
import sys

import cv2
import numpy as np
import toml

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_INPUT = os.path.join(HERE, "example_video.mp4")
DEFAULT_OUTPUT = os.path.join(HERE, "output.toml")

DIFF_THRESH = 35          # per-channel colour difference to background
MIN_COMPONENT_AREA = 150  # px, ignore tiny noise blobs
HURDLE_X = (490, 625)     # approximate hurdle x-extent (fixed camera setup)


def read_frames(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise IOError("Cannot open video: %s" % path)
    frames = []
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frames.append(frame)
    cap.release()
    if not frames:
        raise IOError("No frames in video: %s" % path)
    return frames


class Background:
    """Background model tolerant to small camera jitter."""

    def __init__(self, frame):
        blur = cv2.GaussianBlur(frame, (5, 5), 0)
        self.gray = np.float32(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY))
        self.window = cv2.createHanningWindow(self.gray.shape[::-1], cv2.CV_32F)
        k = np.ones((3, 3), np.uint8)
        # per-pixel range of background values in a 3x3 neighbourhood
        self.lo = cv2.erode(blur, k).astype(np.int16)
        self.hi = cv2.dilate(blur, k).astype(np.int16)

    def align(self, frame):
        """Undo global translation of the frame relative to the background."""
        g = np.float32(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY))
        (dx, dy), _ = cv2.phaseCorrelate(self.gray, g, self.window)
        if abs(dx) > 20 or abs(dy) > 20:
            return frame
        m = np.float32([[1, 0, -dx], [0, 1, -dy]])
        return cv2.warpAffine(frame, m, (frame.shape[1], frame.shape[0]),
                              flags=cv2.INTER_LINEAR,
                              borderMode=cv2.BORDER_REPLICATE)

    def diff(self, frame):
        f = cv2.GaussianBlur(self.align(frame), (5, 5), 0).astype(np.int16)
        d = np.maximum(self.lo - f, f - self.hi)
        return np.clip(d, 0, None).max(axis=2)


def segment(frame, bg):
    diff = bg.diff(frame)
    mask = (diff > DIFF_THRESH).astype(np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    return mask


def runner_stats(mask):
    """Return (area, bottom_y, foot_x, top_y) of the runner, or None."""
    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask)
    if n <= 1:
        return None
    areas = stats[1:, cv2.CC_STAT_AREA]
    main = 1 + int(np.argmax(areas))
    if stats[main, cv2.CC_STAT_AREA] < MIN_COMPONENT_AREA:
        return None
    # include components close to the main blob (limbs split off etc.)
    x, y, w, h = stats[main, :4]
    mx, my = int(0.5 * w) + 20, int(0.25 * h) + 20
    keep = []
    for k in range(1, n):
        if stats[k, cv2.CC_STAT_AREA] < MIN_COMPONENT_AREA:
            continue
        kx, ky, kw, kh = stats[k, :4]
        if (kx + kw >= x - mx and kx <= x + w + mx and
                ky + kh >= y - my and ky <= y + h + my):
            keep.append(k)
    ys, xs = np.nonzero(np.isin(labels, keep))
    bottom = int(ys.max())
    foot_x = float(xs[ys >= bottom - 3].mean())
    return len(ys), bottom, foot_x, int(ys.min())


def find_runs(flags):
    runs, start = [], None
    for i, f in enumerate(flags):
        if f and start is None:
            start = i
        elif not f and start is not None:
            runs.append((start, i - 1))
            start = None
    if start is not None:
        runs.append((start, len(flags) - 1))
    return runs


def analyze(path):
    frames = read_frames(path)
    n = len(frames)
    bg = Background(frames[0])

    area = np.zeros(n)
    bottom = np.full(n, np.nan)
    foot_x = np.full(n, np.nan)
    height = np.full(n, np.nan)
    for i in range(1, n):
        st = runner_stats(segment(frames[i], bg))
        if st is None:
            continue
        area[i], bottom[i], foot_x[i] = st[0], st[1], st[2]
        height[i] = st[1] - st[3]

    if area.max() <= 0:
        raise RuntimeError("No runner detected")

    # frames where the runner is (mostly) visible and reliably segmented
    valid = area >= 0.35 * area.max()
    if valid.sum() < 3:
        raise RuntimeError("Runner detection too unreliable")

    vb = bottom[valid]
    hi = vb[vb >= np.percentile(vb, 50)]
    ground = float(np.median(hi))
    body_h = float(np.nanmedian(height[valid]))
    tol = max(8.0, 0.035 * body_h)

    airborne = valid & (bottom < ground - tol)
    # bridge single-frame gaps caused by detection dropouts inside a flight
    for i in range(1, n - 1):
        if not valid[i] and airborne[i - 1] and airborne[i + 1]:
            airborne[i] = True

    runs = find_runs(airborne)
    if not runs:
        raise RuntimeError("No airborne phase detected")

    hc = 0.5 * (HURDLE_X[0] + HURDLE_X[1])

    def score(run):
        s, e = run
        length = e - s + 1
        xs = foot_x[s:e + 1]
        xs = xs[~np.isnan(xs)]
        # does the flight span the hurdle horizontally?
        spans = 0.0
        if len(xs):
            lo = min(xs.min(), foot_x[max(s - 1, 0)] if not np.isnan(foot_x[max(s - 1, 0)]) else xs.min())
            hi_ = max(xs.max(), foot_x[min(e + 1, n - 1)] if not np.isnan(foot_x[min(e + 1, n - 1)]) else xs.max())
            spans = 1.0 if lo <= hc <= hi_ else 0.0
        # max clearance above ground
        clearance = ground - np.nanmin(bottom[s:e + 1])
        return (length + 3 * spans, clearance)

    s, e = max(runs, key=score)
    takeoff = max(s - 1, 0)
    landing = min(e + 1, n - 1)
    return int(takeoff), int(landing)


def main():
    inp = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_INPUT
    out = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_OUTPUT
    takeoff, landing = analyze(inp)
    result = {
        "jump_takeoff_frame_number": takeoff,
        "jump_land_frame_number": landing,
    }
    with open(out, "w") as f:
        toml.dump(result, f)
    print(toml.dumps(result), end="")


if __name__ == "__main__":
    main()
