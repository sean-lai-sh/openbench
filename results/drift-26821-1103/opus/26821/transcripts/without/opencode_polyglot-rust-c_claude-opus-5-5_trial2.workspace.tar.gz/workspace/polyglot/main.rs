/* /* */
#include <cstdio>
#include <cstdlib>
#include <string>
int main(int argc, char **argv) {
    unsigned long long n = argc > 1 ? strtoull(argv[1], 0, 10) : 0;
    unsigned __int128 a = 1, b = 1, t;
    for (unsigned long long i = 0; i < n; i++) { t = a + b; a = b; b = t; }
    std::string s;
    do { s.insert(s.begin(), char('0' + (int)(a % 10))); a /= 10; } while (a);
    printf("%s\n", s.c_str());
    return 0;
}
#if 0
// */
fn main() {
    let n: u64 = std::env::args().nth(1).and_then(|s| s.trim().parse().ok()).unwrap_or(0);
    let (mut a, mut b) = (1u128, 1u128);
    for _ in 0..n {
        let t = a.wrapping_add(b);
        a = b;
        b = t;
    }
    println!("{}", a);
}
/* /* */
#endif
// */
