#!/usr/bin/env python
"""Refine cell annotations (rectangles and polylines) into polylines with MobileSAM.

Every mask in the metadata csv is used as a box prompt for MobileSAM. The predicted
masks are then post-processed so that:
  * every cell is a single contiguous (4-connected) region without holes,
  * no two cells overlap (contested pixels go to the cell with the higher SAM logit),
  * every output mask is a non-rectangular closed polyline.

Usage:
    python convert_masks.py --weights_path mobile_sam.pt --output_path out/ \
        --rgb_path image.png --csv_path metadata.csv
(positional arguments in the same order are accepted as well)
"""
import argparse
import os

import cv2
import numpy as np
import pandas as pd
import torch
from tqdm import tqdm

from mobile_sam import SamPredictor, sam_model_registry

TILE = 1024          # max tile side fed to MobileSAM for large images
TILE_STRIDE = 768
BATCH = 16           # boxes per decoder call
MARGIN = 3           # px a refined mask may extend beyond the annotated bbox
MIN_AREA = 12        # min px area a final mask should have


# --------------------------------------------------------------------------- I/O
def parse_args():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    names = ["weights_path", "output_path", "rgb_path", "csv_path"]
    helps = ["Path to MobileSAM weights (mobile_sam.pt).",
             "Output folder (or .csv file path) for the refined masks.",
             "Path to the RGB image.",
             "Path to the metadata csv."]
    for n, h in zip(names, helps):
        p.add_argument(n, nargs="?", default=None, help=h)
        p.add_argument("--" + n, dest=n + "_opt", default=None, help=h)
    a = p.parse_args()
    for n in names:
        v = getattr(a, n + "_opt") or getattr(a, n)
        if v is None:
            p.error(f"missing required argument: {n}")
        setattr(a, n, v)
    return a


def load_rgb(path):
    img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    if img is None:
        raise FileNotFoundError(path)
    if img.dtype != np.uint8:
        img = cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    if img.ndim == 2:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
    elif img.shape[2] == 4:
        img = cv2.cvtColor(img, cv2.COLOR_BGRA2RGB)
    else:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return np.ascontiguousarray(img)


def parse_coords(v):
    if isinstance(v, (list, tuple, np.ndarray)):
        return [float(x) for x in v]
    s = str(v).strip().strip("[]()")
    return [float(x) for x in s.replace(";", ",").replace(" ", ",").split(",") if x.strip()]


def resolve_output_file(output_path, csv_path):
    if output_path.lower().endswith(".csv"):
        d = os.path.dirname(output_path)
        if d:
            os.makedirs(d, exist_ok=True)
        return output_path
    os.makedirs(output_path, exist_ok=True)
    return os.path.join(output_path, os.path.basename(csv_path))


# ------------------------------------------------------------------ mask helpers
def largest_component(mask):
    """Largest 4-connected component, with interior holes filled."""
    mask = mask.astype(np.uint8)
    if not mask.any():
        return mask.astype(bool)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=4)
    if n > 2:
        k = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
        mask = (lab == k).astype(np.uint8)
    return mask.astype(bool)


def fill_holes(mask):
    m = mask.astype(np.uint8)
    cnts, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    out = np.zeros_like(m)
    cv2.drawContours(out, cnts, -1, 1, thickness=cv2.FILLED)
    return out.astype(bool)


def clean(mask):
    """Remove 1-px spurs, keep the largest component, fill holes."""
    m = mask.astype(np.uint8)
    opened = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    if opened.sum() >= MIN_AREA:
        m = opened
    m = largest_component(m)
    return fill_holes(m) if m.any() else m


def ellipse_in_box(h, w, x0, y0, x1, y1, scale=1.0):
    """Filled ellipse inscribed in box [x0,x1]x[y0,y1] (inclusive) on an h x w canvas."""
    m = np.zeros((h, w), np.uint8)
    cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    ax = max(1, int(round((x1 - x0) / 2.0 * scale)))
    ay = max(1, int(round((y1 - y0) / 2.0 * scale)))
    cv2.ellipse(m, (int(round(cx)), int(round(cy))), (ax, ay), 0, 0, 360, 1, -1)
    return m.astype(bool)


# ------------------------------------------------------------------ SAM inference
def make_tiles(H, W):
    if max(H, W) <= TILE:
        return [(0, 0, W, H)]

    def starts(n):
        if n <= TILE:
            return [0]
        s = list(range(0, n - TILE, TILE_STRIDE))
        s.append(n - TILE)
        return sorted(set(s))
    return [(x, y, min(W, x + TILE), min(H, y + TILE)) for y in starts(H) for x in starts(W)]


def assign_tile(crop, tiles):
    """Tile that fully contains the crop window (exclusive end), with max margin."""
    x0, y0, x1, y1 = crop
    best, best_m = None, -1e9
    for ti, (tx0, ty0, tx1, ty1) in enumerate(tiles):
        m = min(x0 - tx0, y0 - ty0, tx1 - x1, ty1 - y1)
        if m > best_m:
            best, best_m = ti, m
    return best if best_m >= 0 else None


def run_sam(predictor, img, cells, device):
    """For each cell, fill cell['logit'] / cell['sam'] (crops over cell['crop'])."""
    H, W = img.shape[:2]
    tiles = make_tiles(H, W)
    groups = {}
    for i, c in enumerate(cells):
        ti = assign_tile(c["crop"], tiles)
        groups.setdefault(ti if ti is not None else -1, []).append(i)

    for ti, idxs in groups.items():
        tx0, ty0, tx1, ty1 = (0, 0, W, H) if ti == -1 else tiles[ti]
        predictor.set_image(np.ascontiguousarray(img[ty0:ty1, tx0:tx1]))
        for b in tqdm(range(0, len(idxs), BATCH), desc="MobileSAM", leave=False):
            bi = idxs[b:b + BATCH]
            boxes = np.array([[cells[i]["box"][0] - tx0, cells[i]["box"][1] - ty0,
                               cells[i]["box"][2] - tx0 + 1, cells[i]["box"][3] - ty0 + 1]
                              for i in bi], dtype=np.float32)
            tb = predictor.transform.apply_boxes_torch(
                torch.as_tensor(boxes, device=device), (ty1 - ty0, tx1 - tx0))
            with torch.no_grad():
                logits, scores, _ = predictor.predict_torch(
                    point_coords=None, point_labels=None, boxes=tb,
                    multimask_output=True, return_logits=True)
            logits = logits.cpu().numpy()
            scores = scores.cpu().numpy()
            for k, i in enumerate(bi):
                c = cells[i]
                cx0, cy0, cx1, cy1 = c["crop"]
                lg = logits[k][:, cy0 - ty0:cy1 - ty0, cx0 - tx0:cx1 - tx0]
                choose_mask(c, lg, scores[k])


def choose_mask(c, lg, scores):
    """Pick the best of SAM's multimask outputs for this cell."""
    allowed = c["allowed"]
    ref = c["ref"]
    best, best_val = None, -1e9
    box_area = float(allowed.sum()) or 1.0
    for j in range(lg.shape[0]):
        m = clean((lg[j] > 0) & allowed)
        area = m.sum()
        if area < MIN_AREA:
            continue
        frac = area / box_area
        if c["is_poly"]:
            inter = np.logical_and(m, ref).sum()
            union = np.logical_or(m, ref).sum()
            val = inter / max(union, 1) + 0.1 * scores[j]
        else:
            # box prompt: prefer confident masks that neither fill the whole box
            # (background / rectangle) nor are tiny fragments.
            val = scores[j]
            if frac > 0.97 or frac < 0.1:
                val -= 1.0
        if val > best_val:
            best, best_val = j, val
    if best is None:
        c["sam"] = None
        c["logit"] = None
        return
    c["logit"] = lg[best].astype(np.float32)
    c["sam"] = clean((lg[best] > 0) & allowed)


# --------------------------------------------------------------- post-processing
def resolve(cells, H, W):
    """Build a non-overlapping label map (0 = background, i+1 = cell i)."""
    label = np.zeros((H, W), np.int32)
    best = np.full((H, W), -np.inf, np.float32)
    for i, c in enumerate(cells):
        x0, y0, x1, y1 = c["crop"]
        m = c["mask"]
        s = np.where(m, c["score"], -np.inf).astype(np.float32)
        sub_b = best[y0:y1, x0:x1]
        sub_l = label[y0:y1, x0:x1]
        win = s > sub_b
        sub_b[win] = s[win]
        sub_l[win] = i + 1

    for _ in range(4):
        changed = False
        for i, c in enumerate(cells):
            x0, y0, x1, y1 = c["crop"]
            sub = label[y0:y1, x0:x1]
            own = sub == i + 1
            keep = largest_component(own) if own.any() else own

            # cells must not enclose other cells (exterior polygon would overlap).
            filled = fill_holes(keep) if keep.any() else keep
            inner = filled & ~keep & (sub > 0)
            if inner.any():
                keep = cut_enclosure(keep, inner)
                keep = largest_component(keep) if keep.any() else keep

            # tiny / vanished cell: give it a small ellipse at its own core.
            if keep.sum() < MIN_AREA:
                core = c["core"] & ((sub == 0) | (sub == i + 1))
                if core.sum() < MIN_AREA:
                    core = c["core"]
                core = largest_component(core)
                sub[core] = i + 1
                keep = largest_component(sub == i + 1)

            drop = own & ~keep
            if drop.any() or (keep & ~own).any():
                changed = True
            sub[(sub == i + 1) & ~keep] = 0
            sub[keep] = i + 1
        if not changed:
            break
    return label


def cut_enclosure(keep, inner):
    """Open a ring-shaped mask by removing a straight channel from the enclosed
    region to the nearest edge of the crop."""
    keep = keep.copy()
    h, w = keep.shape
    ys, xs = np.nonzero(inner)
    y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
    d = {"up": y0, "down": h - y1, "left": x0, "right": w - x1}
    side = min(d, key=d.get)
    if side == "up":
        keep[:y1, x0:x1] = False
    elif side == "down":
        keep[y0:, x0:x1] = False
    elif side == "left":
        keep[y0:y1, :x1] = False
    else:
        keep[y0:y1, x0:] = False
    return keep


def mask_to_polyline(mask):
    m = mask.astype(np.uint8)
    cnts, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cnts:
        return None
    cnt = max(cnts, key=lambda c: (cv2.contourArea(c), len(c)))
    return cnt.reshape(-1, 2)


def is_rectangle(pts):
    u = np.unique(pts, axis=0)
    if len(u) > 4:
        return False
    return len(np.unique(u[:, 0])) <= 2 and len(np.unique(u[:, 1])) <= 2


# -------------------------------------------------------------------------- main
def main():
    args = parse_args()
    device = "cpu"
    torch.set_grad_enabled(False)

    img = load_rgb(args.rgb_path)
    H, W = img.shape[:2]

    with open(args.csv_path) as f:
        header = f.readline()
    first = header.split(",")[0].strip().strip('"')
    has_index = first == "" or first.startswith("Unnamed")
    df = pd.read_csv(args.csv_path, index_col=0 if has_index else None)

    # ---------------------------------------------------------------- prompts
    cells = []
    for _, row in df.iterrows():
        xs = parse_coords(row["coords_x"]) if "coords_x" in row and pd.notna(row["coords_x"]) else []
        ys = parse_coords(row["coords_y"]) if "coords_y" in row and pd.notna(row["coords_y"]) else []
        n = min(len(xs), len(ys))
        xs, ys = np.array(xs[:n]), np.array(ys[:n])
        if n > 0:
            bx0, bx1, by0, by1 = xs.min(), xs.max(), ys.min(), ys.max()
        else:
            bx0, bx1, by0, by1 = row["xmin"], row["xmax"], row["ymin"], row["ymax"]
        bx0 = int(np.clip(np.floor(bx0), 0, W - 1)); bx1 = int(np.clip(np.ceil(bx1), 0, W - 1))
        by0 = int(np.clip(np.floor(by0), 0, H - 1)); by1 = int(np.clip(np.ceil(by1), 0, H - 1))
        if bx1 <= bx0:
            bx1 = min(W - 1, bx0 + 1); bx0 = max(0, bx1 - 1)
        if by1 <= by0:
            by1 = min(H - 1, by0 + 1); by0 = max(0, by1 - 1)

        cx0, cy0 = max(0, bx0 - MARGIN), max(0, by0 - MARGIN)
        cx1, cy1 = min(W, bx1 + MARGIN + 1), min(H, by1 + MARGIN + 1)
        ch, cw = cy1 - cy0, cx1 - cx0

        rtype = str(row["type"]).lower() if "type" in row else ""
        uniq = np.unique(np.stack([xs, ys], 1), axis=0) if n else np.zeros((0, 2))
        is_rect = rtype == "rectangle" or (len(uniq) <= 4 and is_rectangle(uniq))
        is_poly = (not is_rect) and n >= 3

        allowed = np.zeros((ch, cw), bool)
        allowed[by0 - cy0:by1 - cy0 + 1, bx0 - cx0:bx1 - cx0 + 1] = True
        if is_poly:
            ref = np.zeros((ch, cw), np.uint8)
            pts = np.round(np.stack([xs - cx0, ys - cy0], 1)).astype(np.int32)
            cv2.fillPoly(ref, [pts], 1)
            ref = ref.astype(bool)
            allowed = cv2.dilate(allowed.astype(np.uint8), np.ones((2 * MARGIN + 1,) * 2, np.uint8)).astype(bool)
            if ref.sum() < MIN_AREA:
                ref = ellipse_in_box(ch, cw, bx0 - cx0, by0 - cy0, bx1 - cx0, by1 - cy0)
        else:
            ref = ellipse_in_box(ch, cw, bx0 - cx0, by0 - cy0, bx1 - cx0, by1 - cy0)
        core = ellipse_in_box(ch, cw, bx0 - cx0, by0 - cy0, bx1 - cx0, by1 - cy0, scale=0.35)
        core &= ref if (core & ref).sum() >= 4 else core
        cells.append(dict(box=(bx0, by0, bx1, by1), crop=(cx0, cy0, cx1, cy1),
                          allowed=allowed, ref=ref, core=core, is_poly=is_poly))

    # ------------------------------------------------------------- MobileSAM
    if cells:
        sam = sam_model_registry["vit_t"](checkpoint=args.weights_path)
        sam.to(device=device)
        sam.eval()
        predictor = SamPredictor(sam)
        run_sam(predictor, img, cells, device)

    n_fallback = 0
    for c in cells:
        if c["sam"] is not None and c["sam"].sum() >= MIN_AREA:
            c["mask"] = c["sam"]
            c["score"] = c["logit"]
        else:  # SAM produced nothing usable: fall back to the annotation shape
            n_fallback += 1
            c["mask"] = clean(c["ref"]) if c["ref"].any() else c["core"]
            c["score"] = np.full(c["mask"].shape, -1.0, np.float32)

    label = resolve(cells, H, W) if cells else np.zeros((H, W), np.int32)

    # ------------------------------------------------------------- polylines
    out_x, out_y, xmin, xmax, ymin, ymax = [], [], [], [], [], []
    for i, c in enumerate(cells):
        x0, y0, x1, y1 = c["crop"]
        m = label[y0:y1, x0:x1] == i + 1
        pts = mask_to_polyline(m)
        if pts is None or len(pts) < 3 or is_rectangle(pts):
            # replace (near-)rectangular / degenerate result by an inscribed shape
            if m.any():
                ys_, xs_ = np.nonzero(m)
                e = ellipse_in_box(*m.shape, xs_.min(), ys_.min(), xs_.max(), ys_.max()) & m
                if e.sum() >= 3:
                    m2 = largest_component(e)
                    label[y0:y1, x0:x1][m & ~m2] = 0
                    m = m2
            pts = mask_to_polyline(m) if m.any() else None
            if pts is None or len(pts) < 3:
                # last resort: small diamond around the box centre
                bx0, by0, bx1, by1 = c["box"]
                cx, cy = (bx0 + bx1) // 2 - x0, (by0 + by1) // 2 - y0
                pts = np.array([[cx, cy - 1], [cx + 1, cy], [cx, cy + 1], [cx - 1, cy]])
        pts = pts + np.array([x0, y0])
        pts = np.vstack([pts, pts[:1]])  # closed polyline, like the input
        out_x.append(",".join(str(int(v)) for v in pts[:, 0]))
        out_y.append(",".join(str(int(v)) for v in pts[:, 1]))
        xmin.append(int(pts[:, 0].min())); xmax.append(int(pts[:, 0].max()))
        ymin.append(int(pts[:, 1].min())); ymax.append(int(pts[:, 1].max()))

    out = df.copy()
    out["xmin"], out["xmax"], out["ymin"], out["ymax"] = xmin, xmax, ymin, ymax
    out["coords_x"], out["coords_y"] = out_x, out_y
    if "type" in out.columns:
        out["type"] = "polyline"

    out_file = resolve_output_file(args.output_path, args.csv_path)
    out.to_csv(out_file, index=has_index)
    print(f"Refined {len(cells)} masks ({n_fallback} fallbacks) -> {out_file}")


if __name__ == "__main__":
    main()
