/* /* */
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <cstdint>
int main(int argc, char** argv) {
    long n = argc > 1 ? atol(argv[1]) : 0;
    // big integers, little-endian limbs in base 1e9
    std::vector<uint32_t> a{1}, b{1};
    for (long i = 0; i < n; i++) {
        std::vector<uint32_t> c;
        uint64_t carry = 0;
        for (size_t j = 0; j < b.size(); j++) {
            uint64_t s = carry + b[j] + (j < a.size() ? a[j] : 0);
            c.push_back((uint32_t)(s % 1000000000ULL));
            carry = s / 1000000000ULL;
        }
        if (carry) c.push_back((uint32_t)carry);
        a.swap(b);
        b.swap(c);
    }
    printf("%u", a.back());
    for (size_t j = a.size() - 1; j-- > 0;) printf("%09u", a[j]);
    printf("\n");
    return 0;
}
static const char* const rust_part = R"rust(
// */
fn main() {
    let n: u64 = std::env::args()
        .nth(1)
        .and_then(|s| s.trim().parse().ok())
        .unwrap_or(0);
    let mut a: Vec<u32> = vec![1];
    let mut b: Vec<u32> = vec![1];
    for _ in 0..n {
        let mut c: Vec<u32> = Vec::with_capacity(b.len() + 1);
        let mut carry: u64 = 0;
        for j in 0..b.len() {
            let s = carry + b[j] as u64 + if j < a.len() { a[j] as u64 } else { 0 };
            c.push((s % 1_000_000_000) as u32);
            carry = s / 1_000_000_000;
        }
        if carry > 0 {
            c.push(carry as u32);
        }
        a = b;
        b = c;
    }
    let mut out = format!("{}", a[a.len() - 1]);
    for j in (0..a.len() - 1).rev() {
        out.push_str(&format!("{:09}", a[j]));
    }
    println!("{}", out);
}
// )rust";
