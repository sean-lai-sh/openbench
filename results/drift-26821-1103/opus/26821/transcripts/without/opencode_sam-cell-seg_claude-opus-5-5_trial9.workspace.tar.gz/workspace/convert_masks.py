#!/usr/bin/env python
"""Refine cell annotations (rectangles and polylines) into polylines with MobileSAM.

Every annotation in the metadata csv is used as a prompt (bounding box + an
interior point) for MobileSAM.  The predicted masks are then post-processed so
that

  * every cell is represented by exactly one contiguous, hole-free polygon,
  * no two polygons overlap (or even touch),
  * no polygon is an axis-aligned rectangle.

The output csv has the same rows / columns as the input csv; only the
``xmin, ymin, xmax, ymax, coords_x, coords_y`` columns are updated.

Usage
-----
python convert_masks.py --weights_path mobile_sam.pt --output_path out_dir \
    --rgb_path slide.png --csv_path slide.csv
(positional arguments in the same order are accepted as well)
"""

import argparse
import glob
import importlib.util
import os
import re
import sys
import warnings

import cv2
import numpy as np
import pandas as pd
import torch
from tqdm import tqdm

warnings.filterwarnings("ignore", category=UserWarning)

_TV_SHIM_LIB = None


def _ensure_torchvision_importable():
    """Work around broken torchvision C++ extensions (e.g. CUDA torchvision
    wheel next to a CPU-only torch).  ``mobile_sam`` imports ``timm`` which
    imports ``torchvision``; when the torchvision extension cannot be loaded,
    ``import torchvision`` crashes while registering fake kernels for the
    ``torchvision::nms`` / ``torchvision::qnms`` operators.  In that case we
    declare those operator schemas ourselves (MobileSAM never calls them) so
    the import succeeds.  Nothing is done when torchvision is healthy."""
    global _TV_SHIM_LIB
    try:
        spec = importlib.util.find_spec("torchvision")
    except Exception:
        spec = None
    if spec is None or not spec.submodule_search_locations:
        return
    tv_dir = list(spec.submodule_search_locations)[0]
    libs = sorted(glob.glob(os.path.join(tv_dir, "_C*.so")) + glob.glob(os.path.join(tv_dir, "_C*.pyd")))
    for lib in libs:
        try:
            torch.ops.load_library(lib)
            return
        except Exception:
            pass
    try:
        _ = torch.ops.torchvision.nms
        return
    except Exception:
        pass
    try:
        _TV_SHIM_LIB = torch.library.Library("torchvision", "FRAGMENT")
        for name in ("nms", "qnms"):
            try:
                _TV_SHIM_LIB.define(f"{name}(Tensor dets, Tensor scores, float iou_threshold) -> Tensor")
            except Exception:
                pass
    except Exception:
        pass


_ensure_torchvision_importable()
from mobile_sam import SamPredictor, sam_model_registry  # noqa: E402

KERNEL3 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
KERNEL5 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))


# ----------------------------------------------------------------------------
# Parsing helpers
# ----------------------------------------------------------------------------
_NUM_RE = re.compile(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?")


def parse_coords(value):
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return np.zeros(0, dtype=np.float64)
    if isinstance(value, (list, tuple, np.ndarray)):
        return np.asarray(value, dtype=np.float64)
    return np.array([float(v) for v in _NUM_RE.findall(str(value))], dtype=np.float64)


def is_rectangle(xs, ys, type_value):
    if isinstance(type_value, str) and type_value.strip().lower().startswith("rect"):
        return True
    if len(xs) < 3:
        return True
    return len(np.unique(np.round(xs))) <= 2 and len(np.unique(np.round(ys))) <= 2


# ----------------------------------------------------------------------------
# Mask helpers
# ----------------------------------------------------------------------------
def largest_cc(mask, connectivity=4):
    mask = mask.astype(np.uint8)
    if not mask.any():
        return mask.astype(bool)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=connectivity)
    if n <= 2:
        return lab == 1
    k = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return lab == k


def fill_holes(mask):
    m = mask.astype(np.uint8)
    if not m.any():
        return mask.astype(bool)
    padded = np.pad(m, 1)
    contours, _ = cv2.findContours(padded, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    filled = np.zeros_like(padded)
    cv2.drawContours(filled, contours, -1, 1, thickness=cv2.FILLED)
    return filled[1:-1, 1:-1].astype(bool)


def iou(a, b):
    inter = np.logical_and(a, b).sum()
    union = np.logical_or(a, b).sum()
    return float(inter) / float(union) if union else 0.0


def clean_mask(mask, min_keep=1):
    """Opening + largest 4-connected component + hole filling.  Falls back to
    a less aggressive cleaning if the opening would delete the object."""
    mask = mask.astype(bool)
    opened = cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_OPEN, KERNEL3).astype(bool)
    out = largest_cc(opened)
    if out.sum() < min_keep:
        out = largest_cc(mask)
    return fill_holes(out)


# ----------------------------------------------------------------------------
# Cell container
# ----------------------------------------------------------------------------
class Cell:
    def __init__(self, idx, xs, ys, rect, H, W):
        self.idx = idx
        self.rect = rect
        xs = np.clip(xs, 0, W - 1)
        ys = np.clip(ys, 0, H - 1)
        self.xs, self.ys = xs, ys
        self.x0b, self.x1b = float(xs.min()), float(xs.max())
        self.y0b, self.y1b = float(ys.min()), float(ys.max())
        bw, bh = self.x1b - self.x0b + 1, self.y1b - self.y0b + 1
        margin = int(round(max(4.0, 0.2 * max(bw, bh))))
        self.wx0 = max(0, int(np.floor(self.x0b)) - margin)
        self.wy0 = max(0, int(np.floor(self.y0b)) - margin)
        self.wx1 = min(W, int(np.ceil(self.x1b)) + margin + 1)
        self.wy1 = min(H, int(np.ceil(self.y1b)) + margin + 1)
        self.prior = self._make_prior()
        self.prior_area = max(1, int(self.prior.sum()))
        self.mask = None      # bool mask in window coordinates
        self.logit = None     # float logits in window coordinates

    @property
    def wshape(self):
        return (self.wy1 - self.wy0, self.wx1 - self.wx0)

    def window_slice(self):
        return (slice(self.wy0, self.wy1), slice(self.wx0, self.wx1))

    def _make_prior(self):
        h, w = self.wshape
        prior = np.zeros((h, w), np.uint8)
        if self.rect:
            cx = (self.x0b + self.x1b) / 2.0 - self.wx0
            cy = (self.y0b + self.y1b) / 2.0 - self.wy0
            ax = max(1.0, (self.x1b - self.x0b) / 2.0)
            ay = max(1.0, (self.y1b - self.y0b) / 2.0)
            cv2.ellipse(prior, (int(round(cx)), int(round(cy))), (int(round(ax)), int(round(ay))),
                        0, 0, 360, 1, thickness=cv2.FILLED)
        else:
            pts = np.stack([self.xs - self.wx0, self.ys - self.wy0], 1)
            cv2.fillPoly(prior, [np.round(pts).astype(np.int32)], 1)
        if not prior.any():
            cy = int(round((self.y0b + self.y1b) / 2.0)) - self.wy0
            cx = int(round((self.x0b + self.x1b) / 2.0)) - self.wx0
            cv2.circle(prior, (cx, cy), 2, 1, thickness=cv2.FILLED)
        return prior.astype(bool)

    def interior_point(self):
        """Point (global coords) deep inside the prior region."""
        dist = cv2.distanceTransform(np.pad(self.prior.astype(np.uint8), 1), cv2.DIST_L2, 3)[1:-1, 1:-1]
        if self.rect:
            # Box centre unless it is very close to the prior border.
            cy = int(round((self.y0b + self.y1b) / 2.0)) - self.wy0
            cx = int(round((self.x0b + self.x1b) / 2.0)) - self.wx0
            cy = int(np.clip(cy, 0, dist.shape[0] - 1))
            cx = int(np.clip(cx, 0, dist.shape[1] - 1))
            if dist[cy, cx] > 0:
                return cx + self.wx0, cy + self.wy0
        cy, cx = np.unravel_index(int(np.argmax(dist)), dist.shape)
        return int(cx) + self.wx0, int(cy) + self.wy0


# ----------------------------------------------------------------------------
# Tiling (SAM works at 1024 px; large images are processed in tiles)
# ----------------------------------------------------------------------------
def tile_starts(length, tile, stride):
    if length <= tile:
        return [0]
    starts = list(range(0, length - tile + 1, stride))
    if starts[-1] != length - tile:
        starts.append(length - tile)
    return starts


def assign_tiles(cells, H, W, tile, overlap):
    stride = max(1, tile - overlap)
    ys = tile_starts(H, tile, stride)
    xs = tile_starts(W, tile, stride)
    tiles = {}
    for c in cells:
        best, best_d = None, -1
        for ty in ys:
            for tx in xs:
                th, tw = min(tile, H - ty), min(tile, W - tx)
                if c.wx0 >= tx and c.wy0 >= ty and c.wx1 <= tx + tw and c.wy1 <= ty + th:
                    d = min(c.wx0 - tx, c.wy0 - ty, tx + tw - c.wx1, ty + th - c.wy1)
                    if d > best_d:
                        best, best_d = (ty, tx, th, tw), d
        if best is None:  # cell does not fit in any regular tile -> custom tile
            size = max(tile, c.wy1 - c.wy0 + 64, c.wx1 - c.wx0 + 64)
            cy, cx = (c.wy0 + c.wy1) // 2, (c.wx0 + c.wx1) // 2
            ty = int(np.clip(cy - size // 2, 0, max(0, H - size)))
            tx = int(np.clip(cx - size // 2, 0, max(0, W - size)))
            best = (ty, tx, min(size, H - ty), min(size, W - tx))
        tiles.setdefault(best, []).append(c)
    return tiles


# ----------------------------------------------------------------------------
# SAM refinement
# ----------------------------------------------------------------------------
def refine_with_sam(predictor, image, cells, tile, overlap):
    H, W = image.shape[:2]
    tiles = assign_tiles(cells, H, W, tile, overlap)
    pbar = tqdm(total=len(cells), desc="MobileSAM", unit="cell")
    for (ty, tx, th, tw), tcells in tiles.items():
        predictor.set_image(np.ascontiguousarray(image[ty:ty + th, tx:tx + tw]))
        for c in tcells:
            box = np.array([c.x0b - tx, c.y0b - ty, c.x1b - tx, c.y1b - ty], dtype=np.float32)
            px, py = c.interior_point()
            pt = np.array([[px - tx, py - ty]], dtype=np.float32)
            candidates = []
            for use_point in (False, True):
                with torch.inference_mode():
                    logits, scores, _ = predictor.predict(
                        point_coords=pt if use_point else None,
                        point_labels=np.array([1]) if use_point else None,
                        box=box,
                        multimask_output=True,
                        return_logits=True,
                    )
                for k in range(logits.shape[0]):
                    candidates.append((logits[k], float(scores[k])))

            wy0, wy1 = c.wy0 - ty, c.wy1 - ty
            wx0, wx1 = c.wx0 - tx, c.wx1 - tx
            box_area = (c.x1b - c.x0b + 1) * (c.y1b - c.y0b + 1)
            best, best_score = None, -np.inf
            for L, s in candidates:
                full = L > 0
                total = int(full.sum())
                lw = L[wy0:wy1, wx0:wx1]
                mw = lw > 0
                area = int(mw.sum())
                if area == 0:
                    continue
                outside = 1.0 - area / max(total, 1)
                score = s + iou(mw, c.prior) - outside
                if c.rect and area > 0.92 * box_area:  # SAM just filled the box
                    score -= 2.0 * (area / box_area - 0.92)
                if score > best_score:
                    best, best_score = lw, score

            mask = None
            if best is not None:
                mask = clean_mask(best > 0, min_keep=max(9, int(0.1 * c.prior_area)))
                if mask.sum() < max(9, 0.15 * c.prior_area):
                    mask = None
            if mask is None:  # SAM failed -> use the prior shape (polygon / ellipse)
                mask = c.prior.copy()
                logit = np.where(mask, 1.0, -1.0).astype(np.float32)
            else:
                logit = best.astype(np.float32)
            c.mask = mask
            c.logit = logit
            pbar.update(1)
    pbar.close()


# ----------------------------------------------------------------------------
# Overlap resolution / topology clean-up on a global label map
# ----------------------------------------------------------------------------
def build_label_map(cells, H, W):
    lab = np.zeros((H, W), np.int32)
    best = np.full((H, W), -np.inf, np.float32)
    for i, c in enumerate(cells, 1):
        sl = c.window_slice()
        val = np.maximum(c.logit, 1e-3)  # filled holes may have negative logits
        claim = c.mask & (val > best[sl])
        lab[sl][claim] = i
        best[sl][claim] = val[claim]
    return lab


def cell_mask_from_label(lab, cells, i):
    c = cells[i - 1]
    return lab[c.window_slice()] == i


def set_cell_mask(lab, cells, i, new_mask):
    c = cells[i - 1]
    sub = lab[c.window_slice()]
    sub[(sub == i) & ~new_mask] = 0
    sub[new_mask] = i


def cut_holes(mask, other):
    """If ``mask`` has holes containing other cells (``other``), cut a thin
    channel from each such hole to the outside so the outer contour no longer
    encloses them.  Returns the modified mask (largest component)."""
    for _ in range(8):
        filled = fill_holes(mask)
        holes = filled & ~mask
        if not holes.any():
            return mask
        if not (holes & other).any():
            return mask  # empty holes are simply filled by the external contour
        n, hl = cv2.connectedComponents(holes.astype(np.uint8), connectivity=4)
        h, w = mask.shape
        for k in range(1, n):
            comp = hl == k
            if not (comp & other).any():
                continue
            yy, xx = np.nonzero(comp)
            cy, cx = int(np.median(yy)), int(np.median(xx))
            # choose the direction with the fewest mask pixels to cross
            options = [
                ("up", mask[:cy, cx][::-1]), ("down", mask[cy + 1:, cx]),
                ("left", mask[cy, :cx][::-1]), ("right", mask[cy, cx + 1:]),
            ]
            d = min(options, key=lambda o: int(o[1].sum()))[0]
            if d == "up":
                mask[:cy + 1, max(0, cx - 1):cx + 1] = False
            elif d == "down":
                mask[cy:, max(0, cx - 1):cx + 1] = False
            elif d == "left":
                mask[max(0, cy - 1):cy + 1, :cx + 1] = False
            else:
                mask[max(0, cy - 1):cy + 1, cx:] = False
        mask = largest_cc(mask)
    return mask


def separate_labels(lab):
    """Remove pixels that are 8-adjacent to a pixel with a larger label so
    that no two different cells touch (guarantees disjoint polygons)."""
    maxn = cv2.dilate(lab.astype(np.float32), np.ones((3, 3), np.uint8))
    remove = (lab > 0) & (maxn > lab)
    lab[remove] = 0
    return lab


def contour_of(mask):
    m = np.pad(mask.astype(np.uint8), 1)
    contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    cnt = max(contours, key=cv2.contourArea).reshape(-1, 2) - 1
    return cnt


def is_degenerate(mask):
    """True if the pixel contour revisits a vertex (self-touching polygon)."""
    m = np.pad(mask.astype(np.uint8), 1)
    contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if not contours:
        return True
    cnt = max(contours, key=len).reshape(-1, 2)
    return len(np.unique(cnt, axis=0)) != len(cnt) or len(cnt) < 4


def is_axis_rect(cnt):
    pts = np.unique(cnt, axis=0)
    return len(pts) <= 4 and len(np.unique(pts[:, 0])) <= 2 and len(np.unique(pts[:, 1])) <= 2


def tidy_cell(lab, cells, i):
    c = cells[i - 1]
    sl = c.window_slice()
    sub = lab[sl]
    mask = sub == i
    if not mask.any():
        return 0
    other = (sub > 0) & (sub != i)
    mask = largest_cc(mask)
    mask = cut_holes(mask, other)
    if is_degenerate(mask):
        for k in (KERNEL3, KERNEL5):
            m2 = largest_cc(cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_OPEN, k).astype(bool))
            if m2.sum() >= 5:
                mask = m2
                if not is_degenerate(mask):
                    break
    # filling empty holes is safe: they only border this cell
    filled = fill_holes(mask)
    if not (filled & other).any():
        mask = filled
    cnt = contour_of(mask)
    if cnt is not None and is_axis_rect(cnt):
        # never output a rectangle: intersect with the inscribed ellipse
        ys, xs = np.nonzero(mask)
        ell = np.zeros_like(mask, np.uint8)
        cv2.ellipse(ell, (int(round((xs.min() + xs.max()) / 2)), int(round((ys.min() + ys.max()) / 2))),
                    (max(1, (xs.max() - xs.min() + 1) // 2), max(1, (ys.max() - ys.min() + 1) // 2)),
                    0, 0, 360, 1, thickness=cv2.FILLED)
        m2 = largest_cc(mask & ell.astype(bool))
        if m2.sum() >= 3:
            mask = m2
    sub[(sub == i) & ~mask] = 0
    return int(mask.sum())


def ensure_present(lab, cells, i):
    """Give a cell that lost (almost) all of its pixels a small region back,
    taken from its own refined mask core (or a small disk at its centre)."""
    c = cells[i - 1]
    sub = lab[c.window_slice()]
    core = cv2.erode(c.mask.astype(np.uint8), KERNEL3).astype(bool)
    if core.sum() < 13:
        core = np.zeros_like(c.mask)
        ys, xs = np.nonzero(c.mask) if c.mask.any() else np.nonzero(c.prior)
        cy, cx = (int(np.median(ys)), int(np.median(xs))) if len(ys) else (core.shape[0] // 2, core.shape[1] // 2)
        tmp = np.zeros(core.shape, np.uint8)
        cv2.circle(tmp, (cx, cy), 3, 1, thickness=cv2.FILLED)
        core = tmp.astype(bool)
    sub[core] = i
    # clear a 1px ring of other cells around the reclaimed core
    ring = cv2.dilate(core.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool) & ~core
    sub[ring & (sub != i) & (sub > 0)] = 0


def polygons_raster(cells, polys, H, W):
    raster = np.zeros((H, W), np.int32)
    count = np.zeros((H, W), np.uint8)
    for i, cnt in enumerate(polys, 1):
        if cnt is None:
            continue
        c = cells[i - 1]
        tmp = np.zeros(c.wshape, np.uint8)
        local = cnt.astype(np.int32) - np.array([c.wx0, c.wy0], np.int32)
        cv2.fillPoly(tmp, [local.reshape(-1, 1, 2)], 1)
        m = tmp.astype(bool)
        sl = c.window_slice()
        count[sl] += m.astype(np.uint8)
        raster[sl][m] = i
    raster[count > 1] = 0
    return raster, count


def resolve(cells, H, W, min_area=5, max_iter=10):
    lab = build_label_map(cells, H, W)
    n = len(cells)
    polys = [None] * n
    for _ in range(max_iter):
        for i in range(1, n + 1):
            tidy_cell(lab, cells, i)
        areas = np.bincount(lab.ravel(), minlength=n + 1)
        small = [i for i in range(1, n + 1) if areas[i] < min_area]
        for i in small:
            ensure_present(lab, cells, i)
        if small:
            for i in range(1, n + 1):
                tidy_cell(lab, cells, i)
        separate_labels(lab)
        for i in range(1, n + 1):
            tidy_cell(lab, cells, i)

        polys = []
        for i in range(1, n + 1):
            c = cells[i - 1]
            cnt = contour_of(cell_mask_from_label(lab, cells, i))
            polys.append(None if cnt is None else cnt + np.array([c.wx0, c.wy0]))
        # verify: rasterized polygons must be disjoint, non-touching, and present
        raster, count = polygons_raster(cells, polys, H, W)
        maxn = cv2.dilate(raster.astype(np.float32), np.ones((3, 3), np.uint8))
        minn = -cv2.dilate(-np.where(raster > 0, raster, np.iinfo(np.int32).max).astype(np.float32),
                           np.ones((3, 3), np.uint8))
        touching = (raster > 0) & ((maxn > raster) | (minn < raster))
        areas = np.bincount(raster.ravel(), minlength=n + 1)
        ok = count.max(initial=0) <= 1 and not touching.any() and all(p is not None for p in polys) \
            and (areas[1:] >= 3).all()
        if ok:
            return polys
        lab = raster.copy()
        lab[touching] = 0
    return polys


# ----------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------
def resolve_output_file(output_path, csv_path):
    if output_path.lower().endswith(".csv"):
        parent = os.path.dirname(os.path.abspath(output_path))
        os.makedirs(parent, exist_ok=True)
        return output_path
    os.makedirs(output_path, exist_ok=True)
    return os.path.join(output_path, os.path.basename(csv_path))


def parse_args():
    p = argparse.ArgumentParser(description="Refine rectangle/polyline cell masks into polylines with MobileSAM.")
    names = ["weights_path", "output_path", "rgb_path", "csv_path"]
    helps = ["Path to the MobileSAM weights (mobile_sam.pt).",
             "Output folder (or .csv file path) for the refined masks.",
             "Path to the RGB image.",
             "Path to the metadata csv."]
    for name, h in zip(names, helps):
        p.add_argument(name, nargs="?", default=None, help=h)
        p.add_argument("--" + name, dest=name + "_opt", default=None, help=h)
    p.add_argument("--tile_size", type=int, default=512, help="Tile size used for large images.")
    p.add_argument("--tile_overlap", type=int, default=160, help="Overlap between tiles.")
    args = p.parse_args()
    for name in names:
        val = getattr(args, name + "_opt") or getattr(args, name)
        if val is None:
            p.error(f"missing required argument: {name}")
        setattr(args, name, val)
    return args


def main():
    args = parse_args()
    torch.set_grad_enabled(False)

    image = cv2.imread(args.rgb_path, cv2.IMREAD_COLOR)
    if image is None:
        from PIL import Image
        image = np.array(Image.open(args.rgb_path).convert("RGB"))
    else:
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    H, W = image.shape[:2]

    df = pd.read_csv(args.csv_path)
    out_file = resolve_output_file(args.output_path, args.csv_path)

    cells = []
    for row_i, (_, row) in enumerate(df.iterrows()):
        xs = parse_coords(row.get("coords_x"))
        ys = parse_coords(row.get("coords_y"))
        k = min(len(xs), len(ys))
        xs, ys = xs[:k], ys[:k]
        if k == 0:  # fall back to the bounding box columns
            x0, x1, y0, y1 = (float(row[c]) for c in ("xmin", "xmax", "ymin", "ymax"))
            xs = np.array([x0, x1, x1, x0, x0])
            ys = np.array([y0, y0, y1, y1, y0])
        rect = is_rectangle(xs, ys, row.get("type"))
        cells.append(Cell(row_i, xs, ys, rect, H, W))

    if cells:
        device = "cuda" if torch.cuda.is_available() else "cpu"
        sam = sam_model_registry["vit_t"](checkpoint=args.weights_path)
        sam.to(device=device)
        sam.eval()
        predictor = SamPredictor(sam)
        refine_with_sam(predictor, image, cells, args.tile_size, args.tile_overlap)
        polys = resolve(cells, H, W)
    else:
        polys = []

    out = df.copy()
    for col in ("xmin", "ymin", "xmax", "ymax"):
        if col not in out.columns:
            out[col] = 0
        out[col] = out[col].astype(object)
    for col in ("coords_x", "coords_y"):
        if col not in out.columns:
            out[col] = ""
        out[col] = out[col].astype(object)
    for row_i, cnt in enumerate(polys):
        if cnt is None:
            continue
        cnt = cnt.astype(int)
        closed = np.vstack([cnt, cnt[:1]])
        idx = out.index[row_i]
        out.at[idx, "xmin"] = int(cnt[:, 0].min())
        out.at[idx, "xmax"] = int(cnt[:, 0].max())
        out.at[idx, "ymin"] = int(cnt[:, 1].min())
        out.at[idx, "ymax"] = int(cnt[:, 1].max())
        out.at[idx, "coords_x"] = ",".join(str(int(v)) for v in closed[:, 0])
        out.at[idx, "coords_y"] = ",".join(str(int(v)) for v in closed[:, 1])

    out = out.rename(columns={c: "" for c in out.columns if str(c).startswith("Unnamed: ")})
    out.to_csv(out_file, index=False)
    print(f"Saved {len(out)} refined masks to {out_file}")


if __name__ == "__main__":
    sys.exit(main())
