"""Extract A1 (up to neuron permutation and row scaling) from a 1-hidden-layer
ReLU network using only black-box queries to forward(x).

Approach: along random lines the network is piecewise linear; each kink is a
point where one hidden neuron switches on/off. The difference of the input
gradient on the two sides of the kink equals a2_i * A1[i, :], i.e. a scaled
row of A1. Collect these over many lines and deduplicate.
"""
import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi, eps=1e-7, min_width=1e-9):
    """Return t values of kinks of g(t)=f(x0+t d) in [lo, hi]."""
    g = lambda t: f(x0 + t * d)
    slope = lambda t: (g(t + eps) - g(t - eps)) / (2 * eps)
    kinks = []

    def rec(a, b, ga, gb, sa, sb, depth):
        if depth > 80:
            return
        scale = max(1.0, abs(sa), abs(sb))
        tol = 1e-8 * scale
        mid = 0.5 * (a + b)
        gm = g(mid)
        if abs(sa - sb) < tol and abs(gm - (ga + gb) / 2) < tol * (b - a + 1e-12):
            return  # linear on [a, b]
        # Try assuming a single kink: intersect the two end lines
        if abs(sa - sb) > tol:
            t = (gb - ga + sa * a - sb * b) / (sa - sb)
            if a < t < b:
                pred = ga + sa * (t - a)
                if abs(g(t) - pred) < 1e-9 * scale and abs(gm - (ga + sa * (mid - a) if mid <= t else gb + sb * (mid - b))) < 1e-9 * scale:
                    # check slopes just around t are sa and sb
                    if (abs(slope(t - 1e-5) - sa) < 1e-6 * scale and
                            abs(slope(t + 1e-5) - sb) < 1e-6 * scale):
                        kinks.append(t)
                        return
        if b - a < min_width:
            return
        sm = slope(mid)
        rec(a, mid, ga, gm, sa, sm, depth + 1)
        rec(mid, b, gm, gb, sm, sb, depth + 1)

    rec(lo, hi, g(lo), g(hi), slope(lo), slope(hi), 0)
    return kinks


def grad(x, h=1e-7):
    gr = np.zeros(DIM)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = h
        gr[i] = (f(x + e) - f(x - e)) / (2 * h)
    return gr


def normalize(v):
    v = v / np.linalg.norm(v)
    j = np.argmax(np.abs(v))
    return v * np.sign(v[j])


def main():
    rows = []      # normalized directions
    counts = []
    stable = 0
    for it in range(400):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        new = 0
        for t in find_kinks(x0, d, -20.0, 20.0):
            xs = x0 + t * d
            delta = 1e-4
            diff = grad(xs + delta * d) - grad(xs - delta * d)
            if np.linalg.norm(diff) < 1e-8:
                continue
            v = normalize(diff)
            for k, r in enumerate(rows):
                if np.linalg.norm(r - v) < 1e-3:
                    counts[k] += 1
                    break
            else:
                rows.append(v)
                counts.append(1)
                new += 1
        stable = stable + 1 if new == 0 else 0
        if it >= 30 and stable >= 30:
            break

    # keep only directions seen more than once if there's noise
    rows = np.array(rows)
    counts = np.array(counts)
    if (counts > 1).sum() > 0 and (counts == 1).sum() > 0:
        rows = rows[counts > 1]
    np.save(OUT, rows)
    print(f"Recovered {rows.shape[0]} neurons; A1 shape estimate {rows.shape}")
    print(rows)
    return rows


if __name__ == "__main__":
    main()
