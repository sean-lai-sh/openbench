"""Pipeline-parallel training step (AFAB schedule) for HuggingFace LlamaForCausalLM."""

import torch
import torch.distributed as dist
import torch.nn.functional as F


def _partition_layers(num_layers, world_size, rank):
    """Return [start, end) layer indices for `rank`, balanced within one layer."""
    base, rem = divmod(num_layers, world_size)
    start = rank * base + min(rank, rem)
    end = start + base + (1 if rank < rem else 0)
    return start, end


def _build_causal_mask(model, hidden_states, position_ids):
    """Build the causal mask exactly as LlamaModel.forward does."""
    try:
        from transformers.masking_utils import create_causal_mask

        return create_causal_mask(
            config=model.config,
            inputs_embeds=hidden_states,
            attention_mask=None,
            past_key_values=None,
            position_ids=position_ids,
        )
    except Exception:
        # Fallback: explicit additive 4D causal mask.
        bsz, seq_len = hidden_states.shape[:2]
        min_val = torch.finfo(hidden_states.dtype).min
        mask = torch.full(
            (seq_len, seq_len), min_val, device=hidden_states.device, dtype=hidden_states.dtype
        )
        mask = torch.triu(mask, diagonal=1)
        return mask[None, None, :, :].expand(bsz, 1, seq_len, seq_len)


def _p2p(ops):
    if not ops:
        return
    reqs = dist.batch_isend_irecv(ops)
    for req in reqs:
        req.wait()


def _send(tensor, peer):
    _p2p([dist.P2POp(dist.isend, tensor.contiguous(), peer)])


def _recv(shape, peer, device, dtype):
    buf = torch.empty(shape, device=device, dtype=dtype)
    _p2p([dist.P2POp(dist.irecv, buf, peer)])
    return buf


def _stage_forward(model, x, start, end, is_first, is_last, device, dtype):
    """Run this rank's portion of the model.

    Returns (stage_input, output). On the first stage `x` is input ids and
    stage_input is None. On the last stage the output is the logits.
    """
    llama = model.model
    if is_first:
        input_ids = x.to(device)
        hidden_states = llama.embed_tokens(input_ids).to(dtype)
        stage_input = None
    else:
        stage_input = x.to(device=device, dtype=dtype).requires_grad_(True)
        hidden_states = stage_input

    seq_len = hidden_states.shape[1]
    position_ids = torch.arange(seq_len, device=device).unsqueeze(0)
    position_embeddings = llama.rotary_emb(hidden_states, position_ids=position_ids)
    causal_mask = _build_causal_mask(model, hidden_states, position_ids)

    for layer in llama.layers[start:end]:
        hidden_states = layer(
            hidden_states,
            attention_mask=causal_mask,
            position_ids=position_ids,
            position_embeddings=position_embeddings,
        )
        if isinstance(hidden_states, tuple):  # older transformers versions
            hidden_states = hidden_states[0]

    if is_last:
        hidden_states = llama.norm(hidden_states)
        output = model.lm_head(hidden_states)
    else:
        output = hidden_states
    return stage_input, output


def train_step_pipeline_afab(model, inputs, targets, device, dtype):
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    is_first = rank == 0
    is_last = rank == world_size - 1
    prev_rank = rank - 1
    next_rank = rank + 1

    num_layers = len(model.model.layers)
    start, end = _partition_layers(num_layers, world_size, rank)
    hidden_size = model.config.hidden_size
    num_microbatches = len(inputs)

    stage_inputs = []
    stage_outputs = []  # hidden states (non-last) or scaled losses (last)
    total_loss = None

    # ---------------- All forward ----------------
    for i in range(num_microbatches):
        mb, seq_len = inputs[i].shape[0], inputs[i].shape[1]
        act_shape = (mb, seq_len, hidden_size)

        if is_first:
            x = inputs[i]
        else:
            x = _recv(act_shape, prev_rank, device, dtype)

        stage_input, output = _stage_forward(
            model, x, start, end, is_first, is_last, device, dtype
        )

        if is_last:
            tgt = targets[i].to(device)
            loss = F.cross_entropy(
                output.reshape(-1, output.shape[-1]).float(), tgt.reshape(-1)
            ) / num_microbatches
            stage_outputs.append(loss)
            total_loss = loss.detach() if total_loss is None else total_loss + loss.detach()
        else:
            _send(output.detach().to(dtype), next_rank)
            stage_outputs.append(output)

        stage_inputs.append(stage_input)

    # ---------------- All backward ----------------
    for i in range(num_microbatches):
        mb, seq_len = inputs[i].shape[0], inputs[i].shape[1]
        act_shape = (mb, seq_len, hidden_size)

        if is_last:
            stage_outputs[i].backward()
        else:
            grad = _recv(act_shape, next_rank, device, dtype)
            torch.autograd.backward(stage_outputs[i], grad_tensors=grad)

        if not is_first:
            grad_in = stage_inputs[i].grad
            if grad_in is None:
                grad_in = torch.zeros(act_shape, device=device, dtype=dtype)
            _send(grad_in.to(device=device, dtype=dtype), prev_rank)

        # Free activations as soon as possible.
        stage_outputs[i] = None
        stage_inputs[i] = None

    return total_loss
