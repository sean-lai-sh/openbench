import torch
import torch.distributed as dist
import torch.nn as nn
import torch.nn.functional as F


def _world_size():
    if dist.is_available() and dist.is_initialized():
        return dist.get_world_size()
    return 1


def _rank():
    if dist.is_available() and dist.is_initialized():
        return dist.get_rank()
    return 0


# ---------------------------------------------------------------------------
# Autograd-aware communication primitives
# ---------------------------------------------------------------------------

class _CopyToParallelRegion(torch.autograd.Function):
    """Identity in forward, all-reduce of the gradient in backward."""

    @staticmethod
    def forward(ctx, x):
        return x

    @staticmethod
    def backward(ctx, grad):
        if _world_size() == 1:
            return grad
        grad = grad.contiguous().clone()
        dist.all_reduce(grad, op=dist.ReduceOp.SUM)
        return grad


class _ReduceFromParallelRegion(torch.autograd.Function):
    """All-reduce (sum) in forward, identity in backward."""

    @staticmethod
    def forward(ctx, x):
        if _world_size() == 1:
            return x
        x = x.contiguous().clone()
        dist.all_reduce(x, op=dist.ReduceOp.SUM)
        return x

    @staticmethod
    def backward(ctx, grad):
        return grad


class _ScatterToParallelRegion(torch.autograd.Function):
    """Split along last dim in forward (keep local chunk), all-gather in backward."""

    @staticmethod
    def forward(ctx, x):
        ws = _world_size()
        if ws == 1:
            return x
        return torch.chunk(x, ws, dim=-1)[_rank()].contiguous()

    @staticmethod
    def backward(ctx, grad):
        return _all_gather_last_dim(grad)


class _GatherFromParallelRegion(torch.autograd.Function):
    """All-gather along last dim in forward, split in backward."""

    @staticmethod
    def forward(ctx, x):
        return _all_gather_last_dim(x)

    @staticmethod
    def backward(ctx, grad):
        ws = _world_size()
        if ws == 1:
            return grad
        return torch.chunk(grad, ws, dim=-1)[_rank()].contiguous()


def _all_gather_last_dim(x):
    ws = _world_size()
    if ws == 1:
        return x
    x = x.contiguous()
    parts = [torch.empty_like(x) for _ in range(ws)]
    dist.all_gather(parts, x)
    return torch.cat(parts, dim=-1).contiguous()


# ---------------------------------------------------------------------------
# Parallel linear layers
# ---------------------------------------------------------------------------

class ColumnParallelLinear(nn.Module):
    """Y = X A + b with A split along its columns (i.e. the output dimension).

    The weight is stored in nn.Linear layout (out_features, in_features), so the
    output dimension (dim 0) is sharded. Outputs are all-gathered along the last
    dimension, so every rank returns the full output.
    """

    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.world_size = _world_size()
        self.rank = _rank()
        assert out_features % self.world_size == 0, \
            "out_features must be divisible by world_size"
        self.output_size_per_partition = out_features // self.world_size

        master_weight = master_weight.detach()
        assert tuple(master_weight.shape) == (out_features, in_features)
        start = self.rank * self.output_size_per_partition
        end = start + self.output_size_per_partition
        self.weight = nn.Parameter(master_weight[start:end, :].clone().contiguous())

        if bias:
            self.bias = nn.Parameter(
                torch.zeros(self.output_size_per_partition,
                            dtype=master_weight.dtype, device=master_weight.device)
            )
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        x = _CopyToParallelRegion.apply(x)
        local_out = F.linear(x, self.weight, self.bias)
        return _GatherFromParallelRegion.apply(local_out)


class RowParallelLinear(nn.Module):
    """Y = X A + b with A split along its rows (i.e. the input dimension).

    The weight is stored in nn.Linear layout (out_features, in_features), so the
    input dimension (dim 1) is sharded. The full input is split along its last
    dimension, each rank computes a partial product, the partial outputs are
    summed (all-reduce), and the full (unsharded) bias is added.
    """

    def __init__(self, in_features, out_features, bias, master_weight):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.world_size = _world_size()
        self.rank = _rank()
        assert in_features % self.world_size == 0, \
            "in_features must be divisible by world_size"
        self.input_size_per_partition = in_features // self.world_size

        master_weight = master_weight.detach()
        assert tuple(master_weight.shape) == (out_features, in_features)
        start = self.rank * self.input_size_per_partition
        end = start + self.input_size_per_partition
        self.weight = nn.Parameter(master_weight[:, start:end].clone().contiguous())

        if bias:
            self.bias = nn.Parameter(
                torch.zeros(out_features,
                            dtype=master_weight.dtype, device=master_weight.device)
            )
        else:
            self.register_parameter("bias", None)

    def forward(self, x):
        if x.shape[-1] == self.input_size_per_partition and self.world_size > 1 \
                and self.in_features != self.input_size_per_partition:
            # Input already partitioned.
            x_local = x
        else:
            x_local = _ScatterToParallelRegion.apply(x)
        partial = F.linear(x_local, self.weight)
        out = _ReduceFromParallelRegion.apply(partial)
        if self.bias is not None:
            out = out + self.bias
        return out
