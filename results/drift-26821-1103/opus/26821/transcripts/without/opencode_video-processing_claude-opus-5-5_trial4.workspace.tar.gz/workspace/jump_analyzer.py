#!/usr/bin/env python3
"""Hurdle jump analyzer.

Detects the takeoff and landing frames of a single hurdle jump in an MP4
video recorded from a static camera, and writes them to a TOML file.

Approach
--------
1. Every frame is compared with a temporally local background model (the
   per-pixel median of frames sampled at least 10 frames before/after it).
   This removes the static scene and is robust to slow lighting changes
   (clouds, auto exposure) that would break a fixed first-frame background.
2. Cast shadows are suppressed, the mask is cleaned with morphology and the
   largest connected component is taken as the athlete.
3. The lowest point of the athlete (feet) is tracked over time. The ground
   level is estimated robustly; frames whose lowest point is clearly above
   the ground are "airborne".
4. The hurdle clearance is the longest airborne run (tie-break: closest to
   the hurdle). Takeoff = last ground-contact frame before it, landing =
   first ground-contact frame after it.

Usage: python jump_analyzer.py [input.mp4] [output.toml]
"""

import os
import sys

import cv2
import numpy as np
import toml

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_INPUT = os.path.join(HERE, "example_video.mp4")
DEFAULT_OUTPUT = os.path.join(HERE, "output.toml")

# Approximate hurdle centre x in the reference geometry (960x540).
HURDLE_X_FRAC = 555.0 / 960.0

BG_OFFSETS = (-30, -24, -18, -12, 12, 18, 24, 30)
MIN_BG_GAP = 10
DIFF_THRESH = 30


def read_frames(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise IOError("Cannot open video: %s" % path)
    frames = []
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frames.append(frame)
    cap.release()
    if not frames:
        raise IOError("No frames read from: %s" % path)
    return frames


def local_background(stack, i):
    n = len(stack)
    idx = sorted(set(min(max(i + o, 0), n - 1) for o in BG_OFFSETS))
    idx = [j for j in idx if abs(j - i) >= MIN_BG_GAP]
    if not idx:  # very short video: fall back to the first frame
        idx = [0]
    return np.median(stack[idx], axis=0)


def foreground_mask(frame, bg):
    f = frame.astype(np.float32)
    diff = np.abs(f - bg).max(axis=2)
    mask = diff > DIFF_THRESH

    # Shadow suppression: uniformly darker pixels with unchanged chromaticity.
    ratio = (f + 1.0) / (bg + 1.0)
    rmin = ratio.min(axis=2)
    rmax = ratio.max(axis=2)
    shadow = (rmin > 0.45) & (rmax < 0.92) & ((rmax - rmin) < 0.08)
    mask &= ~shadow

    mask = mask.astype(np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE,
                            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 15)))
    return mask


def athlete_bottom(mask, min_area):
    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    if n <= 1:
        return None
    k = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    area = stats[k, cv2.CC_STAT_AREA]
    if area < min_area:
        return None
    x, y, w, h = stats[k, :4]
    if h < 0.15 * mask.shape[0]:
        return None
    comp = labels[y:y + h, x:x + w] == k
    ys, xs = np.nonzero(comp)
    bottom = int(ys.max()) + y
    # x of the lowest pixels (foot position)
    foot_x = float(xs[ys >= ys.max() - 2].mean()) + x
    return bottom, foot_x, x, x + w, area


def find_runs(flags):
    runs, start = [], None
    for i, f in enumerate(flags):
        if f and start is None:
            start = i
        elif not f and start is not None:
            runs.append((start, i - 1))
            start = None
    if start is not None:
        runs.append((start, len(flags) - 1))
    return runs


def analyze(path):
    frames = read_frames(path)
    h, w = frames[0].shape[:2]
    stack = np.stack([cv2.GaussianBlur(f, (5, 5), 0) for f in frames]).astype(np.float32)
    n = len(frames)
    min_area = 0.004 * h * w

    bottoms = np.full(n, np.nan)
    foot_x = np.full(n, np.nan)
    centers = np.full(n, np.nan)
    for i in range(n):
        bg = local_background(stack, i)
        mask = foreground_mask(stack[i], bg)
        res = athlete_bottom(mask, min_area)
        if res is None:
            continue
        b, fx, x0, x1, _ = res
        bottoms[i] = b
        foot_x[i] = fx
        centers[i] = 0.5 * (x0 + x1)

    valid = ~np.isnan(bottoms)
    if valid.sum() < 3:
        raise RuntimeError("Athlete not detected")

    vidx = np.nonzero(valid)[0]
    # Restrict to the main contiguous segment where the athlete is visible
    # (allow small detection gaps, e.g. while over the hurdle).
    segs, s = [], vidx[0]
    for a, b in zip(vidx[:-1], vidx[1:]):
        if b - a > 4:
            segs.append((s, a))
            s = b
    segs.append((s, vidx[-1]))
    s0, s1 = max(segs, key=lambda se: valid[se[0]:se[1] + 1].sum())

    # Fill short gaps inside the segment as airborne (very high bottom).
    seg_b = bottoms[s0:s1 + 1].copy()

    known = seg_b[~np.isnan(seg_b)]
    ground = float(np.percentile(known, 85))
    thr = max(8.0, 0.02 * h)

    airborne = np.where(np.isnan(seg_b), True, seg_b < ground - thr)
    runs = find_runs(list(airborne))
    # Ignore runs touching segment borders (athlete entering/leaving frame).
    inner = [r for r in runs if r[0] > 0 and r[1] < len(seg_b) - 1] or runs

    hurdle_x = HURDLE_X_FRAC * w

    def score(r):
        a, b = r
        length = b - a + 1
        cx = np.nanmean(centers[s0 + a:s0 + b + 1])
        dist = abs(cx - hurdle_x) if not np.isnan(cx) else w
        return (length - dist / (0.25 * w), -dist)

    a, b = max(inner, key=score)
    takeoff = s0 + a - 1
    land = s0 + b + 1
    takeoff = int(min(max(takeoff, 0), n - 1))
    land = int(min(max(land, 0), n - 1))
    return takeoff, land


def main():
    in_path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_INPUT
    out_path = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_OUTPUT
    takeoff, land = analyze(in_path)
    result = {
        "jump_takeoff_frame_number": int(takeoff),
        "jump_land_frame_number": int(land),
    }
    with open(out_path, "w") as fh:
        toml.dump(result, fh)
    print(toml.dumps(result), end="")


if __name__ == "__main__":
    main()
