"""Pipeline-parallel training step (AFAB schedule) for LlamaForCausalLM."""

import sys

import torch
import torch.distributed as dist
import torch.nn.functional as F


def _partition_layers(num_layers, world_size, rank):
    """Return [start, end) layer indices for ``rank`` with a balanced split."""
    base, rem = divmod(num_layers, world_size)
    start = rank * base + min(rank, rem)
    end = start + base + (1 if rank < rem else 0)
    return start, end


def _build_causal_mask(model, hidden_states, position_ids):
    """Build the attention mask exactly as LlamaModel.forward would."""
    module = sys.modules.get(type(model.model).__module__)
    create_causal_mask = getattr(module, "create_causal_mask", None) if module else None
    if create_causal_mask is not None:
        try:
            return create_causal_mask(
                config=model.config,
                inputs_embeds=hidden_states,
                attention_mask=None,
                past_key_values=None,
                position_ids=position_ids,
            )
        except TypeError:
            # Older transformers signature.
            return create_causal_mask(
                config=model.config,
                input_embeds=hidden_states,
                attention_mask=None,
                cache_position=position_ids[0],
                past_key_values=None,
                position_ids=position_ids,
            )
    # Fallback: explicit additive 4D causal mask.
    seq_len = hidden_states.shape[1]
    mask = torch.full(
        (seq_len, seq_len),
        torch.finfo(hidden_states.dtype).min,
        device=hidden_states.device,
        dtype=hidden_states.dtype,
    )
    mask = torch.triu(mask, diagonal=1)
    return mask[None, None, :, :]


def _p2p(ops):
    if not ops:
        return
    reqs = dist.batch_isend_irecv(ops)
    for req in reqs:
        req.wait()


def _send(tensor, peer):
    _p2p([dist.P2POp(dist.isend, tensor.contiguous(), peer)])


def _recv(shape, peer, device, dtype):
    buf = torch.empty(shape, device=device, dtype=dtype)
    _p2p([dist.P2POp(dist.irecv, buf, peer)])
    return buf


def train_step_pipeline_afab(model, inputs, targets, device, dtype):
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    is_first = rank == 0
    is_last = rank == world_size - 1

    llama = model.model
    config = model.config
    num_layers = config.num_hidden_layers
    hidden_size = config.hidden_size
    start, end = _partition_layers(num_layers, world_size, rank)
    local_layers = [llama.layers[i] for i in range(start, end)]

    num_microbatches = len(inputs)

    # Saved state for backward.
    stage_inputs = []   # tensors received from previous stage (requires grad), or None
    stage_outputs = []  # hidden states sent to next stage, or the loss on last rank
    losses = []

    # ------------------------------------------------------------------
    # All forward
    # ------------------------------------------------------------------
    for mb in range(num_microbatches):
        input_ids = inputs[mb].to(device)
        mb_size, seq_len = input_ids.shape[0], input_ids.shape[1]
        hs_shape = (mb_size, seq_len, hidden_size)

        if is_first:
            hidden_states = llama.embed_tokens(input_ids).to(dtype)
            stage_input = None
        else:
            stage_input = _recv(hs_shape, rank - 1, device, dtype)
            stage_input.requires_grad_(True)
            hidden_states = stage_input

        position_ids = torch.arange(seq_len, device=device).unsqueeze(0)
        causal_mask = _build_causal_mask(model, hidden_states, position_ids)
        position_embeddings = llama.rotary_emb(hidden_states, position_ids=position_ids)

        for layer in local_layers:
            hidden_states = layer(
                hidden_states,
                attention_mask=causal_mask,
                position_ids=position_ids,
                past_key_values=None,
                use_cache=False,
                position_embeddings=position_embeddings,
            )
            if isinstance(hidden_states, (tuple, list)):
                hidden_states = hidden_states[0]

        if is_last:
            hidden_states = llama.norm(hidden_states)
            logits = model.lm_head(hidden_states)
            tgt = targets[mb].to(device)
            loss = F.cross_entropy(
                logits.reshape(-1, logits.shape[-1]).float(), tgt.reshape(-1)
            )
            loss = loss / num_microbatches
            losses.append(loss.detach())
            stage_outputs.append(loss)
        else:
            hidden_states = hidden_states.to(dtype)
            _send(hidden_states.detach(), rank + 1)
            stage_outputs.append(hidden_states)

        stage_inputs.append(stage_input)

    # ------------------------------------------------------------------
    # All backward
    # ------------------------------------------------------------------
    for mb in range(num_microbatches):
        output = stage_outputs[mb]
        if is_last:
            output.backward()
        else:
            grad = _recv(output.shape, rank + 1, device, dtype)
            torch.autograd.backward(output, grad_tensors=grad)

        if not is_first:
            stage_input = stage_inputs[mb]
            grad_in = stage_input.grad
            if grad_in is None:
                grad_in = torch.zeros_like(stage_input)
            _send(grad_in.to(device=device, dtype=dtype), rank - 1)

        stage_outputs[mb] = None
        stage_inputs[mb] = None

    if is_last and losses:
        return torch.stack(losses).sum()
    return None
