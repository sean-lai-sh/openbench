import json

OUT = "/tmp/obench-cell-8lcwp7l5/bench_opencode_regex-chess_ef7jocw4/re.json"
rules = []


def R(p, r):
    rules.append([p, r])


def rc(i):
    return divmod(i, 8)


def sq(r, c):
    return r * 8 + c


def onb(r, c):
    return 0 <= r < 8 and 0 <= c < 8


KN = [(1, 2), (2, 1), (-1, 2), (-2, 1), (1, -2), (2, -1), (-1, -2), (-2, -1)]
KG = [(a, b) for a in (-1, 0, 1) for b in (-1, 0, 1) if (a, b) != (0, 0)]
ORTH = [(1, 0), (-1, 0), (0, 1), (0, -1)]
DIAG = [(1, 1), (1, -1), (-1, 1), (-1, -1)]


def jumps(s, offs):
    r, c = rc(s)
    return [sq(r + a, c + b) for a, b in offs if onb(r + a, c + b)]


def rays(s, dirs):
    """yield (target, [between squares])"""
    r, c = rc(s)
    for a, b in dirs:
        between = []
        rr, cc = r + a, c + b
        while onb(rr, cc):
            yield sq(rr, cc), list(between)
            between.append(sq(rr, cc))
            rr += a
            cc += b


# ---------- 1. normalise input ----------
R(r"^(\S+ \S+ \S+ \S+).*$", r"\1")
for n in range(8, 1, -1):
    R(str(n) + r"(?=[^ ]* )", "1" * n)
R("/", "")
R(r"^(\S+) w ", r"\1 ")
R(r"\Z", "\n")


# ---------- 2. move generation (anchored on first line) ----------
def gen(cons, changes, castle_re=r"\S+", ep_re=r"\S+", new_ep="-"):
    special = set(cons) | set(changes)
    pat = r"\A"
    segs = []  # (kind, pos or length, groupnum)
    g = 0
    run = 0
    for p in range(65):
        if p < 64 and p not in special:
            run += 1
            continue
        if run:
            g += 1
            pat += "(.{%d})" % run
            segs.append(("run", None, g))
            run = 0
        if p == 64:
            break
        g += 1
        pat += "(" + cons.get(p, ".") + ")"
        segs.append(("sq", p, g))
    g += 1
    cg = g
    g += 1
    eg = g
    pat += " (" + castle_re + ") (" + ep_re + ")\n"
    gof = {p: gi for k, p, gi in segs if k == "sq"}
    orig = "".join(r"\g<%d>" % gi for _, _, gi in segs)
    orig += r" \g<%d> \g<%d>" % (cg, eg) + "\n"
    new = ""
    for k, p, gi in segs:
        if k == "run" or p not in changes:
            new += r"\g<%d>" % gi
        else:
            ch = changes[p]
            if isinstance(ch, int):
                new += r"\g<%d>" % gof[ch]
            else:
                new += ch
    new += r" \g<%d> " % cg + new_ep + "\n"
    R(pat, orig + new)


TGT = "[1a-z]"
for s in range(64):
    r, c = rc(s)
    for t in jumps(s, KN):
        gen({s: "N", t: TGT}, {s: "1", t: "N"})
    for t in jumps(s, KG):
        gen({s: "K", t: TGT}, {s: "1", t: "K"})
    for dirs, cls in ((ORTH, "[QR]"), (DIAG, "[QB]")):
        for t, btw in rays(s, dirs):
            cons = {b: "1" for b in btw}
            cons[s] = cls
            cons[t] = TGT
            gen(cons, {s: "1", t: s})
    if 1 <= r <= 6:
        t = s - 8
        promo = "Q" if r == 1 else "P"
        gen({s: "P", t: "1"}, {s: "1", t: promo})
        if r == 6:
            gen({s: "P", s - 8: "1", s - 16: "1"}, {s: "1", s - 16: "P"},
                new_ep="abcdefgh"[c] + "3")
        for dc in (-1, 1):
            if 0 <= c + dc < 8:
                t = s - 8 + dc
                gen({s: "P", t: "[a-z]"}, {s: "1", t: promo})

for c in range(8):
    t = 16 + c
    cp = 24 + c
    for dc in (-1, 1):
        if 0 <= c + dc < 8:
            s = 24 + c + dc
            gen({s: "P", t: "1", cp: "p"}, {s: "1", t: "P", cp: "1"},
                ep_re="abcdefgh"[c] + "6")

# castling: put kings on every square the king passes; filtered by check test
gen({60: "K", 61: "1", 62: "1", 63: "R"}, {61: "K", 62: "K"},
    castle_re=r"\S*K\S*")
gen({56: "R", 57: "1", 58: "1", 59: "1", 60: "K"}, {58: "K", 59: "K"},
    castle_re=r"\S*Q\S*")

# drop the original line
R(r"\A.*\n", "")


# ---------- 3. remove positions where a white king is attacked ----------
def render(cons):
    out = ""
    pos = 0
    for p in sorted(cons):
        if p > pos:
            out += ".{%d}" % (p - pos) if p - pos > 1 else "."
        out += cons[p]
        pos = p + 1
    return out


for k in range(64):
    r, c = rc(k)
    alts = []
    if r >= 1:
        if c > 0:
            alts.append({k - 9: "p"})
        if c < 7:
            alts.append({k - 7: "p"})
    for a in jumps(k, KN):
        alts.append({a: "n"})
    for a in jumps(k, KG):
        alts.append({a: "k"})
    for dirs, cls in ((ORTH, "[qr]"), (DIAG, "[qb]")):
        for a, btw in rays(k, dirs):
            cons = {b: "1" for b in btw}
            cons[a] = cls
            alts.append(cons)
    pre = "(?=.{%d}K)" % k if k else "(?=K)"
    R("(?m)^" + pre + "(?:" + "|".join(render(x) for x in alts) + r").*\n", "")

# ---------- 4. finish castling moves ----------
R(r"(?m)^(.{56})R1KKK", r"\g<1>11KR1")
R(r"(?m)^(.{60})KKKR", r"\g<1>1RK1")

# ---------- 5. castling rights ----------
R(r"(?m)^(.{60}[^K].{3} [^ K]*)K", r"\1")
R(r"(?m)^(.{60}[^K].{3} [^ Q]*)Q", r"\1")
R(r"(?m)^(.{63}[^R] [^ K]*)K", r"\1")
R(r"(?m)^(.{56}[^R].{7} [^ Q]*)Q", r"\1")
R(r"(?m)^(.{4}[^k].{59} [^ k]*)k", r"\1")
R(r"(?m)^(.{4}[^k].{59} [^ q]*)q", r"\1")
R(r"(?m)^(.{7}[^r].{56} [^ k]*)k", r"\1")
R(r"(?m)^([^r].{63} [^ q]*)q", r"\1")
R(r"(?m)^(.{64})  ", r"\1 - ")

# ---------- 6. back to FEN ----------
R(r"(?m)^" + "(.{8})" * 8 + " ", "/".join(r"\g<%d>" % i for i in range(1, 9)) + " ")
for n in range(8, 1, -1):
    R("1" * n, str(n))
R(r"(?m)^(\S+) (\S+) (\S+)$", r"\1 b \2 \3 0 0")
R(r"\n\Z", "")

json.dump(rules, open(OUT, "w"))
print(len(rules))
