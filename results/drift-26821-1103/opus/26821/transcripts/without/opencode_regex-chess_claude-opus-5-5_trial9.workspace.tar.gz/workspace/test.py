import json, re, random, time, os, chess

RULES = [(re.compile(p), r) for p, r in json.load(open(
    "/tmp/obench-cell-8lcwp7l5/bench_opencode_regex-chess_ef7jocw4/re.json"))]


def run(fen):
    for p, r in RULES:
        fen = p.sub(r, fen)
    return fen.split("\n")


def expected(fen):
    b = chess.Board(fen)
    s = set()
    for m in b.legal_moves:
        if m.promotion and m.promotion != chess.QUEEN:
            continue
        c = b.copy(); c.push(m)
        s.add(" ".join(c.fen().split(" ")[:-2]))
    return s


def check(fen):
    ours = [" ".join(x.split(" ")[:-2]) for x in run(fen)]
    exp = expected(fen)
    ok = len(ours) == len(exp) and all(
        x in exp or x.rpartition(" ")[0] + " -" in exp for x in ours)
    if not ok:
        print("FAIL", fen)
        print(" extra", [x for x in ours if not (x in exp or x.rpartition(" ")[0] + " -" in exp)])
        print(" missing", exp - set(ours) - {x.rpartition(" ")[0] + " -" for x in ours})
    return ok


ex = "rnb1k1nr/p2p1ppp/3B4/1p1NPN1P/6P1/3P1Q2/P1P5/q4Kb1 w kq - 0 1"
print(run(ex))
random.seed(int(os.environ.get("SEED", 1)))
n = fails = 0
t0 = time.time()
for g in range(int(os.environ.get("GAMES", 300))):
    b = chess.Board()
    while not b.is_game_over() and b.ply() < 300:
        if b.turn == chess.WHITE:
            n += 1
            if not check(b.fen()):
                fails += 1
                if fails > 5: raise SystemExit
        moves = list(b.legal_moves)
        caps = [m for m in moves if b.is_capture(m) or m.promotion]
        b.push(random.choice(caps if caps and random.random() < 0.3 else moves))
print("positions", n, "fails", fails, "time/pos", (time.time() - t0) / n)
