"""Black-box extraction of A1 (up to permutation and scaling of rows) from a
one-hidden-layer ReLU network f(x) = A2 relu(A1 x + b1) + b2, using only queries
to forward(x).

Method (critical-point / gradient-difference attack):
  1. Along random lines x(t) = x0 + t d, f is piecewise linear in t; each kink
     is where some neuron i crosses A1_i x + b1_i = 0.
  2. Locate kinks precisely by recursive bisection + intersecting the two
     linear pieces.
  3. At each kink, the input-gradient jumps by A2_i * A1_i. Estimating the
     gradient on both sides with finite differences recovers row i of A1 up
     to scale.
  4. Deduplicate directions (up to sign) across many lines.
"""
import os
import numpy as np
from forward import forward

DIM = 10
rng = np.random.default_rng(12345)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi, eps=1e-7, tol=1e-9, depth=0):
    """Return t values of kinks of g(t)=f(x0+t d) in [lo, hi]."""
    g = lambda t: f(x0 + t * d)
    ga, gb = g(lo), g(hi)
    sa = (g(lo + eps) - ga) / eps
    sb = (gb - g(hi - eps)) / eps
    gm = g((lo + hi) / 2)
    # Linear segment?
    if abs(sa - sb) < 1e-6 * max(1.0, abs(sa)) and \
            abs(gm - (ga + gb) / 2) < tol * max(1.0, abs(ga) + abs(gb)):
        return []
    if hi - lo < 1e-6 or depth > 60:
        return [(lo + hi) / 2]
    # Try single-kink hypothesis: intersect the two lines.
    if abs(sa - sb) > 1e-12:
        tk = (gb - ga + sa * lo - sb * hi) / (sa - sb)
        if lo < tk < hi:
            pred = ga + sa * (tk - lo)
            if abs(g(tk) - pred) < 1e-9 * max(1.0, abs(pred)):
                # check the pieces really are linear on each side
                m1, m2 = (lo + tk) / 2, (tk + hi) / 2
                if abs(g(m1) - (ga + sa * (m1 - lo))) < 1e-9 * max(1, abs(ga)) and \
                        abs(g(m2) - (gb + sb * (m2 - hi))) < 1e-9 * max(1, abs(gb)):
                    return [tk]
    mid = (lo + hi) / 2
    return find_kinks(x0, d, lo, mid, eps, tol, depth + 1) + \
        find_kinks(x0, d, mid, hi, eps, tol, depth + 1)


def grad(x, h=1e-6):
    g = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        g[j] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def normalize(v):
    v = v / np.linalg.norm(v)
    k = np.argmax(np.abs(v))
    return v * np.sign(v[k])


def main():
    rows = []
    no_new = 0
    n_lines = 0
    while no_new < 15 and n_lines < 300:
        n_lines += 1
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        kinks = find_kinks(x0, d, -50.0, 50.0)
        found_new = False
        for tk in kinks:
            xk = x0 + tk * d
            delta = 1e-4
            g1 = grad(xk - delta * d)
            g2 = grad(xk + delta * d)
            diff = g2 - g1
            if np.linalg.norm(diff) < 1e-8:
                continue
            v = normalize(diff)
            if any(abs(abs(np.dot(v, r)) - 1) < 1e-4 for r in rows):
                continue
            # sanity: a second nearby measurement should agree
            g1b = grad(xk - 2 * delta * d)
            g2b = grad(xk + 2 * delta * d)
            vb = g2b - g1b
            if np.linalg.norm(vb) < 1e-8 or abs(abs(np.dot(v, normalize(vb))) - 1) > 1e-4:
                continue
            rows.append(v)
            found_new = True
        no_new = 0 if found_new else no_new + 1

    A1_stolen = np.array(rows)
    print(f"Recovered {A1_stolen.shape[0]} neurons from {n_lines} lines")
    print(A1_stolen)
    np.save(OUT, A1_stolen)
    return A1_stolen


if __name__ == "__main__":
    main()
