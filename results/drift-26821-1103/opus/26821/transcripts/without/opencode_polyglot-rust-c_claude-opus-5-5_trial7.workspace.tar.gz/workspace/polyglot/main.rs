/* /* */
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>
#include <iostream>
int main(int argc, char** argv) {
    if (argc < 2) return 1;
    long n = std::atol(argv[1]);
    std::vector<int> a(1, 1), b(1, 1);
    for (long i = 0; i < n; i++) {
        std::vector<int> c;
        int carry = 0;
        for (size_t j = 0; j < a.size() || j < b.size() || carry; j++) {
            int s = carry + (j < a.size() ? a[j] : 0) + (j < b.size() ? b[j] : 0);
            c.push_back(s % 10);
            carry = s / 10;
        }
        a.swap(b);
        b.swap(c);
    }
    std::string out;
    for (size_t j = a.size(); j-- > 0;) out.push_back(char(48 + a[j]));
    std::cout << out << std::endl;
    return 0;
}
#if 0
*/
fn main() {
    let n: u64 = std::env::args().nth(1).expect("need N").trim().parse().expect("bad N");
    let mut a: Vec<u8> = vec![1];
    let mut b: Vec<u8> = vec![1];
    for _ in 0..n {
        let mut c: Vec<u8> = Vec::new();
        let mut carry = 0u8;
        let mut j = 0;
        while j < a.len() || j < b.len() || carry > 0 {
            let s = carry + if j < a.len() { a[j] } else { 0 } + if j < b.len() { b[j] } else { 0 };
            c.push(s % 10);
            carry = s / 10;
            j += 1;
        }
        a = b;
        b = c;
    }
    let s: String = a.iter().rev().map(|d| (b"0"[0] + d) as char).collect();
    println!("{}", s);
}
/* /* */
#endif
// */
