#!/usr/bin/env python
"""
Refine cell annotations (rectangles and polylines) into non-overlapping,
single-component polyline masks using MobileSAM.

Usage:
    python convert_masks.py --weights_path mobile_sam.pt --output_path out/ \
        --rgb_path image.png --csv_path metadata.csv

Positional arguments are also accepted in the order:
    weights_path output_path rgb_path csv_path
"""

import argparse
import os
import warnings

import cv2
import numpy as np
import pandas as pd
import torch
from tqdm import tqdm

warnings.filterwarnings("ignore")

from mobile_sam import SamPredictor, sam_model_registry  # noqa: E402


# --------------------------------------------------------------------------- #
# I/O helpers
# --------------------------------------------------------------------------- #
def parse_args():
    p = argparse.ArgumentParser(description="Refine cell masks to polylines with MobileSAM.")
    names = ["weights_path", "output_path", "rgb_path", "csv_path"]
    helps = [
        "Path to the MobileSAM weights (mobile_sam.pt).",
        "Output folder (or .csv file path) for the refined masks.",
        "Path to the RGB image.",
        "Path to the metadata csv.",
    ]
    for n, h in zip(names, helps):
        p.add_argument(f"pos_{n}", nargs="?", default=None, help=argparse.SUPPRESS)
        p.add_argument(f"--{n}", type=str, default=None, help=h)
    p.add_argument("--tile_size", type=int, default=512,
                   help="Side of the image windows fed to MobileSAM (smaller = more upsampling).")
    args = p.parse_args()
    for n in names:
        if getattr(args, n) is None:
            setattr(args, n, getattr(args, f"pos_{n}"))
        if getattr(args, n) is None:
            p.error(f"argument {n} is required")
    return args


def load_rgb(path):
    img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    if img is None:
        from PIL import Image
        img = np.array(Image.open(path).convert("RGB"))
        return np.ascontiguousarray(img)
    if img.dtype != np.uint8:
        img = cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    if img.ndim == 2:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
    elif img.shape[2] == 4:
        img = cv2.cvtColor(img, cv2.COLOR_BGRA2RGB)
    else:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return np.ascontiguousarray(img)


def parse_coords(s):
    if isinstance(s, (list, tuple, np.ndarray)):
        return np.asarray(s, dtype=float)
    s = str(s).strip().strip("[]()")
    vals = [v for v in s.replace(";", ",").replace(" ", ",").split(",") if v.strip() != ""]
    return np.asarray([float(v) for v in vals], dtype=float)


def load_model(weights_path):
    model = sam_model_registry["vit_t"]()
    state = torch.load(weights_path, map_location="cpu")
    if isinstance(state, dict) and "model" in state and not any(k.startswith("image_encoder") for k in state):
        state = state["model"]
    model.load_state_dict(state)
    model.to("cpu").eval()
    return SamPredictor(model)


# --------------------------------------------------------------------------- #
# Mask helpers
# --------------------------------------------------------------------------- #
def polygon_mask(xs, ys, shape):
    m = np.zeros(shape, np.uint8)
    pts = np.stack([np.round(xs), np.round(ys)], axis=1).astype(np.int32)
    if len(pts) >= 3:
        cv2.fillPoly(m, [pts], 1)
    elif len(pts) > 0:
        for x, y in pts:
            if 0 <= y < shape[0] and 0 <= x < shape[1]:
                m[y, x] = 1
    return m.astype(bool)


def ellipse_mask(box, shape):
    """Ellipse inscribed in the box (fallback shape that is never rectangular)."""
    x0, y0, x1, y1 = box
    m = np.zeros(shape, np.uint8)
    c = (int(round((x0 + x1) / 2)), int(round((y0 + y1) / 2)))
    ax = (max(int(round((x1 - x0) / 2)), 2), max(int(round((y1 - y0) / 2)), 2))
    cv2.ellipse(m, c, ax, 0, 0, 360, 1, -1)
    return m.astype(bool)


def largest_component(mask, seed=None):
    """Keep one 4-connected component (the largest, or the one most overlapping `seed`)."""
    if not mask.any():
        return mask
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask.astype(np.uint8), connectivity=4)
    if n <= 2:
        return lab == 1
    areas = stats[1:, cv2.CC_STAT_AREA].astype(float)
    if seed is not None and seed.any():
        ov = np.bincount(lab[seed].ravel(), minlength=n)[1:].astype(float)
        score = ov * 1e6 + areas  # prefer overlap with seed, then size
    else:
        score = areas
    return lab == (1 + int(np.argmax(score)))


def clean_mask(mask, seed=None):
    """Smooth, fill holes and keep a single component."""
    m = mask.astype(np.uint8)
    if m.sum() > 30:
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        opened = cv2.morphologyEx(m, cv2.MORPH_OPEN, k)
        if opened.sum() > 0:
            m = opened
    m = largest_component(m.astype(bool), seed).astype(np.uint8)
    # fill holes
    cnts, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if cnts:
        filled = np.zeros_like(m)
        cv2.drawContours(filled, cnts, -1, 1, -1)
        m = filled
    return m.astype(bool)


def iou(a, b):
    inter = np.logical_and(a, b).sum()
    union = np.logical_or(a, b).sum()
    return inter / union if union else 0.0


def mask_to_polygon(mask):
    """Return closed polygon (xs, ys) of the outer contour of a single-component mask."""
    m = mask.astype(np.uint8)
    cnts, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cnts:
        return None
    c = max(cnts, key=cv2.contourArea)[:, 0, :]
    if len(c) < 3:
        return None
    xs = c[:, 0].astype(int).tolist()
    ys = c[:, 1].astype(int).tolist()
    xs.append(xs[0])
    ys.append(ys[0])
    return xs, ys


def is_rectangle(xs, ys):
    pts = set(zip(xs, ys))
    if len(pts) > 4:
        return False
    return len(set(xs)) <= 2 and len(set(ys)) <= 2


# --------------------------------------------------------------------------- #
# Windows (tiles) – SAM works at 1024px; cropping small windows upsamples cells
# --------------------------------------------------------------------------- #
def choose_window(box, H, W, tile):
    x0, y0, x1, y1 = box
    bw, bh = x1 - x0 + 1, y1 - y0 + 1
    if H <= tile and W <= tile:
        return (0, 0, W, H)
    stride = tile // 2

    def starts(L):
        if L <= tile:
            return [0]
        s = list(range(0, L - tile + 1, stride))
        if s[-1] != L - tile:
            s.append(L - tile)
        return s

    pad = 8
    if bw + 2 * pad <= tile and bh + 2 * pad <= tile:
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        best, bd = None, None
        for sy in starts(H):
            for sx in starts(W):
                ex, ey = sx + min(tile, W), sy + min(tile, H)
                if x0 - pad >= sx - (sx == 0) * pad and y0 - pad >= sy - (sy == 0) * pad \
                        and x1 + pad < ex + (ex == W) * pad and y1 + pad < ey + (ey == H) * pad:
                    d = (cx - (sx + ex) / 2) ** 2 + (cy - (sy + ey) / 2) ** 2
                    if bd is None or d < bd:
                        best, bd = (sx, sy, ex, ey), d
        if best is not None:
            return best
    # large object: custom window around the box
    side = int(max(bw, bh) * 1.5) + 2 * pad
    cx, cy = int((x0 + x1) / 2), int((y0 + y1) / 2)
    sx = int(np.clip(cx - side // 2, 0, max(W - side, 0)))
    sy = int(np.clip(cy - side // 2, 0, max(H - side, 0)))
    return (sx, sy, min(sx + side, W), min(sy + side, H))


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main():
    args = parse_args()
    torch.set_grad_enabled(False)

    img = load_rgb(args.rgb_path)
    H, W = img.shape[:2]
    df = pd.read_csv(args.csv_path, index_col=0)
    n = len(df)

    predictor = load_model(args.weights_path)

    # ---- parse annotations ------------------------------------------------ #
    boxes, priors, is_rect = [], [], []
    for _, row in df.iterrows():
        try:
            xs, ys = parse_coords(row["coords_x"]), parse_coords(row["coords_y"])
        except Exception:
            xs, ys = np.array([]), np.array([])
        if len(xs) and len(xs) == len(ys):
            x0, x1, y0, y1 = xs.min(), xs.max(), ys.min(), ys.max()
        else:
            x0, x1, y0, y1 = row["xmin"], row["xmax"], row["ymin"], row["ymax"]
            xs = np.array([x0, x1, x1, x0, x0], float)
            ys = np.array([y0, y0, y1, y1, y0], float)
        x0, x1 = float(np.clip(x0, 0, W - 1)), float(np.clip(x1, 0, W - 1))
        y0, y1 = float(np.clip(y0, 0, H - 1)), float(np.clip(y1, 0, H - 1))
        if x1 < x0:
            x0, x1 = x1, x0
        if y1 < y0:
            y0, y1 = y1, y0
        boxes.append((x0, y0, x1, y1))
        rect = str(row.get("type", "")).lower().startswith("rect") or is_rectangle(
            np.round(xs).astype(int).tolist(), np.round(ys).astype(int).tolist())
        is_rect.append(rect)
        priors.append(polygon_mask(xs, ys, (H, W)))

    # ---- group by window and run MobileSAM -------------------------------- #
    windows = [choose_window(b, H, W, args.tile_size) for b in boxes]
    groups = {}
    for i, w in enumerate(windows):
        groups.setdefault(w, []).append(i)

    sam_masks = [None] * n
    sam_logits = [None] * n
    for win, idxs in tqdm(groups.items(), desc="MobileSAM windows"):
        sx, sy, ex, ey = win
        crop = np.ascontiguousarray(img[sy:ey, sx:ex])
        predictor.set_image(crop)
        ch, cw = crop.shape[:2]
        for i in idxs:
            x0, y0, x1, y1 = boxes[i]
            box = np.array([x0 - sx, y0 - sy, x1 - sx, y1 - sy], dtype=float)
            prior = priors[i][sy:ey, sx:ex]
            logits, scores, _ = predictor.predict(box=box, multimask_output=True, return_logits=True)
            cand = logits > predictor.model.mask_threshold

            # restrict to a slightly enlarged box
            bw, bh = x1 - x0 + 1, y1 - y0 + 1
            mx, my = max(3, 0.15 * bw), max(3, 0.15 * bh)
            lim = np.zeros((ch, cw), bool)
            lim[int(max(0, box[1] - my)):int(min(ch, box[3] + my + 1)),
                int(max(0, box[0] - mx)):int(min(cw, box[2] + mx + 1))] = True
            box_area = bw * bh

            best, best_s = None, -np.inf
            for k in range(cand.shape[0]):
                m = cand[k] & lim
                a = m.sum()
                if a == 0:
                    continue
                frac = a / box_area
                s = float(scores[k])
                if is_rect[i]:
                    # a cell typically fills a good part of its box, but not all of it
                    if frac < 0.15:
                        s -= 0.5
                    elif frac > 1.0:
                        s -= 0.3 * (frac - 1.0) + 0.2
                    s += 0.3 * iou(m, ellipse_mask(box, (ch, cw)))
                else:
                    s = 0.5 * s + iou(m, prior)
                if s > best_s:
                    best, best_s = k, s
            full_m = np.zeros((H, W), bool)
            full_l = np.full((H, W), -1e4, np.float32)
            if best is not None:
                m = clean_mask(cand[best] & lim, seed=prior if not is_rect[i] else None)
                full_m[sy:ey, sx:ex] = m
                full_l[sy:ey, sx:ex] = np.where(lim, logits[best], -1e4)
            sam_masks[i] = full_m
            sam_logits[i] = full_l

    # ---- fallbacks for failed / degenerate predictions -------------------- #
    for i in range(n):
        m = sam_masks[i]
        box_area = (boxes[i][2] - boxes[i][0] + 1) * (boxes[i][3] - boxes[i][1] + 1)
        if m.sum() < max(10, 0.05 * box_area):
            fb = ellipse_mask(boxes[i], (H, W)) if is_rect[i] else priors[i]
            if fb.sum() < 3:
                fb = ellipse_mask(boxes[i], (H, W))
            sam_masks[i] = fb
            sam_logits[i] = np.where(fb, 1.0, -1e4).astype(np.float32)

    # ---- resolve overlaps: each pixel goes to the most confident cell ----- #
    label = np.zeros((H, W), np.int32)       # 0 = background, i+1 = cell i
    best_logit = np.full((H, W), -np.inf, np.float32)
    for i in range(n):
        m = sam_masks[i]
        lg = sam_logits[i]
        upd = m & (lg > best_logit)
        label[upd] = i + 1
        best_logit[upd] = lg[upd]

    final = [None] * n
    for i in range(n):
        final[i] = clean_mask(label == i + 1, seed=sam_masks[i])

    # cells that lost (almost) everything get their own core region back
    for i in range(n):
        if final[i].sum() >= 5:
            continue
        core = sam_masks[i]
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        er = cv2.erode(core.astype(np.uint8), k).astype(bool)
        if er.sum() >= 5:
            core = er
        core = largest_component(core)
        for j in range(n):
            if j != i and final[j] is not None and (final[j] & core).any():
                final[j] = clean_mask(final[j] & ~core, seed=sam_masks[j])
        final[i] = clean_mask(core)

    # enforce exclusivity once more (cleaning can only shrink, but be safe)
    occupied = np.zeros((H, W), bool)
    order = np.argsort([f.sum() for f in final])  # small cells first
    for i in order:
        f = final[i] & ~occupied
        f = largest_component(f)
        final[i] = f
        occupied |= f

    # ---- convert to polylines -------------------------------------------- #
    out = df.copy()
    new_cols = {"xmin": [], "ymin": [], "xmax": [], "ymax": [], "coords_x": [], "coords_y": []}
    for i in range(n):
        poly = mask_to_polygon(final[i]) if final[i].any() else None
        if poly is None or is_rectangle(poly[0][:-1], poly[1][:-1]):
            # degenerate: build a small diamond/octagon inside the free space
            x0, y0, x1, y1 = boxes[i]
            if final[i].any():
                yy, xx = np.nonzero(final[i])
                cx, cy = int(np.median(xx)), int(np.median(yy))
            else:
                cx, cy = int(round((x0 + x1) / 2)), int(round((y0 + y1) / 2))
            xs = [cx, cx + 1, cx, cx - 1, cx]
            ys = [cy - 1, cy, cy + 1, cy, cy - 1]
            xs = [int(np.clip(v, 0, W - 1)) for v in xs]
            ys = [int(np.clip(v, 0, H - 1)) for v in ys]
            poly = (xs, ys)
        xs, ys = poly
        new_cols["xmin"].append(int(min(xs)))
        new_cols["xmax"].append(int(max(xs)))
        new_cols["ymin"].append(int(min(ys)))
        new_cols["ymax"].append(int(max(ys)))
        new_cols["coords_x"].append(",".join(str(int(v)) for v in xs))
        new_cols["coords_y"].append(",".join(str(int(v)) for v in ys))
    for k, v in new_cols.items():
        out[k] = v

    # ---- save ------------------------------------------------------------- #
    if args.output_path.lower().endswith(".csv"):
        out_file = args.output_path
        d = os.path.dirname(out_file)
        if d:
            os.makedirs(d, exist_ok=True)
    else:
        os.makedirs(args.output_path, exist_ok=True)
        out_file = os.path.join(args.output_path, os.path.basename(args.csv_path))
    out.to_csv(out_file)
    print(f"Saved {n} refined masks to {out_file}")


if __name__ == "__main__":
    main()
