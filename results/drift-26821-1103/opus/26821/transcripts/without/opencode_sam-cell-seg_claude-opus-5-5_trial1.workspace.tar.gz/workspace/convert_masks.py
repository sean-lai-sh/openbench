#!/usr/bin/env python
"""Refine cell annotations (rectangles and polylines) into polylines with MobileSAM.

Every row in the metadata csv is used as a box prompt for MobileSAM. The predicted
masks are post-processed so that:
  * every cell has exactly one contiguous (single connected component) mask,
  * no two masks overlap (overlapping pixels go to the mask with the highest logit),
  * every mask is stored as a (non-rectangular) closed polyline.

The output csv has exactly the same rows/columns as the input csv; only the
xmin, ymin, xmax, ymax, coords_x and coords_y columns are updated.

Usage:
    python convert_masks.py --weights_path mobile_sam.pt --output_path out/ \
        --rgb_path image.png --csv_path metadata.csv
"""

import argparse
import os

import cv2
import numpy as np
import pandas as pd
import torch
from tqdm import tqdm

from mobile_sam import SamPredictor, sam_model_registry

TILE_SIZE = 1024  # images larger than this are processed in overlapping tiles
TILE_STRIDE = 768
MIN_AREA = 9  # minimum number of pixels for a valid mask


# --------------------------------------------------------------------------- #
# I/O helpers
# --------------------------------------------------------------------------- #
def parse_args():
    # Arguments may be given either positionally (in the order below) or as --flags.
    p = argparse.ArgumentParser(description="Convert cell masks to polylines using MobileSAM.")
    names = [
        ("weights_path", "Path to the MobileSAM weights (mobile_sam.pt)."),
        ("output_path", "Output folder (or .csv file path) for the refined masks."),
        ("rgb_path", "Path to the RGB image."),
        ("csv_path", "Path to the metadata csv."),
    ]
    for name, help_ in names:
        p.add_argument(f"pos_{name}", nargs="?", default=None, metavar=name, help=help_)
    for name, help_ in names:
        p.add_argument(f"--{name}", f"--{name.replace('_', '-')}", dest=name, type=str,
                       default=None, help=help_)
    args = p.parse_args()
    for name, _ in names:
        if getattr(args, name) is None:
            setattr(args, name, getattr(args, f"pos_{name}"))
        if getattr(args, name) is None:
            p.error(f"missing required argument: {name}")
    return args


def load_rgb(path):
    img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    if img is None:
        from PIL import Image
        img = np.array(Image.open(path).convert("RGB"))
        return np.ascontiguousarray(img)
    if img.dtype != np.uint8:
        img = cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    if img.ndim == 2:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
    elif img.shape[2] == 4:
        img = cv2.cvtColor(img, cv2.COLOR_BGRA2RGB)
    else:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return np.ascontiguousarray(img)


def parse_coords(value):
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return []
    s = str(value).strip().strip("[]()")
    out = []
    for tok in s.replace(";", ",").replace(" ", ",").split(","):
        tok = tok.strip()
        if tok:
            try:
                out.append(float(tok))
            except ValueError:
                pass
    return out


def resolve_output_file(output_path, csv_path):
    if output_path.lower().endswith(".csv"):
        parent = os.path.dirname(output_path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        return output_path
    os.makedirs(output_path, exist_ok=True)
    return os.path.join(output_path, os.path.basename(csv_path))


# --------------------------------------------------------------------------- #
# Geometry helpers
# --------------------------------------------------------------------------- #
def largest_component(mask):
    """Keep only the largest 8-connected component of a boolean mask."""
    if not mask.any():
        return mask
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask.astype(np.uint8), connectivity=8)
    if n <= 2:
        return mask
    k = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return lab == k


def fill_holes(mask):
    if not mask.any():
        return mask
    m = mask.astype(np.uint8)
    contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    filled = np.zeros_like(m)
    cv2.drawContours(filled, contours, -1, 1, thickness=cv2.FILLED)
    return filled.astype(bool)


def clean_mask(mask, forbidden=None):
    """Smooth, keep largest component, fill holes (never into forbidden pixels)."""
    if not mask.any():
        return mask
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    opened = cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_OPEN, kernel).astype(bool)
    if opened.sum() >= MIN_AREA:
        mask = opened
    mask = largest_component(mask)
    filled = fill_holes(mask)
    if forbidden is not None:
        filled &= ~forbidden
    return largest_component(filled)


def ellipse_mask(shape, box, scale=1.0):
    x0, y0, x1, y1 = box
    m = np.zeros(shape, np.uint8)
    cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    ax = max(1, int(round((x1 - x0) / 2.0 * scale)))
    ay = max(1, int(round((y1 - y0) / 2.0 * scale)))
    cv2.ellipse(m, (int(round(cx)), int(round(cy))), (ax, ay), 0, 0, 360, 1, thickness=cv2.FILLED)
    return m.astype(bool)


def polygon_mask(shape, xs, ys):
    m = np.zeros(shape, np.uint8)
    pts = np.round(np.stack([xs, ys], axis=1)).astype(np.int32)
    cv2.fillPoly(m, [pts], 1)
    return m.astype(bool)


def is_rectangle(mask):
    ys, xs = np.nonzero(mask)
    if len(xs) == 0:
        return False
    h = ys.max() - ys.min() + 1
    w = xs.max() - xs.min() + 1
    return len(xs) == h * w


def break_rectangle(mask):
    """Cut the corners of a perfectly rectangular mask so that it becomes a polygon."""
    ys, xs = np.nonzero(mask)
    y0, y1, x0, x1 = ys.min(), ys.max(), xs.min(), xs.max()
    h, w = y1 - y0 + 1, x1 - x0 + 1
    if h < 3 or w < 3:
        return mask
    c = max(1, min(h, w) // 4)
    m = mask.copy()
    for i in range(c):
        k = c - i
        m[y0 + i, x0:x0 + k] = False
        m[y0 + i, x1 - k + 1:x1 + 1] = False
        m[y1 - i, x0:x0 + k] = False
        m[y1 - i, x1 - k + 1:x1 + 1] = False
    return m


def mask_to_polygon(mask):
    """Return (contour Nx2 int array, rasterized polygon mask) for the largest contour."""
    m = mask.astype(np.uint8)
    contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None, None
    cnt = max(contours, key=lambda c: (cv2.contourArea(c), len(c)))
    if len(cnt) < 3 or cv2.contourArea(cnt) <= 0:
        return None, None
    raster = np.zeros_like(m)
    cv2.fillPoly(raster, [cnt], 1)
    return cnt.reshape(-1, 2), raster.astype(bool)


# --------------------------------------------------------------------------- #
# SAM inference
# --------------------------------------------------------------------------- #
def make_tiles(h, w):
    """Overlapping tiles (x0, y0, x1, y1) covering the image."""
    if max(h, w) <= TILE_SIZE:
        return [(0, 0, w, h)]

    def starts(n):
        if n <= TILE_SIZE:
            return [0]
        s = list(range(0, n - TILE_SIZE, TILE_STRIDE))
        s.append(n - TILE_SIZE)
        return sorted(set(s))

    return [(x, y, min(x + TILE_SIZE, w), min(y + TILE_SIZE, h)) for y in starts(h) for x in starts(w)]


def choose_tile(box, tiles, h, w):
    x0, y0, x1, y1 = box
    best, best_margin = None, -np.inf
    for t in tiles:
        if x0 >= t[0] and y0 >= t[1] and x1 <= t[2] and y1 <= t[3]:
            margin = min(x0 - t[0], y0 - t[1], t[2] - x1, t[3] - y1)
            if margin > best_margin:
                best, best_margin = t, margin
    if best is not None:
        return best
    # Box does not fit into any tile: crop centred on the box.
    size = int(max(TILE_SIZE, 1.5 * max(x1 - x0, y1 - y0)))
    cx, cy = (x0 + x1) // 2, (y0 + y1) // 2
    tx0 = int(np.clip(cx - size // 2, 0, max(0, w - size)))
    ty0 = int(np.clip(cy - size // 2, 0, max(0, h - size)))
    return (tx0, ty0, min(w, tx0 + size), min(h, ty0 + size))


def select_mask(logits, scores, prior, allowed, box_area):
    """Pick the best of SAM's multimask outputs."""
    best, best_val = None, -np.inf
    for k in range(logits.shape[0]):
        m = (logits[k] > 0) & allowed
        area = int(m.sum())
        if area < MIN_AREA:
            continue
        inter = np.logical_and(m, prior).sum()
        union = np.logical_or(m, prior).sum()
        iou = inter / union if union else 0.0
        val = float(scores[k]) + iou
        frac = area / max(1.0, box_area)
        if frac > 1.3 or frac < 0.08:  # leaks into background / tiny fragment
            val -= 1.0
        if val > best_val:
            best, best_val = k, val
    return best


def main():
    args = parse_args()
    torch.set_grad_enabled(False)
    device = "cuda" if torch.cuda.is_available() else "cpu"

    image = load_rgb(args.rgb_path)
    H, W = image.shape[:2]

    df = pd.read_csv(args.csv_path, index_col=0)
    n = len(df)

    # ---------------- parse annotations ---------------- #
    boxes, priors = [], []
    for _, row in df.iterrows():
        xs = parse_coords(row.get("coords_x"))
        ys = parse_coords(row.get("coords_y"))
        if len(xs) != len(ys):
            k = min(len(xs), len(ys))
            xs, ys = xs[:k], ys[:k]
        vals = {}
        for c in ("xmin", "ymin", "xmax", "ymax"):
            try:
                vals[c] = float(row.get(c))
            except (TypeError, ValueError):
                vals[c] = np.nan
        if any(np.isnan(v) for v in vals.values()) and xs:
            vals = dict(xmin=min(xs), xmax=max(xs), ymin=min(ys), ymax=max(ys))
        x0 = int(np.clip(np.floor(min(vals["xmin"], vals["xmax"])), 0, W - 1))
        x1 = int(np.clip(np.ceil(max(vals["xmin"], vals["xmax"])), 0, W - 1))
        y0 = int(np.clip(np.floor(min(vals["ymin"], vals["ymax"])), 0, H - 1))
        y1 = int(np.clip(np.ceil(max(vals["ymin"], vals["ymax"])), 0, H - 1))
        if x1 - x0 < 2:
            x0, x1 = max(0, x0 - 1), min(W - 1, x1 + 1)
        if y1 - y0 < 2:
            y0, y1 = max(0, y0 - 1), min(H - 1, y1 + 1)
        box = (x0, y0, x1, y1)
        boxes.append(box)

        rtype = str(row.get("type", "")).lower()
        prior = None
        if len(xs) >= 3 and "rect" not in rtype:
            prior = polygon_mask((H, W), xs, ys)
            if is_rectangle(prior) or prior.sum() < MIN_AREA:
                prior = None
        if prior is None:  # rectangles: an inscribed ellipse is the expected cell shape
            prior = ellipse_mask((H, W), box)
        priors.append(prior)

    # ---------------- MobileSAM predictions ---------------- #
    sam = sam_model_registry["vit_t"](checkpoint=args.weights_path)
    sam.to(device=device)
    sam.eval()
    predictor = SamPredictor(sam)

    tiles = make_tiles(H, W)
    groups = {}
    for i, b in enumerate(boxes):
        groups.setdefault(choose_tile(b, tiles, H, W), []).append(i)

    masks = [None] * n
    logit_maps = [None] * n  # full-res logits (float32) used to resolve overlaps
    for tile, idxs in tqdm(groups.items(), desc="MobileSAM tiles"):
        tx0, ty0, tx1, ty1 = tile
        predictor.set_image(image[ty0:ty1, tx0:tx1])
        for i in tqdm(idxs, desc="cells", leave=False):
            x0, y0, x1, y1 = boxes[i]
            bw, bh = x1 - x0 + 1, y1 - y0 + 1
            box_local = np.array([x0 - tx0, y0 - ty0, x1 - tx0, y1 - ty0], dtype=np.float32)
            logits_local, scores, _ = predictor.predict(
                box=box_local, multimask_output=True, return_logits=True)
            logits = np.full((logits_local.shape[0], H, W), -1e4, dtype=np.float32)
            logits[:, ty0:ty1, tx0:tx1] = logits_local

            # Masks may extend a little beyond the annotated box, but not much.
            mx, my = max(3, int(0.15 * bw)), max(3, int(0.15 * bh))
            allowed = np.zeros((H, W), bool)
            allowed[max(0, y0 - my):min(H, y1 + my + 1), max(0, x0 - mx):min(W, x1 + mx + 1)] = True

            k = select_mask(logits, scores, priors[i], allowed, bw * bh)
            m = None
            if k is not None:
                m = clean_mask((logits[k] > 0) & allowed)
                if m.sum() < MIN_AREA:
                    m = None
            if m is None:  # SAM failed: fall back to the prior shape
                m = priors[i].copy()
                lg = np.where(m, 0.5, -1e4).astype(np.float32)
            else:
                lg = logits[k]
            masks[i] = m
            logit_maps[i] = np.where(m, lg, -np.inf).astype(np.float32)

    # ---------------- resolve overlaps ---------------- #
    priority = np.zeros(n, dtype=bool)  # cells that got squeezed out get a protected core
    cores = [None] * n
    for _ in range(4):
        best = np.full((H, W), -np.inf, dtype=np.float32)
        owner = np.full((H, W), -1, dtype=np.int32)
        for i in range(n):
            lg = logit_maps[i]
            if priority[i]:
                lg = np.where(cores[i], np.float32(1e9), lg)
            upd = lg > best
            best[upd] = lg[upd]
            owner[upd] = i
        squeezed = []
        for i in range(n):
            if np.count_nonzero(largest_component(owner == i)) < MIN_AREA and not priority[i]:
                squeezed.append(i)
        if not squeezed:
            break
        for i in squeezed:
            priority[i] = True
            core = ellipse_mask((H, W), boxes[i], scale=0.4)
            if core.sum() < MIN_AREA:
                core = ellipse_mask((H, W), boxes[i], scale=1.0)
            cores[i] = core

    # ---------------- final polygons (guaranteed disjoint) ---------------- #
    claimed = np.zeros((H, W), dtype=bool)
    order = sorted(range(n), key=lambda i: (not priority[i], np.count_nonzero(owner == i)))
    results = [None] * n
    for i in order:
        others = (owner >= 0) & (owner != i)
        m = clean_mask((owner == i) & ~claimed, forbidden=others | claimed)
        cnt = None
        for _ in range(6):
            if m.sum() < 3:
                break
            if is_rectangle(m):
                m = break_rectangle(m)
            cnt, raster = mask_to_polygon(m)
            if cnt is None:
                break
            overlap = raster & claimed
            if not overlap.any():
                break
            # The polygon encloses pixels of another cell (ring-shaped mask):
            # stay away from claimed pixels and cut a channel to open the ring.
            m = m & ~cv2.dilate(claimed.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool)
            oy, ox = np.nonzero(overlap)
            j = len(oy) // 2
            py, px = int(oy[j]), int(ox[j])
            m[:py + 1, max(0, px - 1):px + 2] = False
            m = largest_component(m)
            cnt = None
        if cnt is None:
            # Last resort: any small free blob near the box centre.
            x0, y0, x1, y1 = boxes[i]
            free = ~cv2.dilate(claimed.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool)
            for scale in (1.0, 0.6, 0.3, 1.5, 2.5):
                cand = largest_component(ellipse_mask((H, W), boxes[i], scale) & free)
                if cand.sum() >= 3:
                    if is_rectangle(cand):
                        cand = break_rectangle(cand)
                    cnt, raster = mask_to_polygon(cand)
                    if cnt is not None and not (raster & claimed).any():
                        break
                    cnt = None
        if cnt is None:
            # Should never happen; emit a tiny diamond at the box centre.
            cx, cy = (boxes[i][0] + boxes[i][2]) // 2, (boxes[i][1] + boxes[i][3]) // 2
            cnt = np.array([[cx, cy - 1], [cx + 1, cy], [cx, cy + 1], [cx - 1, cy]], dtype=np.int32)
            raster = np.zeros((H, W), np.uint8)
            cv2.fillPoly(raster, [cnt], 1)
            raster = raster.astype(bool)
        claimed |= raster
        results[i] = cnt

    # ---------------- write csv ---------------- #
    out = df.copy()
    xmins, ymins, xmaxs, ymaxs, cxs, cys = [], [], [], [], [], []
    for cnt in results:
        xs = [int(v) for v in cnt[:, 0]]
        ys = [int(v) for v in cnt[:, 1]]
        xmins.append(min(xs))
        xmaxs.append(max(xs))
        ymins.append(min(ys))
        ymaxs.append(max(ys))
        xs.append(xs[0])  # close the polyline like the input annotations
        ys.append(ys[0])
        cxs.append(",".join(map(str, xs)))
        cys.append(",".join(map(str, ys)))
    out["xmin"], out["ymin"], out["xmax"], out["ymax"] = xmins, ymins, xmaxs, ymaxs
    out["coords_x"], out["coords_y"] = cxs, cys

    out_file = resolve_output_file(args.output_path, args.csv_path)
    out.to_csv(out_file)
    print(f"Saved {len(out)} refined masks to {out_file}")


if __name__ == "__main__":
    main()
