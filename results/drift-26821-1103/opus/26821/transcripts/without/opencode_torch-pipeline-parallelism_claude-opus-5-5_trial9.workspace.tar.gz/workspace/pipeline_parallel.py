"""Pipeline-parallel training step (AFAB schedule) for LlamaForCausalLM."""

import torch
import torch.distributed as dist
import torch.nn.functional as F


def _partition_layers(num_layers, world_size, rank):
    """Split `num_layers` into `world_size` contiguous, balanced chunks."""
    base, rem = divmod(num_layers, world_size)
    start = rank * base + min(rank, rem)
    end = start + base + (1 if rank < rem else 0)
    return start, end


def _causal_mask(config, hidden_states, position_ids):
    try:
        from transformers.masking_utils import create_causal_mask
    except ImportError:  # very old transformers
        return None
    try:
        return create_causal_mask(
            config=config,
            inputs_embeds=hidden_states,
            attention_mask=None,
            past_key_values=None,
            position_ids=position_ids,
        )
    except TypeError:
        # transformers 4.5x signature
        cache_position = torch.arange(hidden_states.shape[1], device=hidden_states.device)
        return create_causal_mask(
            config=config,
            input_embeds=hidden_states,
            attention_mask=None,
            cache_position=cache_position,
            past_key_values=None,
            position_ids=position_ids,
        )


def _p2p(op, tensor, peer):
    reqs = dist.batch_isend_irecv([dist.P2POp(op, tensor, peer)])
    for r in reqs:
        r.wait()


def train_step_pipeline_afab(model, inputs, targets, device, dtype):
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    is_first = rank == 0
    is_last = rank == world_size - 1

    llama = model.model
    config = model.config
    num_layers = len(llama.layers)
    start, end = _partition_layers(num_layers, world_size, rank)
    my_layers = [llama.layers[i] for i in range(start, end)]

    num_microbatches = len(inputs)
    hidden_size = config.hidden_size

    stage_inputs = []   # received hidden states (leaf tensors requiring grad)
    stage_outputs = []  # outputs of this stage (hidden states or loss)
    total_loss = None

    # ------------------------------------------------------------------
    # All forward
    # ------------------------------------------------------------------
    for mb in range(num_microbatches):
        mb_inputs = inputs[mb].to(device)
        bsz, seq_len = mb_inputs.shape[0], mb_inputs.shape[1]

        if is_first:
            hidden = llama.embed_tokens(mb_inputs).to(device=device, dtype=dtype)
            stage_inputs.append(None)
        else:
            hidden = torch.empty(bsz, seq_len, hidden_size, device=device, dtype=dtype)
            _p2p(dist.irecv, hidden, rank - 1)
            hidden.requires_grad_(True)
            stage_inputs.append(hidden)

        position_ids = torch.arange(seq_len, device=device).unsqueeze(0)
        position_embeddings = llama.rotary_emb(hidden, position_ids)
        attention_mask = _causal_mask(config, hidden, position_ids)

        for layer in my_layers:
            out = layer(
                hidden,
                attention_mask=attention_mask,
                position_ids=position_ids,
                position_embeddings=position_embeddings,
            )
            hidden = out[0] if isinstance(out, tuple) else out

        if is_last:
            hidden = llama.norm(hidden)
            logits = model.lm_head(hidden)
            mb_targets = targets[mb].to(device)
            loss = F.cross_entropy(
                logits.reshape(-1, logits.size(-1)).float(), mb_targets.reshape(-1)
            ) / num_microbatches
            stage_outputs.append(loss)
            total_loss = loss.detach() if total_loss is None else total_loss + loss.detach()
        else:
            stage_outputs.append(hidden)
            _p2p(dist.isend, hidden.detach().to(device=device, dtype=dtype).contiguous(), rank + 1)

    # ------------------------------------------------------------------
    # All backward
    # ------------------------------------------------------------------
    for mb in range(num_microbatches):
        output = stage_outputs[mb]
        if is_last:
            output.backward()
        else:
            grad = torch.empty_like(output, device=device, dtype=dtype)
            _p2p(dist.irecv, grad, rank + 1)
            torch.autograd.backward(output, grad_tensors=grad)

        if not is_first:
            inp = stage_inputs[mb]
            grad_in = inp.grad
            if grad_in is None:
                grad_in = torch.zeros_like(inp)
            _p2p(dist.isend, grad_in.to(device=device, dtype=dtype).contiguous(), rank - 1)

        # free memory
        stage_outputs[mb] = None
        stage_inputs[mb] = None

    return total_loss
