#!/usr/bin/env python
"""
Refine cell annotations (rectangles and polylines) with MobileSAM and save
every mask as a non-overlapping, single-component polyline.

Usage:
    python convert_masks.py --weights_path mobile_sam.pt \
        --output_path out_dir_or_file.csv \
        --rgb_path image.png --csv_path metadata.csv

The output CSV mirrors the input CSV; only the xmin, ymin, xmax, ymax,
coords_x and coords_y columns are updated.
"""
import argparse
import os

import cv2
import numpy as np
import pandas as pd
import torch
from tqdm import tqdm

from mobile_sam import SamPredictor, sam_model_registry


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def parse_args():
    p = argparse.ArgumentParser(description="Convert cell masks to polylines with MobileSAM.")
    p.add_argument("weights_path", nargs="?", default=None, help="Path to MobileSAM weights (mobile_sam.pt).")
    p.add_argument("output_path", nargs="?", default=None,
                   help="Output folder (or .csv file path) where the refined masks are saved.")
    p.add_argument("rgb_path", nargs="?", default=None, help="Path to the RGB image.")
    p.add_argument("csv_path", nargs="?", default=None, help="Path to the metadata CSV.")
    # Also accept the same arguments as --flags.
    p.add_argument("--weights_path", dest="weights_path_opt", default=None)
    p.add_argument("--output_path", dest="output_path_opt", default=None)
    p.add_argument("--rgb_path", dest="rgb_path_opt", default=None)
    p.add_argument("--csv_path", dest="csv_path_opt", default=None)
    a = p.parse_args()
    for name in ("weights_path", "output_path", "rgb_path", "csv_path"):
        opt = getattr(a, name + "_opt")
        if opt is not None:
            setattr(a, name, opt)
        if getattr(a, name) is None:
            p.error(f"argument {name} is required")
    return a


def parse_coords(val):
    if isinstance(val, (list, tuple, np.ndarray)):
        return [float(v) for v in val]
    s = str(val).strip().strip("[]()")
    return [float(v) for v in s.replace(";", ",").split(",") if v.strip() != ""]


def load_model(weights_path):
    model = sam_model_registry["vit_t"](checkpoint=None)
    try:
        state = torch.load(weights_path, map_location="cpu", weights_only=True)
    except TypeError:  # older torch without weights_only
        state = torch.load(weights_path, map_location="cpu")
    if isinstance(state, dict) and "model" in state and not any(k.startswith("image_encoder") for k in state):
        state = state["model"]
    model.load_state_dict(state)
    model.to("cpu").eval()
    return SamPredictor(model)


def largest_component(mask):
    """Keep only the largest 4-connected component (4-conn => unambiguously contiguous)."""
    mask = mask.astype(np.uint8)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=4)
    if n <= 1:
        return mask.astype(bool)
    idx = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return lab == idx


def fill_holes(mask):
    m = mask.astype(np.uint8)
    contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    out = np.zeros_like(m)
    cv2.drawContours(out, contours, -1, 1, thickness=cv2.FILLED)
    return out.astype(bool)


def ellipse_mask(shape, x0, y0, x1, y1):
    m = np.zeros(shape, np.uint8)
    cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    ax, ay = max((x1 - x0) / 2.0, 1.0), max((y1 - y0) / 2.0, 1.0)
    cv2.ellipse(m, (int(round(cx)), int(round(cy))), (int(round(ax)), int(round(ay))), 0, 0, 360, 1, -1)
    return m.astype(bool)


def polygon_mask(shape, xs, ys):
    m = np.zeros(shape, np.uint8)
    pts = np.round(np.stack([xs, ys], 1)).astype(np.int32)
    if len(pts) >= 3:
        cv2.fillPoly(m, [pts], 1)
    return m.astype(bool)


def iou(a, b):
    inter = np.logical_and(a, b).sum()
    union = np.logical_or(a, b).sum()
    return inter / union if union > 0 else 0.0


def mask_to_polygon(mask):
    """Return closed polygon (Nx2 int array) tracing the outer boundary of mask, or None."""
    m = mask.astype(np.uint8)
    contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    c = max(contours, key=cv2.contourArea).reshape(-1, 2)
    if len(c) < 3:
        # degenerate (line / single pixel) -> use the full pixel trace
        contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        c = max(contours, key=len).reshape(-1, 2)
    return c


def is_axis_rectangle(poly):
    if poly is None:
        return True
    uniq = np.unique(poly, axis=0)
    if len(uniq) < 3:
        return True
    xs, ys = np.unique(uniq[:, 0]), np.unique(uniq[:, 1])
    return len(uniq) <= 4 and len(xs) <= 2 and len(ys) <= 2


def render_polygon(shape, poly):
    m = np.zeros(shape, np.uint8)
    cv2.fillPoly(m, [poly.astype(np.int32)], 1)
    return m.astype(bool)


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main():
    args = parse_args()
    torch.set_grad_enabled(False)

    bgr = cv2.imread(args.rgb_path, cv2.IMREAD_COLOR)
    if bgr is None:
        raise FileNotFoundError(f"Could not read image {args.rgb_path}")
    image = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
    H, W = image.shape[:2]

    df = pd.read_csv(args.csv_path)
    n = len(df)

    predictor = load_model(args.weights_path)
    predictor.set_image(image)

    # ---------------- 1. SAM prediction per annotation ---------------- #
    cand_masks = []   # bool HxW candidate masks (cropped storage via bbox)
    cand_logits = []  # float logits for overlap resolution
    crops = []        # (y0, y1, x0, x1) region where candidate lives

    for i in tqdm(range(n), desc="MobileSAM"):
        row = df.iloc[i]
        xs = np.array(parse_coords(row["coords_x"]), dtype=float)
        ys = np.array(parse_coords(row["coords_y"]), dtype=float)
        if len(xs) and len(ys) and len(xs) == len(ys):
            bx0, bx1, by0, by1 = xs.min(), xs.max(), ys.min(), ys.max()
        else:
            bx0, bx1, by0, by1 = float(row["xmin"]), float(row["xmax"]), float(row["ymin"]), float(row["ymax"])
        bx0, bx1 = np.clip([bx0, bx1], 0, W - 1)
        by0, by1 = np.clip([by0, by1], 0, H - 1)
        if bx1 - bx0 < 2:
            bx0, bx1 = max(bx0 - 1, 0), min(bx1 + 1, W - 1)
        if by1 - by0 < 2:
            by0, by1 = max(by0 - 1, 0), min(by1 + 1, H - 1)

        rtype = str(row["type"]).lower() if "type" in df.columns else ""
        uniq = np.unique(np.stack([xs, ys], 1), axis=0) if len(xs) == len(ys) and len(xs) else np.zeros((0, 2))
        is_rect = ("rect" in rtype) or (len(uniq) <= 4 and len(np.unique(xs)) <= 2 and len(np.unique(ys)) <= 2)

        # Region the refined mask is allowed to occupy: bbox + small margin
        bw, bh = bx1 - bx0, by1 - by0
        mx, my = max(3, 0.15 * bw), max(3, 0.15 * bh)
        x0, x1 = int(max(0, np.floor(bx0 - mx))), int(min(W, np.ceil(bx1 + mx) + 1))
        y0, y1 = int(max(0, np.floor(by0 - my))), int(min(H, np.ceil(by1 + my) + 1))
        crops.append((y0, y1, x0, x1))
        shape = (y1 - y0, x1 - x0)

        box = np.array([bx0, by0, bx1, by1], dtype=float)
        masks_l, scores, _ = predictor.predict(box=box, multimask_output=True, return_logits=True)
        masks_l = masks_l[:, y0:y1, x0:x1]
        masks_b = masks_l > predictor.model.mask_threshold

        if is_rect:
            ref = None
        else:
            ref = polygon_mask(shape, xs - x0, ys - y0)
            if ref.sum() == 0:
                ref = None
        box_area = max((bw + 1) * (bh + 1), 1.0)
        in_box = np.zeros(shape, bool)
        in_box[int(by0) - y0:int(by1) - y0 + 1, int(bx0) - x0:int(bx1) - x0 + 1] = True

        best, best_val = None, -np.inf
        for k in range(masks_b.shape[0]):
            m = largest_component(masks_b[k])
            area = m.sum()
            if area == 0:
                continue
            fill = np.logical_and(m, in_box).sum() / box_area
            outside = 1.0 - np.logical_and(m, in_box).sum() / area
            if ref is not None:
                val = iou(m, ref) + 0.1 * float(scores[k])
            else:
                val = float(scores[k])
                # cells inside a bbox should fill it roughly like an ellipse
                if fill < 0.25:
                    val -= (0.25 - fill) * 2
                if fill > 0.95:
                    val -= (fill - 0.95) * 4
            val -= outside
            if val > best_val:
                best_val, best = val, k

        if best is None:
            m = ref if ref is not None else ellipse_mask(shape, bx0 - x0, by0 - y0, bx1 - x0, by1 - y0)
            logit = np.where(m, 1.0, -1.0).astype(np.float32)
        else:
            m = fill_holes(largest_component(masks_b[best]))
            logit = masks_l[best].astype(np.float32)
            # A polyline should agree reasonably with the original drawing; if SAM
            # failed badly, fall back to the original annotation.
            if ref is not None and iou(m, ref) < 0.2:
                m = ref
                logit = np.where(m, 1.0, -1.0).astype(np.float32)
            # Rectangle-like output (SAM returned the whole box) -> use an ellipse
            elif ref is None and np.logical_and(m, in_box).sum() / box_area > 0.97:
                m = np.logical_and(m, ellipse_mask(shape, bx0 - x0, by0 - y0, bx1 - x0, by1 - y0))
        cand_masks.append(m.astype(bool))
        cand_logits.append(logit)

    # ---------------- 2. Resolve overlaps (pixel -> highest logit) ---------------- #
    NEG = -np.inf
    best_logit = np.full((H, W), NEG, np.float32)
    label = np.full((H, W), -1, np.int32)
    for i in range(n):
        y0, y1, x0, x1 = crops[i]
        m = cand_masks[i]
        lg = np.where(m, cand_logits[i], NEG)
        cur = best_logit[y0:y1, x0:x1]
        upd = lg > cur
        cur[upd] = lg[upd]
        label[y0:y1, x0:x1][upd] = i

    def finalize_labels(label):
        """Keep largest component per cell; return dict i -> bool mask (full image)."""
        out = {}
        for i in range(n):
            y0, y1, x0, x1 = crops[i]
            m = label[y0:y1, x0:x1] == i
            if m.sum() == 0:
                out[i] = None
                continue
            m = largest_component(m)
            full = np.zeros((H, W), bool)
            full[y0:y1, x0:x1] = m
            out[i] = full
        return out

    # Rebuild label map so only the kept components remain, give empty cells a seed.
    for _ in range(5):
        masks = finalize_labels(label)
        label = np.full((H, W), -1, np.int32)
        for i in range(n):
            if masks[i] is not None:
                label[masks[i]] = i
        empty = [i for i in range(n) if masks[i] is None]
        if not empty:
            break
        for i in empty:
            # Give the cell the core of its own candidate (or a small central ellipse)
            y0, y1, x0, x1 = crops[i]
            m = cand_masks[i].astype(np.uint8)
            k = max(1, int(0.25 * min(m.shape)))
            core = cv2.erode(m, np.ones((3, 3), np.uint8), iterations=max(1, k // 2)).astype(bool)
            if core.sum() == 0:
                ys_, xs_ = np.nonzero(m)
                if len(ys_):
                    cy, cx = int(np.median(ys_)), int(np.median(xs_))
                else:
                    cy, cx = m.shape[0] // 2, m.shape[1] // 2
                core = np.zeros_like(m, bool)
                core[max(cy - 1, 0):cy + 2, max(cx - 1, 0):cx + 2] = True
            sub = label[y0:y1, x0:x1]
            sub[core] = i

    # ---------------- 3. Convert to polygons, guarantee no overlap ---------------- #
    masks = finalize_labels(label)
    polys = [None] * n
    occupied = np.zeros((H, W), bool)
    order = sorted(range(n), key=lambda i: -(masks[i].sum() if masks[i] is not None else 0))
    # Start with the smaller cells so they keep their shape; larger ones absorb trims.
    for i in reversed(order):
        m = masks[i]
        if m is None:
            continue
        for _ in range(10):
            m = np.logical_and(m, ~occupied)
            m = largest_component(m)
            if m.sum() == 0:
                break
            poly = mask_to_polygon(m)
            if poly is None:
                break
            r = render_polygon((H, W), poly)
            if not np.logical_and(r, occupied).any() and len(np.unique(poly, axis=0)) >= 3:
                if is_axis_rectangle(poly) and m.sum() > 4:
                    # cut corners to avoid an axis-aligned rectangle
                    ys_, xs_ = np.nonzero(m)
                    ell = ellipse_mask((H, W), xs_.min(), ys_.min(), xs_.max(), ys_.max())
                    m2 = largest_component(np.logical_and(m, ell))
                    if m2.sum() > 0 and not np.array_equal(m2, m):
                        m = m2
                        continue
                polys[i] = poly
                occupied |= r
                break
            # polygon rendering spilled onto another cell: shrink and retry
            m = np.logical_and(m, ~cv2.dilate(occupied.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool))

    # Any cell still without a polygon: place a tiny triangle in free space near its box
    for i in range(n):
        if polys[i] is not None:
            continue
        y0, y1, x0, x1 = crops[i]
        free = ~cv2.dilate(occupied.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool)
        sub = free[y0:y1, x0:x1]
        ys_, xs_ = np.nonzero(sub)
        if len(ys_) == 0:
            ys_, xs_ = np.nonzero(free)
            off = (0, 0)
        else:
            off = (y0, x0)
        if len(ys_) == 0:
            cy, cx = (y0 + y1) // 2, (x0 + x1) // 2
        else:
            cyc, cxc = (y1 - y0) / 2.0, (x1 - x0) / 2.0
            j = int(np.argmin((ys_ - cyc) ** 2 + (xs_ - cxc) ** 2)) if off != (0, 0) else 0
            cy, cx = ys_[j] + off[0], xs_[j] + off[1]
        poly = np.array([[cx, cy], [min(cx + 1, W - 1), cy], [cx, min(cy + 1, H - 1)]], np.int32)
        polys[i] = poly
        occupied |= render_polygon((H, W), poly)

    # ---------------- 4. Write output ---------------- #
    out = df.copy()
    for col in ("xmin", "ymin", "xmax", "ymax", "coords_x", "coords_y"):
        if col in out.columns:
            out[col] = out[col].astype(object)
    for i in range(n):
        p = polys[i].astype(int)
        p = np.vstack([p, p[:1]])  # close the polyline like the input format
        idx = out.index[i]
        out.at[idx, "xmin"] = int(p[:, 0].min())
        out.at[idx, "xmax"] = int(p[:, 0].max())
        out.at[idx, "ymin"] = int(p[:, 1].min())
        out.at[idx, "ymax"] = int(p[:, 1].max())
        out.at[idx, "coords_x"] = ",".join(str(int(v)) for v in p[:, 0])
        out.at[idx, "coords_y"] = ",".join(str(int(v)) for v in p[:, 1])

    # Restore a blank header for an unnamed index column (matches input layout)
    out.columns = ["" if str(c).startswith("Unnamed: ") else c for c in out.columns]

    if args.output_path.lower().endswith(".csv"):
        out_file = args.output_path
        parent = os.path.dirname(out_file)
        if parent:
            os.makedirs(parent, exist_ok=True)
    else:
        os.makedirs(args.output_path, exist_ok=True)
        out_file = os.path.join(args.output_path, os.path.basename(args.csv_path))
    out.to_csv(out_file, index=False)
    print(f"Saved {n} refined polyline masks to {out_file}")


if __name__ == "__main__":
    main()
