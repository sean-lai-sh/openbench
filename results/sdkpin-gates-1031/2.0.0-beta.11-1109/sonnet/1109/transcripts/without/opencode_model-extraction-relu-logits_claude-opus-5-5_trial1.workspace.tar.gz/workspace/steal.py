import numpy as np
from forward import forward

rng = np.random.default_rng(1)
D = 10
R = 4.0
N = 4001
ts = np.linspace(-R, R, N)
h = ts[1] - ts[0]


def grad(x, eps=1e-7):
    f0 = forward(x)
    g = np.zeros(D)
    for i in range(D):
        e = np.zeros(D)
        e[i] = eps
        g[i] = (forward(x + e) - f0) / eps
    return g


dirs = []
for _ in range(60):
    p = rng.normal(size=D) * 0.5
    d = rng.normal(size=D)
    d /= np.linalg.norm(d)
    f = np.array([forward(p + t * d) for t in ts])
    sd = f[2:] - 2 * f[1:-1] + f[:-2]
    flagged = np.where(np.abs(sd) > 1e-9)[0] + 1
    groups = []
    for i in flagged:
        if groups and i - groups[-1][-1] <= 3:
            groups[-1].append(i)
        else:
            groups.append([i])
    for g_ in groups:
        lo, hi = g_[0], g_[-1]
        if lo < 3 or hi > N - 4 or hi - lo > 1:
            continue
        sl = (f[lo - 1] - f[lo - 2]) / h
        sr = (f[hi + 2] - f[hi + 1]) / h
        if abs(sr - sl) < 1e-7:
            continue
        tl, tr = ts[lo - 1], ts[hi + 1]
        fl, fr = f[lo - 1], f[hi + 1]
        t = (fr - fl - sr * tr + sl * tl) / (sl - sr)
        if not (tl - h < t < tr + h):
            continue
        dl = 3e-5
        x1 = p + (t - dl) * d
        x2 = p + (t + dl) * d
        g1 = grad(x1)
        g2 = grad(x2)
        diff = g2 - g1
        n = np.linalg.norm(diff)
        if n < 1e-6:
            continue
        diff /= n
        if abs(diff @ d) > 0 and (g1 @ d - sl) ** 2 > 1e-6:
            continue
        dirs.append(diff)

clusters = []
for v in dirs:
    for c in clusters:
        ref = c[0]
        if abs(ref @ v) > 0.9999:
            c.append(v * np.sign(ref @ v))
            break
    else:
        clusters.append([v])

rows = []
for c in clusters:
    if len(c) >= 2:
        m = np.mean(c, axis=0)
        rows.append(m / np.linalg.norm(m))
A = np.array(rows)
np.save("/tmp/obench-cell-f3sc0w53/bench_opencode_model-extraction-relu-logits_vxsn5pbl/stolen_A1.npy", A)
print(A.shape)
