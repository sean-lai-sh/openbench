import os
import numpy as np
from forward import forward

D = 10
H = 1e-8
rng = np.random.default_rng(12345)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")


def grad(x):
    f0 = forward(x)
    g = np.empty(D)
    for i in range(D):
        e = np.zeros(D)
        e[i] = H
        g[i] = (forward(x + e) - f0) / H
    return g


def find_kinks(p, d, R=4.0, N=400):
    ts = np.linspace(-R, R, N)
    fs = np.array([forward(p + t * d) for t in ts])
    dt = ts[1] - ts[0]
    s = np.diff(fs) / dt
    res = []
    for k in range(1, len(s)):
        if abs(s[k] - s[k - 1]) > 1e-7:
            a, b = ts[k - 1], ts[k + 1]
            ga, gb = grad(p + a * d), grad(p + b * d)
            if np.linalg.norm(ga - gb) < 1e-6:
                continue
            while b - a > 1e-5:
                m = 0.5 * (a + b)
                gm = grad(p + m * d)
                if np.linalg.norm(ga - gm) > 1e-6:
                    b, gb = m, gm
                else:
                    a, ga = m, gm
            delta = gb - ga
            if np.linalg.norm(delta) > 1e-5:
                res.append(delta)
    return res


dirs = []
counts = []
for it in range(400):
    p = rng.normal(size=D) * 0.5
    d = rng.normal(size=D)
    d /= np.linalg.norm(d)
    for delta in find_kinks(p, d):
        v = delta / np.linalg.norm(delta)
        for j, (u, n) in enumerate(dirs):
            c = np.dot(u, v)
            if abs(c) > 0.9999:
                v = v if c > 0 else -v
                dirs[j] = ((u * n + v) / np.linalg.norm(u * n + v), n + 1)
                break
        else:
            dirs.append((v, 1))
    big = sum(1 for u, n in dirs if n >= 10)
    counts.append(big)
    if it > 100 and counts[-1] == counts[-60]:
        break

mx = max(n for u, n in dirs)
A1 = np.array([u for u, n in dirs if n >= 0.1 * mx])
np.save(OUT, A1)
print(A1.shape)
print(A1)
