"""Extract A1 (up to neuron permutation and row scaling) using only forward() queries.

Method: along random lines, the network output is piecewise linear; each kink
corresponds to a hidden neuron's hyperplane A1_i . x + b1_i = 0. At a kink the
gradient jumps by A2_i * A1_i, which is A1_i up to scale. We collect these jump
vectors, normalize, and deduplicate.
"""
import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi, flo, fhi, depth=0, out=None):
    """Recursively locate t values where f(x0 + t d) is non-linear."""
    if out is None:
        out = []
    mid = 0.5 * (lo + hi)
    fmid = f(x0 + mid * d)
    if abs(fmid - 0.5 * (flo + fhi)) < 1e-12 * max(1.0, abs(fmid)) and depth > 6:
        return out  # linear on this segment (assume)
    if hi - lo < 1e-6:
        out.append(mid)
        return out
    find_kinks(x0, d, lo, mid, flo, fmid, depth + 1, out)
    find_kinks(x0, d, mid, hi, fmid, fhi, depth + 1, out)
    return out


def refine(x0, d, t, w=1e-5):
    """Refine a kink location by intersecting the two linear pieces."""
    h = 1e-7
    tl, tr = t - w, t + w
    fl, fr = f(x0 + tl * d), f(x0 + tr * d)
    sl = (fl - f(x0 + (tl - h) * d)) / h
    sr = (f(x0 + (tr + h) * d) - fr) / h
    if abs(sl - sr) < 1e-12:
        return t
    tk = (fr - fl + sl * tl - sr * tr) / (sl - sr)
    if tl - w <= tk <= tr + w:
        return tk
    return t


def grad(x, h=1e-8):
    f0 = f(x)
    g = np.empty(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        g[j] = (f(x + e) - f0) / h
    return g


def main():
    rows = []
    n_lines = 200
    T = 20.0
    for _ in range(n_lines):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        flo, fhi = f(x0 - T * d), f(x0 + T * d)
        ts = find_kinks(x0, d, -T, T, flo, fhi)
        for t in ts:
            t = refine(x0, d, t)
            eps = 1e-6
            g1 = grad(x0 + (t - eps) * d)
            g2 = grad(x0 + (t + eps) * d)
            diff = g2 - g1
            n = np.linalg.norm(diff)
            if n < 1e-8:
                continue
            v = diff / n
            k = np.argmax(np.abs(v))
            v = v * np.sign(v[k])
            rows.append(v)

    # Deduplicate by direction (cluster).
    clusters = []
    for v in rows:
        for c in clusters:
            if abs(np.dot(c[0], v)) > 0.999:
                c.append(v * np.sign(np.dot(c[0], v)))
                break
        else:
            clusters.append([v])
    # Keep clusters that appear more than once (filters spurious detections).
    print("cluster sizes:", sorted(len(c) for c in clusters))
    med = np.median([len(c) for c in clusters])
    good = [np.median(np.array(c), axis=0) for c in clusters
            if len(c) >= max(2, 0.1 * med)]
    A = np.array([g / np.linalg.norm(g) for g in good])
    print(f"Recovered {A.shape[0]} neurons")
    np.set_printoptions(precision=5, suppress=True, linewidth=150)
    print(A)
    np.save(OUT, A)


if __name__ == "__main__":
    main()
