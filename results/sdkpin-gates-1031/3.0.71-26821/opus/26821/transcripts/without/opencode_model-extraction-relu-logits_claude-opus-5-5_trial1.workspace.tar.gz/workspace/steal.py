"""Extract A1 (up to neuron permutation and row scaling) from a 1-hidden-layer
ReLU network using only black-box queries to forward(x).

Method (critical-point / gradient-jump attack):
  1. Along random lines x0 + t*d, f is piecewise linear in t. Find kinks by
     recursively comparing the function against the linear extrapolations of
     its end slopes. Each kink is a point where one hidden neuron flips.
  2. At a kink x*, the gradient of f jumps by +-A2_i * A1_i. Compute exact
     finite-difference gradients just on either side of x*; their difference is
     row i of A1 up to scale.
  3. Normalize, sign-fix and cluster the recovered directions; each cluster is
     one neuron.
"""
import os
import numpy as np
from forward import forward

DIM = 10
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stolen_A1.npy")
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, lo, hi, tol=1e-9):
    g = lambda t: f(x0 + t * d)
    slope_h = 1e-7
    kinks = []

    def slope_right(t):
        return (g(t + slope_h) - g(t)) / slope_h

    def slope_left(t):
        return (g(t) - g(t - slope_h)) / slope_h

    def rec(a, b, fa, fb, depth):
        if b - a < 1e-6 or depth > 60:
            return
        sa, sb = slope_right(a), slope_left(b)
        scale = 1e-6 * (1 + abs(fa) + abs(fb))
        # No kink: one linear piece
        if abs(sa - sb) < tol * 10 + 1e-9 * (abs(sa) + abs(sb)):
            if abs(fa + sa * (b - a) - fb) < scale:
                return
        else:
            # Try single-kink hypothesis: intersect the two lines
            tc = (fb - fa + sa * a - sb * b) / (sa - sb)
            if a < tc < b:
                pred = fa + sa * (tc - a)
                if abs(g(tc) - pred) < scale:
                    # verify both sides are linear up to tc
                    m1 = (a + tc) / 2
                    m2 = (tc + b) / 2
                    if (abs(g(m1) - (fa + sa * (m1 - a))) < scale and
                            abs(g(m2) - (fb - sb * (b - m2))) < scale):
                        kinks.append(tc)
                        return
        m = (a + b) / 2
        fm = g(m)
        rec(a, m, fa, fm, depth + 1)
        rec(m, b, fm, fb, depth + 1)

    rec(lo, hi, g(lo), g(hi), 0)
    return kinks


def grad(x, h=1e-7):
    f0 = f(x)
    gr = np.zeros(DIM)
    for j in range(DIM):
        e = np.zeros(DIM)
        e[j] = h
        gr[j] = (f(x + e) - f0) / h
    return gr


def main():
    dirs = []
    n_lines = 60
    for _ in range(n_lines):
        x0 = rng.normal(size=DIM)
        d = rng.normal(size=DIM)
        d /= np.linalg.norm(d)
        for t in find_kinks(x0, d, -20.0, 20.0):
            xs = x0 + t * d
            eps = 1e-4
            g1 = grad(xs + eps * d)
            g2 = grad(xs - eps * d)
            diff = g1 - g2
            n = np.linalg.norm(diff)
            if n < 1e-8:
                continue
            v = diff / n
            v *= np.sign(v[np.argmax(np.abs(v))])
            dirs.append(v)

    # Cluster directions
    clusters = []  # list of [sum_vector, count]
    for v in dirs:
        for c in clusters:
            ref = c[0] / np.linalg.norm(c[0])
            if abs(ref @ v) > 0.999:
                c[0] += v * np.sign(ref @ v)
                c[1] += 1
                break
        else:
            clusters.append([v.copy(), 1])

    rows = [c[0] / np.linalg.norm(c[0]) for c in clusters if c[1] >= 2]
    A = np.array(rows)
    np.save(OUT, A)
    print(f"Recovered {A.shape[0]} neurons")
    print(A)
    return A


if __name__ == "__main__":
    main()
