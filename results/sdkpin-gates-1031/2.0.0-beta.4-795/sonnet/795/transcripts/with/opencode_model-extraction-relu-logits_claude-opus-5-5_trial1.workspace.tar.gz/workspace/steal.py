import numpy as np
from forward import forward

D = 10
rng = np.random.default_rng(1)
EPS = 1e-6


def grad(x):
    g = np.zeros(D)
    for i in range(D):
        e = np.zeros(D)
        e[i] = EPS
        g[i] = (forward(x + e) - forward(x - e)) / (2 * EPS)
    return g


def canon(v):
    v = v / np.linalg.norm(v)
    k = np.argmax(np.abs(v))
    return v if v[k] > 0 else -v


found = []


def add(v):
    if np.linalg.norm(v) < 1e-6:
        return
    c = canon(v)
    for i, (f, n) in enumerate(found):
        if np.linalg.norm(f - c) < 1e-3:
            found[i] = (f, n + 1)
            return
    found.append((c, 1))


R = 15.0
N = 3001
ts = np.linspace(-R, R, N)
h = ts[1] - ts[0]
for line in range(40):
    p = rng.normal(size=D)
    d = rng.normal(size=D)
    d /= np.linalg.norm(d)
    f = np.array([forward(p + t * d) for t in ts])
    s = np.diff(f) / h
    tol = 1e-7
    for k in range(2, N - 4):
        if abs(s[k - 1] - s[k - 2]) > tol or abs(s[k + 2] - s[k + 1]) > tol:
            continue
        if abs(s[k + 1] - s[k - 1]) < 1e-5:
            continue
        xl = p + (ts[k] - 0.5 * h) * d
        xr = p + (ts[k + 1] + 0.5 * h) * d
        gl, gr = grad(xl), grad(xr)
        add(gr - gl)

found.sort(key=lambda a: -a[1])
rows = [f for f, n in found if n >= 3]
A = np.array(rows)
np.save("/tmp/obench-cell-xvwc_k4b/bench_opencode_model-extraction-relu-logits_jnbmb6ph/stolen_A1.npy", A)
print(A.shape, [n for f, n in found])
