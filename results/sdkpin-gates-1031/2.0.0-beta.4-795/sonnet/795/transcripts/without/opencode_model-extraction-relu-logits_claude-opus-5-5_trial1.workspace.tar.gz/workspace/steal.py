import numpy as np
from forward import forward

D = 10
rng = np.random.default_rng(1)


def f(x):
    return forward(x)


def grad(x, h=2e-5):
    f0 = f(x)
    g = np.zeros(D)
    for i in range(D):
        e = np.zeros(D)
        e[i] = h
        g[i] = (f(x + e) - f0) / h
    return g


def find_kinks(p, d, R=8.0, n=800):
    ts = np.linspace(-R, R, n + 1)
    vals = np.array([f(p + t * d) for t in ts])
    kinks = []
    sec = vals[2:] - 2 * vals[1:-1] + vals[:-2]
    idx = np.where(np.abs(sec) > 1e-9)[0]
    visited = set()
    for i in idx:
        lo, hi = i, i + 2
        if any(abs(i - v) <= 1 for v in visited):
            continue
        visited.add(i)
        a, b = ts[lo], ts[hi]
        for _ in range(60):
            m1 = a + (b - a) / 3
            m2 = a + 2 * (b - a) / 3
            fa, fb = f(p + a * d), f(p + b * d)
            f1, f2 = f(p + m1 * d), f(p + m2 * d)
            l1 = fa + (fb - fa) / 3
            l2 = fa + 2 * (fb - fa) / 3
            if abs(f1 - l1) < 1e-13 and abs(f2 - l2) < 1e-13:
                break
            if abs(f1 - l1) > abs(f2 - l2) * 0 + 1e-13 and abs(f1 - l1) >= abs(f2 - l2):
                b = m2
            else:
                a = m1
            if b - a < 1e-9:
                break
        tk = 0.5 * (a + b)
        e = 3e-4
        tl, tr = tk - e, tk + e
        if tl < ts[0] or tr > ts[-1]:
            continue
        s = 5e-5
        fl0, fl1 = f(p + (tl - s) * d), f(p + tl * d)
        fr0, fr1 = f(p + tr * d), f(p + (tr + s) * d)
        sl = (fl1 - fl0) / s
        sr = (fr1 - fr0) / s
        if abs(sl - sr) < 1e-6:
            continue
        xk = p + tk * d
        gl = grad(xk - e * d)
        gr = grad(xk + e * d)
        jump = gr - gl
        if abs(jump @ d) < 1e-6:
            continue
        kinks.append((xk, jump))
    return kinks


allj = []
for _ in range(150):
    p = rng.normal(size=D) * 0.5
    d = rng.normal(size=D)
    d /= np.linalg.norm(d)
    for xk, j in find_kinks(p, d):
        allj.append(j)

units = []
for j in allj:
    n = np.linalg.norm(j)
    if n < 1e-6:
        continue
    u = j / n
    k = np.argmax(np.abs(u))
    if u[k] < 0:
        u = -u
        j = -j
    units.append((u, j))

clusters = []
for u, j in units:
    for c in clusters:
        if abs(c["u"] @ u) > 0.999:
            s = np.sign(c["u"] @ u)
            c["js"].append(s * j)
            c["n"] += 1
            break
    else:
        clusters.append({"u": u, "js": [j], "n": 1})

rows = []
mx = max(c["n"] for c in clusters)
for c in clusters:
    if c["n"] < 0.2 * mx:
        continue
    v = np.mean(c["js"], axis=0)
    rows.append(v / np.linalg.norm(v))
A1 = np.array(rows)
np.save("/tmp/obench-cell-pjr_32x6/bench_opencode_model-extraction-relu-logits_w99kkco5/stolen_A1.npy", A1)
print(A1)
