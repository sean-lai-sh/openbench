import os
import sys
import itertools
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from forward import forward

D = 10
rng = np.random.default_rng(12345)
N_QUERIES = [0]


def f(x):
    N_QUERIES[0] += 1
    return forward(np.asarray(x, dtype=np.float64))


def grad(x, h=1e-7):
    f0 = f(x)
    g = np.zeros(D)
    for j in range(D):
        e = np.zeros(D)
        e[j] = h
        g[j] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def find_kinks(x0, d, lo, hi):
    fl = lambda t: f(x0 + t * d)
    kinks = []
    stack = [(lo, hi, fl(lo), fl(hi))]
    while stack:
        a, b, fa, fb = stack.pop()
        m = 0.5 * (a + b)
        fm = fl(m)
        q1, q3 = a + 0.25 * (b - a), a + 0.75 * (b - a)
        f1, f3 = fl(q1), fl(q3)
        lin = lambda t: fa + (fb - fa) * (t - a) / (b - a)
        tol = 1e-12 + 1e-10 * max(abs(fa), abs(fb), 1.0)
        if abs(fm - lin(m)) < tol and abs(f1 - lin(q1)) < tol and abs(f3 - lin(q3)) < tol:
            continue
        if b - a < 1e-5:
            h = 1e-8
            sa = (fl(a + h) - fa) / h
            sb = (fb - fl(b - h)) / h
            if abs(sa - sb) > 1e-9:
                tk = (fb - fa + sa * a - sb * b) / (sa - sb)
                if a - 1e-6 <= tk <= b + 1e-6:
                    kinks.append(tk)
                    continue
            kinks.append(m)
            continue
        stack.append((a, m, fa, fm))
        stack.append((m, b, fm, fb))
    return sorted(kinks)


def merge_close(ts, tol=1e-6):
    out = []
    for t in ts:
        if out and abs(t - out[-1]) < tol:
            continue
        out.append(t)
    return out


def main():
    normals = []
    deltas = []
    points = []

    def known(n):
        for m in normals:
            if abs(abs(np.dot(m, n)) - 1) < 1e-4:
                return True
        return False

    stale = 0
    for it in range(200):
        x0 = rng.standard_normal(D)
        d = rng.standard_normal(D)
        d /= np.linalg.norm(d)
        ts = merge_close(find_kinks(x0, d, -20.0, 20.0))
        new = 0
        for t in ts:
            xs = x0 + t * d
            eps = 1e-4
            gp = grad(xs + eps * d)
            gm = grad(xs - eps * d)
            delta = gp - gm
            nrm = np.linalg.norm(delta)
            if nrm < 1e-8:
                continue
            n = delta / nrm
            if known(n):
                continue
            normals.append(n)
            deltas.append(delta)
            points.append(xs)
            new += 1
        stale = stale + 1 if new == 0 else 0
        if stale >= 15 and it >= 20:
            break

    normals = np.array(normals)
    deltas = np.array(deltas)
    k = len(normals)

    # Orient each delta so that "positive side" is where n.(x - x*) > 0.
    # delta currently = g(+d side) - g(-d side); with n = delta/|delta|,
    # we need the step side relative to n, recompute delta with respect to n.
    fixed = []
    for i in range(k):
        n, xs = normals[i], points[i]
        eps = 1e-4
        dl = grad(xs + eps * n) - grad(xs - eps * n)
        fixed.append(dl)
    deltas = np.array(fixed)

    # gradient(x) = sum_i delta_i * 1[pos_i(x)] - sum_{i in Neg} delta_i
    # Solve for the set Neg (neurons active on the negative side) to fix signs.
    signs = np.ones(k)
    try:
        cs = []
        for _ in range(3):
            x = rng.standard_normal(D)
            pos = np.array([np.dot(normals[i], x - points[i]) > 0 for i in range(k)])
            g = grad(x)
            cs.append(deltas[pos].sum(axis=0) - g)
        target = np.mean(cs, axis=0)
        if k <= 24:
            best, best_err = None, np.inf
            chunk_bits = min(k, 16)
            low = np.array(list(itertools.product([0, 1], repeat=chunk_bits)), dtype=np.float64)
            low_sums = low @ deltas[:chunk_bits]
            rest = k - chunk_bits
            for hi in itertools.product([0, 1], repeat=rest):
                hi = np.array(hi, dtype=np.float64)
                base = hi @ deltas[chunk_bits:] if rest else np.zeros(D)
                err = np.linalg.norm(low_sums + base - target, axis=1)
                j = np.argmin(err)
                if err[j] < best_err:
                    best_err = err[j]
                    best = np.concatenate([low[j], hi])
            if best_err < 1e-4 * max(1.0, np.linalg.norm(target)):
                signs = np.where(best > 0.5, -1.0, 1.0)
    except Exception:
        pass

    A1 = normals * signs[:, None]
    np.save(os.path.join(HERE, "stolen_A1.npy"), A1)
    print(f"Recovered {k} neurons using {N_QUERIES[0]} queries")
    print(A1)
    return A1


if __name__ == "__main__":
    main()
