import os
import numpy as np
from forward import forward

DIM = 10
HERE = os.path.dirname(os.path.abspath(__file__))
rng = np.random.default_rng(12345)


def f(x):
    return forward(np.asarray(x, dtype=np.float64))


def find_kinks(x0, d, a, b, fa, fb, out, depth=0):
    m = 0.5 * (a + b)
    fm = f(x0 + m * d)
    if abs(fm - 0.5 * (fa + fb)) < 1e-12 * (1 + abs(fa) + abs(fb)) and depth > 4:
        return
    if b - a < 1e-6:
        out.append(m)
        return
    find_kinks(x0, d, a, m, fa, fm, out, depth + 1)
    find_kinks(x0, d, m, b, fm, fb, out, depth + 1)


def refine_kink(x0, d, t, w=1e-5):
    e = w * 1e-2
    tl, tr = t - w, t + w
    sl = (f(x0 + tl * d) - f(x0 + (tl - e) * d)) / e
    sr = (f(x0 + (tr + e) * d) - f(x0 + tr * d)) / e
    if abs(sr - sl) < 1e-9:
        return None
    fl = f(x0 + tl * d)
    fr = f(x0 + tr * d)
    tk = (fr - fl + sl * tl - sr * tr) / (sl - sr)
    if not (tl <= tk <= tr):
        return t
    return tk


def gradient(x, h):
    g = np.zeros(DIM)
    for i in range(DIM):
        e = np.zeros(DIM)
        e[i] = h
        g[i] = (f(x + e) - f(x - e)) / (2 * h)
    return g


def normal_at_kink(xk, d):
    delta = 1e-4
    h = 1e-6
    gp = gradient(xk + delta * d, h)
    gm = gradient(xk - delta * d, h)
    v = gp - gm
    n = np.linalg.norm(v)
    if n < 1e-9:
        return None
    return v / n


def canon(v):
    i = np.argmax(np.abs(v))
    return v * np.sign(v[i])


rows = []
counts = []
stale = 0
for it in range(400):
    x0 = rng.normal(size=DIM) * 0.5
    d = rng.normal(size=DIM)
    d /= np.linalg.norm(d)
    T = 5.0
    ts = []
    find_kinks(x0, d, -T, T, f(x0 - T * d), f(x0 + T * d), ts)
    ts = sorted(ts)
    merged = []
    for t in ts:
        if not merged or t - merged[-1] > 1e-4:
            merged.append(t)
    new = 0
    for t in merged:
        tk = refine_kink(x0, d, t)
        if tk is None:
            continue
        v = normal_at_kink(x0 + tk * d, d)
        if v is None:
            continue
        v = canon(v)
        for k, r in enumerate(rows):
            if abs(np.dot(r, v)) > 0.9999:
                counts[k] += 1
                break
        else:
            rows.append(v)
            counts.append(1)
            new += 1
    stale = stale + 1 if new == 0 else 0
    if stale >= 30 and it >= 50:
        break

rows = [r for r, c in zip(rows, counts) if c >= 2]
A1_stolen = np.array(rows)
print(A1_stolen.shape)
print(A1_stolen)
np.save(os.path.join(HERE, "stolen_A1.npy"), A1_stolen)
